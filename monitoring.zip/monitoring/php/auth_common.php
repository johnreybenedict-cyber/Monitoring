<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/audit.php';

function csj_json_input(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '{}', true);
    return is_array($data) ? $data : [];
}

function csj_set_login_session(string $profileKey, ?string $studentName = null): void {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    session_regenerate_id(true);
    $_SESSION['student_profile_key'] = $profileKey;
    $_SESSION['student_authenticated'] = true;
    if ($studentName !== null) $_SESSION['student_name'] = $studentName;
    unset($_SESSION['instructor_name']);
    unset(
        $_SESSION['instructor_authenticated'],
        $_SESSION['instructor_key'],
        $_SESSION['dean_authenticated'],
        $_SESSION['dean_id'],
        $_SESSION['dean_name']
    );
}

function csj_is_authenticated(): bool {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    return !empty($_SESSION['student_authenticated']) && !empty($_SESSION['student_profile_key']);
}

function csj_current_account(PDO $pdo): ?array {
    if (!csj_is_authenticated()) return null;
    $key = (string)$_SESSION['student_profile_key'];
    $stmt = $pdo->prepare('SELECT * FROM student_accounts WHERE profile_key = ? LIMIT 1');
    $stmt->execute([$key]);
    return $stmt->fetch() ?: null;
}

function csj_require_account(PDO $pdo): array {
    $account = csj_current_account($pdo);
    if (!$account) {
        http_response_code(401);
        echo json_encode(['ok'=>false,'message'=>'Please log in first.']);
        exit;
    }
    return $account;
}

function csj_base_url(): string {
    // Behind ngrok the browser talks HTTPS to ngrok, but ngrok talks plain HTTP
    // to XAMPP -- so trust the forwarded headers when they are present.
    $fwdProto = strtolower(trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0]));
    $https = $fwdProto === 'https'
        || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ((int)($_SERVER['SERVER_PORT'] ?? 80) === 443);
    $scheme = $https ? 'https' : 'http';
    $fwdHost = trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_HOST'] ?? ''))[0]);
    $host = $fwdHost !== '' ? $fwdHost : ($_SERVER['HTTP_HOST'] ?? 'localhost');
    $folder = rtrim(str_replace('\\','/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return $scheme . '://' . $host . ($folder === '/' ? '' : $folder);
}

function csj_random_token(int $bytes = 32): string {
    return bin2hex(random_bytes($bytes));
}


/**
 * Ensure the plain password is not already used by any Student, Teacher, or Dean account.
 */
function csj_assert_password_unique(
    PDO $pdo,
    string $plainPassword,
    $excludeStudentAccountId = null,
    $excludeInstructorKey = null,
    $excludeDeanId = null
): void {
    if ($plainPassword === '') return;
    $tables = [
        ['sql' => "SELECT account_id AS id, password_hash FROM student_accounts WHERE password_hash IS NOT NULL AND password_hash <> ''",
         'exclude' => $excludeStudentAccountId],
        ['sql' => "SELECT instructor_key AS id, password_hash FROM instructor_profiles WHERE password_hash IS NOT NULL AND password_hash <> ''",
         'exclude' => $excludeInstructorKey],
        ['sql' => "SELECT dean_id AS id, password_hash FROM dean_accounts WHERE password_hash IS NOT NULL AND password_hash <> ''",
         'exclude' => $excludeDeanId],
    ];
    foreach ($tables as $t) {
        try {
            $st = $pdo->query($t['sql']);
            if (!$st) continue;
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                if ($t['exclude'] !== null && (string)$row['id'] === (string)$t['exclude']) continue;
                $hash = (string)($row['password_hash'] ?? '');
                if ($hash !== '' && password_verify($plainPassword, $hash)) {
                    throw new RuntimeException('That password is already in use. Please choose a different password.');
                }
            }
        } catch (RuntimeException $e) {
            throw $e;
        } catch (Throwable $e) {
        }
    }
}
