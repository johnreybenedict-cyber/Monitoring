<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
$profileKey = csj_student_profile_key();

// Remove profile picture (no file upload required)
if (isset($_POST['remove']) && (string)$_POST['remove'] === '1') {
    try {
        $pdo = csj_student_db();
        $st = $pdo->prepare('SELECT photo_path FROM student_profiles WHERE profile_key = ? LIMIT 1');
        $st->execute([$profileKey]);
        $oldPath = (string)($st->fetchColumn() ?: '');
        $instructorRoot = function_exists('csj_instructor_root') ? csj_instructor_root() : null;
        $sharedDir = $instructorRoot ? $instructorRoot . '/assets/uploads/students' : null;
        $localDir = __DIR__ . '/../assets/uploads/students';
        foreach ([$sharedDir, $localDir] as $dir) {
            if (!$dir || !is_dir($dir)) continue;
            foreach (glob($dir . '/' . $profileKey . '.*') as $old) {
                @unlink($old);
            }
        }
        // Also try deleting by stored path if it looks local
        if ($oldPath !== '' && strpos($oldPath, '..') === false) {
            $candidates = [
                __DIR__ . '/../' . ltrim($oldPath, '/'),
                ($instructorRoot ? $instructorRoot . '/' . ltrim($oldPath, '/') : null),
            ];
            foreach ($candidates as $c) {
                if ($c && is_file($c)) @unlink($c);
            }
        }
        $pdo->prepare('UPDATE student_profiles SET photo_path = NULL, updated_at = CURRENT_TIMESTAMP WHERE profile_key = ?')
            ->execute([$profileKey]);
        echo json_encode(['ok' => true, 'removed' => true, 'photoPath' => '']);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not remove the profile picture.']);
    }
    exit;
}

if (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'No photo received. Choose an image first.']);
    exit;
}
$file = $_FILES['photo'];
if ($file['size'] > 4 * 1024 * 1024) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Photo is too large (max 4 MB).']);
    exit;
}

$allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($file['tmp_name']);
if (!isset($allowed[$mime])) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Unsupported image type. Use JPG, PNG, WEBP or GIF.']);
    exit;
}
$ext = $allowed[$mime];

// Prefer the separate instructor app's upload folder so its existing
// View Self-Monitoring photo display continues to work without CSS changes.
$instructorRoot = csj_instructor_root();
$sharedDir = $instructorRoot ? $instructorRoot . '/assets/uploads/students' : null;
$localDir = __DIR__ . '/../assets/uploads/students';
$uploadDir = $sharedDir ?: $localDir;
if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);
if (!is_dir($uploadDir) || !is_writable($uploadDir)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'The student photo upload folder is not writable.']);
    exit;
}

foreach (glob($uploadDir . '/' . $profileKey . '.*') as $old) @unlink($old);
$filename = $profileKey . '.' . $ext;
$dest = $uploadDir . '/' . $filename;
if (!move_uploaded_file($file['tmp_name'], $dest)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not save the uploaded photo.']);
    exit;
}

// The instructor dashboard expects this path relative to its own project root.
$webPath = 'assets/uploads/students/' . $filename;
try {
    $pdo = csj_student_db();
    $stmt = $pdo->prepare(
        "INSERT INTO student_profiles (profile_key, student_name, course_year, photo_path)
         VALUES (?, '', '', ?)
         ON DUPLICATE KEY UPDATE photo_path = VALUES(photo_path), updated_at = CURRENT_TIMESTAMP"
    );
    $stmt->execute([$profileKey, $webPath]);
    $studentWebPath = $webPath;
    if ($instructorRoot) {
        $studentWebPath = '../' . basename($instructorRoot) . '/' . $webPath;
    }
    echo json_encode(['ok' => true, 'photoPath' => $studentWebPath . '?v=' . time()]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Photo was saved, but MySQL could not link it to the profile.']);
}
