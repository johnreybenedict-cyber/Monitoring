<?php
/**
 * Shared "new semester" popup (Dean / Instructor / Student).
 *
 * csj_semester_popup_render([
 *   'seconds'  => 10,                         // auto-close delay
 *   'show'     => ['title'=>..., 'headline'=>..., 'sub'=>...]   // optional: open immediately
 *   'reload'   => true,                       // reload the page when the popup closes
 *   'rightClickClose' => true,                // Student + Teacher: right-click (or long-press) closes it at once
 * ]);
 *
 * Always defines  window.csjShowSemesterPopup({title, headline, sub, seconds, onClose})
 * so JavaScript can open it later too (the Dean page does this right after the
 * final approval). It is a native modal <dialog>, so it is always centered on
 * screen with a dimmed backdrop, and it clears itself after `seconds` (a live
 * countdown is shown in the hint line). Default length = CSJ_WELCOME_POPUP_SECONDS in config.php.
 */
function csj_semester_popup_render(array $opts = []): void {
    $seconds = (int)($opts['seconds'] ?? (defined('CSJ_WELCOME_POPUP_SECONDS') ? CSJ_WELCOME_POPUP_SECONDS : 5));
    if ($seconds < 3) $seconds = 3;
    $show   = isset($opts['show']) && is_array($opts['show']) ? $opts['show'] : null;
    $reload = !empty($opts['reload']);
    $rightClick = !empty($opts['rightClickClose']);
    $cfg = json_encode(
        ['seconds' => $seconds, 'show' => $show, 'reload' => $reload, 'rightClick' => $rightClick],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
    );
    ?>
<style>
  dialog.csj-sem{
    position:fixed;inset:0;margin:auto;padding:0;border:0;border-radius:20px;
    width:min(480px,92vw);max-height:90vh;overflow:hidden;background:#fff;color:#1d271f;
    box-shadow:0 28px 70px rgba(10,40,22,.45);
    text-align:center;
  }
  dialog.csj-sem:not([open]){display:none}
  dialog.csj-sem::backdrop{background:rgba(8,30,18,.55);backdrop-filter:blur(2px)}
  dialog.csj-sem[open]{animation:csjSemIn .35s cubic-bezier(.2,.9,.3,1.2)}
  @keyframes csjSemIn{from{opacity:0;transform:translateY(14px) scale(.94)}to{opacity:1;transform:none}}
  .csj-sem-head{
    background:linear-gradient(135deg,#14522f,#1b6b3f);color:#fff;padding:22px 24px 18px;
    border-bottom:4px solid #e7b416;
  }
  .csj-sem-seal{
    width:64px;height:64px;border-radius:50%;object-fit:cover;background:#fff;
    border:3px solid #e7b416;box-shadow:0 4px 12px rgba(0,0,0,.25);margin:0 auto 10px;display:block;
  }
  .csj-sem-title{font-family:Georgia,'Times New Roman',serif;font-size:13px;letter-spacing:.18em;text-transform:uppercase;font-weight:700;color:#f6dc85;margin:0}
  .csj-sem-body{padding:26px 28px 8px}
  .csj-sem-headline{
    font-family:Georgia,'Times New Roman',serif;font-size:25px;line-height:1.3;font-weight:700;
    color:#14522f;margin:0;text-wrap:balance;
  }
  .csj-sem-sub{margin:14px 0 0;font-size:14px;line-height:1.55;color:#4b5a4f}
  .csj-sem-foot{padding:18px 28px 22px}
  .csj-sem-row{display:flex;justify-content:center;margin-top:4px}
  .csj-sem-ok{
    appearance:none;border:0;cursor:pointer;background:#14522f;color:#fff;font:600 14px/1 inherit;
    padding:10px 20px;border-radius:999px;
  }
  .csj-sem-ok:hover{background:#0f4325}
  .csj-sem-ok:focus-visible{outline:3px solid #e7b416;outline-offset:2px}
  @media (prefers-reduced-motion:reduce){dialog.csj-sem[open]{animation:none}}
  @media print{dialog.csj-sem{display:none!important}}
</style>

<dialog id="csjSemesterPopup" class="csj-sem" aria-labelledby="csjSemHeadline" aria-live="polite">
  <div class="csj-sem-head">
    <img class="csj-sem-seal" src="assets/logos/csj-seal.jpg" alt="" onerror="this.style.display='none'">
    <p class="csj-sem-title" id="csjSemTitle">New Semester</p>
  </div>
  <div class="csj-sem-body">
    <h2 class="csj-sem-headline" id="csjSemHeadline"></h2>
    <p class="csj-sem-sub" id="csjSemSub"></p>
  </div>
  <div class="csj-sem-foot" style="padding:12px 28px 18px;">
    <p class="csj-sem-auto" id="csjSemAutoHint" style="display:none;margin:0;"></p>
  </div>
</dialog>

<script>
(function () {
  var CFG = <?= $cfg ?>;
  var CSJ_POPUP_SECONDS = CFG.seconds;           // how long the popup stays (seconds)
  var dlg = document.getElementById('csjSemesterPopup');
  var timer = null, onCloseCb = null;
  if (!dlg) return;

  function el(id) { return document.getElementById(id); }

  var hint = null;

  function finish() {
    if (timer) { clearInterval(timer); timer = null; }
    if (dlg.open) { try { dlg.close(); } catch (e) { dlg.removeAttribute('open'); } }
    var cb = onCloseCb; onCloseCb = null;
    if (typeof cb === 'function') { try { cb(); } catch (e) {} }
  }

  // Countdown text removed — dialog still auto-closes after `seconds`.
  function paintHint(left) { /* no visible countdown */ }

  window.csjShowSemesterPopup = function (o) {
    o = o || {};
    var seconds = Math.max(3, Number(o.seconds) || CSJ_POPUP_SECONDS);
    el('csjSemTitle').textContent    = o.title    || 'New Semester';
    el('csjSemHeadline').textContent = o.headline || '';
    el('csjSemSub').textContent      = o.sub      || '';
    el('csjSemSub').style.display    = o.sub ? '' : 'none';
    onCloseCb = typeof o.onClose === 'function' ? o.onClose : null;

    if (timer) clearInterval(timer);
    var started = Date.now(), total = seconds * 1000;
    paintHint(seconds);
    timer = setInterval(function () {
      var elapsed = Date.now() - started;
      if (elapsed >= total) { finish(); return; }          // clears itself after `seconds`
      paintHint(Math.max(1, Math.ceil((total - elapsed) / 1000)));
    }, 250);

    if (!dlg.open) {
      if (typeof dlg.showModal === 'function') dlg.showModal();   // centered modal
      else dlg.setAttribute('open', '');                          // CSS still centers it
    }
    /* no Got it button */
  };

  // Close on left-click or right-click anywhere on the dialog (and Esc).
  dlg.addEventListener('click', function (e) {
    // only close when the click is on the dialog surface (not forced on every child if needed — whole dialog is fine)
    finish();
  });
  dlg.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    finish();
  });
  dlg.addEventListener('cancel', function (e) { e.preventDefault(); finish(); });
   // Esc key
  if (CFG.rightClick) {
    dlg.addEventListener('contextmenu', function (e) {
      e.preventDefault();          // no browser menu on top of the popup
      if (dlg.open) finish();      // right-click anywhere (also on the dimmed backdrop) closes it
    });
  }

  if (CFG.show) {
    var s = CFG.show;
    if (CFG.reload) s.onClose = function () { location.reload(); };
    var go = function () { window.csjShowSemesterPopup(s); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
  }
})();
</script>
<?php
}
