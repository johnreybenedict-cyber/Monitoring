<?php
header('Content-Type: application/json; charset=utf-8');
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/audit.php';

function dean_approval_response(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

/**
 * When every student who submitted a chart has all 3 periods approved:
 * - Keep historical Archive (dean_archived_periods)
 * - Snapshot remaining live charts into Archive
 * - Clear live TblPrelim / TblMidTerm / TblFinal + submissions + instructor subjects
 * - Advance semester and raise student/instructor welcome flags
 */
function csj_try_new_semester_transition(PDO $pdo, string $deanName): array {
    if (function_exists('csj_ensure_system_flags')) {
        csj_ensure_system_flags($pdo);
    } else {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS system_flags (
                flag_key VARCHAR(64) NOT NULL PRIMARY KEY,
                flag_value TEXT,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
    }
    if (function_exists('csj_ensure_archive_tables')) {
        csj_ensure_archive_tables($pdo);
    }

    // Source of truth = the stored charts themselves: the semester only changes when EVERY
    // student who has a monitoring sheet has all three periods (Prelims, Midterms, Finals)
    // approved by the Dean. (Students who never submitted anything are not waited for.)
    $latest = [];
    $rows = $pdo->query(
        'SELECT profile_key, chart_json FROM monitoring_submissions ORDER BY updated_at DESC'
    )->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) {
        $pk = (string)$r['profile_key'];
        if (!isset($latest[$pk])) $latest[$pk] = (string)$r['chart_json'];
    }
    $submitted = count($latest);
    if ($submitted < 1) {
        return ['transitioned' => false, 'reason' => 'no_submissions'];
    }
    $pending = 0;
    foreach ($latest as $json) {
        $chart = json_decode($json, true);
        $periods = is_array($chart) ? csj_normalize_periods($chart) : [];
        foreach (['prelims', 'midterms', 'finals'] as $pk) {
            if (empty($periods[$pk]['deanApproved'])) { $pending++; break; }
        }
    }
    if ($pending > 0) {
        return ['transitioned' => false, 'reason' => 'not_all_approved', 'submitted' => $submitted, 'pending' => $pending];
    }

    $oldSemester = function_exists('csj_get_current_semester')
        ? csj_get_current_semester($pdo)
        : 'First Semester, AY 2026-2027';
    $newSemester = function_exists('csj_advance_semester')
        ? csj_advance_semester($oldSemester)
        : 'Second Semester, AY 2026-2027';

    // Same code path as the Dean's manual Semester / AY change (see config.php).
    return csj_apply_semester_transition($pdo, $deanName, $oldSemester, $newSemester, 'automatic');
}

if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    dean_approval_response(['ok' => false, 'message' => 'Dean login is required.'], 401);
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    dean_approval_response(['ok' => false, 'message' => 'POST is required.'], 405);
}

$payload = json_decode(file_get_contents('php://input') ?: '{}', true);
$payload = is_array($payload) ? $payload : [];
$selectionId = filter_var($payload['selectionId'] ?? null, FILTER_VALIDATE_INT);
$profileKey = strtolower(trim((string)($payload['profileKey'] ?? '')));
$periodKey = strtolower(trim((string)($payload['period'] ?? '')));
$decisionValue = $payload['decision'] ?? '';
$decision = is_string($decisionValue) ? strtolower(trim($decisionValue)) : '';
if ($decision === '' && is_bool($payload['approve'] ?? null)) {
    $decision = $payload['approve'] ? 'approved' : 'pending';
}

if (!preg_match('/^[a-f0-9]{32}$/', $profileKey)) {
    dean_approval_response(['ok' => false, 'message' => 'A valid student profile is required.'], 422);
}
$scope = strtolower(trim((string)($payload['scope'] ?? 'subject')));
if (!in_array($scope, ['subject', 'period'], true)) {
    $scope = 'subject';
}
if (!in_array($periodKey, ['prelims', 'midterms', 'finals'], true)
    || !in_array($decision, ['approved', 'denied', 'pending'], true)) {
    dean_approval_response(['ok' => false, 'message' => 'Choose a valid monitoring period and approval state.'], 422);
}

function dean_approval_norm_code(string $code): string {
    return strtolower(preg_replace('/[^a-z0-9]/i', '', trim($code)) ?? '');
}

try {
    $pdo = csj_student_db();
    $payloadSemester = trim((string)($payload['semester'] ?? ''));
    $selection = null;
    if ($selectionId && $selectionId > 0) {
        $selectionStmt = $pdo->prepare(
            'SELECT subject_code, semester
             FROM instructor_subject_selections
             WHERE selection_id = ? LIMIT 1'
        );
        $selectionStmt->execute([$selectionId]);
        $selection = $selectionStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if (!$selection) {
        $selection = [
            'subject_code' => '',
            'semester' => $payloadSemester,
        ];
    }

    $pdo->beginTransaction();
    // Prefer given/selection semester, else latest submission for this student
    $submission = null;
    $semTry = trim((string)($selection['semester'] ?? ''));
    if ($semTry !== '') {
        $submissionStmt = $pdo->prepare(
            'SELECT chart_json, student_name, semester FROM monitoring_submissions
             WHERE profile_key = ? AND semester = ? LIMIT 1 FOR UPDATE'
        );
        $submissionStmt->execute([$profileKey, $semTry]);
        $submission = $submissionStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if (!$submission) {
        $submissionStmt = $pdo->prepare(
            'SELECT chart_json, student_name, semester FROM monitoring_submissions
             WHERE profile_key = ? ORDER BY updated_at DESC LIMIT 1 FOR UPDATE'
        );
        $submissionStmt->execute([$profileKey]);
        $submission = $submissionStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if (!$submission) {
        $pdo->rollBack();
        dean_approval_response(['ok' => false, 'message' => 'The student has no submitted chart. Ask them to click Submit.'], 404);
    }
    $chartJson = $submission['chart_json'];
    // Keep approval written against the actual stored semester row
    $selection['semester'] = (string)($submission['semester'] ?? $selection['semester']);

    $chart = json_decode((string)$chartJson, true);
    if (!is_array($chart)) {
        $pdo->rollBack();
        dean_approval_response(['ok' => false, 'message' => 'The student chart data is invalid.'], 500);
    }

    $periods = csj_normalize_periods($chart);
    $deanName = (string)($_SESSION['dean_name'] ?? 'Dean');
    $reviewedAt = date('Y-m-d H:i:s');

    if ($scope === 'period') {
        // Periods must be approved in order (Prelims -> Midterms -> Finals) and,
        // for the same reason, cannot be un-approved while a LATER period is approved.
        $order = ['prelims', 'midterms', 'finals'];
        $labels = ['prelims' => 'Prelims', 'midterms' => 'Midterms', 'finals' => 'Finals'];
        $pos = array_search($periodKey, $order, true);
        if ($decision === 'approved' && $pos > 0) {
            $before = $order[$pos - 1];
            if (empty($periods[$before]['deanApproved'])) {
                $pdo->rollBack();
                dean_approval_response(['ok' => false, 'message' => 'Approve the ' . $labels[$before] . ' first. The student can only continue to the ' . $labels[$periodKey] . ' after the ' . $labels[$before] . ' is approved.'], 409);
            }
        }
        if ($decision !== 'approved') {
            for ($i = $pos + 1; $i < count($order); $i++) {
                if (!empty($periods[$order[$i]]['deanApproved'])) {
                    $pdo->rollBack();
                    dean_approval_response(['ok' => false, 'message' => 'Clear the ' . $labels[$order[$i]] . ' approval first, then you can clear the ' . $labels[$periodKey] . '.'], 409);
                }
            }
        }
        // Period-level Dean approval (shown as "The Dean: Approve" on student chart)
        if ($decision === 'approved') {
            $periods[$periodKey]['deanApproved'] = true;
            $periods[$periodKey]['deanApprovedBy'] = $deanName;
            $periods[$periodKey]['deanApprovedAt'] = $reviewedAt;
        } else {
            $periods[$periodKey]['deanApproved'] = false;
            unset($periods[$periodKey]['deanApprovedBy'], $periods[$periodKey]['deanApprovedAt']);
        }
    } else {
        // Legacy per-subject path (kept for compatibility; UI no longer exposes Deny/Approve chips)
        $needle = dean_approval_norm_code((string)$selection['subject_code']);
        $matchedIndex = null;
        foreach ($periods[$periodKey]['subjects'] as $index => $subject) {
            if (dean_approval_norm_code((string)($subject['code'] ?? '')) === $needle && $needle !== '') {
                $matchedIndex = $index;
                break;
            }
        }
        if ($matchedIndex === null) {
            $pdo->rollBack();
            dean_approval_response(['ok' => false, 'message' => 'This subject is not on the student’s selected monitoring period.'], 404);
        }

        $periods[$periodKey]['subjects'][$matchedIndex]['approved'] = $decision === 'approved';
        $periods[$periodKey]['subjects'][$matchedIndex]['reviewStatus'] = $decision;
        $periods[$periodKey]['subjects'][$matchedIndex]['instructor'] = $decision === 'approved'
            ? 'Dean: ' . $deanName
            : '';
        if ($decision !== 'pending') {
            $periods[$periodKey]['subjects'][$matchedIndex]['reviewedBy'] = $deanName;
            $periods[$periodKey]['subjects'][$matchedIndex]['reviewedAt'] = $reviewedAt;
        } else {
            unset(
                $periods[$periodKey]['subjects'][$matchedIndex]['reviewedBy'],
                $periods[$periodKey]['subjects'][$matchedIndex]['reviewedAt']
            );
        }
        if ($decision === 'approved') {
            $periods[$periodKey]['subjects'][$matchedIndex]['approvedAt'] = $reviewedAt;
        } else {
            unset($periods[$periodKey]['subjects'][$matchedIndex]['approvedAt']);
        }
    }

    $chart['periods'] = $periods;
    unset($chart['prelims'], $chart['midterms'], $chart['finals']);

    $updatedJson = json_encode($chart, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($updatedJson === false) {
        throw new RuntimeException('Could not encode the updated student chart.');
    }
    $updateStmt = $pdo->prepare(
        'UPDATE monitoring_submissions
         SET chart_json = ?, updated_at = CURRENT_TIMESTAMP
         WHERE profile_key = ? AND semester = ?'
    );
    $updateStmt->execute([$updatedJson, $profileKey, $selection['semester']]);
    csj_audit_log(
        $pdo,
        $decision === 'approved'
            ? 'dean_approval'
            : ($decision === 'denied' ? 'dean_denial' : 'dean_approval_removed'),
        'student',
        $profileKey,
        (string)$submission['student_name'],
        [
            'subject_code' => (string)$selection['subject_code'],
            'semester' => (string)$selection['semester'],
            'period' => $periodKey,
            'decision' => $decision,
            'scope' => $scope,
        ],
        'dean',
        (string)$_SESSION['dean_id'],
        $deanName
    );
    $pdo->commit();

    $csjTransition = ['transitioned' => false];

    // Archive this period snapshot (history is kept across semesters)
    if ($decision === 'approved' && $scope === 'period') {
        try {
            csj_ensure_archive_tables($pdo);
            $nameRow = $pdo->prepare(
                'SELECT student_name, course_year, student_id FROM student_profiles WHERE profile_key = ? LIMIT 1'
            );
            $nameRow->execute([$profileKey]);
            $nr = $nameRow->fetch(PDO::FETCH_ASSOC) ?: [];
            $periodSnapshot = $periods[$periodKey] ?? [];
            $arch = $pdo->prepare(
                'INSERT INTO dean_archived_periods
                    (profile_key, period_key, student_name, course_year, semester, chart_period_json, archived_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                    student_name = VALUES(student_name),
                    course_year = VALUES(course_year),
                    chart_period_json = VALUES(chart_period_json),
                    archived_at = CURRENT_TIMESTAMP,
                    archived_by = VALUES(archived_by)'
            );
            $arch->execute([
                $profileKey,
                $periodKey,
                (string)($nr['student_name'] ?? $submission['student_name'] ?? ''),
                (string)($nr['course_year'] ?? ''),
                (string)($selection['semester'] ?? $submission['semester'] ?? ''),
                json_encode($periodSnapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $deanName,
            ]);

            // If all 3 periods are Dean-approved, mark student fully done this semester
            $allApproved = true;
            foreach (['prelims', 'midterms', 'finals'] as $pkCheck) {
                if (empty($periods[$pkCheck]['deanApproved'])) {
                    $allApproved = false;
                    break;
                }
            }
            if ($allApproved) {
                $pdo->prepare(
                    'INSERT INTO dean_archived_students
                        (profile_key, student_name, course_year, student_id, semester, archived_by)
                     VALUES (?, ?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE
                        student_name = VALUES(student_name),
                        course_year = VALUES(course_year),
                        student_id = VALUES(student_id),
                        semester = VALUES(semester),
                        archived_at = CURRENT_TIMESTAMP,
                        archived_by = VALUES(archived_by)'
                )->execute([
                    $profileKey,
                    (string)($nr['student_name'] ?? $submission['student_name'] ?? ''),
                    (string)($nr['course_year'] ?? ''),
                    (string)($nr['student_id'] ?? ''),
                    (string)($selection['semester'] ?? $submission['semester'] ?? ''),
                    $deanName,
                ]);
            }
        } catch (Throwable $archiveErr) {
            // Approval already committed; the archive snapshot is best-effort history.
            error_log('Dean approval archive failed: ' . $archiveErr->getMessage());
        }

        // Finals approved -> check whether EVERY student is now fully approved.
        // Runs on its own so an archive hiccup can never block the new semester.
        if (!empty($periods['finals']['deanApproved'])) {
            try {
                $csjTransition = csj_try_new_semester_transition($pdo, $deanName);
            } catch (Throwable $trErr) {
                error_log('Semester transition failed: ' . $trErr->getMessage());
                $csjTransition = ['transitioned' => false, 'error' => true];
            }
        }
    }

    // Recover: remove from "fully done" list if Dean clears an approval
    if ($decision === 'pending' && $scope === 'period') {
        try {
            $pdo->prepare('DELETE FROM dean_archived_students WHERE profile_key = ?')->execute([$profileKey]);
            // Only remove THIS semester's snapshot. Without the semester filter, un-approving a
            // period in the new semester wiped that student's archive from every past semester.
            $pdo->prepare(
                'DELETE FROM dean_archived_periods WHERE profile_key = ? AND period_key = ? AND semester = ?'
            )->execute([$profileKey, $periodKey, (string)($selection['semester'] ?? $submission['semester'] ?? '')]);
        } catch (Throwable $e) { /* ignore */ }
    }

    $transitioned = !empty($csjTransition['transitioned']);
    if ($transitioned) {
        csj_welcome_mark_seen($pdo, 'dean', (string)$_SESSION['dean_id'], (string)$csjTransition['transitionId']);
    }
    dean_approval_response([
        'ok' => true,
        'approved' => $decision === 'approved',
        'status' => $decision,
        'deanName' => $deanName,
        'scope' => $scope,
        'complete' => !empty($periods['finals']['deanApproved']),
        'semesterTransition' => $transitioned,
        'newSemester' => $csjTransition['to'] ?? null,
        'previousSemester' => $csjTransition['from'] ?? null,
        'transitionId' => $csjTransition['transitionId'] ?? null,
        'clearedStudents' => $csjTransition['cleared'] ?? 0,
        'message' => $transitioned
            ? ('All students approved. New semester started: ' . ($csjTransition['to'] ?? ''))
            : ($scope === 'period'
                ? ($decision === 'approved' ? 'Period approved by Dean.' : 'Dean period approval cleared.')
                : ($decision === 'approved'
                    ? 'Subject approved for this period.'
                    : ($decision === 'denied' ? 'Subject denied for this period.' : 'Review decision cleared for this period.'))),
    ]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    error_log('Dean approval update failed: ' . $e->getMessage());
    dean_approval_response(['ok' => false, 'message' => 'Approval could not be saved. Please check the database connection and try again.'], 500);
}

