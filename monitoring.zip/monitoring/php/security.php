<?php
/**
 * DIGIMON - security helpers (anti SQL injection + login hardening).
 *
 * Layers of protection (defence in depth):
 *   1. Every query in the project uses PDO PREPARED STATEMENTS - user input is sent
 *      to MySQL as DATA, never glued into the SQL text.
 *   2. Whitelist validation: IDs may only contain letters, digits . _ -  (no quotes,
 *      spaces, semicolons, @ ...), so an injection payload cannot even reach the query.
 *   3. csj_looks_like_sqli() rejects text that carries classic injection patterns
 *      (UNION SELECT, ' OR 1=1, --, /* *\/, SLEEP(), ; DROP ...) before it is used.
 *   4. The PDO connection refuses stacked queries (MYSQL_ATTR_MULTI_STATEMENTS = false).
 *   5. Failed-login throttling slows down password guessing / injection probing.
 *   6. Session cookies are HttpOnly + SameSite (+ Secure automatically behind ngrok HTTPS).
 */

if (!function_exists('csj_is_https')) {

/** True when the visitor is on HTTPS (direct, or through ngrok's X-Forwarded-Proto). */
function csj_is_https(): bool {
    $fwd = strtolower(trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0]));
    return $fwd === 'https'
        || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ((int)($_SERVER['SERVER_PORT'] ?? 80) === 443);
}

/** Harden the session cookie. Must run BEFORE session_start(); silently does nothing otherwise. */
function csj_harden_session(): void {
    if (PHP_SAPI === 'cli' || session_status() !== PHP_SESSION_NONE || headers_sent()) return;
    @ini_set('session.use_strict_mode', '1');
    @ini_set('session.use_only_cookies', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => csj_is_https(),   // true on the ngrok https:// address, false on http://localhost
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

/** Real client IP (ngrok puts the visitor's address in X-Forwarded-For). */
function csj_client_ip(): string {
    $fwd = trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''))[0]);
    $ip  = $fwd !== '' ? $fwd : (string)($_SERVER['REMOTE_ADDR'] ?? '');
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'unknown';
}

/** Remove NUL / control characters and cap the length. */
function csj_clean_text(string $value, int $max = 255): string {
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value) ?? '';
    $value = trim($value);
    return mb_substr($value, 0, $max);
}

/**
 * Heuristic detector for SQL-injection payloads. Used as an EXTRA layer on top of prepared
 * statements. It looks for SQL *syntax*, so ordinary names like "O'Brien" or "Dela Cruz,
 * Juan Santos" are never flagged.
 */
function csj_looks_like_sqli(string $value): bool {
    if ($value === '') return false;
    $v = strtolower(rawurldecode($value));
    $patterns = [
        '/\bunion\b[\s\/\*\(]+(all\b[\s\/\*]+)?select\b/',          // UNION SELECT
        '/\bselect\b[\s\S]{0,80}\bfrom\b/',                          // SELECT ... FROM
        '/(\'|"|`|\)|\b\d+\b)\s*(or|and|xor)\s*(\(|\'|"|`|\d|true\b|false\b|not\b|null\b)/', // ' OR 1=1 / ) AND (1
        '/\b(or|and)\b\s+[\'"`]?\w+[\'"`]?\s*(=|<|>|like\b)\s*[\'"`]?\w+/', // OR 'a'='a'
        '/;\s*(drop|delete|insert|update|alter|create|truncate|exec|shutdown|grant|replace)\b/', // stacked queries
        '/\b(drop|truncate)\s+(table|database|schema)\b/',
        '/\b(insert\s+into|delete\s+from|update\s+\w+\s+set)\b/',
        '/\b(sleep|benchmark|pg_sleep|waitfor\s+delay|load_file|extractvalue|updatexml)\s*\(/',
        '/\binto\s+(out|dump)file\b/',
        '/\binformation_schema\b|\bmysql\.user\b|\bsys\.\w+/',
        '/(--|#)\s*$|--\s|\/\*|\*\//',                               // SQL comments
        '/\b(char|chr|concat|group_concat|hex|unhex|ascii|substring|substr)\s*\(\s*\d*[^)]{0,60}\)\s*(,|\)|=)/', // obfuscation helpers
        '/0x[0-9a-f]{6,}/',                                          // hex-encoded payloads
        '/\bexec(ute)?\s*(\(|\s+xp_)/',
    ];
    foreach ($patterns as $p) {
        if (preg_match($p, $v)) return true;
    }
    return false;
}

/** Student ID / Teacher ID / Dean username: letters, digits, dot, underscore, hyphen only. */
function csj_clean_identity(string $raw): string {
    $id = trim($raw);
    if ($id === '') return '';
    if (!preg_match('/^[A-Za-z0-9._\-]{1,64}$/', $id) || csj_looks_like_sqli($id)) {
        throw new RuntimeException('Invalid ID format. Use your Student ID or Teacher ID only.');
    }
    return $id;
}

/** Full name, e.g. "Dela Cruz, Juan Santos Jr." Letters (any language), spaces , . ' - only. */
function csj_clean_person_name(string $raw): string {
    $name = csj_clean_text($raw, 150);
    $name = preg_replace('/\s+/u', ' ', $name) ?? '';
    if ($name === '') return '';
    if (!preg_match('/^[\p{L}\p{M}][\p{L}\p{M}\s,.\'’\-]*$/u', $name) || csj_looks_like_sqli($name)) {
        throw new RuntimeException('Full Name may contain only letters, spaces, commas, periods, hyphens and apostrophes. Format: Last Name, First Name, Middle Name');
    }
    return $name;
}

/** Free text such as department / course: control chars removed + injection check. */
function csj_clean_plain_field(string $raw, int $max = 150): string {
    $v = csj_clean_text($raw, $max);
    if ($v !== '' && csj_looks_like_sqli($v)) {
        throw new RuntimeException('That value contains characters that are not allowed.');
    }
    return $v;
}

/* ------------------------------------------------------------------ */
/* Failed-login throttling (per IP + ID). Auto-creates its own table.  */
/* ------------------------------------------------------------------ */
if (!defined('CSJ_LOGIN_MAX_FAILS'))   define('CSJ_LOGIN_MAX_FAILS', 10);     // failed attempts allowed ...
if (!defined('CSJ_LOGIN_WINDOW_SECS')) define('CSJ_LOGIN_WINDOW_SECS', 600);  // ... within this many seconds (10 minutes)

function csj_ensure_login_attempts(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS login_attempts (
            attempt_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            ip_address VARCHAR(64) NOT NULL,
            identity   VARCHAR(80) NOT NULL,
            attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_ip_identity (ip_address, identity, attempted_at)
         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}

/** Throws when this IP + ID already failed too many times recently. */
function csj_login_throttle_check(PDO $pdo, string $identity): void {
    try {
        csj_ensure_login_attempts($pdo);
        $st = $pdo->prepare(
            'SELECT COUNT(*) AS fails, MIN(attempted_at) AS first_at
               FROM login_attempts
              WHERE ip_address = ? AND identity = ?
                AND attempted_at > (NOW() - INTERVAL ' . (int)CSJ_LOGIN_WINDOW_SECS . ' SECOND)'
        );
        $st->execute([csj_client_ip(), mb_substr(strtolower($identity), 0, 80)]);
        $row = $st->fetch();
        if ($row && (int)$row['fails'] >= CSJ_LOGIN_MAX_FAILS) {
            $wait = max(1, (int)ceil(CSJ_LOGIN_WINDOW_SECS / 60));
            throw new RuntimeException('Too many failed log-in attempts. Please wait about ' . $wait . ' minutes and try again.');
        }
    } catch (PDOException $e) {
        error_log('csj_login_throttle_check: ' . $e->getMessage());   // never block login because of a logging problem
    }
}

function csj_login_throttle_fail(PDO $pdo, string $identity): void {
    try {
        csj_ensure_login_attempts($pdo);
        $pdo->prepare('INSERT INTO login_attempts (ip_address, identity) VALUES (?, ?)')
            ->execute([csj_client_ip(), mb_substr(strtolower($identity), 0, 80)]);
        // housekeeping: forget entries older than a day
        $pdo->exec('DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 1 DAY)');
    } catch (PDOException $e) {
        error_log('csj_login_throttle_fail: ' . $e->getMessage());
    }
}

function csj_login_throttle_clear(PDO $pdo, string $identity): void {
    try {
        $pdo->prepare('DELETE FROM login_attempts WHERE ip_address = ? AND identity = ?')
            ->execute([csj_client_ip(), mb_substr(strtolower($identity), 0, 80)]);
    } catch (PDOException $e) { /* ignore */ }
}

}
