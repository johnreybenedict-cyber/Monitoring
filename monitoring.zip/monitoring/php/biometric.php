<?php
ini_set('display_errors','0');
ini_set('log_errors','1');
ob_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/audit.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function b64e(string $d): string { return rtrim(strtr(base64_encode($d), '+/', '-_'), '='); }
function b64d(string $d): string { $d=strtr($d,'-_','+/'); while(strlen($d)%4)$d.='='; $v=base64_decode($d,true); if($v===false)throw new RuntimeException('Invalid Base64URL.'); return $v; }
function bin_input(): array { $d=json_decode(file_get_contents('php://input')?:'{}',true); return is_array($d)?$d:[]; }
function origin(): string {
    $forwarded = strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')));
    $https=($forwarded==='https') || (!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||((int)($_SERVER['SERVER_PORT']??80)===443);
    $host=(string)($_SERVER['HTTP_X_FORWARDED_HOST'] ?? ($_SERVER['HTTP_HOST'] ?? 'localhost'));
    return ($https?'https':'http').'://'.$host;
}
function normalize_origin(string $v): string {
    $v=trim($v);
    $parts=parse_url($v);
    if(!$parts || empty($parts['scheme']) || empty($parts['host'])) return '';
    // WebAuthn RP IDs do not contain ports. For local XAMPP use, allow the
    // same hostname on a different Apache port (e.g. :80 vs :8080).
    return strtolower($parts['scheme']).'://'.strtolower($parts['host']);
}
function rp(): string {
    $host=(string)($_SERVER['HTTP_X_FORWARDED_HOST'] ?? ($_SERVER['HTTP_HOST']??'localhost'));
    return preg_replace('/:\d+$/','',$host) ?: 'localhost';
}

/* Minimal CBOR decoder for WebAuthn attestation/authenticator data. */
function cbor_len(string $d,int &$i,int $add): int { if($add<24)return $add; if($add===24){return ord($d[$i++]);} if($add===25){$v=unpack('n',substr($d,$i,2))[1];$i+=2;return $v;} if($add===26){$v=unpack('N',substr($d,$i,4))[1];$i+=4;return $v;} if($add===27){$p=substr($d,$i,8);$i+=8;$a=unpack('N2',$p);return $a[1]*4294967296+$a[2];} throw new RuntimeException('Unsupported CBOR length.'); }
function cbor_read(string $d,int &$i){ $b=ord($d[$i++]);$major=$b>>5;$add=$b&31;if($add===31)throw new RuntimeException('Indefinite CBOR is not supported.'); if($major===0)return cbor_len($d,$i,$add); if($major===1)return -1-cbor_len($d,$i,$add); if($major===2){$n=cbor_len($d,$i,$add);$v=substr($d,$i,$n);$i+=$n;return $v;} if($major===3){$n=cbor_len($d,$i,$add);$v=substr($d,$i,$n);$i+=$n;return $v;} if($major===4){$n=cbor_len($d,$i,$add);$a=[];for($x=0;$x<$n;$x++)$a[]=cbor_read($d,$i);return $a;} if($major===5){$n=cbor_len($d,$i,$add);$m=[];for($x=0;$x<$n;$x++){ $k=cbor_read($d,$i);$m[(string)$k]=cbor_read($d,$i);}return $m;} if($major===7){if($add===20)return false;if($add===21)return true;if($add===22)return null;if($add===23)return null;} throw new RuntimeException('Unsupported CBOR value.'); }
function der_len(int $n): string { if($n<128)return chr($n);$b='';while($n>0){$b=chr($n&255).$b;$n>>=8;}return chr(0x80|strlen($b)).$b; }
function der_tlv(int $tag,string $v): string{return chr($tag).der_len(strlen($v)).$v;}
function der_int(string $v): string {$v=ltrim($v,"\0");if($v==='' )$v="\0";if((ord($v[0])&128)!==0)$v="\0".$v;return der_tlv(2,$v);}
function cose_public_key_pem(array $k): string {
    $kty=(int)($k['1']??0); $alg=(int)($k['3']??0);
    if($kty===2 && $alg===-7){
        $x=$k['-2']??'';$y=$k['-3']??'';if(strlen($x)!==32||strlen($y)!==32)throw new RuntimeException('Unsupported EC public key.');
        $point="\x04".$x.$y;
        // AlgorithmIdentifier for an EC key MUST be a SEQUENCE of TWO OIDs:
        // id-ecPublicKey (1.2.840.10045.2.1) followed by the named curve
        // (prime256v1 / P-256, 1.2.840.10045.3.1.7). The id-ecPublicKey OID
        // was missing here, which made every registered EC public key
        // (i.e. virtually every real fingerprint/Windows Hello/Touch Id/
        // Face Id credential) an invalid SubjectPublicKeyInfo -- so
        // openssl_verify() could never succeed and login always failed
        // with "Biometric signature could not be verified", regardless of
        // hostname/ngrok. This restores the correct two-OID identifier.
        $algId=der_tlv(0x30,der_tlv(0x06,"\x2A\x86\x48\xCE\x3D\x02\x01").der_tlv(0x06,"\x2A\x86\x48\xCE\x3D\x03\x01\x07"));
        $spki=der_tlv(0x30,$algId.der_tlv(0x03,"\0".$point));
    } elseif($kty===3 && $alg===-257){
        $n=$k['-1']??'';$e=$k['-2']??'';if($n===''||$e==='')throw new RuntimeException('Unsupported RSA public key.');
        $rsa=der_tlv(0x30,der_int($n).der_int($e));
        $algId=der_tlv(0x30,der_tlv(0x06,"\x2A\x86\x48\x86\xF7\x0D\x01\x01\x01").der_tlv(0x05,''));
        $spki=der_tlv(0x30,$algId.der_tlv(0x03,"\0".$rsa));
    } else throw new RuntimeException('This device returned an unsupported biometric key type.');
    return "-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($spki),64,"\n")."-----END PUBLIC KEY-----\n";
}
function parse_attestation_public_key(string $att): array {
    $i=0;$obj=cbor_read($att,$i);if(!is_array($obj)||empty($obj['authData']))throw new RuntimeException('Invalid authenticator data.');
    $auth=$obj['authData'];if(strlen($auth)<55)throw new RuntimeException('Authenticator data is too short.');
    $flags=ord($auth[32]);if(($flags&0x40)===0)throw new RuntimeException('No credential data was returned by the authenticator.');
    $pos=37;$aaguid=substr($auth,$pos,16);$pos+=16;$len=unpack('n',substr($auth,$pos,2))[1];$pos+=2;$credId=substr($auth,$pos,$len);$pos+=$len;$cose=cbor_read($auth,$pos);if(!is_array($cose))throw new RuntimeException('Invalid credential public key.');
    return ['credential_id'=>b64e($credId),'public_key'=>cose_public_key_pem($cose),'sign_count'=>unpack('N',substr($auth,33,4))[1]];
}
function ensure_table(PDO $pdo): void {
    // Deliberately no foreign key here. Older CSJ installations may have a
    // different profile_key definition in student_profiles; keeping this
    // security table independent prevents errno 150 while the application
    // still verifies the profile_key on every operation.
    $pdo->exec("CREATE TABLE IF NOT EXISTS student_biometrics (biometric_id INT UNSIGNED AUTO_INCREMENT, profile_key CHAR(32) NOT NULL, credential_id VARCHAR(1024) NOT NULL, attestation_object LONGTEXT NOT NULL, client_data_json LONGTEXT NOT NULL, public_key_pem TEXT NULL, sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0, authenticator_type VARCHAR(80) DEFAULT 'platform', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, last_used_at DATETIME DEFAULT NULL, PRIMARY KEY(biometric_id), UNIQUE KEY uq_biometric_credential(credential_id), KEY idx_biometric_profile(profile_key)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    try{$pdo->exec("ALTER TABLE student_biometrics ADD COLUMN public_key_pem TEXT NULL AFTER client_data_json");}catch(Throwable $e){} try{$pdo->exec("ALTER TABLE student_biometrics ADD COLUMN sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER public_key_pem");}catch(Throwable $e){}
    // Instructor biometric table (used by shared login_options / login_verify).
    $pdo->exec("CREATE TABLE IF NOT EXISTS instructor_biometric_credentials (
      credential_row_id INT UNSIGNED AUTO_INCREMENT,
      instructor_key CHAR(32) NOT NULL,
      credential_id VARCHAR(512) NOT NULL,
      public_key TEXT DEFAULT NULL,
      sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
      transports VARCHAR(100) DEFAULT NULL,
      device_label VARCHAR(120) DEFAULT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      last_used_at DATETIME DEFAULT NULL,
      PRIMARY KEY (credential_row_id),
      UNIQUE KEY uq_credential_id (credential_id(191)),
      KEY idx_bio_instructor (instructor_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    try{$pdo->exec("ALTER TABLE instructor_biometric_credentials ADD COLUMN sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0");}catch(Throwable $e){}
    try{$pdo->exec("ALTER TABLE instructor_biometric_credentials ADD COLUMN public_key TEXT DEFAULT NULL");}catch(Throwable $e){}
    try{$pdo->exec("ALTER TABLE instructor_biometric_credentials ADD COLUMN last_used_at DATETIME DEFAULT NULL");}catch(Throwable $e){}
    // Ensure instructor_profiles exists so JOIN in login_verify never fails hard.
    $pdo->exec("CREATE TABLE IF NOT EXISTS instructor_profiles (
      instructor_row_id INT UNSIGNED AUTO_INCREMENT,
      instructor_key CHAR(32) NOT NULL,
      teacher_id VARCHAR(50) DEFAULT NULL,
      full_name VARCHAR(150) DEFAULT NULL,
      program VARCHAR(150) DEFAULT NULL,
      address VARCHAR(255) DEFAULT NULL,
      contact_no VARCHAR(50) DEFAULT NULL,
      email VARCHAR(150) DEFAULT NULL,
      password_hash VARCHAR(255) DEFAULT NULL,
      photo_path VARCHAR(255) DEFAULT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (instructor_row_id),
      UNIQUE KEY uq_instructor_key (instructor_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function challenge_new(string $kind): string { $_SESSION['csj_webauthn_'.$kind.'_challenge']=b64e(random_bytes(32));$_SESSION['csj_webauthn_'.$kind.'_time']=time();return $_SESSION['csj_webauthn_'.$kind.'_challenge']; }
function check_client(string $b64,string $type,string $challenge): array { $raw=b64d($b64);$d=json_decode($raw,true);if(!is_array($d)||($d['type']??'')!==$type)throw new RuntimeException('Invalid WebAuthn response type.');if(!hash_equals($challenge,(string)($d['challenge']??'')))throw new RuntimeException('Biometric challenge verification failed.');if(normalize_origin((string)($d['origin']??''))!==normalize_origin(origin()))throw new RuntimeException('Biometric login must use the same site name you used when registering it. For XAMPP, always use the same hostname such as localhost.');return $d; }

function der_from_ecdsa_raw(string $sig): string {
    // Some browser/platform combinations return ECDSA signatures as the
    // 64-byte IEEE-P1363 form (r || s), while WebAuthn normally uses DER.
    // Convert it so OpenSSL can verify either representation.
    if (strlen($sig) !== 64) return $sig;
    $r = ltrim(substr($sig, 0, 32), "\0");
    $s = ltrim(substr($sig, 32, 32), "\0");
    if ($r === '') $r = "\0";
    if ($s === '') $s = "\0";
    if ((ord($r[0]) & 0x80) !== 0) $r = "\0".$r;
    if ((ord($s[0]) & 0x80) !== 0) $s = "\0".$s;
    return der_tlv(0x30, der_tlv(0x02,$r).der_tlv(0x02,$s));
}
function norm_cred_id(string $id): string {
    $id = trim($id);
    // Strip common base64url/base64 padding differences so lookup succeeds
    // whether the browser or DB stored padded or unpadded forms.
    $id = rtrim($id, '=');
    return $id;
}
function decode_key_material(string $v): string {
    // Accept PEM, standard base64, or base64url public key material.
    if ($v === '') return '';
    if (strpos($v, 'BEGIN PUBLIC KEY') !== false) return $v;
    $raw = base64_decode($v, true);
    if ($raw === false) {
        // base64url fallback
        $padded = $v . str_repeat('=', (4 - strlen($v) % 4) % 4);
        $raw = base64_decode(strtr($padded, '-_', '+/'), true);
    }
    if ($raw === false || $raw === '') return '';
    return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($raw), 64, "\n") . "-----END PUBLIC KEY-----\n";
}
function public_key_for_verify(array $row, string $kind): string {
    $v = $kind === 'student' ? (string)($row['public_key_pem'] ?? '') : (string)($row['public_key'] ?? '');
    return decode_key_material($v);
}
function find_biometric_by_credential($pdo, string $cred): array {
    $variants = array_unique(array_filter([
        $cred,
        norm_cred_id($cred),
        rtrim($cred, '='),
        $cred . str_repeat('=', (4 - strlen(rtrim($cred, '=')) % 4) % 4),
    ]));
    // Student first
    foreach ($variants as $c) {
        $st = $pdo->prepare('SELECT b.*, p.student_name AS display_name FROM student_biometrics b LEFT JOIN student_profiles p ON p.profile_key=b.profile_key WHERE b.credential_id=? LIMIT 1');
        $st->execute([$c]);
        $b = $st->fetch();
        if ($b) return ['kind' => 'student', 'row' => $b];
    }
    // Instructor (LEFT JOIN so missing profile does not hide credential)
    foreach ($variants as $c) {
        $st = $pdo->prepare('SELECT b.*, COALESCE(p.full_name, \'\') AS display_name FROM instructor_biometric_credentials b LEFT JOIN instructor_profiles p ON p.instructor_key=b.instructor_key WHERE b.credential_id=? LIMIT 1');
        $st->execute([$c]);
        $b = $st->fetch();
        if ($b) return ['kind' => 'instructor', 'row' => $b];
    }
    // Last resort: scan and compare normalized IDs (handles rare encoding drift)
    try {
        $q = $pdo->query('SELECT b.*, p.student_name AS display_name FROM student_biometrics b LEFT JOIN student_profiles p ON p.profile_key=b.profile_key');
        $needle = norm_cred_id($cred);
        while ($r = $q->fetch()) {
            if (norm_cred_id((string)$r['credential_id']) === $needle) return ['kind' => 'student', 'row' => $r];
        }
    } catch (Throwable $e) {}
    try {
        $q = $pdo->query('SELECT b.*, COALESCE(p.full_name, \'\') AS display_name FROM instructor_biometric_credentials b LEFT JOIN instructor_profiles p ON p.instructor_key=b.instructor_key');
        $needle = norm_cred_id($cred);
        while ($r = $q->fetch()) {
            if (norm_cred_id((string)$r['credential_id']) === $needle) return ['kind' => 'instructor', 'row' => $r];
        }
    } catch (Throwable $e) {}
    return ['kind' => '', 'row' => null];
}

try{
 $pdo=csj_student_db();ensure_table($pdo);$action=$_GET['action']??'';
 if($action==='status'){
   if(!isset($_SESSION['student_profile_key'])){echo json_encode(['ok'=>true,'enrolled'=>false]);exit;}
   $st=$pdo->prepare('SELECT COUNT(*) FROM student_biometrics WHERE profile_key=?');$st->execute([$_SESSION['student_profile_key']]);echo json_encode(['ok'=>true,'enrolled'=>(int)$st->fetchColumn()>0]);exit;
 }
 if($action==='options'){
   $key=csj_student_profile_key();$st=$pdo->prepare('SELECT student_id,student_name,course_year,email FROM student_profiles WHERE profile_key=? LIMIT 1');$st->execute([$key]);$p=$st->fetch();if(!$p||trim((string)$p['student_name'])===''||trim((string)$p['course_year'])==='')throw new RuntimeException('Please enter and save your Student Name and Course & Year first.');
   $st=$pdo->prepare('SELECT credential_id FROM student_biometrics WHERE profile_key=?');$st->execute([$key]);$exclude=[];while($r=$st->fetch())$exclude[]=['type'=>'public-key','id'=>$r['credential_id']];
   $ch=challenge_new('register');echo json_encode(['ok'=>true,'publicKey'=>['challenge'=>$ch,'rp'=>['name'=>'Colegio de San Jose - Self-Monitoring Dashboard','id'=>rp()],'user'=>['id'=>b64e(hash('sha256',$key,true)),'name'=>(string)($p['student_id']?:$key),'displayName'=>(string)$p['student_name']],'pubKeyCredParams'=>[['type'=>'public-key','alg'=>-7],['type'=>'public-key','alg'=>-257]],'timeout'=>60000,'attestation'=>'none','authenticatorSelection'=>['authenticatorAttachment'=>'platform','residentKey'=>'discouraged','requireResidentKey'=>false,'userVerification'=>'required'],'excludeCredentials'=>$exclude]]);exit;
 }
 if($action==='register'){
   $d=bin_input();$ch=$_SESSION['csj_webauthn_register_challenge']??'';$t=(int)($_SESSION['csj_webauthn_register_time']??0);if(!$ch||time()-$t>300)throw new RuntimeException('The biometric request expired. Please try again.');
   $client=(string)($d['response']['clientDataJSON']??'');check_client($client,'webauthn.create',$ch);$parsed=parse_attestation_public_key(b64d((string)($d['response']['attestationObject']??'')));$key=csj_student_profile_key();
   // A fresh registration replaces this student's previous biometric credential(s).
   // This prevents an older credential/public-key pair from being selected at login
   // after the site was moved to another ngrok hostname or the browser credential changed.
   $pdo->beginTransaction();
   try {
     $pdo->prepare('DELETE FROM student_biometrics WHERE profile_key=?')->execute([$key]);
     $pdo->prepare('INSERT INTO student_biometrics(profile_key,credential_id,attestation_object,client_data_json,public_key_pem,sign_count,authenticator_type) VALUES(?,?,?,?,?,?,?)')->execute([$key,$parsed['credential_id'],(string)($d['response']['attestationObject']??''),$client,$parsed['public_key'],$parsed['sign_count'],'platform']);
     $nameStmt=$pdo->prepare('SELECT student_name FROM student_profiles WHERE profile_key=? LIMIT 1');$nameStmt->execute([$key]);$studentName=(string)($nameStmt->fetchColumn()?:'Student');
     csj_audit_log($pdo,'student_biometric_registered','student',$key,$studentName,['method'=>'webauthn'],'student',$key,$studentName);
     $pdo->commit();
   } catch(Throwable $e) { if($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
   unset($_SESSION['csj_webauthn_register_challenge'],$_SESSION['csj_webauthn_register_time']);echo json_encode(['ok'=>true,'message'=>'Fingerprint/device biometric is ready. You can now use it on the separate login page.']);exit;
 }
 if($action==='login_options' || $action==='biometric_login_options'){
   $ch=challenge_new('login');
   // Fingerprint-first login: provide the registered credential IDs so the
   // platform authenticator can go straight to the device biometric prompt,
   // instead of asking the user to choose/type a passkey. The server still
   // identifies the account from the returned credential ID.
   $ids=[];
   try { $q=$pdo->query('SELECT credential_id FROM student_biometrics'); while($r=$q->fetch()) $ids[]=['type'=>'public-key','id'=>$r['credential_id']]; } catch(Throwable $e) {}
   try{$q=$pdo->query('SELECT credential_id FROM instructor_biometric_credentials');while($r=$q->fetch())$ids[]=['type'=>'public-key','id'=>$r['credential_id']];}catch(Throwable $e){}
   echo json_encode(['ok'=>true,'publicKey'=>['challenge'=>$ch,'rpId'=>rp(),'timeout'=>60000,'userVerification'=>'required','allowCredentials'=>$ids]]);exit;
 }
 if($action==='login_verify' || $action==='biometric_login_verify'){
   $d=bin_input();$ch=$_SESSION['csj_webauthn_login_challenge']??'';$t=(int)($_SESSION['csj_webauthn_login_time']??0);if(!$ch||time()-$t>300)throw new RuntimeException('The biometric login request expired. Please try again.');
   $clientB64=(string)($d['response']['clientDataJSON']??'');$client=check_client($clientB64,'webauthn.get',$ch);$cred=(string)($d['id']??'');if($cred==='')throw new RuntimeException('No biometric credential was returned.');
   $found=find_biometric_by_credential($pdo,$cred); $kind=$found['kind']; $b=$found['row'];
   if(!$b) throw new RuntimeException('This device biometric is not enabled for this account.');
   $verifyKey=public_key_for_verify($b,$kind);
   if($verifyKey===''){
     // Try recovering key from stored attestation if present (student registrations)
     if($kind==='student' && !empty($b['attestation_object'])){
       try{ $recovered=parse_attestation_public_key(b64d((string)$b['attestation_object'])); $verifyKey=$recovered['public_key']??''; }catch(Throwable $ignored){}
     }
   }
   if($verifyKey==='')throw new RuntimeException('This device biometric is not enabled for this account. Please register your fingerprint again from your dashboard.');
   $auth=b64d((string)($d['response']['authenticatorData']??''));$sig=b64d((string)($d['response']['signature']??''));if(strlen($auth)<37)throw new RuntimeException('Invalid authenticator data.');$rpHash=hash('sha256',rp(),true);if(!hash_equals($rpHash,substr($auth,0,32)))throw new RuntimeException('Biometric was used for a different website.');$flags=ord($auth[32]);if(($flags&1)===0||($flags&4)===0)throw new RuntimeException('User verification was not completed.');$count=unpack('N',substr($auth,33,4))[1];
   $signed=$auth.hash('sha256',b64d($clientB64),true);
   // Verify the exact WebAuthn assertion. Browsers normally return DER ECDSA
   // signatures; a few Android/browser combinations return raw P-1363 (r||s).
   $candidates=[$verifyKey];
   if($kind==='student' && !empty($b['attestation_object'])){
     try{ $repaired=parse_attestation_public_key(b64d((string)$b['attestation_object'])); if($repaired['public_key']!==$verifyKey){$candidates[]=$repaired['public_key'];} }catch(Throwable $ignored){}
   }
   $ok=0; $successfulKey=$verifyKey;
   foreach($candidates as $candidateKey){
     $v=openssl_verify($signed,$sig,$candidateKey,OPENSSL_ALGO_SHA256);
     if($v===1){$ok=1;$successfulKey=$candidateKey;break;}
     if(strlen($sig)===64){
       $v=openssl_verify($signed,der_from_ecdsa_raw($sig),$candidateKey,OPENSSL_ALGO_SHA256);
       if($v===1){$ok=1;$successfulKey=$candidateKey;break;}
     }
   }
   if($ok!==1)throw new RuntimeException('Biometric signature could not be verified. The registered device credential does not match this website. Please register your fingerprint again using the same HTTPS/ngrok address.');
   if($kind==='student' && $successfulKey!==$verifyKey){try{$pdo->prepare('UPDATE student_biometrics SET public_key_pem=? WHERE biometric_id=?')->execute([$successfulKey,$b['biometric_id']]);}catch(Throwable $ignored){}}if($count!==0 && (int)$b['sign_count']>0 && $count<=(int)$b['sign_count'])throw new RuntimeException('The biometric authenticator counter is invalid.');
   unset($_SESSION['csj_webauthn_login_challenge'],$_SESSION['csj_webauthn_login_time']);session_regenerate_id(true);
   if($kind==='student'){ $pdo->prepare('UPDATE student_biometrics SET sign_count=?,last_used_at=NOW() WHERE biometric_id=?')->execute([$count,$b['biometric_id']]); unset($_SESSION['instructor_authenticated'],$_SESSION['instructor_key'],$_SESSION['instructor_name'],$_SESSION['dean_authenticated'],$_SESSION['dean_id'],$_SESSION['dean_name']); $_SESSION['student_profile_key']=$b['profile_key'];$_SESSION['student_authenticated']=true;$_SESSION['student_name']=(string)($b['display_name']??'Student');csj_audit_log($pdo,'biometric_login','student',(string)$b['profile_key'],(string)($b['display_name']??'Student'),['method'=>'webauthn'],'student',(string)$b['profile_key'],(string)($b['display_name']??'Student'));$redirect='student.php'; }
   else { $pdo->prepare('UPDATE instructor_biometric_credentials SET sign_count=?,last_used_at=NOW() WHERE credential_row_id=?')->execute([$count,$b['credential_row_id']]); unset($_SESSION['student_authenticated'],$_SESSION['student_profile_key'],$_SESSION['student_name'],$_SESSION['dean_authenticated'],$_SESSION['dean_id'],$_SESSION['dean_name']); $_SESSION['instructor_key']=$b['instructor_key'];$_SESSION['instructor_authenticated']=true;$_SESSION['instructor_name']=(string)($b['display_name']??'Teacher');csj_audit_log($pdo,'biometric_login','teacher',(string)$b['instructor_key'],(string)($b['display_name']??'Teacher'),['method'=>'webauthn'],'teacher',(string)$b['instructor_key'],(string)($b['display_name']??'Teacher'));setcookie('csj_instructor_key',$b['instructor_key'],['expires'=>time()+31536000,'path'=>'/','samesite'=>'Lax']);$redirect='instructor-dashboard.php'; }
   echo json_encode(['ok'=>true,'message'=>'Biometric login successful.','redirect'=>$redirect,'role'=>$kind]);exit;
 }
 throw new RuntimeException('Unknown biometric action.');
}catch(Throwable $e){
  if (ob_get_length()) ob_clean();
  http_response_code(400);
  echo json_encode(['ok'=>false,'message'=>$e->getMessage()?:'Biometric operation failed.'], JSON_UNESCAPED_UNICODE);
}
if (ob_get_length()) ob_end_flush();
