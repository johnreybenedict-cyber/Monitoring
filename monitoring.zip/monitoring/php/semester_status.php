<?php
/**
 * GET php/semester_status.php
 * Tiny public heartbeat: which semester is live and which transition id is current.
 * Open dashboards poll it and reload themselves the moment the Dean starts a new semester.
 * Contains no personal data.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../config.php';
try {
    $pdo = csj_student_db();
    echo json_encode([
        'ok' => true,
        'semester' => csj_get_current_semester($pdo),
        'transitionId' => csj_transition_id($pdo),
    ]);
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['ok' => false]);
}
