<?php
/**
 * Shared Feedback box for both the Student and Instructor dashboards.
 *
 * The sender's role ('student' or 'instructor') and identity are read
 * from their own dashboard's session (the exact same session flags
 * student.php / instructor-dashboard.php already require just to load
 * those pages) -- never from anything the client sends. This is what
 * lets one endpoint serve both dashboards while still knowing for sure
 * which kind of user actually submitted each row.
 *
 * Action:
 *   POST { message } -> inserts one row into `feedback`, tagged with the
 *                        signed-in role, name, and identifying key.
 */
header('Content-Type: application/json; charset=utf-8');
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/db.php';

function csj_ensure_feedback(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS feedback (
      feedback_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
      role VARCHAR(20) NOT NULL,
      profile_key CHAR(32) DEFAULT NULL,
      instructor_key CHAR(32) DEFAULT NULL,
      user_name VARCHAR(150) DEFAULT NULL,
      message TEXT NOT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (feedback_id),
      KEY idx_feedback_role (role),
      KEY idx_feedback_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

$payload = json_decode(file_get_contents('php://input') ?: '{}', true);
$payload = is_array($payload) ? $payload : [];
$action = strtolower(trim((string)($payload['action'] ?? $_GET['action'] ?? 'send')));
if ($action === '') $action = 'send';

$message = trim((string)($payload['message'] ?? ''));

if ($action !== 'send') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Unknown action.']);
    exit;
}

if ($message === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Please write your feedback first.']);
    exit;
}
$message = function_exists('mb_substr') ? mb_substr($message, 0, 4000) : substr($message, 0, 4000);

try {
    $pdo = csj_db();
    csj_ensure_feedback($pdo);

    $role = '';
    $profileKey = null;
    $instructorKey = null;
    $userName = null;

    // Each dashboard's own login already put these exact session flags in
    // place before the page would even load, so checking them here is
    // enough to know -- server-side, not from anything the browser sent --
    // whether this request came from the Student or the Instructor view.
    if (!empty($_SESSION['instructor_authenticated']) && !empty($_SESSION['instructor_key'])) {
        $role = 'instructor';
        $instructorKey = (string)$_SESSION['instructor_key'];
        try {
            $st = $pdo->prepare('SELECT full_name FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
            $st->execute([$instructorKey]);
            $userName = $st->fetchColumn() ?: null;
        } catch (Throwable $e) { /* profile not set up yet */ }
    } elseif (!empty($_SESSION['student_authenticated']) && !empty($_SESSION['student_profile_key'])) {
        $role = 'student';
        $profileKey = (string)$_SESSION['student_profile_key'];
        try {
            $st = $pdo->prepare('SELECT student_name FROM student_profiles WHERE profile_key = ? LIMIT 1');
            $st->execute([$profileKey]);
            $userName = $st->fetchColumn() ?: null;
        } catch (Throwable $e) { /* profile not set up yet */ }
    } else {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Please log in first.']);
        exit;
    }

    $ins = $pdo->prepare(
        'INSERT INTO feedback (role, profile_key, instructor_key, user_name, message) VALUES (?, ?, ?, ?, ?)'
    );
    $ins->execute([$role, $profileKey, $instructorKey, $userName, $message]);

    echo json_encode(['ok' => true, 'message' => 'Thanks for your feedback!']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Feedback is not available until MySQL is connected.']);
}
