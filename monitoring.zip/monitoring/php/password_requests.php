<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/auth_common.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function password_request_response(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

try {
    $pdo = csj_student_db();
    $action = (string)($_GET['action'] ?? '');
    $data = csj_json_input();
    if ($action !== 'list' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        password_request_response(['ok' => false, 'message' => 'POST is required for this action.'], 405);
    }

    if ($action === 'request') {
        $role = (string)($data['role'] ?? '');
        $identity = trim((string)($data['identity'] ?? ''));
        $reason = trim((string)($data['reason'] ?? ''));

        if (!in_array($role, ['student', 'teacher'], true)) {
            password_request_response(['ok' => false, 'message' => 'Choose Student or Teacher as the account type.'], 422);
        }
        if ($identity === '') {
            password_request_response(['ok' => false, 'message' => 'Enter your Student ID / Teacher ID or account email.'], 422);
        }
        if (strlen($identity) > 150 || strlen($reason) > 500) {
            password_request_response(['ok' => false, 'message' => 'One or more fields exceed the allowed length.'], 422);
        }

        // Resolve registered account name from the database (no name field on the form)
        $identityKey = strtolower($identity);
        $registeredName = '';
        if ($role === 'student') {
            $lookup = $pdo->prepare(
                'SELECT sp.student_name
                 FROM student_accounts sa
                 INNER JOIN student_profiles sp ON sp.profile_key = sa.profile_key
                 WHERE LOWER(sa.student_id) = ? OR LOWER(sa.email) = ?
                 LIMIT 1'
            );
            $lookup->execute([$identityKey, $identityKey]);
            $registeredName = trim((string)($lookup->fetchColumn() ?: ''));
        } else {
            $lookup = $pdo->prepare(
                'SELECT full_name FROM instructor_profiles
                 WHERE LOWER(teacher_id) = ? OR LOWER(email) = ?
                 LIMIT 1'
            );
            $lookup->execute([$identityKey, $identityKey]);
            $registeredName = trim((string)($lookup->fetchColumn() ?: ''));
        }
        // Store registered name for the Dean list; fall back to the identifier if unknown
        $requesterName = $registeredName !== '' ? $registeredName : $identity;

        $recentStmt = $pdo->prepare(
            'SELECT COUNT(*) FROM password_reset_requests
             WHERE account_role = ? AND LOWER(account_identifier) = LOWER(?)
               AND created_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)'
        );
        $recentStmt->execute([$role, $identity]);
        if ((int)$recentStmt->fetchColumn() >= 3) {
            password_request_response(['ok' => false, 'message' => 'Too many recent requests for this account. Please contact the Dean’s office directly.'], 429);
        }

        $pendingStmt = $pdo->prepare(
            'SELECT request_id FROM password_reset_requests
             WHERE account_role = ? AND LOWER(account_identifier) = LOWER(?) AND status = ? LIMIT 1'
        );
        $pendingStmt->execute([$role, $identity, 'pending']);
        if ($pendingStmt->fetchColumn()) {
            password_request_response(['ok' => true, 'message' => 'A request for this account is already pending with the Dean’s office.']);
        }

        $pdo->beginTransaction();
        $insert = $pdo->prepare(
            'INSERT INTO password_reset_requests
                (account_role, account_identifier, requester_name, requester_note)
             VALUES (?, ?, ?, ?)'
        );
        $insert->execute([$role, $identity, $requesterName, $reason !== '' ? $reason : null]);
        csj_audit_log(
            $pdo,
            'password_reset_requested',
            $role,
            $identity,
            $requesterName,
            [],
            $role,
            $identity,
            $requesterName
        );
        $pdo->commit();
        password_request_response(['ok' => true, 'message' => 'Your request has been sent to the Dean’s office for identity verification. Please follow up with the office in person.']);
    }

    if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
        password_request_response(['ok' => false, 'message' => 'Dean login is required.'], 401);
    }

    if ($action === 'list') {
        $stmt = $pdo->query(
            'SELECT request_id, account_role, account_identifier, requester_name,
                requester_note, status, created_at, reviewed_at
             FROM password_reset_requests
             ORDER BY (status = \'pending\') DESC, created_at DESC
             LIMIT 200'
        );
        $requests = $stmt->fetchAll();
        foreach ($requests as &$request) {
            $identity = strtolower(trim((string)$request['account_identifier']));
            if ($request['account_role'] === 'student') {
                $accountStmt = $pdo->prepare(
                    'SELECT sa.student_id, sa.email, sp.student_name
                     FROM student_accounts sa
                     INNER JOIN student_profiles sp ON sp.profile_key = sa.profile_key
                     WHERE LOWER(sa.student_id) = ? LIMIT 1'
                );
                $accountStmt->execute([$identity]);
                $account = $accountStmt->fetch();
                if (!$account) {
                    $accountStmt = $pdo->prepare(
                        'SELECT sa.student_id, sa.email, sp.student_name
                         FROM student_accounts sa
                         INNER JOIN student_profiles sp ON sp.profile_key = sa.profile_key
                         WHERE LOWER(sa.email) = ? LIMIT 1'
                    );
                    $accountStmt->execute([$identity]);
                    $account = $accountStmt->fetch();
                }
                if ($account) {
                    $request['registered_name'] = $account['student_name'];
                    $request['matched_identifier'] = $account['student_id'] ?: $account['email'];
                }
            } else {
                $accountStmt = $pdo->prepare(
                    'SELECT teacher_id, email, full_name
                     FROM instructor_profiles WHERE LOWER(teacher_id) = ? LIMIT 1'
                );
                $accountStmt->execute([$identity]);
                $account = $accountStmt->fetch();
                if (!$account) {
                    $accountStmt = $pdo->prepare(
                        'SELECT teacher_id, email, full_name
                         FROM instructor_profiles WHERE LOWER(email) = ? LIMIT 1'
                    );
                    $accountStmt->execute([$identity]);
                    $account = $accountStmt->fetch();
                }
                if ($account) {
                    $request['registered_name'] = $account['full_name'];
                    $request['matched_identifier'] = $account['teacher_id'] ?: $account['email'];
                }
            }
            $request['account_found'] = isset($account) && (bool)$account;
            unset($account);
        }
        unset($request);
        password_request_response(['ok' => true, 'requests' => $requests]);
    }

    $requestId = filter_var($data['requestId'] ?? null, FILTER_VALIDATE_INT);
    if (!$requestId || $requestId < 1) {
        password_request_response(['ok' => false, 'message' => 'A valid request ID is required.'], 422);
    }

    if ($action === 'dismiss') {
        $requestInfo = $pdo->prepare(
            'SELECT account_role, account_identifier, requester_name
             FROM password_reset_requests WHERE request_id = ? AND status = ? LIMIT 1'
        );
        $requestInfo->execute([$requestId, 'pending']);
        $request = $requestInfo->fetch();
        if (!$request) {
            password_request_response(['ok' => false, 'message' => 'That request is no longer pending. Refresh the request list.'], 409);
        }
        $pdo->beginTransaction();
        $stmt = $pdo->prepare(
            'UPDATE password_reset_requests
             SET status = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
             WHERE request_id = ? AND status = ?'
        );
        $stmt->execute(['dismissed', (int)$_SESSION['dean_id'], $requestId, 'pending']);
        if ($stmt->rowCount() !== 1) {
            $pdo->rollBack();
            password_request_response(['ok' => false, 'message' => 'That request is no longer pending. Refresh the request list.'], 409);
        }
        csj_audit_log(
            $pdo,
            'password_reset_request_dismissed',
            (string)$request['account_role'],
            (string)$request['account_identifier'],
            (string)$request['requester_name'],
            ['request_id' => (int)$requestId],
            'dean',
            (string)$_SESSION['dean_id'],
            (string)($_SESSION['dean_name'] ?? 'Dean')
        );
        $pdo->commit();
        password_request_response(['ok' => true, 'message' => 'Request dismissed.']);
    }

    if ($action === 'reset') {
        $newPassword = (string)($data['newPassword'] ?? '');
        if (($data['identityVerified'] ?? false) !== true) {
            password_request_response(['ok' => false, 'message' => 'Confirm that you verified the requester’s identity before resetting.'], 422);
        }
        if (strlen($newPassword) < 8) {
            password_request_response(['ok' => false, 'message' => 'The new password must be at least 8 characters.'], 422);
        }
        try {
            if (function_exists('csj_assert_password_unique')) {
                csj_assert_password_unique($pdo, $newPassword);
            }
        } catch (Throwable $e) {
            password_request_response(['ok' => false, 'message' => $e->getMessage()], 422);
        }

        $pdo->beginTransaction();
        $requestStmt = $pdo->prepare(
            'SELECT account_role, account_identifier, requester_name, status
             FROM password_reset_requests WHERE request_id = ? FOR UPDATE'
        );
        $requestStmt->execute([$requestId]);
        $request = $requestStmt->fetch();
        if (!$request || $request['status'] !== 'pending') {
            $pdo->rollBack();
            password_request_response(['ok' => false, 'message' => 'That request is no longer pending. Refresh the request list.'], 409);
        }
        if (!in_array($request['account_role'], ['student', 'teacher'], true)) {
            $pdo->rollBack();
            password_request_response(['ok' => false, 'message' => 'This request has an unsupported account type. No password was changed.'], 409);
        }

        $hash = password_hash($newPassword, PASSWORD_DEFAULT);
        $identity = strtolower(trim((string)$request['account_identifier']));
        if ($request['account_role'] === 'student') {
            $accountStmt = $pdo->prepare('SELECT account_id FROM student_accounts WHERE LOWER(student_id) = ? LIMIT 1 FOR UPDATE');
            $accountStmt->execute([$identity]);
            $accountId = $accountStmt->fetchColumn();
            if (!$accountId) {
                $accountStmt = $pdo->prepare('SELECT account_id FROM student_accounts WHERE LOWER(email) = ? LIMIT 1 FOR UPDATE');
                $accountStmt->execute([$identity]);
                $accountId = $accountStmt->fetchColumn();
            }
            if (!$accountId) {
                $pdo->rollBack();
                password_request_response(['ok' => false, 'message' => 'No student account matches this request. Verify the requester’s ID/email before resetting.'], 404);
            }
            $updateAccount = $pdo->prepare('UPDATE student_accounts SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE account_id = ?');
        } else {
            $accountStmt = $pdo->prepare('SELECT instructor_key FROM instructor_profiles WHERE LOWER(teacher_id) = ? LIMIT 1 FOR UPDATE');
            $accountStmt->execute([$identity]);
            $accountKey = $accountStmt->fetchColumn();
            if (!$accountKey) {
                $accountStmt = $pdo->prepare('SELECT instructor_key FROM instructor_profiles WHERE LOWER(email) = ? LIMIT 1 FOR UPDATE');
                $accountStmt->execute([$identity]);
                $accountKey = $accountStmt->fetchColumn();
            }
            if (!$accountKey) {
                $pdo->rollBack();
                password_request_response(['ok' => false, 'message' => 'No teacher account matches this request. Verify the requester’s ID/email before resetting.'], 404);
            }
            $updateAccount = $pdo->prepare('UPDATE instructor_profiles SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE instructor_key = ?');
            $accountId = $accountKey;
        }
        $updateAccount->execute([$hash, $accountId]);

        $finishStmt = $pdo->prepare(
            'UPDATE password_reset_requests
             SET status = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
             WHERE request_id = ? AND status = ?'
        );
        $finishStmt->execute(['resolved', (int)$_SESSION['dean_id'], $requestId, 'pending']);
        if ($finishStmt->rowCount() !== 1) {
            $pdo->rollBack();
            password_request_response(['ok' => false, 'message' => 'The request changed while being processed. No password was changed.'], 409);
        }
        csj_audit_log(
            $pdo,
            'password_reset_completed',
            (string)$request['account_role'],
            (string)$request['account_identifier'],
            (string)$request['requester_name'],
            ['request_id' => (int)$requestId],
            'dean',
            (string)$_SESSION['dean_id'],
            (string)($_SESSION['dean_name'] ?? 'Dean')
        );
        $pdo->commit();
        password_request_response(['ok' => true, 'message' => 'Password reset. Give the new password to the verified account holder through a private, in-person channel.']);
    }

    password_request_response(['ok' => false, 'message' => 'Unsupported request action.'], 404);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    error_log('Password request handling failed: ' . $e->getMessage());
    password_request_response(['ok' => false, 'message' => 'The request could not be processed. Check the database connection and password-reset request table.'], 500);
}
