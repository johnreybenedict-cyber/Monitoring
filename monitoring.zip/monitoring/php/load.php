<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
$profileKey = csj_student_profile_key();

/** Adds the live transition id so an open student page can notice a new semester. */
function csj_with_transition(array $chart, ?PDO $pdo = null): array {
    $chart['transitionId'] = csj_transition_id($pdo);
    return $chart;
}

$dataFile = __DIR__ . '/../data/chart.json';
$fallback = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : null;

try {
    $pdo = csj_student_db();
    $currentSemester = function_exists('csj_get_current_semester')
        ? csj_get_current_semester($pdo)
        : (string)($fallback['meta']['semester'] ?? 'First Semester, AY 2026-2027');
    $stmt = $pdo->prepare(
        'SELECT chart_json, semester FROM monitoring_submissions
         WHERE profile_key = ? ORDER BY updated_at DESC LIMIT 1'
    );
    $stmt->execute([$profileKey]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row && !empty($row['chart_json'])) {
        $chart = json_decode($row['chart_json'], true);
        if (is_array($chart)) {
            $chart['periods'] = csj_normalize_periods($chart);
            $chart['access'] = csj_period_access($chart['periods']);
            if (empty($chart['meta']['semester']) && !empty($row['semester'])) {
                $chart['meta']['semester'] = $row['semester'];
            }
            echo json_encode(csj_with_transition($chart, $pdo), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit;
        }
    }
    // No submission (e.g. after new-semester reset) → blank chart for current semester
    if (is_array($fallback)) {
        $fallback['meta'] = $fallback['meta'] ?? [];
        $fallback['meta']['semester'] = $currentSemester;
        $fallback['periods'] = csj_normalize_periods(['periods' => []]);
        $fallback['access'] = csj_period_access($fallback['periods']);
        echo json_encode(csj_with_transition($fallback, $pdo), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
} catch (Throwable $e) {
    // Fall back to the bundled chart only when MySQL is temporarily unavailable.
}

if (is_array($fallback)) {
    $fallback['periods'] = csj_normalize_periods($fallback);
    $fallback['access'] = csj_period_access($fallback['periods']);
    echo json_encode($fallback, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} else {
    http_response_code(404);
    echo json_encode(['ok' => false, 'message' => 'No saved chart found yet.']);
}
