<?php
/**
 * Two-way Instructor ↔ Student chat about monitoring.
 *
 * Actions:
 *   send_instructor  POST { profileKey, body, subjectCode?, semester? }
 *   send_student     POST { body, instructorKey? }  (reply; optional target instructor)
 *   thread_student   GET/POST – student's full inbox (all instructors)
 *   thread_instructor GET/POST { profileKey } – conversation with one student
 *   inbox_instructor GET/POST – instructor's full inbox, one row per student
 *   unread_student   GET – unread count for student (instructor messages)
 *   unread_instructor GET – unread count for instructor (student replies)
 *   mark_read_student POST
 *   mark_read_instructor POST { profileKey }
 *
 * Legacy aliases: send, list_student, unread_count, mark_read
 */
header('Content-Type: application/json; charset=utf-8');
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/db.php';

function csj_ensure_messages(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS instructor_student_messages (
      message_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
      instructor_key CHAR(32) NOT NULL,
      instructor_name VARCHAR(150) DEFAULT NULL,
      profile_key CHAR(32) NOT NULL,
      subject_code VARCHAR(80) DEFAULT NULL,
      semester VARCHAR(120) DEFAULT NULL,
      body TEXT NOT NULL,
      sender_role VARCHAR(20) NOT NULL DEFAULT 'instructor',
      is_read TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (message_id),
      KEY idx_msg_student (profile_key, is_read),
      KEY idx_msg_instructor (instructor_key),
      KEY idx_msg_created (created_at),
      KEY idx_msg_sender (sender_role)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    try {
        $pdo->exec("ALTER TABLE instructor_student_messages ADD COLUMN sender_role VARCHAR(20) NOT NULL DEFAULT 'instructor' AFTER body");
    } catch (Throwable $e) { /* already exists */ }
    try {
        $pdo->exec("ALTER TABLE instructor_student_messages ADD COLUMN instructor_name VARCHAR(150) DEFAULT NULL AFTER instructor_key");
    } catch (Throwable $e) { /* already exists */ }
}

function csj_instructor_session(): string {
    if (empty($_SESSION['instructor_key'])) {
        $cookieKey = preg_replace('/[^a-f0-9]/', '', (string)($_COOKIE['csj_instructor_key'] ?? ''));
        if (strlen($cookieKey) === 32) {
            $_SESSION['instructor_key'] = $cookieKey;
        }
    }
    return (string)($_SESSION['instructor_key'] ?? '');
}

// NOTE: csj_student_profile_key() is already defined in config.php (loaded
// above via db.php) -- it was also redeclared here, which is a hard PHP
// fatal error ("Cannot redeclare csj_student_profile_key()"). PHP prints
// that fatal error as raw HTML ("<br /> <b>Fatal error</b> ...") even
// though this endpoint sets a JSON content-type, which is exactly what
// broke the browser's JSON.parse() with "Unexpected token '<'". Removing
// the duplicate here and reusing config.php's version (which already
// falls back to the profile-key cookie the same way) fixes it.

$payload = json_decode(file_get_contents('php://input') ?: '{}', true);
$payload = is_array($payload) ? $payload : [];
$action = strtolower(trim((string)($payload['action'] ?? $_GET['action'] ?? '')));

// Legacy aliases
if ($action === 'send') $action = 'send_instructor';
if ($action === 'list_student') $action = 'thread_student';
if ($action === 'unread_count') $action = 'unread_student';
if ($action === 'mark_read') $action = 'mark_read_student';

try {
    $pdo = csj_db();
    csj_ensure_messages($pdo);

    /* ---------- Instructor sends ---------- */
    if ($action === 'send_instructor') {
        $instructorKey = csj_instructor_session();
        if ($instructorKey === '') {
            http_response_code(401);
            echo json_encode(['ok' => false, 'message' => 'Instructor session required.']);
            exit;
        }
        if (empty($_SESSION['instructor_authenticated'])) {
            $_SESSION['instructor_authenticated'] = true;
        }
        $profileKey = trim((string)($payload['profileKey'] ?? ''));
        $body = trim((string)($payload['body'] ?? ''));
        $subject = trim((string)($payload['subjectCode'] ?? ''));
        $semester = trim((string)($payload['semester'] ?? ''));
        if ($profileKey === '' || $body === '') {
            http_response_code(422);
            echo json_encode(['ok' => false, 'message' => 'Student and message body are required.']);
            exit;
        }
        if (mb_strlen($body) > 2000) {
            http_response_code(422);
            echo json_encode(['ok' => false, 'message' => 'Message is too long (max 2000 characters).']);
            exit;
        }
        $st = $pdo->prepare('SELECT full_name FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
        $st->execute([$instructorKey]);
        $instructorName = trim((string)$st->fetchColumn()) ?: 'Instructor';

        $ins = $pdo->prepare(
            'INSERT INTO instructor_student_messages
              (instructor_key, instructor_name, profile_key, subject_code, semester, body, sender_role, is_read)
             VALUES (?, ?, ?, ?, ?, ?, \'instructor\', 0)'
        );
        $ins->execute([
            $instructorKey,
            $instructorName,
            $profileKey,
            $subject !== '' ? $subject : null,
            $semester !== '' ? $semester : null,
            $body,
        ]);
        echo json_encode([
            'ok' => true,
            'message' => 'Message sent.',
            'messageId' => (int)$pdo->lastInsertId(),
            'sender_role' => 'instructor',
        ]);
        exit;
    }

    /* ---------- Student replies ---------- */
    if ($action === 'send_student') {
        $profileKey = csj_student_profile_key();
        if ($profileKey === '' || empty($_SESSION['student_authenticated'])) {
            http_response_code(401);
            echo json_encode(['ok' => false, 'message' => 'Student session required.']);
            exit;
        }
        $body = trim((string)($payload['body'] ?? ''));
        if ($body === '') {
            http_response_code(422);
            echo json_encode(['ok' => false, 'message' => 'Message body is required.']);
            exit;
        }
        if (mb_strlen($body) > 2000) {
            http_response_code(422);
            echo json_encode(['ok' => false, 'message' => 'Message is too long (max 2000 characters).']);
            exit;
        }
        // Target instructor: explicit key, or last instructor who messaged this student
        $instructorKey = preg_replace('/[^a-f0-9]/', '', (string)($payload['instructorKey'] ?? ''));
        if (strlen($instructorKey) !== 32) {
            $st = $pdo->prepare(
                "SELECT instructor_key FROM instructor_student_messages
                 WHERE profile_key = ? AND sender_role = 'instructor'
                 ORDER BY created_at DESC LIMIT 1"
            );
            $st->execute([$profileKey]);
            $instructorKey = (string)$st->fetchColumn();
        }
        if (strlen($instructorKey) !== 32) {
            // Any instructor who has this student in selections is not required;
            // allow reply only if there is an existing thread, else error.
            http_response_code(422);
            echo json_encode(['ok' => false, 'message' => 'No instructor conversation yet. Wait for a teacher message first, or open a thread.']);
            exit;
        }
        $st = $pdo->prepare('SELECT full_name FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
        $st->execute([$instructorKey]);
        $instructorName = trim((string)$st->fetchColumn()) ?: 'Instructor';

        $st = $pdo->prepare('SELECT student_name FROM student_profiles WHERE profile_key = ? LIMIT 1');
        $st->execute([$profileKey]);
        $studentName = trim((string)$st->fetchColumn()) ?: 'Student';

        $ins = $pdo->prepare(
            'INSERT INTO instructor_student_messages
              (instructor_key, instructor_name, profile_key, subject_code, semester, body, sender_role, is_read)
             VALUES (?, ?, ?, NULL, NULL, ?, \'student\', 0)'
        );
        $ins->execute([$instructorKey, $instructorName, $profileKey, $body]);
        echo json_encode([
            'ok' => true,
            'message' => 'Reply sent.',
            'messageId' => (int)$pdo->lastInsertId(),
            'sender_role' => 'student',
            'studentName' => $studentName,
        ]);
        exit;
    }

    /* ---------- Student thread (inbox) ---------- */
    if ($action === 'thread_student') {
        $profileKey = csj_student_profile_key();
        if ($profileKey === '' || empty($_SESSION['student_authenticated'])) {
            http_response_code(401);
            echo json_encode(['ok' => false, 'message' => 'Student session required.']);
            exit;
        }
        $st = $pdo->prepare(
            'SELECT message_id, instructor_key, instructor_name, subject_code, semester,
                    body, sender_role, is_read, created_at
             FROM instructor_student_messages
             WHERE profile_key = ?
             ORDER BY created_at ASC
             LIMIT 300'
        );
        $st->execute([$profileKey]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['ok' => true, 'messages' => $rows]);
        exit;
    }

    /* ---------- Instructor thread with one student ---------- */
    if ($action === 'thread_instructor') {
        $instructorKey = csj_instructor_session();
        if ($instructorKey === '') {
            http_response_code(401);
            echo json_encode(['ok' => false, 'message' => 'Instructor session required.']);
            exit;
        }
        $profileKey = trim((string)($payload['profileKey'] ?? $_GET['profile_key'] ?? ''));
        if ($profileKey === '') {
            http_response_code(422);
            echo json_encode(['ok' => false, 'message' => 'profileKey is required.']);
            exit;
        }
        $st = $pdo->prepare(
            'SELECT message_id, instructor_key, instructor_name, subject_code, semester,
                    body, sender_role, is_read, created_at
             FROM instructor_student_messages
             WHERE profile_key = ? AND instructor_key = ?
             ORDER BY created_at ASC
             LIMIT 300'
        );
        $st->execute([$profileKey, $instructorKey]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['ok' => true, 'messages' => $rows, 'profileKey' => $profileKey]);
        exit;
    }

    if ($action === 'unread_student') {
        $profileKey = csj_student_profile_key();
        if ($profileKey === '' || empty($_SESSION['student_authenticated'])) {
            echo json_encode(['ok' => true, 'unread' => 0]);
            exit;
        }
        $st = $pdo->prepare(
            "SELECT COUNT(*) FROM instructor_student_messages
             WHERE profile_key = ? AND sender_role = 'instructor' AND is_read = 0"
        );
        $st->execute([$profileKey]);
        echo json_encode(['ok' => true, 'unread' => (int)$st->fetchColumn()]);
        exit;
    }

    if ($action === 'unread_instructor') {
        $instructorKey = csj_instructor_session();
        if ($instructorKey === '') {
            echo json_encode(['ok' => true, 'unread' => 0]);
            exit;
        }
        $st = $pdo->prepare(
            "SELECT COUNT(*) FROM instructor_student_messages
             WHERE instructor_key = ? AND sender_role = 'student' AND is_read = 0"
        );
        $st->execute([$instructorKey]);
        echo json_encode(['ok' => true, 'unread' => (int)$st->fetchColumn()]);
        exit;
    }

    /* ---------- Instructor's full inbox (all students, one row each) ---------- */
    if ($action === 'inbox_instructor') {
        $instructorKey = csj_instructor_session();
        if ($instructorKey === '') {
            http_response_code(401);
            echo json_encode(['ok' => false, 'message' => 'Instructor session required.']);
            exit;
        }
        $st = $pdo->prepare(
            'SELECT m.message_id, m.profile_key, m.subject_code, m.semester, m.body,
                    m.sender_role, m.is_read, m.created_at,
                    COALESCE(sp.student_name, "Student") AS student_name
             FROM instructor_student_messages m
             LEFT JOIN student_profiles sp ON sp.profile_key = m.profile_key
             WHERE m.instructor_key = ?
             ORDER BY m.created_at ASC
             LIMIT 500'
        );
        $st->execute([$instructorKey]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['ok' => true, 'messages' => $rows]);
        exit;
    }

    if ($action === 'mark_read_student') {
        $profileKey = csj_student_profile_key();
        if ($profileKey === '' || empty($_SESSION['student_authenticated'])) {
            http_response_code(401);
            echo json_encode(['ok' => false, 'message' => 'Student session required.']);
            exit;
        }
        // Optional instructorKey scopes this to just that one conversation,
        // so opening one instructor's thread doesn't clear the unread
        // badge on a different instructor's still-unread thread.
        $instructorKey = preg_replace('/[^a-f0-9]/', '', (string)($payload['instructorKey'] ?? ''));
        if (strlen($instructorKey) === 32) {
            $st = $pdo->prepare(
                "UPDATE instructor_student_messages SET is_read = 1
                 WHERE profile_key = ? AND instructor_key = ? AND sender_role = 'instructor' AND is_read = 0"
            );
            $st->execute([$profileKey, $instructorKey]);
        } else {
            $st = $pdo->prepare(
                "UPDATE instructor_student_messages SET is_read = 1
                 WHERE profile_key = ? AND sender_role = 'instructor' AND is_read = 0"
            );
            $st->execute([$profileKey]);
        }
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'mark_read_instructor') {
        $instructorKey = csj_instructor_session();
        if ($instructorKey === '') {
            http_response_code(401);
            echo json_encode(['ok' => false, 'message' => 'Instructor session required.']);
            exit;
        }
        $profileKey = trim((string)($payload['profileKey'] ?? ''));
        if ($profileKey !== '') {
            $st = $pdo->prepare(
                "UPDATE instructor_student_messages SET is_read = 1
                 WHERE instructor_key = ? AND profile_key = ? AND sender_role = 'student' AND is_read = 0"
            );
            $st->execute([$instructorKey, $profileKey]);
        } else {
            $st = $pdo->prepare(
                "UPDATE instructor_student_messages SET is_read = 1
                 WHERE instructor_key = ? AND sender_role = 'student' AND is_read = 0"
            );
            $st->execute([$instructorKey]);
        }
        echo json_encode(['ok' => true]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Unknown action: ' . $action]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Messages unavailable: ' . $e->getMessage()]);
}
