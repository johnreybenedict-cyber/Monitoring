<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/audit.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Dean login required.']);
    exit;
}

function ensure_student_academic_cols(PDO $pdo): void {
    foreach ([
        "ALTER TABLE student_profiles ADD COLUMN program VARCHAR(20) DEFAULT NULL",
        "ALTER TABLE student_profiles ADD COLUMN year_level VARCHAR(20) DEFAULT NULL",
        "ALTER TABLE student_profiles ADD COLUMN enrollment_status VARCHAR(20) DEFAULT NULL",
        "ALTER TABLE student_profiles ADD COLUMN major VARCHAR(80) DEFAULT NULL",
    ] as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) {}
    }
}

function year_to_number(string $year): string {
    $map = ['1st' => '1', '2nd' => '2', '3rd' => '3', '4th' => '4'];
    return $map[$year] ?? '';
}

function build_course_year(string $program, string $year): string {
    $n = year_to_number($year);
    if ($program === '' && $n === '') return '';
    if ($program !== '' && $n !== '') return $program . ' ' . $n;
    return $program !== '' ? $program : $n;
}

function normalize_program(string $raw): string {
    $p = strtoupper(trim($raw));
    $p = str_replace([' ', '-'], '', $p);
    if ($p === 'BEED') return 'BEEd';
    if ($p === 'BSED') return 'BSEd';
    if ($p === 'BSBA') return 'BSBA';
    if ($p === 'BSIT') return 'BSIT';
    return '';
}

try {
    $pdo = csj_db();
    ensure_student_academic_cols($pdo);
    $raw = file_get_contents('php://input');
    $d = json_decode($raw ?: '[]', true);
    if (!is_array($d)) $d = $_POST;
    $action = (string)($d['action'] ?? $_GET['action'] ?? 'list');

    if ($action === 'list' || $action === '') {
        // Ensure phone table exists (self-heal older XAMPP installs)
        try {
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS student_phone_numbers (
                    phone_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    profile_key CHAR(32) NOT NULL,
                    phone_number VARCHAR(30) NOT NULL,
                    is_primary TINYINT(1) NOT NULL DEFAULT 1,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (phone_id),
                    UNIQUE KEY uq_profile_phone (profile_key, phone_number),
                    KEY idx_phone_profile (profile_key)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
        } catch (Throwable $e) {}

        $q = trim((string)($d['q'] ?? $_GET['q'] ?? ''));
        // Load profiles; phone from student_phone_numbers when available
        $sql = 'SELECT sp.profile_key, sp.student_id, sp.student_name, sp.course_year, sp.program, sp.year_level,
                       sp.enrollment_status, sp.major, sp.email, sp.address, sp.guardian, sp.contact_no, sp.photo_path
                FROM student_profiles sp';
        $params = [];
        if ($q !== '') {
            $sql .= ' WHERE sp.student_name LIKE ? OR sp.student_id LIKE ? OR sp.course_year LIKE ? OR sp.program LIKE ? OR sp.contact_no LIKE ? OR sp.major LIKE ?';
            $like = '%' . $q . '%';
            $params = [$like, $like, $like, $like, $like, $like];
        }
        $sql .= ' ORDER BY sp.student_name ASC LIMIT 500';
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);

        // Overlay primary phone from student_phone_numbers when table exists
        try {
            $phSt = $pdo->prepare(
                'SELECT phone_number FROM student_phone_numbers WHERE profile_key = ? ORDER BY is_primary DESC, phone_id ASC LIMIT 1'
            );
            foreach ($rows as &$row) {
                $phSt->execute([(string)($row['profile_key'] ?? '')]);
                $pn = (string)($phSt->fetchColumn() ?: '');
                if ($pn !== '') $row['contact_no'] = $pn;
                $ph = (string)($row['contact_no'] ?? '');
                if (preg_match('/^\+63([0-9]{10})$/', $ph, $m)) {
                    $row['contact_no'] = '0' . $m[1];
                }
            }
            unset($row);
        } catch (Throwable $e) {
            // phone table optional
            foreach ($rows as &$row) {
                $ph = (string)($row['contact_no'] ?? '');
                if (preg_match('/^\+63([0-9]{10})$/', $ph, $m)) {
                    $row['contact_no'] = '0' . $m[1];
                }
            }
            unset($row);
        }
        echo json_encode(['ok' => true, 'students' => $rows]);
        exit;
    }

    if ($action === 'save') {
        $key = trim((string)($d['profile_key'] ?? ''));
        if ($key === '' || !preg_match('/^[a-f0-9]{32}$/i', $key)) {
            throw new RuntimeException('Invalid student profile.');
        }

        $program = normalize_program((string)($d['program'] ?? ''));
        $year = trim((string)($d['year_level'] ?? ''));
        if ($year !== '' && !in_array($year, ['1st', '2nd', '3rd', '4th'], true)) {
            throw new RuntimeException('Year must be 1st, 2nd, 3rd, or 4th.');
        }

        $status = strtolower(trim((string)($d['enrollment_status'] ?? '')));
        if ($status !== '' && !in_array($status, ['regular', 'irregular'], true)) {
            throw new RuntimeException('Status must be regular or irregular.');
        }

        $major = trim((string)($d['major'] ?? ''));
        // Programs with majors: major is required and must be a valid option.
        // Programs without majors (BSIT, BEEd): major is cleared and save still works.
        if ($program === 'BSBA') {
            if ($major === '') {
                throw new RuntimeException('Please select a Major for BSBA (Operations Management or Financial Management).');
            }
            if (!in_array($major, ['Operations Management', 'Financial Management'], true)) {
                throw new RuntimeException('BSBA major must be Operations Management or Financial Management.');
            }
        } elseif ($program === 'BSEd') {
            if ($major === '') {
                throw new RuntimeException('Please select a Major for BSEd (English or Filipino).');
            }
            if (!in_array($major, ['English', 'Filipino'], true)) {
                throw new RuntimeException('BSEd major must be English or Filipino.');
            }
        } else {
            // BSIT, BEEd, or blank program — no major
            $major = '';
        }

        if ($program === '') {
            throw new RuntimeException('Please select a Program (BEEd, BSEd, BSBA, or BSIT).');
        }
        if ($year === '') {
            throw new RuntimeException('Please select a Year level (1st–4th).');
        }

        $st = $pdo->prepare('SELECT student_name, course_year FROM student_profiles WHERE profile_key = ? LIMIT 1');
        $st->execute([$key]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new RuntimeException('Student not found.');

        $courseYear = build_course_year($program, $year);
        if ($courseYear === '') $courseYear = (string)$row['course_year'];

        $pdo->prepare(
            'UPDATE student_profiles SET
                program = ?, year_level = ?, enrollment_status = ?, major = ?,
                course_year = ?, updated_at = CURRENT_TIMESTAMP
             WHERE profile_key = ?'
        )->execute([
            $program !== '' ? $program : null,
            $year !== '' ? $year : null,
            $status !== '' ? $status : null,
            $major !== '' ? $major : null,
            $courseYear,
            $key,
        ]);

        if (function_exists('csj_audit_log')) {
            csj_audit_log(
                $pdo, 'dean_student_profile_updated', 'student', $key, (string)$row['student_name'],
                [
                    'program' => $program,
                    'year_level' => $year,
                    'enrollment_status' => $status,
                    'major' => $major,
                    'course_year' => $courseYear,
                ],
                'dean', (string)$_SESSION['dean_id'], (string)($_SESSION['dean_name'] ?? 'Dean')
            );
        }

        echo json_encode(['ok' => true, 'message' => 'Student profile updated.', 'course_year' => $courseYear]);
        exit;
    }

    throw new RuntimeException('Unknown action.');
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => $e->getMessage()]);
}
