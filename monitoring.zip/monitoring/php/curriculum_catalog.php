<?php
/**
 * Official curriculum course codes by Program → Year → Semester term (1|2).
 * Codes are stored WITHOUT section suffix (no -1 / -2).
 * Display form matches the prospectus (e.g. "SSci 101", "CC 101").
 *
 * For BSBA year 3–4, majors diverge (Operations Management / Financial Management).
 * For BSEd year 2–4, majors diverge (English / Filipino) when data is available.
 */
return [

  // -------------------------------------------------------------------------
  // BSIT
  // -------------------------------------------------------------------------
  'BSIT' => [
    '1st' => [
      '1' => [
        'SSci 101', 'SSci 102', 'Math 101', 'Eng 101', 'PE 101',
        'NSTP 11', 'RE-CVF 101', 'CC 101', 'CC 102',
      ],
      '2' => [
        'Entrep 101', 'SSci 104', 'Philo 101', 'Sci 101', 'Hum 101',
        'PE 102', 'NSTP 12', 'RE-CVF 102', 'CC 103',
      ],
    ],
    '2nd' => [
      '1' => [
        'IT 101', 'Fil 101', 'CC 105', 'PF 101', 'PT 101',
        'MS 101', 'PE 203', 'RE-CVF 203',
      ],
      '2' => [
        'Eng 202', 'CC 104', 'IPT 101', 'IM 101', 'WS 101',
        'PE 204', 'RE-CVF 204',
      ],
    ],
    '3rd' => [
      '1' => [
        'CC 106', 'SIA 101', 'MS 102', 'NET 101', 'SP 101',
        'MM 101', 'SSci 103', 'RE-CVF 305',
      ],
      '2' => [
        'HCI 101', 'NET 102', 'PF 102', 'IAS 101', 'MM 102',
        'RE-CVF 306',
      ],
    ],
    '4th' => [
      '1' => [
        'SP 102', 'CAP 101', 'SA 101', 'IAS 102', 'MM 103', 'MM 104',
      ],
      '2' => [
        'PRAC 101', 'CAP 102',
      ],
    ],
  ],

  // -------------------------------------------------------------------------
  // BEEd
  // -------------------------------------------------------------------------
  'BEEd' => [
    '1st' => [
      '1' => [
        'SSci 101', 'SSci 102', 'Math 101', 'Eng 101', 'SSci 103',
        'PE 101', 'NSTP 11', 'RE-CVF 101', 'Fil 101', 'Educ 101',
      ],
      '2' => [
        'SSci 104', 'Philo 101', 'Sci 101', 'Hum 101', 'PE 102',
        'NSTP 12', 'RE-CVF 102', 'IT 101', 'Entrep 101', 'Educ 102',
      ],
    ],
    '2nd' => [
      '1' => [
        'Spec 201', 'Spec 202', 'Spec 203', 'Spec 204', 'Spec 205',
        'PE 203', 'RE-CVF 203', 'Educ 203', 'Educ 204',
      ],
      '2' => [
        'Spec 206', 'Spec 207', 'Spec 208', 'Spec 209', 'Spec 210',
        'PE 204', 'RE-CVF 204', 'Educ 205', 'Educ 206',
      ],
    ],
    '3rd' => [
      '1' => [
        'Spec 311', 'Spec 312', 'Spec 313', 'Spec 314', 'Spec 315',
        'RE-CVF 305', 'Educ 307', 'Educ 308',
      ],
      '2' => [
        'Spec 316', 'Spec 317', 'Spec 318', 'Spec 319',
        'RE-CVF 306', 'Educ Elect 301', 'Educ 309', 'Educ 310',
      ],
    ],
    '4th' => [
      '1' => ['Educ 411'],
      '2' => ['Educ 412'],
    ],
  ],

  // -------------------------------------------------------------------------
  // BSEd – Filipino major (English shares year 1 GE; major courses diverge later)
  // -------------------------------------------------------------------------
  'BSEd' => [
    '1st' => [
      '1' => [
        'SSci 101', 'SSci 102', 'Math 101', 'Eng 101', 'SSci 103',
        'PE 101', 'NSTP 11', 'RE-CVF 101', 'Fil 101', 'Educ 101',
      ],
      '2' => [
        'SSci 104', 'Philo 101', 'Sci 101', 'Hum 101', 'PE 102',
        'NSTP 12', 'RE-CVF 102', 'IT 101', 'Entrep 101', 'Educ 102',
      ],
    ],
    '2nd' => [
      // Default / Filipino track
      '1' => [
        'Fil 201', 'Fil 202', 'Fil 203', 'Fil 204', 'Fil 205',
        'PE 203', 'RE-CVF 203', 'Educ 203', 'Educ 204',
      ],
      '2' => [
        'Fil 206', 'Fil 207', 'Fil 208', 'Fil 209', 'Fil 210',
        'PE 204', 'RE-CVF 204', 'Educ 205', 'Educ 206',
      ],
      'Filipino' => [
        '1' => [
          'Fil 201', 'Fil 202', 'Fil 203', 'Fil 204', 'Fil 205',
          'PE 203', 'RE-CVF 203', 'Educ 203', 'Educ 204',
        ],
        '2' => [
          'Fil 206', 'Fil 207', 'Fil 208', 'Fil 209', 'Fil 210',
          'PE 204', 'RE-CVF 204', 'Educ 205', 'Educ 206',
        ],
      ],
      'English' => [
        '1' => [
          'Eng 201', 'Eng 202', 'Eng 203', 'Eng 204', 'Eng 205',
          'PE 203', 'RE-CVF 203', 'Educ 203', 'Educ 204',
        ],
        '2' => [
          'Eng 206', 'Eng 207', 'Eng 208', 'Eng 209', 'Eng 210',
          'PE 204', 'RE-CVF 204', 'Educ 205', 'Educ 206',
        ],
      ],
    ],
    '3rd' => [
      '1' => [
        'Fil 311', 'Fil 312', 'Fil 313', 'Fil Elect 301', 'Fil 314',
        'Fil 315', 'RE-CVF 305', 'Educ 307', 'Educ 308',
      ],
      '2' => [
        'Fil 316', 'Fil 317', 'Fil 320', 'Fil Elect 302', 'Fil 318',
        'Fil 319', 'RE-CVF 306', 'Educ 309', 'Educ 310',
      ],
      'Filipino' => [
        '1' => [
          'Fil 311', 'Fil 312', 'Fil 313', 'Fil Elect 301', 'Fil 314',
          'Fil 315', 'RE-CVF 305', 'Educ 307', 'Educ 308',
        ],
        '2' => [
          'Fil 316', 'Fil 317', 'Fil 320', 'Fil Elect 302', 'Fil 318',
          'Fil 319', 'RE-CVF 306', 'Educ 309', 'Educ 310',
        ],
      ],
      'English' => [
        '1' => [
          'Eng 311', 'Eng 312', 'Eng 313', 'Eng Elect 301', 'Eng 314',
          'Eng 315', 'RE-CVF 305', 'Educ 307', 'Educ 308',
        ],
        '2' => [
          'Eng 316', 'Eng 317', 'Eng 320', 'Eng Elect 302', 'Eng 318',
          'Eng 319', 'RE-CVF 306', 'Educ 309', 'Educ 310',
        ],
      ],
    ],
    '4th' => [
      '1' => ['Educ 411'],
      '2' => ['Educ 412'],
      'Filipino' => ['1' => ['Educ 411'], '2' => ['Educ 412']],
      'English'  => ['1' => ['Educ 411'], '2' => ['Educ 412']],
    ],
  ],

  // -------------------------------------------------------------------------
  // BSBA – Year 1–2 shared; Year 3–4 split by major
  // -------------------------------------------------------------------------
  'BSBA' => [
    '1st' => [
      '1' => [
        'SSci 101', 'SSci 102', 'Math 101', 'Eng 101', 'SSci 103',
        'PE 101', 'NSTP 11', 'RE-CVF 101',
      ],
      '2' => [
        'SSci 104', 'Philo 101', 'Sci 101', 'Computer 101', 'Entrep 101',
        'PE 102', 'NSTP 12', 'RE-CVF 102',
      ],
    ],
    '2nd' => [
      '1' => [
        'Fil 101', 'Math 202', 'English 202', 'Accounting 201', 'Mgt 201',
        'CBMEC 201', 'PE 203', 'RE-CVF 203',
      ],
      '2' => [
        'IT 101', 'Hum 101', 'Economics 201', 'FME 201', 'FME 202',
        'FM 201', 'PE 204', 'RE-CVF 204',
      ],
      // Operations Management year 2 uses same foundation as FM prospectus year 2
      'Operations Management' => [
        '1' => [
          'Fil 101', 'Math 202', 'English 202', 'Accounting 201', 'Mgt 201',
          'CBMEC 201', 'PE 203', 'RE-CVF 203',
        ],
        '2' => [
          'IT 101', 'Hum 101', 'Economics 201', 'FME 201', 'FME 202',
          'FM 201', 'PE 204', 'RE-CVF 204',
        ],
      ],
      'Financial Management' => [
        '1' => [
          'Fil 101', 'Math 202', 'English 202', 'Accounting 201', 'Mgt 201',
          'CBMEC 201', 'PE 203', 'RE-CVF 203',
        ],
        '2' => [
          'IT 101', 'Hum 101', 'Economics 201', 'FME 201', 'FME 202',
          'FM 201', 'PE 204', 'RE-CVF 204',
        ],
      ],
    ],
    '3rd' => [
      'Operations Management' => [
        '1' => [
          'Bus Law 301', 'Mgt 302', 'OM 301', 'OM 302', 'OM 303', 'RE-CVF 305',
        ],
        '2' => [
          'OM 304', 'OM 305', 'OM 306', 'OME 303', 'OME 304',
          'Taxation 301', 'RE-CVF 306',
        ],
      ],
      'Financial Management' => [
        '1' => [
          'Bus Law 301', 'Mgt 302', 'FM 302', 'FM 303', 'FM 304', 'RE-CVF 305',
        ],
        '2' => [
          'FM 305', 'FM 306', 'FM 307', 'FME 303', 'Language 101',
          'Taxation 301', 'RE-CVF 306',
        ],
      ],
      // fallback if major not set
      '1' => [
        'Bus Law 301', 'Mgt 302', 'RE-CVF 305',
      ],
      '2' => [
        'Taxation 301', 'RE-CVF 306',
      ],
    ],
    '4th' => [
      'Operations Management' => [
        '1' => [
          'CBMEC 402', 'Mgt 403', 'Mgt 404', 'Mgt 405',
          'OM 407', 'OM 408', 'OME 405',
        ],
        '2' => ['Practicum'],
      ],
      'Financial Management' => [
        '1' => [
          'CBMEC 402', 'FME 404', 'FME 405', 'FM 408',
          'Mgt 403', 'Mgt 404', 'Mgt 405',
        ],
        '2' => ['Practicum'],
      ],
      '1' => ['CBMEC 402', 'Mgt 403', 'Mgt 404', 'Mgt 405'],
      '2' => ['Practicum'],
    ],
  ],
];
