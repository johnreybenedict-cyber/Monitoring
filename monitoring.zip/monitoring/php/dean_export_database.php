<?php
/**
 * Dean-only FULL DATABASE BACKUP (.sql)
 *
 * Streams a complete dump of the whole database: structure + every row of EVERY table
 * (student / instructor / dean accounts, monitoring sheets, archive, feedback, audit trail,
 * system flags, biometric records ...). It is a plain mysqldump-style file, so it can be
 * restored with phpMyAdmin -> Import, or:  mysql -u root < backup.sql
 *
 * Tables are discovered at run time (SHOW FULL TABLES), so tables added later are included
 * automatically. All data is read from ONE consistent snapshot, so the file is internally
 * consistent even while students are using the system.
 *
 * Profile photos are FILES (assets/uploads/...), not database rows: copy that folder as well.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/audit.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    header('Location: ../index.php');
    exit;
}

@set_time_limit(0);
@ini_set('memory_limit', '512M');
@ini_set('zlib.output_compression', '0');

function csj_dump_ident(string $name): string {
    return '`' . str_replace('`', '``', $name) . '`';
}

/** Turn one PDO value into an SQL literal according to the column type. */
function csj_dump_literal(PDO $pdo, $value, string $columnType): string {
    if ($value === null) return 'NULL';
    $type = strtolower($columnType);
    if (preg_match('/(blob|binary|varbinary|bit)\b/', $type)) {
        return $value === '' ? "''" : '0x' . bin2hex((string)$value);
    }
    if (preg_match('/^(tinyint|smallint|mediumint|int|integer|bigint|decimal|numeric|float|double|real)\b/', $type)
        && is_numeric($value)) {
        return (string)$value;
    }
    return $pdo->quote((string)$value);
}

try {
    $pdo = csj_student_db();
    $dbName = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
    if ($dbName === '') throw new RuntimeException('No database selected.');
    $version = (string)$pdo->query('SELECT VERSION()')->fetchColumn();

    // Ensure runtime tables exist so the dump covers the full expected set (22 tables).
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS login_attempts (
                attempt_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                ip_address VARCHAR(45) NOT NULL,
                identity VARCHAR(120) NOT NULL DEFAULT '',
                attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (attempt_id),
                KEY idx_login_attempts_lookup (ip_address, identity, attempted_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {}
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS instructor_phone_numbers (
                phone_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                instructor_key CHAR(32) NOT NULL,
                phone_number VARCHAR(30) NOT NULL,
                is_primary TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (phone_id),
                UNIQUE KEY uq_instructor_phone (instructor_key, phone_number),
                KEY idx_instructor_phone (instructor_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {}

    // Canonical 22 tables shown in phpMyAdmin for csj_self_monitoring
    $expectedTables = [
        'audit_trail',
        'dean_accounts',
        'dean_archived_periods',
        'dean_archived_students',
        'feedback',
        'instructor_biometric_credentials',
        'instructor_phone_numbers',
        'instructor_profiles',
        'instructor_student_messages',
        'instructor_subject_selections',
        'login_attempts',
        'monitoring_submissions',
        'password_reset_requests',
        'semester_welcome_seen',
        'student_accounts',
        'student_biometrics',
        'student_phone_numbers',
        'student_profiles',
        'system_flags',
        'tblfinal',
        'tblmidterm',
        'tblprelim',
    ];

    $found = [];
    $views = [];
    foreach ($pdo->query('SHOW FULL TABLES')->fetchAll(PDO::FETCH_NUM) as $row) {
        $name = (string)$row[0];
        if (strtoupper((string)$row[1]) === 'VIEW') $views[] = $name;
        else $found[strtolower($name)] = $name; // preserve real casing
    }

    // Prefer expected order (case-insensitive match), then any extra tables
    $tables = [];
    $used = [];
    foreach ($expectedTables as $want) {
        $lk = strtolower($want);
        if (isset($found[$lk])) {
            $tables[] = $found[$lk];
            $used[$lk] = true;
        }
    }
    $extras = [];
    foreach ($found as $lk => $real) {
        if (!isset($used[$lk])) $extras[] = $real;
    }
    sort($extras, SORT_NATURAL | SORT_FLAG_CASE);
    $tables = array_merge($tables, $extras);
    sort($views, SORT_NATURAL | SORT_FLAG_CASE);

    // Record the export in the audit trail BEFORE the snapshot, so the entry is inside the backup.
    try {
        csj_audit_log(
            $pdo, 'database_export', 'system', 'database', $dbName,
            ['tables' => count($tables), 'format' => 'sql'],
            'dean', (string)$_SESSION['dean_id'], (string)($_SESSION['dean_name'] ?? 'Dean')
        );
    } catch (Throwable $e) { /* never block a backup because of the log */ }

    // One consistent snapshot for the whole dump, read row by row (low memory).
    $pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');
    $pdo->exec('START TRANSACTION WITH CONSISTENT SNAPSHOT');
    $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);

    $counts = [];
    foreach ($tables as $t) {
        $counts[$t] = (int)$pdo->query('SELECT COUNT(*) FROM ' . csj_dump_ident($t))->fetchColumn();
    }
    $create = [];
    $columns = [];
    foreach ($tables as $t) {
        $r = $pdo->query('SHOW CREATE TABLE ' . csj_dump_ident($t))->fetch(PDO::FETCH_NUM);
        $create[$t] = (string)($r[1] ?? '');
        $cols = [];
        foreach ($pdo->query('SHOW COLUMNS FROM ' . csj_dump_ident($t))->fetchAll(PDO::FETCH_ASSOC) as $c) {
            $cols[(string)$c['Field']] = (string)$c['Type'];
        }
        $columns[$t] = $cols;
    }
    $viewSql = [];
    foreach ($views as $v) {
        $r = $pdo->query('SHOW CREATE VIEW ' . csj_dump_ident($v))->fetch(PDO::FETCH_NUM);
        $viewSql[$v] = (string)($r[1] ?? '');
    }
} catch (Throwable $e) {
    error_log('Database export failed (before output): ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'The database backup could not be created. Please check the database connection and try again.';
    exit;
}

while (ob_get_level() > 0) { @ob_end_clean(); }
$filename = 'csj_full_database_backup_' . date('Y-m-d_H-i-s') . '.sql';
header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Accel-Buffering: no');

function csj_dump_out(string $s): void { echo $s; if (connection_status() === CONNECTION_NORMAL) { @flush(); } }

$deanName = (string)($_SESSION['dean_name'] ?? 'Dean');
$totalRows = array_sum($counts);

csj_dump_out("-- ============================================================\n");
csj_dump_out("-- CSJ Self-Monitoring - FULL DATABASE BACKUP\n");
csj_dump_out("-- Database    : {$dbName}\n");
csj_dump_out("-- Generated   : " . date('Y-m-d H:i:s') . " (server time)\n");
csj_dump_out("-- Exported by : {$deanName} (Dean)\n");
csj_dump_out("-- MySQL       : {$version}\n");
csj_dump_out("-- Contents    : " . count($tables) . " tables, {$totalRows} rows (structure + data)\n");
csj_dump_out("--\n");
foreach ($tables as $t) {
    csj_dump_out('--   ' . str_pad($t, 38) . $counts[$t] . " rows\n");
}
csj_dump_out("--\n");
csj_dump_out("-- RESTORE : phpMyAdmin -> Import (choose this file), or  mysql -u root < this_file.sql\n");
csj_dump_out("--           Existing tables with the same names are replaced (DROP TABLE IF EXISTS).\n");
csj_dump_out("-- NOTE    : this file contains accounts and password hashes. Keep it private.\n");
csj_dump_out("--           Profile photos are files in assets/uploads/ - back that folder up too.\n");
csj_dump_out("-- ============================================================\n\n");

csj_dump_out("SET NAMES utf8mb4;\n");
csj_dump_out("SET FOREIGN_KEY_CHECKS = 0;\n");
csj_dump_out("SET UNIQUE_CHECKS = 0;\n");
csj_dump_out("SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n");
csj_dump_out("SET AUTOCOMMIT = 0;\n\n");
csj_dump_out('CREATE DATABASE IF NOT EXISTS ' . csj_dump_ident($dbName) . " DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n");
csj_dump_out('USE ' . csj_dump_ident($dbName) . ";\n\n");

try {
    foreach ($tables as $t) {
        $q = csj_dump_ident($t);
        csj_dump_out("-- ------------------------------------------------------------\n");
        csj_dump_out("-- Table {$q}  ({$counts[$t]} rows)\n");
        csj_dump_out("-- ------------------------------------------------------------\n");
        csj_dump_out("DROP TABLE IF EXISTS {$q};\n");
        csj_dump_out($create[$t] . ";\n\n");
        if ($counts[$t] === 0) { csj_dump_out("-- (no rows)\n\n"); continue; }

        $stmt = $pdo->query('SELECT * FROM ' . $q);
        $colList = null;
        $batch = [];
        $batchBytes = 0;
        $flushBatch = function () use (&$batch, &$batchBytes, &$colList, $q) {
            if (!$batch) return;
            csj_dump_out('INSERT INTO ' . $q . ' (' . $colList . ") VALUES\n" . implode(",\n", $batch) . ";\n");
            $batch = [];
            $batchBytes = 0;
        };
        while (($row = $stmt->fetch(PDO::FETCH_ASSOC)) !== false) {
            if ($colList === null) {
                $colList = implode(', ', array_map('csj_dump_ident', array_keys($row)));
            }
            $vals = [];
            foreach ($row as $col => $val) {
                $vals[] = csj_dump_literal($pdo, $val, $columns[$t][$col] ?? '');
            }
            $line = '(' . implode(', ', $vals) . ')';
            $batch[] = $line;
            $batchBytes += strlen($line);
            // keep every INSERT well under MySQL's max_allowed_packet
            if (count($batch) >= 200 || $batchBytes >= 400000) $flushBatch();
        }
        $flushBatch();
        $stmt->closeCursor();
        csj_dump_out("\n");
    }

    foreach ($views as $v) {
        csj_dump_out("-- View " . csj_dump_ident($v) . "\n");
        csj_dump_out('DROP VIEW IF EXISTS ' . csj_dump_ident($v) . ";\n" . $viewSql[$v] . ";\n\n");
    }

    $pdo->exec('COMMIT');
    csj_dump_out("COMMIT;\n");
    csj_dump_out("SET FOREIGN_KEY_CHECKS = 1;\nSET UNIQUE_CHECKS = 1;\nSET AUTOCOMMIT = 1;\n");
    csj_dump_out("-- End of CSJ full database backup (" . count($tables) . " tables, {$totalRows} rows)\n");
} catch (Throwable $e) {
    error_log('Database export failed (during output): ' . $e->getMessage());
    csj_dump_out("\n-- !!! BACKUP INCOMPLETE: an error stopped the export. Do NOT use this file. Run the export again. !!!\n");
}
exit;
