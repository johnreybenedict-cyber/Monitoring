<?php
/**
 * Instructor profile photo upload / remove.
 */
header('Content-Type: application/json; charset=utf-8');
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/db.php';

if (empty($_SESSION['instructor_authenticated']) && empty($_SESSION['instructor_key'])) {
    // also accept instructor_key session variants used by this app
    if (empty($_SESSION['instructor_key']) && empty($_COOKIE['csj_instructor_key'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Instructor login is required.']);
        exit;
    }
}

$key = (string)($_SESSION['instructor_key'] ?? $_COOKIE['csj_instructor_key'] ?? '');
if ($key === '') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Instructor login is required.']);
    exit;
}

try {
    $pdo = csj_student_db();
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Database unavailable.']);
    exit;
}

// Ensure photo_path column
try {
    $pdo->exec("ALTER TABLE instructor_profiles ADD COLUMN photo_path VARCHAR(255) DEFAULT NULL");
} catch (Throwable $ignored) {}

$uploadDir = __DIR__ . '/../assets/uploads/instructors';
if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);

if (isset($_POST['remove']) && (string)$_POST['remove'] === '1') {
    try {
        $st = $pdo->prepare('SELECT photo_path FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
        $st->execute([$key]);
        $old = (string)($st->fetchColumn() ?: '');
        if ($old !== '') {
            $base = basename($old);
            foreach ([$uploadDir . '/' . $base, __DIR__ . '/../' . ltrim($old, '/')] as $path) {
                if (is_file($path)) @unlink($path);
            }
        }
        foreach (glob($uploadDir . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $key) . '.*') as $f) {
            @unlink($f);
        }
        $pdo->prepare('UPDATE instructor_profiles SET photo_path = NULL WHERE instructor_key = ?')->execute([$key]);
        echo json_encode(['ok' => true, 'removed' => true, 'photoPath' => '']);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not remove the profile picture.']);
    }
    exit;
}

if (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'No photo received. Choose an image first.']);
    exit;
}

$file = $_FILES['photo'];
$max = 3 * 1024 * 1024;
if (($file['size'] ?? 0) > $max) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Image is too large (max 3 MB).']);
    exit;
}
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($file['tmp_name']) ?: '';
$map = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/webp' => 'webp',
    'image/gif' => 'gif',
];
if (!isset($map[$mime])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Use a JPG, PNG, WEBP, or GIF image.']);
    exit;
}
if (!is_dir($uploadDir) || !is_writable($uploadDir)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'The instructor photo upload folder is not writable.']);
    exit;
}

$safeKey = preg_replace('/[^a-zA-Z0-9_-]/', '', $key) ?: 'instructor';
foreach (glob($uploadDir . '/' . $safeKey . '.*') as $old) @unlink($old);
$filename = $safeKey . '.' . $map[$mime];
$dest = $uploadDir . '/' . $filename;
if (!move_uploaded_file($file['tmp_name'], $dest)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not save the uploaded photo.']);
    exit;
}
$webPath = 'assets/uploads/instructors/' . $filename;
try {
    $pdo->prepare(
        'INSERT INTO instructor_profiles (instructor_key, full_name, photo_path)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE photo_path = VALUES(photo_path)'
    )->execute([$key, '', $webPath]);
    echo json_encode(['ok' => true, 'photoPath' => $webPath . '?v=' . time()]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Photo saved but could not update profile.']);
}
