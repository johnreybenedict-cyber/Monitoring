<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
$profileKey = csj_student_profile_key();

try {
    $pdo = csj_student_db();
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS student_phone_numbers (
                phone_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                profile_key CHAR(32) NOT NULL,
                phone_number VARCHAR(30) NOT NULL,
                is_primary TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (phone_id),
                UNIQUE KEY uq_profile_phone (profile_key, phone_number),
                KEY idx_phone_profile (profile_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {}

    $stmt = $pdo->prepare(
        'SELECT student_id, student_name, course_year, email, address, contact_no, guardian, photo_path, program, year_level, enrollment_status, major
         FROM student_profiles WHERE profile_key = ? LIMIT 1'
    );
    $stmt->execute([$profileKey]);
    $profile = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    // Prefer student_phone_numbers; fall back to contact_no
    $phone = '';
    try {
        $ph = $pdo->prepare(
            'SELECT phone_number FROM student_phone_numbers WHERE profile_key = ? ORDER BY is_primary DESC, phone_id ASC LIMIT 1'
        );
        $ph->execute([$profileKey]);
        $phone = (string)($ph->fetchColumn() ?: '');
    } catch (Throwable $e) {}
    if ($phone === '' && !empty($profile['contact_no'])) {
        $phone = (string)$profile['contact_no'];
    }
    // Display as 09XXXXXXXXX for PH numbers
    if (preg_match('/^\+63([0-9]{10})$/', $phone, $m)) {
        $phone = '0' . $m[1];
    }
    $profile['contact_no'] = $phone;

    echo json_encode(['ok' => true, 'profile' => $profile], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not load profile.']);
}
