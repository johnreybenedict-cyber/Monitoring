<?php

function csj_audit_log(
    PDO $pdo,
    string $action,
    ?string $targetRole = null,
    ?string $targetId = null,
    ?string $targetName = null,
    array $details = [],
    ?string $actorRole = null,
    ?string $actorId = null,
    ?string $actorName = null
): void {
    if ($actorRole === null || $actorId === null || $actorName === null) {
        if (!empty($_SESSION['dean_authenticated']) && !empty($_SESSION['dean_id'])) {
            $actorRole = 'dean';
            $actorId = (string)$_SESSION['dean_id'];
            $actorName = (string)($_SESSION['dean_name'] ?? 'Dean');
        } elseif (!empty($_SESSION['instructor_authenticated']) && !empty($_SESSION['instructor_key'])) {
            $actorRole = 'teacher';
            $actorId = (string)$_SESSION['instructor_key'];
            $actorName = (string)($_SESSION['instructor_name'] ?? 'Teacher');
        } elseif (!empty($_SESSION['student_authenticated']) && !empty($_SESSION['student_profile_key'])) {
            $actorRole = 'student';
            $actorId = (string)$_SESSION['student_profile_key'];
            $actorName = (string)($_SESSION['student_name'] ?? 'Student');
        }
    }

    $encodedDetails = json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encodedDetails === false) {
        throw new RuntimeException('Could not encode audit event details.');
    }

    $stmt = $pdo->prepare(
        'INSERT INTO audit_trail
            (actor_role, actor_id, actor_name, action, target_role, target_id, target_name, details)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $actorRole,
        $actorId,
        $actorName !== null ? substr($actorName, 0, 150) : null,
        substr($action, 0, 80),
        $targetRole !== null ? substr($targetRole, 0, 30) : null,
        $targetId !== null ? substr($targetId, 0, 80) : null,
        $targetName !== null ? substr($targetName, 0, 150) : null,
        $encodedDetails,
    ]);
}
