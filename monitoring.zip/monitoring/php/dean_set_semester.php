<?php
/**
 * Dean edits the Semester box and/or the AY box on dean-dashboard.php.
 *
 * Changing the semester here is the SAME as the automatic "new semester" that starts when every
 * student is approved (csj_apply_semester_transition in config.php):
 *   - all live monitoring sheets are saved into the Archive, then cleared
 *   - instructor subject lists are cleared
 *   - the new semester is stored and students / instructors see the New Semester popup once
 * The Archive is never deleted.
 *
 * Because that clears live data it is only done for a deliberate, confirmed request
 * (confirm=1 sent by the dashboard after the Dean clicks "Start new semester").
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/audit.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function dean_sem_json(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data);
    exit;
}

if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    dean_sem_json(['ok' => false, 'message' => 'Dean login is required.'], 401);
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    dean_sem_json(['ok' => false, 'message' => 'POST is required.'], 405);
}
// A page on another website cannot send this header without a CORS preflight, so this blocks
// forged cross-site requests to a destructive endpoint.
if (strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) !== 'xmlhttprequest') {
    dean_sem_json(['ok' => false, 'message' => 'Invalid request.'], 400);
}

$term = trim((string)($_POST['semester_term'] ?? ''));
$ay = preg_replace('/^AY\s*/i', '', trim((string)($_POST['semester_ay'] ?? '')));

if (!in_array($term, ['First', 'Second'], true)) {
    dean_sem_json(['ok' => false, 'message' => 'Choose First Semester or Second Semester.'], 422);
}
if (!preg_match('/^(\d{4})-(\d{4})$/', (string)$ay, $m)) {
    dean_sem_json(['ok' => false, 'message' => 'Invalid academic year (use YYYY-YYYY, e.g. 2028-2029).'], 422);
}
if ((int)$m[2] !== (int)$m[1] + 1) {
    dean_sem_json(['ok' => false, 'message' => 'The academic year must be two consecutive years (e.g. 2028-2029).'], 422);
}
if (($_POST['confirm'] ?? '') !== '1') {
    dean_sem_json(['ok' => false, 'message' => 'Please confirm the semester change.'], 422);
}

$newSemester = $term . ' Semester, AY ' . $ay;

try {
    $pdo = csj_student_db();
    $deanName = (string)($_SESSION['dean_name'] ?? 'Dean');
    $oldSemester = csj_get_current_semester($pdo);

    // Nothing to do when the Dean re-selects the semester that is already active.
    if (strcasecmp(trim($oldSemester), $newSemester) === 0) {
        dean_sem_json(['ok' => true, 'changed' => false, 'semester' => $oldSemester,
                       'message' => 'That is already the current semester.']);
    }

    $result = csj_apply_semester_transition($pdo, $deanName, $oldSemester, $newSemester, 'manual');

    // The Dean who started it does not need the welcome popup.
    csj_welcome_mark_seen($pdo, 'dean', (string)$_SESSION['dean_id'], (string)$result['transitionId']);

    dean_sem_json([
        'ok' => true,
        'changed' => true,
        'semester' => $newSemester,
        'previousSemester' => $oldSemester,
        'clearedStudents' => $result['cleared'],
        'transitionId' => $result['transitionId'],
        'message' => 'New semester started: ' . $newSemester,
    ]);
} catch (Throwable $e) {
    error_log('dean_set_semester: ' . $e->getMessage());
    dean_sem_json(['ok' => false, 'message' => 'The semester could not be changed. Please try again.'], 500);
}
