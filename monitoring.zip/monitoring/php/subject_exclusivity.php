<?php
/**
 * One instructor per subject code per semester (exclusive Load Subject / signup).
 * Matching is normalized (CAP 102 === CAP102 === CAP102-1).
 */

if (!function_exists('csj_subject_norm_key')) {
    function csj_subject_norm_key(string $s): string {
        return strtolower(preg_replace('/[^a-z0-9]/i', '', trim($s)) ?? '');
    }
}

/**
 * Map of normalized subject key => ['code' => display code, 'instructor_key' => ..., 'instructor_name' => ...]
 * for subjects already claimed this semester by other instructors (or all if $excludeKey is null).
 *
 * @return array<string, array{code:string,instructor_key:string,instructor_name:string}>
 */
function csj_taken_subjects_for_semester(PDO $pdo, string $semester, ?string $excludeInstructorKey = null): array {
    $semester = trim($semester);
    if ($semester === '') return [];

    try {
        $sql = 'SELECT iss.subject_code, iss.instructor_key, COALESCE(ip.full_name, \'\') AS instructor_name
                FROM instructor_subject_selections iss
                LEFT JOIN instructor_profiles ip ON ip.instructor_key = iss.instructor_key
                WHERE iss.semester = ?';
        $params = [$semester];
        if ($excludeInstructorKey !== null && $excludeInstructorKey !== '') {
            $sql .= ' AND iss.instructor_key <> ?';
            $params[] = $excludeInstructorKey;
        }
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $out = [];
        while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
            $code = trim((string)($row['subject_code'] ?? ''));
            $k = csj_subject_norm_key($code);
            if ($k === '' || isset($out[$k])) continue;
            $out[$k] = [
                'code' => $code,
                'instructor_key' => (string)($row['instructor_key'] ?? ''),
                'instructor_name' => (string)($row['instructor_name'] ?? ''),
            ];
        }
        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

/**
 * Filter a list of subject codes: remove any already taken by another instructor.
 * Returns [allowed_codes, conflict_display_codes].
 *
 * @param string[] $codes
 * @return array{0: string[], 1: string[]}
 */
function csj_filter_exclusive_subjects(PDO $pdo, string $semester, array $codes, ?string $excludeInstructorKey = null): array {
    $taken = csj_taken_subjects_for_semester($pdo, $semester, $excludeInstructorKey);
    $allowed = [];
    $conflicts = [];
    $seen = [];
    foreach ($codes as $raw) {
        $code = trim((string)$raw);
        if ($code === '') continue;
        $k = csj_subject_norm_key($code);
        if ($k === '' || isset($seen[$k])) continue;
        $seen[$k] = true;
        if (isset($taken[$k])) {
            $conflicts[] = $taken[$k]['code'] ?: $code;
            continue;
        }
        $allowed[] = $code;
    }
    return [$allowed, $conflicts];
}
