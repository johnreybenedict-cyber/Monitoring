<?php
date_default_timezone_set('Asia/Manila');
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/audit.php';
$profileKey = csj_student_profile_key();

    

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Invalid submission.']);
    exit;
}

$profile = is_array($payload['profile'] ?? null) ? $payload['profile'] : [];
$studentId = trim((string)($profile['studentId'] ?? ''));
$studentName = trim((string)($profile['studentName'] ?? ''));
$courseYear = trim((string)($profile['courseYear'] ?? ''));
$email = trim((string)($profile['email'] ?? ''));
$chart = $payload['chart'] ?? null;

if ($studentName === '' || $courseYear === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Student Name and Course & Year are required.']);
    exit;
}
if (!is_array($chart) || !isset($chart['meta']) || !isset($chart['periods']) || !is_array($chart['periods'])) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Incomplete monitoring chart.']);
    exit;
}

$chart['meta']['studentName'] = $studentName;
$chart['meta']['courseYear'] = $courseYear;
try {
    $tmpPdo = csj_student_db();
    $officialSem = function_exists('csj_get_current_semester') ? csj_get_current_semester($tmpPdo) : null;
} catch (Throwable $e) {
    $officialSem = null;
}
$clientSem = trim((string)($chart['meta']['semester'] ?? ''));
// The server decides the semester, not the browser: a student keeps updating the sheet they
// already have, otherwise a NEW sheet is always created for the live semester. This stops an
// old tab (opened before the Dean started a new semester) from resurrecting last semester.
$existingSem = '';
try {
    $exStmt = $tmpPdo->prepare('SELECT semester FROM monitoring_submissions WHERE profile_key = ? ORDER BY updated_at DESC LIMIT 1');
    $exStmt->execute([$profileKey]);
    $existingSem = (string)($exStmt->fetchColumn() ?: '');
} catch (Throwable $e) {
    $existingSem = '';
}
$semester = $existingSem !== '' ? $existingSem
    : ($officialSem ?: ($clientSem !== '' ? $clientSem : 'First Semester, AY 2026-2027'));
$chart['meta']['semester'] = $semester;

// Guarantee prelims/midterms/finals all exist and are well-formed, no
// matter what the browser sent.
$chart['periods'] = csj_normalize_periods($chart);
foreach ($chart['periods'] as &$periodData) {
    if (!is_array($periodData['subjects'] ?? null)) continue;
    // (client-sent deanApproved is never trusted; stored approvals are restored below)
    foreach ($periodData['subjects'] as &$subject) {
        if (!is_array($subject)) continue;
        $subject['approved'] = false;
        $subject['reviewStatus'] = 'pending';
        $subject['instructor'] = '';
        unset($subject['approvedAt'], $subject['reviewedBy'], $subject['reviewedAt']);
    }
    unset($subject);
}
unset($periodData);

// Anti-copy helpers. Students may type freely; only exact copies of
// another student's entry under the *same subject code* are blocked.
function norm_code(string $s): string {
    return strtolower(preg_replace('/\s+/', '', trim($s)));
}
function csj_norm_entry_text(string $s): string {
    return strtolower(preg_replace('/\s+/', ' ', trim($s)));
}
function csj_is_placeholder_entry(string $norm): bool {
    return $norm === '' || (bool)preg_match('/^what i learned\.?\.?\.?$/i', $norm);
}

/**
 * True if the text has a capital letter that is NOT:
 *  - the very first letter of the cell, or
 *  - the first letter after "." or "," (start of a new sentence/clause).
 * Examples blocked: "I love yoU", "learNed", "ALL CAPS mid word".
 */
function csj_cell_text_has_disallowed_capital(string $text): bool {
    $text = trim($text);
    if ($text === '') return false;
    // Prefer mb_* when available; fall back to byte-safe ASCII loop for XAMPP builds without mbstring.
    $useMb = function_exists('mb_strlen') && function_exists('mb_substr') && function_exists('mb_strtolower');
    $len = $useMb ? mb_strlen($text, 'UTF-8') : strlen($text);
    $seenLetter = false;
    for ($i = 0; $i < $len; $i++) {
        $ch = $useMb ? mb_substr($text, $i, 1, 'UTF-8') : $text[$i];
        if (!preg_match('/[A-Za-z]/', $ch)) continue;
        $lower = $useMb ? mb_strtolower($ch, 'UTF-8') : strtolower($ch);
        if ($ch === $lower) { $seenLetter = true; continue; }
        // Uppercase letter
        if (!$seenLetter) { $seenLetter = true; continue; } // first letter of cell
        $j = $i - 1;
        while ($j >= 0) {
            $pj = $useMb ? mb_substr($text, $j, 1, 'UTF-8') : $text[$j];
            if ($pj !== ' ') break;
            $j--;
        }
        $prev = $j >= 0 ? ($useMb ? mb_substr($text, $j, 1, 'UTF-8') : $text[$j]) : '';
        if ($prev === '.' || $prev === ',') { $seenLetter = true; continue; }
        return true;
    }
    return false;
}

/**
 * True when a comma or period is glued to the next letter with no space.
 * e.g. "Hello,John" should be "Hello, John".
 */
function csj_cell_text_missing_space_after_punct(string $text): bool {
    $text = trim($text);
    if ($text === '') return false;
    return (bool)preg_match('/[A-Za-z0-9][,.][A-Za-z]/', $text);
}


// Capital-letter honesty check: capitals only allowed as the first letter
// of the cell or right after "." / ",". Blocks e.g. "I love yoU".
foreach ($chart['periods'] as $periodData) {
    foreach ((array)($periodData['rows'] ?? []) as $row) {
        foreach ((array)($row['entries'] ?? []) as $entryText) {
            $raw = trim((string)$entryText);
            if ($raw === '' || preg_match('/^what i learned\.?\.?\.?$/i', $raw)) continue;
            if (csj_cell_text_has_disallowed_capital($raw) || csj_cell_text_missing_space_after_punct($raw)) {
                http_response_code(422);
                echo json_encode([
                    'ok' => false,
                    'message' => "Don't copy what others have learned lets be honest what you have learned",
                    'copiedText' => $raw,
                    'reason' => 'honesty_format',
                ]);
                exit;
            }
        }
    }
}

// Subject codes must match the official catalog (empty is allowed).

$csjCatalog = [];
$catalogPath = __DIR__ . '/subjects_catalog.php';
if (is_file($catalogPath)) {
    $loaded = include $catalogPath;
    if (is_array($loaded)) {
        foreach ($loaded as $c) {
            $csjCatalog[strtolower(preg_replace('/\s+/', '', (string)$c))] = true;
        }
    }
}
if (!empty($csjCatalog)) {
    foreach ($chart['periods'] as $periodData) {
        foreach ((array)($periodData['subjects'] ?? []) as $subj) {
            $code = trim((string)($subj['code'] ?? ''));
            if ($code === '') continue;
            $normCode = strtolower(preg_replace('/\s+/', '', $code));
            if (!isset($csjCatalog[$normCode])) {
                http_response_code(422);
                echo json_encode(['ok' => false, 'message' => 'Your subject code is wrong, please enter your Subject code.']);
                exit;
            }
        }
    }
}

try {
    $pdo = csj_student_db();

    // Drop legacy global unique indexes on subjectN_text_key if present.
    // Those keys blocked identical text even for different subject codes.
    $indexNames = [];
    for ($i = 1; $i <= 9; $i++) {
        $indexNames[] = "uq_prelim_s{$i}_text";
        $indexNames[] = "uq_midterm_s{$i}_text";
        $indexNames[] = "uq_final_s{$i}_text";
    }
    foreach (['TblPrelim', 'TblMidTerm', 'TblFinal'] as $tbl) {
        foreach ($indexNames as $idxName) {
            try { $pdo->exec("ALTER TABLE `$tbl` DROP INDEX `$idxName`"); } catch (Throwable $ignored) {}
        }
    }

    // Cross-student copy check scoped to the SAME subject code.
    // Key = normalizedSubjectCode + "\0" + normalizedEntryText
    // Same subject code + same learning text is blocked across all other students
    // (not limited to an exact semester string, so AY label differences cannot bypass honesty).
    $otherStmt = $pdo->prepare('SELECT chart_json FROM monitoring_submissions WHERE profile_key != ?');
    $otherStmt->execute([$profileKey]);
    $takenBySubject = [];
    while ($otherJson = $otherStmt->fetchColumn()) {
        $otherChart = json_decode((string)$otherJson, true);
        if (!is_array($otherChart)) continue;
        $otherPeriods = csj_normalize_periods($otherChart);
        foreach ($otherPeriods as $periodData) {
            $codeById = [];
            foreach ((array)($periodData['subjects'] ?? []) as $s) {
                $id = (string)((int)($s['id'] ?? 0));
                $c = norm_code((string)($s['code'] ?? ''));
                if ($id !== '0' && $c !== '') $codeById[$id] = $c;
            }
            foreach ((array)($periodData['rows'] ?? []) as $row) {
                foreach ((array)($row['entries'] ?? []) as $sid => $entryText) {
                    $code = $codeById[(string)$sid] ?? '';
                    if ($code === '') continue;
                    $norm = csj_norm_entry_text((string)$entryText);
                    if (csj_is_placeholder_entry($norm) || $norm === '') continue;
                    $takenBySubject[$code . "\0" . $norm] = true;
                }
            }
        }
    }
    foreach ($chart['periods'] as $periodData) {
        $codeById = [];
        foreach ((array)($periodData['subjects'] ?? []) as $s) {
            $id = (string)((int)($s['id'] ?? 0));
            $c = norm_code((string)($s['code'] ?? ''));
            if ($id !== '0' && $c !== '') $codeById[$id] = $c;
        }
        foreach ((array)($periodData['rows'] ?? []) as $row) {
            foreach ((array)($row['entries'] ?? []) as $sid => $entryText) {
                $code = $codeById[(string)$sid] ?? '';
                if ($code === '') continue;
                $norm = csj_norm_entry_text((string)$entryText);
                if (csj_is_placeholder_entry($norm) || $norm === '') continue;
                if (isset($takenBySubject[$code . "\0" . $norm])) {
                    http_response_code(422);
                    echo json_encode([
                        'ok' => false,
                        'message' => "Don't copy what others have learned lets be honest what you have learned",
                        'copiedText' => (string)$entryText,
                        'subjectCode' => $code,
                    ]);
                    exit;
                }
            }
        }
    }

    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'INSERT INTO student_profiles (profile_key, student_id, student_name, course_year, email)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           student_id = VALUES(student_id),
           student_name = VALUES(student_name),
           course_year = VALUES(course_year),
           email = VALUES(email),
           updated_at = CURRENT_TIMESTAMP'
    );
    $stmt->execute([$profileKey, $studentId !== '' ? $studentId : null, $studentName, $courseYear, $email !== '' ? $email : null]);

    // Keep the existing account synchronized. Email is only profile/contact data;
    // it is not verified and is never used to block login.
    $aStmt = $pdo->prepare('SELECT account_id FROM student_accounts WHERE profile_key = ? LIMIT 1');
    $aStmt->execute([$profileKey]);
    $accountId = $aStmt->fetchColumn();
    if ($accountId) {
        $pdo->prepare('UPDATE student_accounts SET email=?, student_id=?, updated_at=CURRENT_TIMESTAMP WHERE account_id=?')->execute([$email !== '' ? $email : null, $studentId !== '' ? $studentId : null, $accountId]);
    }

    // Critical: merge the existing DB chart first so staff review decisions
    // can never be forged or erased by a later student Submit.
    // This is done PER PERIOD (Prelims/Midterms/Finals are matched and
    // merged independently) so an approval on one sheet never leaks onto
    // another sheet's matching subject code.
    $oldStmt = $pdo->prepare('SELECT chart_json FROM monitoring_submissions WHERE profile_key = ? AND semester = ? LIMIT 1 FOR UPDATE');
    $oldStmt->execute([$profileKey, $semester]);
    $oldJson = $oldStmt->fetchColumn();

    if ($oldJson !== false) {
        $oldChart = json_decode($oldJson, true);
        if (is_array($oldChart)) {
            $oldPeriods = csj_normalize_periods($oldChart);
            foreach ($chart['periods'] as $periodKey => &$periodData) {
                if (empty($periodData['subjects']) || empty($oldPeriods[$periodKey]['subjects'])) continue;

                $oldByCode = [];
                foreach ($oldPeriods[$periodKey]['subjects'] as $oldSubject) {
                    $code = norm_code((string)($oldSubject['code'] ?? ''));
                    if ($code !== '') $oldByCode[$code] = $oldSubject;
                }

                foreach ($periodData['subjects'] as &$newSubject) {
                    $code = norm_code((string)($newSubject['code'] ?? ''));
                    if ($code !== '' && isset($oldByCode[$code])) {
                        $oldSubject = $oldByCode[$code];
                        $reviewStatus = (string)($oldSubject['reviewStatus'] ?? '');
                        if (!in_array($reviewStatus, ['approved', 'denied', 'pending'], true)) {
                            $reviewStatus = !empty($oldSubject['approved']) ? 'approved' : 'pending';
                        }
                        $newSubject['reviewStatus'] = $reviewStatus;
                        $newSubject['approved'] = $reviewStatus === 'approved';
                        $newSubject['instructor'] = (string)($oldSubject['instructor'] ?? '');
                        if (isset($oldSubject['approvedAt'])) $newSubject['approvedAt'] = $oldSubject['approvedAt'];
                        else unset($newSubject['approvedAt']);
                        if (isset($oldSubject['reviewedBy'])) $newSubject['reviewedBy'] = $oldSubject['reviewedBy'];
                        else unset($newSubject['reviewedBy']);
                        if (isset($oldSubject['reviewedAt'])) $newSubject['reviewedAt'] = $oldSubject['reviewedAt'];
                        else unset($newSubject['reviewedAt']);
                    }
                }
                unset($newSubject);
            }
            unset($periodData);
        }
    }


    // ------------------------------------------------------------------
    // Sequence lock (Prelims -> Midterms -> Finals), decided ONLY from what
    // the database already holds. The browser can never grant itself access
    // or forge a Dean approval.
    // ------------------------------------------------------------------
    $storedChartForGate = (isset($oldChart) && is_array($oldChart)) ? $oldChart : [];
    if (!$storedChartForGate) {
        $latestStmt = $pdo->prepare('SELECT chart_json FROM monitoring_submissions WHERE profile_key = ? ORDER BY updated_at DESC LIMIT 1');
        $latestStmt->execute([$profileKey]);
        $latestJson = $latestStmt->fetchColumn();
        $decodedLatest = $latestJson ? json_decode((string)$latestJson, true) : null;
        if (is_array($decodedLatest)) $storedChartForGate = $decodedLatest;
    }
    $storedPeriodsForGate = csj_normalize_periods($storedChartForGate);
    $periodAccess = csj_period_access($storedPeriodsForGate);
    foreach (['prelims', 'midterms', 'finals'] as $gateKey) {
        if (!isset($chart['periods'][$gateKey]) || !is_array($chart['periods'][$gateKey])) {
            $chart['periods'][$gateKey] = $storedPeriodsForGate[$gateKey];
        }
        if (empty($periodAccess[$gateKey])) {
            // Locked period: ignore everything the browser sent for it.
            $chart['periods'][$gateKey] = $storedPeriodsForGate[$gateKey];
        }
        // Approval flags always come from the database.
        $chart['periods'][$gateKey]['deanApproved'] = !empty($storedPeriodsForGate[$gateKey]['deanApproved']);
        if (!empty($storedPeriodsForGate[$gateKey]['deanApproved'])) {
            $chart['periods'][$gateKey]['deanApprovedBy'] = (string)($storedPeriodsForGate[$gateKey]['deanApprovedBy'] ?? '');
            $chart['periods'][$gateKey]['deanApprovedAt'] = (string)($storedPeriodsForGate[$gateKey]['deanApprovedAt'] ?? '');
        } else {
            $chart['periods'][$gateKey]['deanApprovedBy'] = '';
            $chart['periods'][$gateKey]['deanApprovedAt'] = '';
        }
    }
    
    // Keep Dean-approved periods exactly as last saved (student cannot edit those periods)
    try {
        $prevStmt = $pdo->prepare(
            'SELECT chart_json FROM monitoring_submissions WHERE profile_key = ? ORDER BY updated_at DESC LIMIT 1'
        );
        $prevStmt->execute([$profileKey]);
        $prevJson = $prevStmt->fetchColumn();
        if ($prevJson) {
            $prevChart = json_decode((string)$prevJson, true);
            if (is_array($prevChart) && !empty($prevChart['periods']) && is_array($prevChart['periods'])) {
                foreach ($prevChart['periods'] as $pk => $prevPeriod) {
                    if (is_array($prevPeriod) && !empty($prevPeriod['deanApproved'])) {
                        $chart['periods'][$pk] = $prevPeriod;
                    }
                }
            }
        }
    } catch (Throwable $e) { /* ignore */ }

    
    // Preserve Dean-approved periods (student cannot change Prelims/Midterms/Finals after approval)
    try {
        $prevStmt = $pdo->prepare(
            'SELECT chart_json FROM monitoring_submissions WHERE profile_key = ? ORDER BY updated_at DESC LIMIT 1'
        );
        $prevStmt->execute([$profileKey]);
        $prevJson = $prevStmt->fetchColumn();
        if ($prevJson) {
            $prevChart = json_decode((string)$prevJson, true);
            if (is_array($prevChart) && !empty($prevChart['periods']) && is_array($prevChart['periods'])) {
                if (!isset($chart['periods']) || !is_array($chart['periods'])) {
                    $chart['periods'] = [];
                }
                foreach (['prelims', 'midterms', 'finals'] as $pk) {
                    $prevPer = $prevChart['periods'][$pk] ?? null;
                    if (is_array($prevPer) && !empty($prevPer['deanApproved'])) {
                        $chart['periods'][$pk] = $prevPer; // keep approved snapshot
                    }
                }
            }
        }
    } catch (Throwable $e) { /* ignore */ }
    // deanApproved periods must not be overwritten by the student client
$chartJson = json_encode($chart, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($chartJson === false) throw new RuntimeException('Could not encode monitoring chart.');

    $stmt = $pdo->prepare(
        'INSERT INTO monitoring_submissions (profile_key, semester, student_name, course_year, chart_json)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           student_name = VALUES(student_name),
           course_year = VALUES(course_year),
           chart_json = VALUES(chart_json),
           updated_at = CURRENT_TIMESTAMP'
    );
    $stmt->execute([$profileKey, $semester, $studentName, $courseYear, $chartJson]);

    // Mirror each period into its own plain SQL table (TblPrelim / TblMidTerm /
    // TblFinal) -- one row per review event, one column pair (code + text) per
    // subject slot 1..9. This is purely a queryable mirror of $chart['periods'];
    // monitoring_submissions above stays the source of truth the page reads from.
    $periodTableMap = [
        'prelims'  => 'TblPrelim',
        'midterms' => 'TblMidTerm',
        'finals'   => 'TblFinal',
    ];

    foreach ($periodTableMap as $periodKey => $table) {
        $periodData = $chart['periods'][$periodKey] ?? null;
        if (!is_array($periodData)) continue;

        $codeBySubject = [];
        foreach ((array)($periodData['subjects'] ?? []) as $s) {
            $codeBySubject[(int)($s['id'] ?? 0)] = (string)($s['code'] ?? '');
        }

        foreach ((array)($periodData['rows'] ?? []) as $row) {
            $event = (int)($row['event'] ?? 0);
            if ($event < 1 || $event > 6) continue;
            $entries = (array)($row['entries'] ?? []);

            $cols = ['profile_key', 'student_id', 'student_name', 'course_year', 'semester', 'review_event'];
            $vals = [$profileKey, $studentId !== '' ? $studentId : null, $studentName, $courseYear, $semester, $event];

            for ($i = 1; $i <= 9; $i++) {
                $cols[] = "subject{$i}_code";
                $cols[] = "subject{$i}_text";
                $vals[] = $codeBySubject[$i] ?? '';
                $vals[] = (string)($entries[(string)$i] ?? '');
            }

            $delStmt = $pdo->prepare(
                "DELETE FROM `$table` WHERE profile_key = ? AND semester = ? AND review_event = ?"
            );
            $delStmt->execute([$profileKey, $semester, $event]);

            $colSql = '`' . implode('`, `', $cols) . '`';
            $placeholders = implode(',', array_fill(0, count($vals), '?'));

            $rowStmt = $pdo->prepare("INSERT INTO `$table` ($colSql) VALUES ($placeholders)");
            $rowStmt->execute($vals);
        }
    }

    $entryCount = 0;
    foreach ($chart['periods'] as $periodData) {
        foreach ((array)($periodData['rows'] ?? []) as $row) {
            foreach ((array)($row['entries'] ?? []) as $entryText) {
                if (trim((string)$entryText) !== '') $entryCount++;
            }
        }
    }
    csj_audit_log(
        $pdo,
        'student_submission',
        'student',
        $profileKey,
        $studentName,
        ['semester' => $semester, 'non_empty_entry_count' => $entryCount],
        'student',
        $profileKey,
        $studentName
    );
    $pdo->commit();

    // NOTE: this used to also file_put_contents() the just-saved chart into
    // the single shared data/chart.json file. That file is read as a
    // fallback template by student.php and php/load.php for any student who
    // doesn't have a row in monitoring_submissions yet (e.g. a brand-new
    // sign-up before their first Submit). Because the write above was not
    // scoped to a particular student, whichever student saved last would
    // overwrite that shared file with THEIR name, subjects, and entries --
    // and every other/new student would then see that leftover content
    // until they saved their own chart. Each student's actual data already
    // lives correctly in monitoring_submissions (scoped by profile_key +
    // semester); data/chart.json is only meant to be the blank starting
    // template, so it must never be overwritten with a real submission.

    echo json_encode(['ok' => true, 'message' => 'Submitted successfully to MySQL.', 'savedAt' => date('Y-m-d H:i:s')]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    // The TblPrelim/TblMidTerm/TblFinal subjectN_text_key UNIQUE keys are a
    // database-level safety net for the cross-student duplicate check above
    // (it closes the tiny race window where two students submit the exact
    // same text at the exact same instant). Surface that the same way.
    // Only the text-uniqueness keys (uq_*_sN_text) mean "copied answer"; any
    // other duplicate (e.g. a Student ID already used) is a different problem
    // and must not be reported as copying.
    if ($e instanceof PDOException && $e->getCode() === '23000' && strpos($e->getMessage(), '_text') !== false) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'message' => "Don't copy what others have learned lets be honest what you have learned"]);
        exit;
    }
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'MySQL submission failed. Start MySQL in XAMPP and import schema.sql.']);
}
