<?php
/**
 * Resolve subject codes for a student based on program / year / major / semester.
 * Returns codes WITHOUT section suffix (no -1).
 */

function csj_normalize_program_key(string $program): string {
    $u = strtoupper(preg_replace('/\s+/', '', $program));
    if ($u === 'BEED') return 'BEEd';
    if ($u === 'BSED') return 'BSEd';
    if ($u === 'BSBA') return 'BSBA';
    if ($u === 'BSIT') return 'BSIT';
    return $program;
}

function csj_normalize_year_key(string $year): string {
    $y = strtolower(trim($year));
    if (in_array($y, ['1', '1st', 'first', 'year 1', '1st year'], true)) return '1st';
    if (in_array($y, ['2', '2nd', 'second', 'year 2', '2nd year'], true)) return '2nd';
    if (in_array($y, ['3', '3rd', 'third', 'year 3', '3rd year'], true)) return '3rd';
    if (in_array($y, ['4', '4th', 'fourth', 'year 4', '4th year'], true)) return '4th';
    // also accept "BSIT 1", "BSBA 4" style from course_year
    if (preg_match('/\b(1st|2nd|3rd|4th)\b/i', $year, $m)) {
        return strtolower($m[1]);
    }
    if (preg_match('/\b([1-4])\b/', $year, $m)) {
        $map = ['1' => '1st', '2' => '2nd', '3' => '3rd', '4' => '4th'];
        return $map[$m[1]] ?? '';
    }
    return '';
}

/** Detect first vs second semester term from semester label string. */
function csj_semester_term(string $semesterLabel): string {
    $s = strtolower($semesterLabel);
    if (strpos($s, 'second') !== false || strpos($s, '2nd') !== false) return '2';
    return '1'; // default First Semester
}

/**
 * Strip section suffix like -1, -2 from a code and insert a space before digits when missing.
 * "CC101-1" → "CC 101", "SSci 101-1" → "SSci 101", "EDUC412-1" → "EDUC 412"
 */
function csj_strip_section_code(string $code): string {
    $code = trim($code);
    if ($code === '') return '';
    // remove trailing -digits (section)
    $code = preg_replace('/-\d+$/', '', $code) ?? $code;
    // if no space between letters and digits, insert one: EDUC412 → EDUC 412
    if (!preg_match('/\s/', $code) && preg_match('/^([A-Za-z][A-Za-z.\-]*)(\d.*)$/', $code, $m)) {
        $code = $m[1] . ' ' . $m[2];
    }
    return trim($code);
}

/**
 * Base code key for comparisons: uppercase, no spaces, no section suffix.
 * "SSci 101-1" and "SSCI101" → "SSCI101"
 */
function csj_code_base_key(string $code): string {
    $c = csj_strip_section_code($code);
    return strtoupper(preg_replace('/\s+/', '', $c) ?? '');
}

/**
 * @return string[] list of display codes for the student combobox
 */
function csj_curriculum_codes_for_student(
    string $program,
    string $yearLevel,
    string $major,
    string $semesterLabel
): array {
    static $catalog = null;
    if ($catalog === null) {
        $file = __DIR__ . '/curriculum_catalog.php';
        $catalog = is_file($file) ? (include $file) : [];
        if (!is_array($catalog)) $catalog = [];
    }

    $prog = csj_normalize_program_key($program);
    $year = csj_normalize_year_key($yearLevel);
    // try parse year from course_year-like strings if year empty
    if ($year === '' && $yearLevel !== '') {
        $year = csj_normalize_year_key($yearLevel);
    }
    $term = csj_semester_term($semesterLabel);
    $major = trim($major);

    if ($prog === '' || $year === '' || !isset($catalog[$prog][$year])) {
        return [];
    }

    $yearNode = $catalog[$prog][$year];

    // Prefer major-specific block when present
    if ($major !== '' && isset($yearNode[$major]) && is_array($yearNode[$major])) {
        $termNode = $yearNode[$major][$term] ?? $yearNode[$major]['1'] ?? [];
        if (is_array($termNode) && $termNode !== [] && array_keys($termNode) === range(0, count($termNode) - 1)) {
            return array_values(array_map('strval', $termNode));
        }
    }

    // Shared term list
    $termNode = $yearNode[$term] ?? [];
    if (is_array($termNode) && $termNode !== [] && array_keys($termNode) === range(0, count($termNode) - 1)) {
        return array_values(array_map('strval', $termNode));
    }

    return [];
}

/**
 * All subject codes for a program + major across years 1st–4th and both semesters.
 * Used when enrollment status is irregular.
 *
 * @return string[]
 */
function csj_curriculum_codes_all_years_for_program(string $program, string $major): array {
    static $catalog = null;
    if ($catalog === null) {
        $file = __DIR__ . '/curriculum_catalog.php';
        $catalog = is_file($file) ? (include $file) : [];
        if (!is_array($catalog)) $catalog = [];
    }

    $prog = csj_normalize_program_key($program);
    $major = trim($major);
    if ($prog === '' || !isset($catalog[$prog]) || !is_array($catalog[$prog])) {
        return [];
    }

    $out = [];
    $years = ['1st', '2nd', '3rd', '4th'];
    $terms = ['1', '2'];

    foreach ($years as $year) {
        if (!isset($catalog[$prog][$year]) || !is_array($catalog[$prog][$year])) {
            continue;
        }
        $yearNode = $catalog[$prog][$year];

        foreach ($terms as $term) {
            $termNode = null;
            // Prefer major-specific when present
            if ($major !== '' && isset($yearNode[$major]) && is_array($yearNode[$major])) {
                $termNode = $yearNode[$major][$term] ?? null;
            }
            if (!is_array($termNode)) {
                $termNode = $yearNode[$term] ?? null;
            }
            if (is_array($termNode) && $termNode !== [] && array_keys($termNode) === range(0, count($termNode) - 1)) {
                foreach ($termNode as $code) {
                    if (is_string($code) && $code !== '') {
                        $out[] = $code;
                    }
                }
            }
        }
    }
    return $out;
}

/**
 * Flat unique list of ALL curriculum codes (for fallback validation).
 */
function csj_all_curriculum_codes(): array {
    static $flat = null;
    if ($flat !== null) return $flat;
    $file = __DIR__ . '/curriculum_catalog.php';
    $catalog = is_file($file) ? (include $file) : [];
    if (!is_array($catalog)) $catalog = [];
    $out = [];
    $walk = function ($node) use (&$walk, &$out) {
        if (!is_array($node)) return;
        // list of strings?
        $isList = $node !== [] && array_keys($node) === range(0, count($node) - 1);
        if ($isList) {
            foreach ($node as $v) {
                if (is_string($v) && $v !== '') $out[$v] = true;
            }
            return;
        }
        foreach ($node as $v) $walk($v);
    };
    $walk($catalog);
    $flat = array_keys($out);
    sort($flat);
    return $flat;
}

/**
 * Build student combobox list:
 * 1) curriculum-filtered codes for program/year/major/semester when available
 * 2) else full curriculum codes
 * 3) else legacy subjects_catalog.php with section stripped
 */
function csj_student_subject_code_options(
    string $program,
    string $yearLevel,
    string $major,
    string $semesterLabel,
    string $enrollmentStatus = ''
): array {
    $status = strtolower(trim($enrollmentStatus));
    // Irregular: all years (1st–4th) for this Course + Major only
    if ($status === 'irregular') {
        $codes = csj_curriculum_codes_all_years_for_program($program, $major);
    } else {
        // Regular (default): only current year + current semester for Course + Major
        $codes = csj_curriculum_codes_for_student($program, $yearLevel, $major, $semesterLabel);
    }
    if ($codes === []) {
        $codes = csj_all_curriculum_codes();
    }
    if ($codes === []) {
        $legacy = __DIR__ . '/subjects_catalog.php';
        if (is_file($legacy)) {
            $loaded = include $legacy;
            if (is_array($loaded)) {
                foreach ($loaded as $c) {
                    $codes[] = csj_strip_section_code((string)$c);
                }
            }
        }
    }
    // unique preserve order
    $seen = [];
    $out = [];
    foreach ($codes as $c) {
        $c = csj_strip_section_code((string)$c);
        if ($c === '') continue;
        $k = csj_code_base_key($c);
        if ($k === '' || isset($seen[$k])) continue;
        $seen[$k] = true;
        $out[] = $c;
    }
    return $out;
}
