<?php
require_once __DIR__ . '/../config.php';

function csj_db(): PDO {
    return csj_student_db();
}
