<?php
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ob_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/auth_common.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../mail_config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/** Login identity: allow only safe ID characters (blocks SQL injection payloads). */
function csj_sanitize_login_identity(string $raw): string {
    return csj_clean_identity($raw);   // php/security.php: whitelist + SQL-injection pattern check
}

function valid_email_or_fail(string $email): void { if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Please enter a valid email address.'); }
function password_ok(string $p): void { if (strlen($p) < 8) throw new RuntimeException('Password must be at least 8 characters.'); }

function ensure_student_phone_table(PDO $pdo): void {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS student_phone_numbers (
            phone_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            profile_key CHAR(32) NOT NULL,
            phone_number VARCHAR(30) NOT NULL,
            is_primary TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (phone_id),
            UNIQUE KEY uq_profile_phone (profile_key, phone_number),
            KEY idx_phone_profile (profile_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

function normalize_phone(string $phone): string {
    $phone = trim($phone);
    if ($phone === '') return '';
    // Keep digits only (and a leading + if present)
    $phone = preg_replace('/[^0-9+]/', '', $phone) ?? '';
    // Strip leading 00 international prefix → +
    if (str_starts_with($phone, '00')) $phone = '+' . substr($phone, 2);
    // Philippine local formats → E.164
    if (preg_match('/^09[0-9]{9}$/', $phone)) {
        $phone = '+63' . substr($phone, 1);
    } elseif (preg_match('/^9[0-9]{9}$/', $phone)) {
        $phone = '+63' . $phone;
    } elseif (preg_match('/^639[0-9]{9}$/', $phone)) {
        $phone = '+' . $phone;
    }
    if (!preg_match('/^\+[0-9]{7,15}$/', $phone)) {
        throw new RuntimeException('Enter a valid phone number, e.g. 09171234567.');
    }
    return $phone;
}

/** Display form for PH numbers: +63917… → 0917… */
function format_phone_display(string $phone): string {
    $phone = trim($phone);
    if ($phone === '') return '';
    if (preg_match('/^\+63([0-9]{10})$/', $phone, $m)) return '0' . $m[1];
    return $phone;
}
try {
    $pdo = csj_student_db();
    try { $pdo->exec('ALTER TABLE student_profiles ADD COLUMN contact_no VARCHAR(50) DEFAULT NULL'); } catch (Throwable $ignored) {}
    try { ensure_student_phone_table($pdo); } catch (Throwable $ignored) {}
    try { $pdo->exec('ALTER TABLE instructor_profiles ADD COLUMN teacher_id VARCHAR(50) DEFAULT NULL'); } catch (Throwable $ignored) {}
    try { $pdo->exec('ALTER TABLE instructor_profiles ADD COLUMN program VARCHAR(150) DEFAULT NULL'); } catch (Throwable $ignored) {}
    try { $pdo->exec('ALTER TABLE instructor_profiles ADD COLUMN address VARCHAR(255) DEFAULT NULL'); } catch (Throwable $ignored) {}
    try { $pdo->exec('ALTER TABLE instructor_profiles ADD COLUMN contact_no VARCHAR(50) DEFAULT NULL'); } catch (Throwable $ignored) {}
    try { $pdo->exec('ALTER TABLE instructor_profiles ADD COLUMN password_hash VARCHAR(255) DEFAULT NULL'); } catch (Throwable $ignored) {}
    
    $action = $_GET['action'] ?? '';
    $d = csj_json_input();

    if ($action === 'signup') {
        $studentId=csj_sanitize_login_identity((string)($d['studentId']??''));
        $name=csj_clean_person_name((string)($d['studentName']??''));
        $course=csj_clean_plain_field((string)($d['courseYear']??''),100);
        $email=strtolower(trim((string)($d['email']??'')));
        $pass=(string)($d['password']??'');
        $program=strtoupper(trim((string)($d['program']??'')));
        $yearRaw=trim((string)($d['yearLevel']??''));
        $major=trim((string)($d['major']??''));
        $status=strtolower(trim((string)($d['enrollmentStatus']??'')));

        // Normalize year level labels (1 → 1st, etc.)
        $yearMap = ['1'=>'1st','2'=>'2nd','3'=>'3rd','4'=>'4th','1st'=>'1st','2nd'=>'2nd','3rd'=>'3rd','4th'=>'4th'];
        $yearLevel = $yearMap[$yearRaw] ?? '';

        // Normalize program codes
        if ($program === 'BEED') $program = 'BEED';
        if ($program === 'BSED') $program = 'BSEd';

        // Major rules (match Dean Student Profile)
        $majorsByProgram = [
            'BSBA' => ['Operations Management', 'Financial Management'],
            'BSEd' => ['English', 'Filipino'],
            'BSED' => ['English', 'Filipino'],
        ];
        $allowedMajors = $majorsByProgram[$program] ?? [];
        if ($allowedMajors) {
            if ($major === '' || !in_array($major, $allowedMajors, true)) {
                throw new RuntimeException('Please select a valid major for ' . $program . '.');
            }
        } else {
            $major = ''; // BEED / BSIT have no major
        }

        if ($status !== '' && !in_array($status, ['regular', 'irregular'], true)) {
            throw new RuntimeException('Status must be Regular or Irregular.');
        }
        if ($status === '') $status = 'regular';

        if ($studentId===''||$name===''||$course==='') throw new RuntimeException('Student ID, Student Name and Course & Year are required.');
        valid_email_or_fail($email); password_ok($pass); csj_assert_password_unique($pdo, $pass);
        $stmt=$pdo->prepare('SELECT COUNT(*) FROM student_accounts WHERE student_id=?'); $stmt->execute([$studentId]); if((int)$stmt->fetchColumn()>0) throw new RuntimeException('That Student ID is already registered.');
        if ($email!=='') { $stmt=$pdo->prepare('SELECT COUNT(*) FROM student_accounts WHERE email=?'); $stmt->execute([$email]); if((int)$stmt->fetchColumn()>0) throw new RuntimeException('That email is already registered.'); }
        $hash=password_hash($pass,PASSWORD_DEFAULT); $profileKey=bin2hex(random_bytes(16));

        // Self-heal columns on older XAMPP databases
        try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN program VARCHAR(20) DEFAULT NULL"); } catch (Throwable $ignored) {}
        try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN year_level VARCHAR(20) DEFAULT NULL"); } catch (Throwable $ignored) {}
        try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN enrollment_status VARCHAR(20) DEFAULT NULL"); } catch (Throwable $ignored) {}
        try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN major VARCHAR(80) DEFAULT NULL"); } catch (Throwable $ignored) {}

        $pdo->beginTransaction();
        $st=$pdo->prepare(
            'INSERT INTO student_profiles(profile_key,student_id,student_name,course_year,email,program,year_level,enrollment_status,major)
             VALUES(?,?,?,?,?,?,?,?,?)'
        );
        $st->execute([
            $profileKey,
            $studentId,
            $name,
            $course,
            $email?:null,
            $program !== '' ? $program : null,
            $yearLevel !== '' ? $yearLevel : null,
            $status !== '' ? $status : null,
            $major !== '' ? $major : null,
        ]);
        $st=$pdo->prepare('INSERT INTO student_accounts(profile_key,student_id,email,password_hash) VALUES(?,?,?,?)');
        $st->execute([$profileKey,$studentId,$email !== '' ? $email : null,$hash]);
        csj_audit_log($pdo, 'student_signup', 'student', $profileKey, $name, [
            'student_id' => $studentId,
            'program' => $program,
            'year_level' => $yearLevel,
            'major' => $major,
            'enrollment_status' => $status,
        ], 'student', $profileKey, $name);
        $pdo->commit(); csj_set_login_session($profileKey, $name);
        echo json_encode(['ok'=>true,'message'=>'Account created successfully.','redirect'=>'student.php']); exit;
    }

    if ($action === 'instructor_signup') {
        $teacherId=csj_sanitize_login_identity((string)($d['teacherId']??''));
        $name=csj_clean_person_name((string)($d['fullName']??''));
        $email=strtolower(trim((string)($d['email']??'')));
        $pass=(string)($d['password']??'');
        if($teacherId===''||$name==='') throw new RuntimeException('Teacher ID and Full Name are required.');
        valid_email_or_fail($email); password_ok($pass); csj_assert_password_unique($pdo, $pass);
        $st=$pdo->prepare('SELECT COUNT(*) FROM instructor_profiles WHERE teacher_id=?'); $st->execute([$teacherId]);
        if((int)$st->fetchColumn()>0) throw new RuntimeException('That Teacher ID is already registered.');
        if($email!==''){ $st=$pdo->prepare('SELECT COUNT(*) FROM instructor_profiles WHERE email=?'); $st->execute([$email]); if((int)$st->fetchColumn()>0) throw new RuntimeException('That email is already registered.'); }
        $key=bin2hex(random_bytes(16)); $hash=password_hash($pass,PASSWORD_DEFAULT);
        $department = csj_clean_plain_field((string)($d['department'] ?? ''), 150);

        // Subjects the teacher picked in "Choose Subject(s) You Handle".
        // Only codes that really exist in the master catalog are accepted.
        $catalog = is_file(__DIR__ . '/subjects_catalog.php') ? require __DIR__ . '/subjects_catalog.php' : [];
        $catalog = is_array($catalog) ? array_map(static fn($c) => strtoupper(trim((string)$c)), $catalog) : [];
        $subjectsIn = $d['subjects'] ?? [];
        if (!is_array($subjectsIn)) $subjectsIn = [];
        $subjectsIn = array_values(array_unique(array_filter(array_map(static function ($c) {
            return strtoupper(trim((string)$c));
        }, $subjectsIn))));
        $subjectsIn = array_values(array_intersect($subjectsIn, $catalog));
        if (!$subjectsIn) throw new RuntimeException('Please click Load Subjects and choose at least one subject you handle.');

        // The LIVE semester, so the chosen subjects show on the Instructor Dashboard.
        // Read BEFORE the transaction: it may run CREATE TABLE IF NOT EXISTS (DDL = implicit commit).
        $semester = csj_signup_semester($pdo);
        $pdo->beginTransaction();
        $st=$pdo->prepare('INSERT INTO instructor_profiles(instructor_key,teacher_id,full_name,email,password_hash,program) VALUES(?,?,?,?,?,?)');
        $st->execute([$key,$teacherId,$name,$email?:null,$hash,$department!==''?$department:null]);
        // Subjects chosen at signup -> instructor_subject_selections (same table the dashboard reads)
        $insSub = $pdo->prepare(
            'INSERT IGNORE INTO instructor_subject_selections (instructor_key, subject_code, semester) VALUES (?, ?, ?)'
        );
        foreach ($subjectsIn as $code) {
            $insSub->execute([$key, $code, $semester]);
        }
        csj_audit_log($pdo, 'teacher_signup', 'teacher', $key, $name, ['teacher_id' => $teacherId, 'subjects' => $subjectsIn], 'teacher', $key, $name);
        $pdo->commit();
        session_regenerate_id(true);
        $_SESSION['instructor_authenticated']=true; $_SESSION['instructor_key']=$key;
        $_SESSION['instructor_name']=$name;
        unset(
            $_SESSION['student_authenticated'],
            $_SESSION['student_profile_key'],
            $_SESSION['student_name'],
            $_SESSION['dean_authenticated'],
            $_SESSION['dean_id'],
            $_SESSION['dean_name']
        );
        setcookie('csj_instructor_key',$key,['expires'=>time()+31536000,'path'=>'/','samesite'=>'Lax']);
        echo json_encode(['ok'=>true,'message'=>'Instructor account created successfully.','redirect'=>'instructor-dashboard.php']); exit;
    }

    if ($action === 'login') {
        $identity=strtolower(csj_sanitize_login_identity((string)($d['identity']??''))); $pass=(string)($d['password']??'');
        if($identity===''||$pass==='') throw new RuntimeException('Enter your Student ID or Teacher ID and password.');
        csj_login_throttle_check($pdo, $identity);   // too many recent failures? stop here

        $st=$pdo->prepare('SELECT dean_id,username,full_name,email,password_hash FROM dean_accounts WHERE LOWER(username)=? LIMIT 1');
        $st->execute([$identity]); $dean=$st->fetch();
        if($dean && password_verify($pass,$dean['password_hash'])){
            session_regenerate_id(true);
            $_SESSION = [
                'dean_authenticated' => true,
                'dean_id' => (int)$dean['dean_id'],
                'dean_name' => $dean['full_name'],
            ];
            setcookie('csj_student_profile_key','',time()-3600,'/');
            setcookie('csj_instructor_key','',time()-3600,'/');
            csj_login_throttle_clear($pdo, $identity);
            csj_audit_log($pdo, 'login', 'dean', (string)$dean['dean_id'], (string)$dean['full_name'], [], 'dean', (string)$dean['dean_id'], (string)$dean['full_name']);
            echo json_encode(['ok'=>true,'message'=>'Login successful.','redirect'=>'dean-dashboard.php','role'=>'dean']); exit;
        }

        $st=$pdo->prepare('SELECT a.*,p.student_name,p.course_year FROM student_accounts a JOIN student_profiles p ON p.profile_key COLLATE utf8mb4_unicode_ci = a.profile_key COLLATE utf8mb4_unicode_ci WHERE a.student_id COLLATE utf8mb4_unicode_ci = ? COLLATE utf8mb4_unicode_ci LIMIT 1');
        $st->execute([$identity]); $a=$st->fetch();
        if($a && password_verify($pass,$a['password_hash'])){
            csj_set_login_session($a['profile_key'], (string)$a['student_name']);
            csj_login_throttle_clear($pdo, $identity);
            csj_audit_log($pdo, 'login', 'student', (string)$a['profile_key'], (string)$a['student_name'], [], 'student', (string)$a['profile_key'], (string)$a['student_name']);
            echo json_encode(['ok'=>true,'message'=>'Login successful.','redirect'=>'student.php','role'=>'student']); exit;
        }

        $st=$pdo->prepare('SELECT instructor_key,teacher_id,full_name,email,password_hash FROM instructor_profiles WHERE LOWER(teacher_id)=? LIMIT 1');
        $st->execute([$identity]); $i=$st->fetch();
        if($i && !empty($i['password_hash']) && password_verify($pass,$i['password_hash'])){
            session_regenerate_id(true);
            $_SESSION['instructor_authenticated']=true; $_SESSION['instructor_key']=$i['instructor_key'];
            $_SESSION['instructor_name']=$i['full_name'];
            unset(
                $_SESSION['student_authenticated'],
                $_SESSION['student_profile_key'],
                $_SESSION['student_name'],
                $_SESSION['dean_authenticated'],
                $_SESSION['dean_id'],
                $_SESSION['dean_name']
            );
            setcookie('csj_instructor_key',$i['instructor_key'],['expires'=>time()+31536000,'path'=>'/','samesite'=>'Lax']);
            csj_login_throttle_clear($pdo, $identity);
            csj_audit_log($pdo, 'login', 'teacher', (string)$i['instructor_key'], (string)$i['full_name'], [], 'teacher', (string)$i['instructor_key'], (string)$i['full_name']);
            echo json_encode(['ok'=>true,'message'=>'Login successful.','redirect'=>'instructor-dashboard.php','role'=>'instructor']); exit;
        }
        csj_login_throttle_fail($pdo, $identity);
        csj_audit_log($pdo, 'login_failed', 'account', null, null, ['method' => 'password'], 'system', null, 'Unauthenticated visitor');
        throw new RuntimeException('Invalid login details.');
    }



if ($action === 'change_password') {
        $a=csj_require_account($pdo); $current=(string)($d['currentPassword']??''); $new=(string)($d['newPassword']??''); password_ok($new);
        if(!password_verify($current,$a['password_hash'])) throw new RuntimeException('Current password is incorrect.');
        if(password_verify($new,$a['password_hash'])) throw new RuntimeException('New password must be different from the current password.');
        csj_assert_password_unique($pdo, $new, (string)$a['account_id'], null, null);
        $pdo->beginTransaction();
        $pdo->prepare('UPDATE student_accounts SET password_hash=? WHERE account_id=?')->execute([password_hash($new,PASSWORD_DEFAULT),$a['account_id']]);
        $nameStmt=$pdo->prepare('SELECT student_name FROM student_profiles WHERE profile_key=? LIMIT 1'); $nameStmt->execute([$a['profile_key']]); $studentName=(string)($nameStmt->fetchColumn() ?: 'Student');
        csj_audit_log($pdo, 'password_change', 'student', (string)$a['profile_key'], $studentName, [], 'student', (string)$a['profile_key'], $studentName);
        $pdo->commit();
        echo json_encode(['ok'=>true,'message'=>'Password changed successfully.']); exit;
    }

    if ($action === 'set_password_legacy') {
        $key=csj_student_profile_key(); $st=$pdo->prepare('SELECT p.*,a.account_id FROM student_profiles p LEFT JOIN student_accounts a ON a.profile_key=p.profile_key WHERE p.profile_key=? LIMIT 1'); $st->execute([$key]); $p=$st->fetch(); if(!$p) throw new RuntimeException('Save your profile first.');
        $new=(string)($d['newPassword']??''); password_ok($new); $hash=password_hash($new,PASSWORD_DEFAULT);
        $pdo->beginTransaction();
        if($p['account_id']) $pdo->prepare('UPDATE student_accounts SET password_hash=? WHERE account_id=?')->execute([$hash,$p['account_id']]); else { $pdo->prepare('INSERT INTO student_accounts(profile_key,student_id,email,password_hash) VALUES(?,?,?,?)')->execute([$key,$p['student_id']?:null,$p['email']?:null, $hash]); }
        csj_audit_log($pdo, 'password_set', 'student', $key, (string)$p['student_name'], [], 'student', $key, (string)$p['student_name']);
        $pdo->commit();
        csj_set_login_session($key, (string)$p['student_name']);
        echo json_encode(['ok'=>true,'message'=>'Password saved successfully.']); exit;
    }

    if ($action === 'save_profile') {
        csj_require_account($pdo);
        $key=(string)$_SESSION['student_profile_key']; $studentId=trim((string)($d['studentId']??'')); $name=trim((string)($d['studentName']??'')); $course=trim((string)($d['courseYear']??'')); $email=strtolower(trim((string)($d['email']??''))); $address=trim((string)($d['address']??'')); $contact=normalize_phone((string)($d['contactNo']??'')); $guardian=trim((string)($d['guardian']??''));
        if($name===''||$course==='') throw new RuntimeException('Student Name and Course & Year are required.'); valid_email_or_fail($email);
        $st=$pdo->prepare('SELECT profile_key FROM student_profiles WHERE CONVERT(student_id USING utf8mb4) COLLATE utf8mb4_unicode_ci = CONVERT(? USING utf8mb4) COLLATE utf8mb4_unicode_ci AND profile_key<>? LIMIT 1'); if($studentId!==''){ $st->execute([$studentId,$key]); if($st->fetch()) throw new RuntimeException('That Student ID is already in use.'); }
        if($email!==''){ $st=$pdo->prepare('SELECT profile_key FROM student_accounts WHERE CONVERT(email USING utf8mb4) COLLATE utf8mb4_unicode_ci = CONVERT(? USING utf8mb4) COLLATE utf8mb4_unicode_ci AND profile_key<>? LIMIT 1'); $st->execute([$email,$key]); if($st->fetch()) throw new RuntimeException('That email is already in use.'); }
        $pdo->beginTransaction();
        $pdo->prepare('INSERT INTO student_profiles(profile_key,student_id,student_name,course_year,email,address,contact_no,guardian) VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE student_id=VALUES(student_id),student_name=VALUES(student_name),course_year=VALUES(course_year),email=VALUES(email),address=VALUES(address),contact_no=VALUES(contact_no),guardian=VALUES(guardian),updated_at=CURRENT_TIMESTAMP')->execute([$key,$studentId?:null,$name,$course,$email?:null,$address?:null,$contact?:null,$guardian?:null]);
        $st=$pdo->prepare('SELECT account_id FROM student_accounts WHERE profile_key=? LIMIT 1'); $st->execute([$key]); $aid=$st->fetchColumn(); if($aid){ $pdo->prepare('UPDATE student_accounts SET student_id=?,email=? WHERE account_id=?')->execute([$studentId?:null,$email,$aid]); }
        // Phone Number → student_phone_numbers (primary) + student_profiles.contact_no
        ensure_student_phone_table($pdo);
        $pdo->prepare('DELETE FROM student_phone_numbers WHERE profile_key = ?')->execute([$key]);
        if ($contact !== '') {
            $pdo->prepare(
                'INSERT INTO student_phone_numbers (profile_key, phone_number, is_primary) VALUES (?, ?, 1)'
            )->execute([$key, $contact]);
            // Keep contact_no in sync (store E.164; UI may show 09… form)
            $pdo->prepare('UPDATE student_profiles SET contact_no = ? WHERE profile_key = ?')->execute([$contact, $key]);
        } else {
            $pdo->prepare('UPDATE student_profiles SET contact_no = NULL WHERE profile_key = ?')->execute([$key]);
        }
        $_SESSION['student_name'] = $name;
        csj_audit_log($pdo, 'student_profile_updated', 'student', $key, $name, [], 'student', $key, $name);
        $pdo->commit();
        echo json_encode(['ok'=>true,'message'=>'Profile saved successfully.','needsVerification'=>false]); exit;
    }

    if ($action === 'profile_status') {
        $a=csj_require_account($pdo); echo json_encode(['ok'=>true,'email'=>$a['email']]); exit;
    }
    throw new RuntimeException('Unknown account action.');
} catch (Throwable $e) {
    if(isset($pdo)&&$pdo->inTransaction()) $pdo->rollBack();
    if (ob_get_length()) ob_clean();
    http_response_code(400);
    echo json_encode(['ok'=>false,'message'=>$e->getMessage() ?: 'Account operation failed.'], JSON_UNESCAPED_UNICODE);
}
if (ob_get_length()) ob_end_flush();

