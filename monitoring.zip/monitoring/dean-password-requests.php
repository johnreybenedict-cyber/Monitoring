<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    header('Location: index.php');
    exit;
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
$deanName = htmlspecialchars((string)($_SESSION['dean_name'] ?? 'Dean'), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Password Requests - CSJ Dean Dashboard</title>
  <link rel="icon" href="assets/logos/csj-seal.jpg">
  <link rel="stylesheet" href="css/style.css">
  <style>
    .dean-layout{min-height:calc(100vh - 74px);display:grid;grid-template-columns:245px minmax(0,1fr)}
    .dean-sidebar{padding:24px 16px;background:var(--paper);border-right:1px solid var(--line)}
    .dean-sidebar-label{margin:0 12px 10px;color:var(--ink-soft);font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
    .dean-nav-link{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--radius-sm);background:var(--pine-100);color:var(--pine-900);font-size:13px;font-weight:700;text-decoration:none;margin-top:8px}
    .dean-nav-link:first-of-type{margin-top:0}
    .dean-nav-link.active{background:var(--pine-200,#d7e8dc)}
    .dean-content{min-width:0;padding:32px clamp(16px,4vw,48px)}
    .dean-heading{margin:0 0 6px;color:var(--pine-900);font-family:var(--font-display);font-size:26px}
    .dean-intro{margin:0 0 22px;color:var(--ink-soft);font-size:13px;line-height:1.6}
    .request-list{display:grid;gap:14px}
    .request-card{padding:18px;background:var(--paper);border:1px solid var(--line);border-left:4px solid var(--gold-500);border-radius:var(--radius-md);box-shadow:var(--shadow-card)}
    .request-head{display:flex;justify-content:space-between;gap:14px;align-items:flex-start}
    .request-name{margin:0;color:var(--pine-900);font-family:var(--font-display);font-size:18px}
    .request-meta{margin-top:6px;color:var(--ink-soft);font-size:12px;line-height:1.55;overflow-wrap:anywhere}
    .request-status{flex:none;padding:5px 9px;border-radius:999px;background:var(--pine-100);color:var(--pine-900);font-size:10px;font-weight:700;text-transform:uppercase}
    .request-status.pending{background:#fff2cf;color:#684800}
    .request-note{margin:13px 0 0;padding:12px;background:var(--parchment);border-radius:var(--radius-sm);color:var(--ink);font-size:12px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere}
    .verify-line{display:flex;align-items:flex-start;gap:8px;margin:14px 0;color:var(--ink);font-size:12px;line-height:1.5}
    .verify-line input{margin-top:2px}
    .reset-controls{display:grid;grid-template-columns:minmax(180px,1fr) auto auto;gap:9px;align-items:center}
    .reset-controls input[type=password]{min-height:38px;padding:8px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--paper)}
    .dismiss-button{background:var(--paper);border:1px solid var(--line);border-radius:999px;padding:9px 15px;color:var(--ink-soft);font:inherit;font-size:12px;font-weight:600;cursor:pointer}
    .request-message{min-height:18px;margin:10px 0 0;color:var(--ink-soft);font-size:12px}
    .request-message.error{color:var(--danger)}
    .request-message.success{color:var(--pine-700)}
    .notice,.empty-state{padding:16px;border-radius:var(--radius-md);font-size:13px;line-height:1.6}
    .notice{margin-bottom:16px;background:var(--pine-100);color:var(--pine-900)}
    .empty-state{background:var(--parchment);border:1px solid var(--line-soft);color:var(--ink-soft)}
    @media(max-width:760px){.dean-layout{grid-template-columns:1fr}.dean-sidebar{padding:12px 16px;border-right:0;border-bottom:1px solid var(--line)}.dean-sidebar-label{display:none}.dean-content{padding:22px 16px}.reset-controls{grid-template-columns:1fr}.request-head{flex-direction:column}}
  </style>
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="brand-logo">
      <div class="brand-text">
        <span class="brand-title">CSJ Dean Dashboard</span>
        <span class="brand-sub">Higher Education Department &middot; Dean View</span>
      </div>
    </div>
    <div class="topbar-actions">
      <a class="btn btn-ghost" href="logout.php">Logout</a>
    </div>
  </header>
  <div class="dean-layout">
        <aside class="dean-sidebar" aria-label="Dean navigation">
      <p class="dean-sidebar-label">Menu</p>
      <a class="dean-nav-link" href="dean-dashboard.php"><span aria-hidden="true">&#9638;</span> Student Entries</a>
      <a class="dean-nav-link" href="dean-student-profiles.php"><span aria-hidden="true">&#128100;</span> Student Profile</a>
      <a class="dean-nav-link active" href="dean-password-requests.php" aria-current="page"><span aria-hidden="true">&#128274;</span> Password Requests</a>
      <a class="dean-nav-link" href="dean-audit-trail.php"><span aria-hidden="true">&#9776;</span> Audit Trail</a>
      <a class="dean-nav-link" href="dean-feedback.php"><span aria-hidden="true">&#9998;</span> Feedback</a>
      <a class="dean-nav-link" href="dean-archive.php"><span aria-hidden="true">&#128230;</span> Archive</a>
    </aside>
    <main class="dean-content">
      <h1 class="dean-heading">Password reset requests</h1>
      <div id="requestMessage" class="request-message" role="status" aria-live="polite"></div>
      <div id="requestList" class="request-list"><div class="empty-state">Loading requests…</div></div>
    </main>
  </div>
  <script>
  (function(){
    'use strict';
    const list = document.getElementById('requestList');
    const globalMessage = document.getElementById('requestMessage');
    const endpoint = 'php/password_requests.php';

    function node(tag, className, text) {
      const element = document.createElement(tag);
      if (className) element.className = className;
      if (text !== undefined) element.textContent = text;
      return element;
    }

    async function api(action, payload, method) {
      const options = {method: method || 'GET', credentials: 'same-origin', cache: 'no-store'};
      if (payload) {
        options.headers = {'Content-Type': 'application/json'};
        options.body = JSON.stringify(payload);
      }
      const response = await fetch(endpoint + '?action=' + encodeURIComponent(action), options);
      let data;
      try { data = await response.json(); }
      catch (error) { throw new Error('Server returned an invalid response.'); }
      if (!response.ok || !data.ok) throw new Error(data.message || 'Request failed.');
      return data;
    }

    function render(requests) {
      list.replaceChildren();
      if (!requests.length) {
        list.appendChild(node('div', 'empty-state', 'There are no password reset requests.'));
        return;
      }

      requests.forEach(function(request) {
        const card = node('article', 'request-card');
        const head = node('div', 'request-head');
        const details = document.createElement('div');
        details.appendChild(node('h2', 'request-name', request.requester_name));
        details.appendChild(node(
          'div',
          'request-meta',
          request.account_role.toUpperCase() + ' · ' + request.account_identifier +
          (request.account_found
            ? '\nMatched account: ' + request.registered_name + ' (' + request.matched_identifier + ')'
            : '\nNo matching account found for this ID/email.') +
          '\nReceived: ' + request.created_at +
          (request.reviewed_at ? '\nReviewed: ' + request.reviewed_at : '')
        ));
        head.appendChild(details);
        head.appendChild(node('span', 'request-status ' + request.status, request.status));
        card.appendChild(head);

        if (request.requester_note) {
          card.appendChild(node('p', 'request-note', request.requester_note));
        }

        const message = node('p', 'request-message', '');
        message.setAttribute('aria-live', 'polite');
        card.appendChild(message);

        if (request.status === 'pending') {
          const form = document.createElement('form');
          const verifyLabel = node('label', 'verify-line');
          const verify = document.createElement('input');
          verify.type = 'checkbox';
          verify.required = true;
          verifyLabel.appendChild(verify);
          verifyLabel.appendChild(document.createTextNode('I verified this person’s identity and confirmed the matching account.'));
          form.appendChild(verifyLabel);

          const controls = node('div', 'reset-controls');
          const password = document.createElement('input');
          password.type = 'password';
          password.minLength = 8;
          password.maxLength = 200;
          password.required = true;
          password.autocomplete = 'new-password';
          password.placeholder = 'Set new password (8+ characters)';
          password.setAttribute('aria-label', 'New account password');
          controls.appendChild(password);

          const reset = node('button', 'btn btn-primary', 'Verify & reset');
          reset.type = 'submit';
          controls.appendChild(reset);
          const dismiss = node('button', 'dismiss-button', 'Dismiss');
          dismiss.type = 'button';
          controls.appendChild(dismiss);
          form.appendChild(controls);

          form.addEventListener('submit', async function(event) {
            event.preventDefault();
            reset.disabled = true;
            message.className = 'request-message';
            message.textContent = 'Resetting password…';
            try {
              const result = await api('reset', {requestId: Number(request.request_id), newPassword: password.value, identityVerified: verify.checked}, 'POST');
              message.className = 'request-message success';
              message.textContent = result.message;
              password.value = '';
              await loadRequests();
            } catch (error) {
              message.className = 'request-message error';
              message.textContent = error.message;
              reset.disabled = false;
            }
          });

          dismiss.addEventListener('click', async function() {
            dismiss.disabled = true;
            message.className = 'request-message';
            message.textContent = 'Dismissing request…';
            try {
              await api('dismiss', {requestId: Number(request.request_id)}, 'POST');
              await loadRequests();
            } catch (error) {
              message.className = 'request-message error';
              message.textContent = error.message;
              dismiss.disabled = false;
            }
          });

          card.appendChild(form);
        }
        list.appendChild(card);
      });
    }

    async function loadRequests() {
      globalMessage.className = 'request-message';
      globalMessage.textContent = '';
      try {
        const data = await api('list');
        render(data.requests || []);
      } catch (error) {
        list.replaceChildren(node('div', 'empty-state', error.message));
      }
    }

    loadRequests();
  })();
  </script>
</body>
</html>
