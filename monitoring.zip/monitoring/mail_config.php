<?php
/**
 * CSJ email configuration -- a real, optional email delivery (password notices, etc.)
 * for account verification codes (email delivery
 * that most school deployments won't have configured).
 *
 * Uses a plain SMTP-over-sockets client (no Composer/PHPMailer needed).
 * Works with Gmail (use an App Password, not your normal password),
 * Outlook/Office365, or any other SMTP provider.
 *
 * Configure via environment variables, or edit the defaults below:
 *   CSJ_SMTP_HOST, CSJ_SMTP_PORT, CSJ_SMTP_USER, CSJ_SMTP_PASS, CSJ_SMTP_FROM
 *
 * If this is also left unconfigured, csj_send_mail() throws a clear
 * RuntimeException -- callers can catch it and fall back further, or
 * surface it to the user.
 */
define('CSJ_SMTP_HOST', getenv('CSJ_SMTP_HOST') ?: '');
define('CSJ_SMTP_PORT', (int)(getenv('CSJ_SMTP_PORT') ?: 587));
define('CSJ_SMTP_USER', getenv('CSJ_SMTP_USER') ?: '');
define('CSJ_SMTP_PASS', getenv('CSJ_SMTP_PASS') ?: '');
define('CSJ_SMTP_FROM', getenv('CSJ_SMTP_FROM') ?: (CSJ_SMTP_USER ?: 'no-reply@csj-self-monitoring.local'));
define('CSJ_SMTP_FROM_NAME', 'CSJ Self-Monitoring Dashboard');

function csj_mail_configured(): bool {
    return CSJ_SMTP_HOST !== '' && CSJ_SMTP_USER !== '' && CSJ_SMTP_PASS !== '';
}

/** Read one SMTP response line and return its numeric code. */
function csj_smtp_expect($sock, string $context): int {
    $line = fgets($sock, 512);
    if ($line === false) throw new RuntimeException("SMTP: no response while $context.");
    $code = (int)substr($line, 0, 3);
    // Multi-line responses ("250-...") continue until a line with a space
    // after the code ("250 ...").
    while (isset($line[3]) && $line[3] === '-') {
        $line = fgets($sock, 512);
        if ($line === false) break;
    }
    return $code;
}

function csj_smtp_send($sock, string $cmd): void {
    fwrite($sock, $cmd . "\r\n");
}

function csj_send_mail(string $to, string $subject, string $body): void {
    if (!csj_mail_configured()) {
        throw new RuntimeException('Email delivery is not configured yet. Set CSJ_SMTP_HOST / CSJ_SMTP_USER / CSJ_SMTP_PASS (env vars) or edit mail_config.php.');
    }
    $host = CSJ_SMTP_HOST;
    $port = CSJ_SMTP_PORT;
    $useTls = in_array($port, [587], true);
    $useSsl = in_array($port, [465], true);

    $transport = $useSsl ? "ssl://$host" : $host;
    $sock = @stream_socket_client("$transport:$port", $errno, $errstr, 20);
    if (!$sock) {
        throw new RuntimeException("Could not connect to mail server $host:$port ($errstr).");
    }
    stream_set_timeout($sock, 20);

    csj_smtp_expect($sock, 'connecting');
    csj_smtp_send($sock, 'EHLO csj-self-monitoring.local');
    csj_smtp_expect($sock, 'EHLO');

    if ($useTls) {
        csj_smtp_send($sock, 'STARTTLS');
        if (csj_smtp_expect($sock, 'STARTTLS') >= 400) throw new RuntimeException('Mail server rejected STARTTLS.');
        if (!stream_socket_enable_crypto($sock, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            throw new RuntimeException('Could not start TLS with the mail server.');
        }
        csj_smtp_send($sock, 'EHLO csj-self-monitoring.local');
        csj_smtp_expect($sock, 'EHLO after STARTTLS');
    }

    csj_smtp_send($sock, 'AUTH LOGIN');
    csj_smtp_expect($sock, 'AUTH LOGIN');
    csj_smtp_send($sock, base64_encode(CSJ_SMTP_USER));
    csj_smtp_expect($sock, 'sending username');
    csj_smtp_send($sock, base64_encode(CSJ_SMTP_PASS));
    if (csj_smtp_expect($sock, 'sending password') >= 400) {
        fclose($sock);
        throw new RuntimeException('Mail server rejected the SMTP username/password.');
    }

    csj_smtp_send($sock, 'MAIL FROM:<' . CSJ_SMTP_FROM . '>');
    csj_smtp_expect($sock, 'MAIL FROM');
    csj_smtp_send($sock, 'RCPT TO:<' . $to . '>');
    if (csj_smtp_expect($sock, 'RCPT TO') >= 400) {
        fclose($sock);
        throw new RuntimeException("Mail server rejected the recipient address ($to).");
    }
    csj_smtp_send($sock, 'DATA');
    csj_smtp_expect($sock, 'DATA');

    $headers = [
        'From: ' . CSJ_SMTP_FROM_NAME . ' <' . CSJ_SMTP_FROM . '>',
        'To: <' . $to . '>',
        'Subject: ' . $subject,
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Date: ' . date('r'),
    ];
    // Dot-stuff any line that starts with a lone "." per RFC 5321.
    $escapedBody = preg_replace('/^\./m', '..', $body);
    csj_smtp_send($sock, implode("\r\n", $headers) . "\r\n\r\n" . $escapedBody . "\r\n.");
    if (csj_smtp_expect($sock, 'sending message body') >= 400) {
        fclose($sock);
        throw new RuntimeException('Mail server rejected the message.');
    }

    csj_smtp_send($sock, 'QUIT');
    fclose($sock);
}

/** j***@gmail.com -- for showing "we emailed you" without exposing the full address. */
function csj_mask_email(string $email): string {
    $at = strpos($email, '@');
    if ($at === false || $at < 1) return $email;
    $name = substr($email, 0, $at);
    $domain = substr($email, $at);
    return $name[0] . str_repeat('*', max(1, strlen($name) - 1)) . $domain;
}
