<?php
require_once __DIR__ . '/php/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    header('Location: index.php');
    exit;
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function audit_h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function audit_program_from_course(?string $courseYear): string {
    $c = trim((string)$courseYear);
    if ($c === '') return '—';
    // e.g. "BSIT 3", "BSED 2", "BEED 1", "BSBA 4"
    if (preg_match('/\b(BEED|BSED|BSEd|BSBA|BSIT)\b/i', $c, $m)) {
        $p = strtoupper($m[1]);
        if ($p === 'BSED') $p = 'BSEd';
        return $p;
    }
    return '—';
}

function audit_format_action(string $action): string {
    return ucwords(str_replace('_', ' ', $action));
}

$roleFilter = (string)($_GET['role'] ?? '');
$allowedRoles = ['', 'student', 'teacher', 'dean', 'system'];
if (!in_array($roleFilter, $allowedRoles, true)) $roleFilter = '';
$actionFilter = trim((string)($_GET['action'] ?? ''));
$dateFrom = trim((string)($_GET['date_from'] ?? ''));
$dateTo = trim((string)($_GET['date_to'] ?? ''));

// Normalize datetime-local values (YYYY-MM-DDTHH:MM) to SQL datetime
function audit_parse_dt(string $raw): ?string {
    $raw = trim(str_replace('T', ' ', $raw));
    if ($raw === '') return null;
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw)) return $raw . ' 00:00:00';
    if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $raw)) return $raw . ':00';
    if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $raw)) return $raw;
    return null;
}
$fromSql = audit_parse_dt($dateFrom);
$toSql = audit_parse_dt($dateTo);

$entryActions = [
    'student_submission',
    'instructor_approval',
    'instructor_denial',
    'instructor_approval_removed',
    'dean_approval',
    'dean_denial',
    'dean_approval_removed',
];
$records = [];
$availableActions = [];
$pageError = '';

try {
    $pdo = csj_db();
    $availableActions = $pdo->query('SELECT DISTINCT action FROM audit_trail ORDER BY action')->fetchAll(PDO::FETCH_COLUMN);

    $where = [];
    $params = [];
    if ($roleFilter !== '') {
        $where[] = 'a.actor_role = ?';
        $params[] = $roleFilter;
    }
    if ($actionFilter === 'entries') {
        $where[] = 'a.action IN (' . implode(', ', array_fill(0, count($entryActions), '?')) . ')';
        array_push($params, ...$entryActions);
    } elseif ($actionFilter !== '' && strlen($actionFilter) <= 80) {
        $where[] = 'a.action = ?';
        $params[] = $actionFilter;
    } else {
        $actionFilter = '';
    }
    if ($fromSql !== null) {
        $where[] = 'a.created_at >= ?';
        $params[] = $fromSql;
    }
    if ($toSql !== null) {
        $where[] = 'a.created_at <= ?';
        $params[] = $toSql;
    }

    // Enrich actor with Student ID / Teacher ID, course_year, program
    $sql = 'SELECT
                a.audit_id,
                a.actor_role,
                a.actor_id,
                a.actor_name,
                a.action,
                a.target_role,
                a.target_id,
                a.target_name,
                a.details,
                a.created_at,
                sp.student_id AS student_id,
                sp.course_year AS student_course_year,
                ip.teacher_id AS teacher_id,
                ip.program AS teacher_program
            FROM audit_trail a
            LEFT JOIN student_profiles sp
                ON a.actor_role = \'student\'
               AND (sp.profile_key = a.actor_id OR sp.student_id = a.actor_id)
            LEFT JOIN instructor_profiles ip
                ON a.actor_role = \'teacher\'
               AND (ip.instructor_key = a.actor_id OR ip.teacher_id = a.actor_id)';
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY a.audit_id DESC LIMIT 400';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('Dean audit trail could not load: ' . $e->getMessage());
    $pageError = 'Audit events could not be loaded. Check that the audit_trail table exists.';
}

$deanName = audit_h((string)($_SESSION['dean_name'] ?? 'Dean'));

// For datetime-local inputs
$dateFromInput = $dateFrom;
$dateToInput = $dateTo;
if ($dateFromInput !== '' && strpos($dateFromInput, ' ') !== false) {
    $dateFromInput = str_replace(' ', 'T', substr($dateFromInput, 0, 16));
}
if ($dateToInput !== '' && strpos($dateToInput, ' ') !== false) {
    $dateToInput = str_replace(' ', 'T', substr($dateToInput, 0, 16));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Audit Trail - CSJ Dean Dashboard</title>
  <link rel="icon" href="assets/logos/csj-seal.jpg">
  <link rel="stylesheet" href="css/style.css">
  <style>
    .dean-layout{min-height:calc(100vh - 74px);display:grid;grid-template-columns:245px minmax(0,1fr)}
    .dean-sidebar{padding:24px 16px;background:var(--paper);border-right:1px solid var(--line)}
    .dean-sidebar-label{margin:0 12px 10px;color:var(--ink-soft);font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
    .dean-nav-link{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--radius-sm);background:var(--pine-100);color:var(--pine-900);font-size:13px;font-weight:700;text-decoration:none;margin-top:8px}
    .dean-nav-link:first-of-type{margin-top:0}
    .dean-nav-link.active{background:var(--pine-200,#d7e8dc)}
    .dean-content{min-width:0;padding:32px clamp(16px,4vw,48px)}
    .dean-heading{margin:0 0 20px;color:var(--pine-900);font-family:var(--font-display);font-size:26px}
    .audit-filters{display:flex;flex-wrap:wrap;align-items:end;gap:12px;margin-bottom:18px;padding:18px;background:var(--paper);border:1px solid var(--line);border-radius:var(--radius-lg)}
    .audit-filters label{display:flex;flex-direction:column;gap:6px;color:var(--ink-soft);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
    .audit-filters select,
    .audit-filters input[type="datetime-local"]{
      min-width:160px;min-height:40px;padding:8px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);
      background:var(--paper);color:var(--ink);font:inherit;font-size:13px;text-transform:none;letter-spacing:normal
    }
    .audit-filters .filter-actions{display:flex;gap:8px;align-items:center;padding-bottom:1px}
    .audit-table-wrap{overflow:auto;border:1px solid var(--line);border-radius:var(--radius-lg);background:var(--paper)}
    .audit-table{width:100%;border-collapse:collapse;min-width:900px;font-size:13px}
    .audit-table thead th{
      position:sticky;top:0;z-index:1;
      background:var(--pine-900);color:#fff;font-size:11px;font-weight:700;
      letter-spacing:.04em;text-transform:uppercase;text-align:left;
      padding:12px 14px;border-bottom:2px solid var(--gold-500);white-space:nowrap
    }
    .audit-table tbody td{
      padding:12px 14px;border-bottom:1px solid var(--line-soft);color:var(--ink);
      vertical-align:top;line-height:1.45
    }
    .audit-table tbody tr:nth-child(even){background:rgba(14,61,36,.03)}
    .audit-table tbody tr:hover{background:rgba(14,61,36,.07)}
    .audit-id{font-weight:700;color:var(--pine-900);font-family:ui-monospace,Consolas,monospace;font-size:12px}
    .audit-name{font-weight:700;color:var(--pine-900)}
    .audit-role-meta{color:var(--ink-soft);font-size:11px;margin-top:2px}
    .audit-action-cell{font-weight:700;color:var(--pine-800)}
    .audit-dt{color:var(--ink-soft);font-size:12px;white-space:nowrap}
    .empty-state,.error-state{padding:16px;border-radius:var(--radius-md);font-size:13px;line-height:1.6}
    .empty-state{background:var(--parchment);border:1px solid var(--line-soft);color:var(--ink-soft)}
    .error-state{background:#fff0ec;border:1px solid #e6b4a7;color:#7d291b}
    @media(max-width:760px){
      .dean-layout{grid-template-columns:1fr}
      .dean-sidebar{padding:12px 16px;border-right:0;border-bottom:1px solid var(--line)}
      .dean-sidebar-label{display:none}
      .dean-content{padding:22px 16px}
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="brand-logo">
      <div class="brand-text">
        <span class="brand-title">CSJ Dean Dashboard</span>
        <span class="brand-sub">Higher Education Department &middot; Dean View</span>
      </div>
    </div>
    <div class="topbar-actions">
      <a class="btn btn-ghost" href="logout.php">Logout</a>
    </div>
  </header>

  <div class="dean-layout">
        <aside class="dean-sidebar" aria-label="Dean navigation">
      <p class="dean-sidebar-label">Menu</p>
      <a class="dean-nav-link" href="dean-dashboard.php"><span aria-hidden="true">&#9638;</span> Student Entries</a>
      <a class="dean-nav-link" href="dean-student-profiles.php"><span aria-hidden="true">&#128100;</span> Student Profile</a>
      <a class="dean-nav-link" href="dean-password-requests.php"><span aria-hidden="true">&#128274;</span> Password Requests</a>
      <a class="dean-nav-link active" href="dean-audit-trail.php" aria-current="page"><span aria-hidden="true">&#9776;</span> Audit Trail</a>
      <a class="dean-nav-link" href="dean-feedback.php"><span aria-hidden="true">&#9998;</span> Feedback</a>
      <a class="dean-nav-link" href="dean-archive.php"><span aria-hidden="true">&#128230;</span> Archive</a>
    </aside>

    <main class="dean-content">
      <h1 class="dean-heading">Audit trail</h1>

      <form class="audit-filters" method="get" action="dean-audit-trail.php">
        <label for="role">Actor role
          <select id="role" name="role" onchange="this.form.submit()">
            <option value="">All roles</option>
            <option value="student" <?= $roleFilter === 'student' ? 'selected' : '' ?>>Student</option>
            <option value="teacher" <?= $roleFilter === 'teacher' ? 'selected' : '' ?>>Teacher</option>
            <option value="dean" <?= $roleFilter === 'dean' ? 'selected' : '' ?>>Dean</option>
            <option value="system" <?= $roleFilter === 'system' ? 'selected' : '' ?>>System</option>
          </select>
        </label>
        <label for="action">Action
          <select id="action" name="action" onchange="this.form.submit()">
            <option value="">All actions</option>
            <option value="entries" <?= $actionFilter === 'entries' ? 'selected' : '' ?>>Entries</option>
            <?php foreach ($availableActions as $action): ?>
              <option value="<?= audit_h((string)$action) ?>" <?= $actionFilter === $action ? 'selected' : '' ?>><?= audit_h(audit_format_action((string)$action)) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label for="date_from">From date &amp; time
          <input type="datetime-local" id="date_from" name="date_from" value="<?= audit_h($dateFromInput) ?>">
        </label>
        <label for="date_to">To date &amp; time
          <input type="datetime-local" id="date_to" name="date_to" value="<?= audit_h($dateToInput) ?>">
        </label>
        <div class="filter-actions">
          <button type="submit" class="btn btn-primary" style="min-height:40px;">Apply</button>
          <a class="btn btn-ghost" href="dean-audit-trail.php" style="min-height:40px;">Clear</a>
        </div>
      </form>

      <?php if ($pageError !== ''): ?>
        <div class="error-state"><?= audit_h($pageError) ?></div>
      <?php elseif (!$records): ?>
        <div class="empty-state">No audit events were found for the selected filters.</div>
      <?php else: ?>
        <div class="audit-table-wrap">
          <table class="audit-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Role</th>
                <th>Program/Department</th>
                <th>Actions</th>
                <th>Date and Time</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($records as $record):
                $role = strtolower((string)($record['actor_role'] ?? ''));
                $name = (string)($record['actor_name'] ?? 'Unknown');
                $idDisplay = '—';
                $roleLabel = ucfirst($role !== '' ? $role : 'Unknown');
                $roleMeta = '';
                $program = '—';

                if ($role === 'student') {
                    $idDisplay = trim((string)($record['student_id'] ?? '')) ?: (string)($record['actor_id'] ?? '—');
                    $course = trim((string)($record['student_course_year'] ?? ''));
                    $roleMeta = $course !== '' ? $course : 'Year and course';
                    $roleLabel = 'Student';
                    $program = audit_program_from_course($course);
                } elseif ($role === 'teacher') {
                    $idDisplay = trim((string)($record['teacher_id'] ?? '')) ?: (string)($record['actor_id'] ?? '—');
                    $dept = trim((string)($record['teacher_program'] ?? ''));
                    $roleMeta = $dept !== '' ? $dept : 'Department handled';
                    $roleLabel = 'Teacher';
                    $program = audit_program_from_course($dept);
                    if ($program === '—' && $dept !== '') {
                        // If program field already stores BEED/BSIT etc.
                        $program = audit_program_from_course($dept) !== '—'
                            ? audit_program_from_course($dept)
                            : (preg_match('/\b(BEED|BSED|BSEd|BSBA|BSIT)\b/i', $dept, $mm) ? strtoupper($mm[1] === 'BSED' ? 'BSEd' : $mm[1]) : $dept);
                    }
                } elseif ($role === 'dean') {
                    $idDisplay = (string)($record['actor_id'] ?? 'Dean');
                    $roleLabel = 'Dean';
                    $roleMeta = 'Higher Education Department';
                    $program = '—';
                } else {
                    $idDisplay = (string)($record['actor_id'] ?? '—');
                }

                $actionLabel = audit_format_action((string)($record['action'] ?? ''));
                $dt = (string)($record['created_at'] ?? '');
            ?>
              <tr>
                <td class="audit-id"><?= audit_h($idDisplay) ?></td>
                <td class="audit-name"><?= audit_h($name) ?></td>
                <td>
                  <?= audit_h($roleLabel) ?>
                  <?php if ($roleMeta !== ''): ?>
                    <div class="audit-role-meta"><?= audit_h($roleMeta) ?></div>
                  <?php endif; ?>
                </td>
                <td><?= audit_h($program) ?></td>
                <td class="audit-action-cell"><?= audit_h($actionLabel) ?></td>
                <td class="audit-dt"><?= audit_h($dt) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </main>
  </div>
</body>
</html>
