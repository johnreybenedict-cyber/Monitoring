<?php
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Previously this page never actually required login -- it only hid the
// Logout link when $_SESSION['student_authenticated'] was empty, while
// csj_student_profile_key() below would silently keep working off the
// leftover "csj_student_profile_key" cookie regardless. That's why
// clicking Logout and then pressing the browser's Back button still
// showed a usable dashboard (just without a Logout button): the page was
// never actually protected, and browsers can also restore it from cache
// without re-running any PHP at all. Both are fixed here: a real
// session check that sends a logged-out visitor to the login page, and
// no-store headers so Back/Forward can't show an old authenticated copy
// instead of re-checking the session.
if (empty($_SESSION['student_authenticated']) || empty($_SESSION['student_profile_key'])) {
    header('Location: index.php');
    exit;
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$profileKey = csj_student_profile_key();

/**
 * CSJ Self-Monitoring Dashboard
 * Student-facing view. Reads data/chart.json and renders the review table.
 * Approval status/instructor name are read-only here -- only the
 * (separate) instructor dashboard is allowed to flip "approved".
 *
 * The chart now has THREE independent monitoring sheets -- Prelims,
 * Midterms, and Finals -- each with its own 9-subject table
 * (TblPrelim / TblMidterm / TblFinals) and its own 6 review-event rows.
 * A Previous/Next control lets the student page between them; only the
 * active sheet prints, one page at a time.
 */
$dataFile = __DIR__ . '/data/chart.json';
$chart = json_decode(file_get_contents($dataFile), true);
if (!is_array($chart)) $chart = [];

$meta = $chart['meta'] ?? [];

$studentName = $meta['studentName'] ?? "";
$courseYear  = $meta['courseYear'] ?? "";
$profileStudentId = "";
$profileEmail = "";
$profilePhoto = "";
$profilePhotoUrl = "";
$profileAddress = "";
$profileContact = "";
$profileGuardian = "";
$profileStatus = "";
$profileMajor = "";
$profileProgram = "";
$profileYearLevel = "";
$studentLoggedIn = false;
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$studentLoggedIn = !empty($_SESSION['student_authenticated']) && !empty($_SESSION['student_profile_key']);

// Load the saved profile from MySQL when available. The page still opens if MySQL is offline.
try {
    $pdo = csj_student_db();
    // Self-heal older XAMPP databases that were created before contact_no existed.
    try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN contact_no VARCHAR(50) DEFAULT NULL"); } catch (Throwable $ignored) {}
    try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN guardian VARCHAR(150) DEFAULT NULL"); } catch (Throwable $ignored) {}
    try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN program VARCHAR(20) DEFAULT NULL"); } catch (Throwable $ignored) {}
    try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN year_level VARCHAR(20) DEFAULT NULL"); } catch (Throwable $ignored) {}
    try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN enrollment_status VARCHAR(20) DEFAULT NULL"); } catch (Throwable $ignored) {}
    try { $pdo->exec("ALTER TABLE student_profiles ADD COLUMN major VARCHAR(80) DEFAULT NULL"); } catch (Throwable $ignored) {}
    $stmt = $pdo->prepare('SELECT student_name, course_year, student_id, email, address, contact_no, guardian, photo_path, program, year_level, enrollment_status, major FROM student_profiles WHERE profile_key = ? LIMIT 1');
    $stmt->execute([$profileKey]);
    if ($profile = $stmt->fetch()) {
        $studentName = $profile['student_name'] ?? $studentName;
        $courseYear  = $profile['course_year'] ?? $courseYear;
        $profileStudentId = $profile['student_id'] ?? '';
        $profileEmail = $profile['email'] ?? '';
        $profileAddress = $profile['address'] ?? '';
        $profileContact = $profile['contact_no'] ?? '';
        try {
            $ph = $pdo->prepare('SELECT phone_number FROM student_phone_numbers WHERE profile_key = ? ORDER BY is_primary DESC, phone_id ASC LIMIT 1');
            $ph->execute([$profileKey]);
            $pn = (string)($ph->fetchColumn() ?: '');
            if ($pn !== '') $profileContact = $pn;
        } catch (Throwable $e) {}
        $profileGuardian = $profile['guardian'] ?? '';
        $profileStatus = $profile['enrollment_status'] ?? '';
        $profileMajor = $profile['major'] ?? '';
        $profileProgram = $profile['program'] ?? '';
        $profileYearLevel = $profile['year_level'] ?? '';
        $profilePhoto = $profile['photo_path'] ?? '';
        if ($profilePhoto !== '') {
            $instructorRoot = csj_instructor_root();
            if ($instructorRoot) {
                $profilePhotoUrl = '../' . basename($instructorRoot) . '/' . ltrim($profilePhoto, '/');
            } else {
                $profilePhotoUrl = $profilePhoto;
            }
        }
    }
} catch (Throwable $e) {
    // MySQL is optional until the schema is imported and MySQL is started.
}

// The database is the source of truth for the student's submitted chart.
// After a semester transition, submissions are cleared so the student starts a fresh sheet
// labeled with the official current semester.
try {
    $pdo2 = $pdo ?? csj_student_db();
    $currentSemester = function_exists('csj_get_current_semester')
        ? csj_get_current_semester($pdo2)
        : 'First Semester, AY 2026-2027';
    $stmtAny = $pdo2->prepare(
        'SELECT chart_json, student_name, course_year, semester FROM monitoring_submissions
         WHERE profile_key = ? ORDER BY updated_at DESC LIMIT 1'
    );
    $stmtAny->execute([$profileKey]);
    $saved = $stmtAny->fetch();
    if ($saved) {
        $savedChart = json_decode($saved['chart_json'], true);
        if (is_array($savedChart)) {
            $chart = $savedChart;
            $meta = $chart['meta'] ?? $meta;
            $studentName = $saved['student_name'] ?: ($meta['studentName'] ?? $studentName);
            $courseYear = $saved['course_year'] ?: ($meta['courseYear'] ?? $courseYear);
            if (!empty($saved['semester'])) {
                $meta['semester'] = $saved['semester'];
            }
        }
    } else {
        // New semester / no submission yet → empty chart for the current academic period
        $meta['semester'] = $currentSemester;
        if (isset($chart['meta']) && is_array($chart['meta'])) {
            $chart['meta']['semester'] = $currentSemester;
        }
        // Ensure periods are blank (no leftover approvals)
        if (function_exists('csj_normalize_periods')) {
            $chart['periods'] = csj_normalize_periods(['periods' => []]);
        }
    }
} catch (Throwable $e) {
    // Fall back to chart.json if MySQL is unavailable.
    if (empty($meta['semester'])) {
        $meta['semester'] = function_exists('csj_default_semester') ? csj_default_semester() : 'First Semester, AY 2026-2027';
    }
}

// Normalize into the three guaranteed sheets: prelims, midterms, finals.
$periodDefs = csj_period_definitions();
$periods    = csj_normalize_periods($chart);
$firstKey   = array_key_first($periodDefs);



// Period-level Dean approval: only approved periods are read-only
$csjApprovedPeriods = []; // e.g. ['prelims' => true, 'midterms' => true]
$csjLockReason = 'Your monitoring chart was approved by the Dean. You can view and print it, but you can no longer edit or submit.';
try {
    if (!empty($chart['periods']) && is_array($chart['periods'])) {
        foreach ($chart['periods'] as $pk => $per) {
            if (is_array($per) && !empty($per['deanApproved'])) {
                $csjApprovedPeriods[(string)$pk] = true;
            }
        }
    }
} catch (Throwable $e) {
    $csjApprovedPeriods = [];
}
$csjHasAnyApproved = !empty($csjApprovedPeriods);

// Prelims -> Midterms -> Finals: which sheets may this student open right now?
$csjPeriodAccess = csj_period_access($periods);


// Subject codes for comboboxes: filtered by student's Course / Year / Major / Semester.
// Codes are shown WITHOUT section suffix (e.g. "SSci 101" not "SSci 101-1").
require_once __DIR__ . '/php/curriculum_helpers.php';
// Infer program/year from course_year label when Dean fields are empty (e.g. "BSIT 1")
if (($profileProgram ?? '') === '' && $courseYear !== '') {
    if (preg_match('/\b(BEEd|BEED|BSEd|BSED|BSBA|BSIT)\b/i', $courseYear, $m)) {
        $profileProgram = $m[1];
    }
}
if (($profileYearLevel ?? '') === '' && $courseYear !== '') {
    if (preg_match('/\b(1st|2nd|3rd|4th|[1-4])\b/i', $courseYear, $m)) {
        $profileYearLevel = $m[1];
    }
}
$semesterForCodes = (string)($meta['semester'] ?? (function_exists('csj_get_current_semester') ? csj_get_current_semester() : 'First Semester'));
$csjSubjectCodes = csj_student_subject_code_options(
    (string)($profileProgram ?? ''),
    (string)($profileYearLevel ?? ''),
    (string)($profileMajor ?? ''),
    $semesterForCodes,
    (string)($profileStatus ?? '')
);


// New-semester welcome: shown ONCE per account per transition (remembered in the database),
// never to a student who registered after the semester already changed.
$csjNewSemesterMsg = '';
$csjTransitionId = '';
try {
    $flagPdo = isset($pdo) && $pdo instanceof PDO ? $pdo : csj_student_db();
    $csjTransitionId = csj_transition_id($flagPdo);
    $csjWelcome = csj_welcome_pending($flagPdo, 'student', (string)$profileKey);
    if (!empty($csjWelcome['pending']) && !empty($studentLoggedIn)) {
        $csjNewSemesterMsg = 'New semester, new learnings.';
        csj_welcome_mark_seen($flagPdo, 'student', (string)$profileKey, $csjWelcome['transitionId']);
    }
} catch (Throwable $e) {
    $csjNewSemesterMsg = '';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CSJ Self-Monitoring Dashboard</title>
<link rel="icon" href="assets/logos/csj-seal.jpg">
<link rel="stylesheet" href="css/style.css?v=<?= (int)(@filemtime(__DIR__ . '/css/style.css') ?: time()) ?>">
<style>
  /* Additive rules only -- css/style.css is untouched.
     These style the new Prelims/Midterms/Finals navigation and panels,
     reusing the same design tokens already defined in style.css. */
  .period-toolbar{
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin: 0 2px 14px;
  }
  .btn-outline{
    background: transparent;
    color: var(--pine-800);
    border: 1px solid var(--pine-700);
  }
  .btn-outline:hover{ background: var(--pine-100); }
  .btn-outline:disabled{
    opacity: .4;
    cursor: not-allowed;
    background: transparent;
    transform: none;
  }
  .period-status{
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
  }
  .period-label{
    font-family: var(--font-display);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: .02em;
    color: var(--pine-800);
    background: var(--pine-100);
    border: 1px solid var(--line);
    border-radius: 999px;
    padding: 6px 20px;
    min-width: 120px;
    text-align: center;
  }
  .period-steps{ display: flex; gap: 6px; }
  .period-step{
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--line);
    transition: background .15s ease, transform .15s ease;
  }
  .period-step.is-current{ background: var(--gold-500); transform: scale(1.2); }
  .period-panel{ display: none; }
  .period-panel.is-active{ display: block; }

  /* Bottom row — matches monitoring sheet image (name | course | dean) */
  .student-bottom-fields{
    display: flex;
    gap: 28px;
    align-items: flex-end;
    margin-top: 18px;
    padding-top: 10px;
    border-top: 1px solid #e9e3d0;
    position: relative;
    z-index: 1;
  }
  .bottom-field{
    min-width: 0;
    font-size: 11px;
    color: #1d271f;
  }
  .bottom-field-name,
  .bottom-field-course{
    flex: 1 1 0;
  }
  .bottom-dean-wrap{
    flex: 0 0 150px;
    width: 150px;
    text-align: right;
  }
  .bottom-line{
    display: block;
    width: 100%;
    box-sizing: border-box;
    border: 0;
    border-bottom: 1px solid #5b6b5e;
    padding: 4px 0 2px;
    min-height: 1.35em;
    line-height: 1.3;
    font: inherit;
    color: inherit;
  }
  .bottom-label{
    display: block;
    margin-top: 4px;
    font-size: 10px;
    color: #5b6b5e;
  }
  .bottom-dean-wrap .bottom-line,
  .bottom-dean-wrap .bottom-label{
    text-align: Center;
  }
  .dean-signature{
    font-family: var(--font-display);
    font-size: 12.5px;
    font-weight: 600;
    color: var(--pine-900);
    letter-spacing: 0.01em;
    white-space: nowrap;
  }
  .dean-signature.is-approved{
    color: var(--pine-800);
  }
  .dean-signature.is-approved strong{
    color: var(--pine-900);
    font-weight: 700;
  }
  .dear-dean-note{
    display: inline;
    font-weight: 700;
    color: var(--pine-900);
    margin-left: 4px;
  }

  .period-step.is-locked{ background: transparent; border: 1px solid #b9c2bb; }

  @media (max-width: 720px){
    .period-toolbar{
      flex-wrap: wrap;
      justify-content: center;
      gap: 10px;
      margin-bottom: 12px;
    }
    .period-toolbar .btn-outline{ flex: 1 1 auto; justify-content: center; }
    .period-status{ order: -1; flex-basis: 100%; }
    .period-label{ font-size: 13px; padding: 6px 16px; }
    .student-bottom-fields{ flex-wrap: wrap; }
    .bottom-dean-wrap{
      flex: 1 1 100%;
      width: auto;
      margin-top: 8px;
    }
  }

  @media (max-width: 480px){
    .period-toolbar .btn-outline{ padding: 8px 12px; font-size: 12px; }
    .period-label{ min-width: 100px; }
  }

  @media print{
    #chartLockedBanner{ display: none !important; }

    .period-toolbar{ display: none !important; }
    .student-bottom-fields{
      display: flex !important;
      flex-direction: row !important;
      flex-wrap: nowrap !important;
      align-items: flex-end !important;
      gap: 8mm !important;
      margin-top: 3mm !important;
      padding-top: 2mm !important;
      border-top: 1px solid #2a3a2e !important;
    }
    .bottom-field-name,
    .bottom-field-course{
      flex: 1 1 0 !important;
      min-width: 0 !important;
    }
    .bottom-dean-wrap{
      flex: 0 0 40mm !important;
      width: 40mm !important;
      max-width: 40mm !important;
      text-align: Center !important;
    }
    .bottom-line{
      display: block !important;
      width: 100% !important;
      border: 0 !important;
      border-bottom: 1px solid #1d271f !important;
      min-height: 1.35em !important;
      padding: 4px 0 2px !important;
      color: #000 !important;
      font-weight: 600 !important;
    }
    .bottom-label{
      display: block !important;
      margin-top: 4px !important;
      font-size: 8pt !important;
      color: #5b6b5e !important;
    }
    .bottom-dean-wrap .bottom-line,
    .bottom-dean-wrap .bottom-label{
      text-align: Center !important;
    }
    .dean-signature{
      color: #0e3d24 !important;
      font-weight: 700 !important;
      text-align: Center !important;
    }
    .dear-dean-note{ color: #0e3d24 !important; font-weight: 700 !important; }
    @page{
      /* Flexible for short bond (Letter/A4) and long bond (Legal/Folio) — browser print dialog picks paper */
      size: landscape;
      margin: 6mm;
    }
    #chartLockedBanner,
    .topbar,
    .period-toolbar,
    #saveStatus{ display: none !important; }
    html, body{
      width: 100% !important;
      height: auto !important;
      background: #fff !important;
    }
    .sheet-wrap, .sheet, #printSheet{
      width: 100% !important;
      max-width: none !important;
      margin: 0 !important;
      box-shadow: none !important;
      border: none !important;
    }
    .period-panel{ display: none !important; }
    .period-panel.is-active{ display: block !important; }
    #fingerprintSection, dialog{ display: none !important; }
    *{ -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
  }
  

  /* Match original subject-code pill look (empty rounded field) */
  select.subject-code-input{
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
    height: 28px;
    min-height: 28px;
    text-align: center;
    text-align-last: center;
    background: rgba(255,255,255,0.10);
    border: 1px solid rgba(255,255,255,0.40);
    border-radius: 8px;
    color: var(--paper, #f7f4e8);
    font-family: var(--font-display, Georgia, "Times New Roman", serif);
    font-weight: 700;
    font-size: 12px;
    letter-spacing: 0.02em;
    padding: 2px 6px;
    margin: 2px 0 0;
    cursor: pointer;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-image: none;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.12);
  }
  select.subject-code-input:focus{
    outline: none;
    border-color: rgba(201, 162, 39, 0.9);
    background: rgba(255,255,255,0.16);
  }
  select.subject-code-input option{
    color: #1d271f;
    background: #fff;
    font-weight: 600;
  }
  select.subject-code-input:disabled{
    opacity: .95;
    cursor: default;
  }
@media print{
    select.subject-code-input{
      -webkit-appearance: none !important;
      appearance: none !important;
      background: transparent !important;
      border: 1px solid rgba(255,255,255,0.45) !important;
      border-radius: 4px !important;
      color: #ffffff !important;
      font-size: 9pt !important;
      font-weight: 700 !important;
      padding: 2px !important;
      box-shadow: none !important;
    }
  }
</style>
</head>
<body>

<header class="topbar">
  <div class="brand">
    <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="brand-logo">
    <div class="brand-text">
      <span class="brand-title">CSJ Self-Monitoring Dashboard</span>
      <span class="brand-sub">Higher Education Department &middot; Student View</span>
    </div>
  </div>
  <div class="topbar-actions">
    <span id="saveStatus" class="save-status" aria-live="polite"></span>
    <button id="submitBtn" class="btn btn-primary" type="button">
      <svg viewBox="0 0 24 24" class="icon"><path d="M5 3h11l5 5v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M8 3v6h8V3" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M7 21v-7h10v7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
      Submit
    </button>
    <button id="notifyBtn" class="btn btn-ghost" type="button" title="Instructor messages" aria-label="Messages" style="position:relative;">
      🔔<span id="notifyBadge" style="display:none;position:absolute;top:2px;right:2px;min-width:16px;height:16px;padding:0 4px;border-radius:999px;background:#c0392b;color:#fff;font-size:10px;line-height:16px;text-align:center;font-weight:700;">0</span>
    </button>
    <button id="profileBtn" class="btn btn-ghost" type="button">Profile</button>
    <button id="feedbackBtn" class="btn btn-ghost" type="button" title="Send feedback">Feedback</button>
    <button id="printBtn" class="btn btn-ghost" type="button">
      <svg viewBox="0 0 24 24" class="icon"><path d="M6 9V3h12v6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><rect x="4" y="9" width="16" height="8" rx="1" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M6 14h12v7H6z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
      Print
    </button>
<?php if ($studentLoggedIn): ?>
    <a id="logoutBtn" class="btn btn-ghost" href="logout.php" style="text-decoration:none;">Logout</a>
    <?php endif; ?>
  </div>
</header>

<?php
require_once __DIR__ . '/php/semester_popup.php';
csj_semester_popup_render([
    'seconds' => CSJ_WELCOME_POPUP_SECONDS,
    'rightClickClose' => true,   // right-click closes the semester dialog
    'show' => $csjNewSemesterMsg !== '' ? [
        'title'    => 'New Semester',
        'headline' => $csjNewSemesterMsg,
        'sub'      => 'Your monitoring sheets (Prelims, Midterms, Finals) start fresh for ' . ($meta['semester'] ?? 'the new semester') . '.',
    ] : null,
]);
?>
<script>window.CSJ_TRANSITION_ID = <?= json_encode($csjTransitionId) ?>;</script>
<?php if (!empty($csjHasAnyApproved)): ?>
  <div id="chartLockedBanner" style="max-width:1180px;margin:12px auto 0;padding:12px 16px;background:#e8f5e9;border:1px solid #a5d6a7;border-radius:10px;color:#1b5e20;font-size:13px;font-weight:600;display:none;">
    Your monitoring chart was approved by the Dean. You can view and print it, but you can no longer edit or submit.
  </div>
<?php endif; ?>
<main class="sheet-wrap">
  <section class="sheet" id="printSheet">

    <div class="letterhead">
      <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="letterhead-logo logo-left">
      <div class="letterhead-text">
        <h1><?= htmlspecialchars($meta['college'] ?? 'COLEGIO DE SAN JOSE, JARO, ILOILO CITY, INC.') ?></h1>
        <p class="address">E. Lopez St., Brgy. Our Lady of Fatima, Jaro, Iloilo City</p>
        <h2><?= htmlspecialchars($meta['department'] ?? 'HIGHER EDUCATION DEPARTMENT') ?></h2>
        <h3 id="chartTitle"><?= htmlspecialchars($periods[$firstKey]['chartTitle']) ?></h3>
        <p class="semester"><?= htmlspecialchars($meta['semester'] ?? (function_exists('csj_get_current_semester') ? csj_get_current_semester() : 'First Semester, AY 2026-2027')) ?></p>
      </div>
      <img src="assets/logos/dc-slmes-logo.png" alt="Daughters of Charity - St. Louise de Marillac Educational System" class="letterhead-logo logo-right">
    </div>

    <p class="dear-student">
      Dear Student, fill out each box below with what you learned or accomplished for every
      review event of the corresponding subject. This chart is meant to help you see your
      progress and manage your time before each exam period.
      <strong class="dear-dean-note">— The Dean</strong>
    </p>

    <div class="period-toolbar">
      <button id="periodPrev" class="btn btn-outline" type="button">
        <svg viewBox="0 0 24 24" class="icon" width="15" height="15"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        Previous
      </button>
      <div class="period-status">
        <span id="periodLabel" class="period-label"><?= htmlspecialchars($periodDefs[$firstKey]['label']) ?></span>
        <div class="period-steps" aria-hidden="true">
          <?php foreach ($periodDefs as $key => $def): ?>
          <span class="period-step<?= $key === $firstKey ? ' is-current' : '' ?><?= empty($csjPeriodAccess[$key]) ? ' is-locked' : '' ?>" data-step="<?= $key ?>"></span>
          <?php endforeach; ?>
        </div>
      </div>
      <button id="periodNext" class="btn btn-outline" type="button">
        Next
        <svg viewBox="0 0 24 24" class="icon" width="15" height="15"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
    </div>


    <?php foreach ($periodDefs as $key => $def):
        $subjects = $periods[$key]['subjects'];
        $rows     = $periods[$key]['rows'];
        $panelDeanApproved = !empty($periods[$key]['deanApproved']);
        $panelDeanBy = (string)($periods[$key]['deanApprovedBy'] ?? 'Dean');
    ?>
    <section class="period-panel<?= $key === $firstKey ? ' is-active' : '' ?>" data-period="<?= $key ?>" data-chart-title="<?= htmlspecialchars($periods[$key]['chartTitle'], ENT_QUOTES) ?>" data-dean-approved="<?= $panelDeanApproved ? '1' : '0' ?>" data-locked="<?= !empty($csjPeriodAccess[$key]) ? '0' : '1' ?>" data-dean-by="<?= htmlspecialchars($panelDeanBy, ENT_QUOTES) ?>">
      <div class="table-scroll">
      <table class="chart-table" id="<?= $def['tableId'] ?>">
        <colgroup>
          <?php for ($i = 0; $i < count($subjects); $i++): ?>
            <col class="col-subject">
          <?php endfor; ?>
        </colgroup>
        <thead>
          <tr class="head-row">
            <?php foreach ($subjects as $s): ?>
            <th class="subject-head">
              <span class="subject-label">Subject <?= (int)$s['id'] ?></span>
              <select
                class="subject-code-input"
                data-subject="<?= (int)$s['id'] ?>"
                <?= !empty($panelDeanApproved) ? 'disabled' : '' ?>
              >
                <option value="">&nbsp;</option>
                <?php
                  $curCode = trim((string)($s['code'] ?? ''));
                  // Drop section suffix for display/match: "EDUC412-1" → "EDUC 412"
                  if (function_exists('csj_strip_section_code')) {
                      $curCodeDisp = csj_strip_section_code($curCode);
                  } else {
                      $curCodeDisp = preg_replace('/-\d+$/', '', $curCode) ?? $curCode;
                  }
                  $curNorm = function_exists('csj_code_base_key')
                      ? csj_code_base_key($curCode)
                      : strtoupper(preg_replace('/\s+/', '', preg_replace('/-\d+$/', '', $curCode) ?? $curCode) ?? '');
                  $found = false;
                  foreach ($csjSubjectCodes as $catCode):
                    $catNorm = function_exists('csj_code_base_key')
                        ? csj_code_base_key((string)$catCode)
                        : strtoupper(preg_replace('/\s+/', '', (string)$catCode) ?? '');
                    $sel = ($curNorm !== '' && $catNorm === $curNorm);
                    if ($sel) $found = true;
                ?>
                <option value="<?= htmlspecialchars((string)$catCode, ENT_QUOTES) ?>"<?= $sel ? ' selected' : '' ?>><?= htmlspecialchars((string)$catCode) ?></option>
                <?php endforeach;
                  // Keep a previously saved code that is not in the filtered list
                  if ($curCodeDisp !== '' && !$found):
                ?>
                <option value="<?= htmlspecialchars($curCodeDisp, ENT_QUOTES) ?>" selected><?= htmlspecialchars($curCodeDisp) ?> (saved)</option>
                <?php endif; ?>
              </select>
            </th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
          <tr class="entry-row" data-event="<?= (int)$r['event'] ?>">
            <?php foreach ($subjects as $s):
                  $val = $r['entries'][(string)$s['id']] ?? ''; ?>
            <td class="entry-cell">
              <div class="cell-inner">
                <div
                  class="cell-text"
                  contenteditable="<?= !empty($panelDeanApproved) ? 'false' : 'true' ?>"
                  data-row="<?= (int)$r['event'] ?>"
                  data-subject="<?= (int)$s['id'] ?>"
                  data-placeholder=""
                ><?= htmlspecialchars($val) ?></div>
              </div>
            </td>
            <?php endforeach; ?>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr class="approve-row">
            <?php foreach ($subjects as $s): ?>
            <?php
              $reviewStatus = in_array($s['reviewStatus'] ?? '', ['approved', 'denied', 'pending'], true)
                  ? $s['reviewStatus']
                  : (!empty($s['approved']) ? 'approved' : 'pending');
              $reviewerName = (string)($s['reviewedBy'] ?? $s['instructor'] ?? '');
            ?>
            <td class="approve-cell" data-subject="<?= (int)$s['id'] ?>">
              <div class="approve-box <?= $reviewStatus === 'approved' ? 'is-approved' : ($reviewStatus === 'denied' ? 'is-denied' : 'is-pending') ?>">
                <svg viewBox="0 0 24 24" class="approve-icon">
                  <?php if ($reviewStatus === 'approved'): ?>
                    <circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.12"/>
                    <path d="M7 12.5l3 3 7-7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                  <?php elseif ($reviewStatus === 'denied'): ?>
                    <circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.12"/>
                    <path d="M8 8l8 8m0-8l-8 8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
                  <?php else: ?>
                    <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-dasharray="3 3"/>
                    <path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
                  <?php endif; ?>
                </svg>
                <span class="approve-word"><?= htmlspecialchars(ucfirst($reviewStatus), ENT_QUOTES, 'UTF-8') ?></span>
              </div>
              <div class="instructor-name"><?= htmlspecialchars($reviewStatus === 'pending' || $reviewerName === '' ? '—' : $reviewerName) ?></div>
            </td>
            <?php endforeach; ?>
          </tr>
        </tfoot>
      </table>
      </div>
    </section>
    <?php endforeach; ?>

    <?php
      $bottomDeanApproved = !empty($periods[$firstKey]['deanApproved']);
    ?>
    <div class="student-bottom-fields">
      <div class="bottom-field bottom-field-name">
        <div id="studentNameLabel" class="bottom-line"><?= htmlspecialchars($studentName !== '' ? $studentName : '—', ENT_QUOTES) ?></div>
        <input id="studentName" type="hidden" value="<?= htmlspecialchars($studentName, ENT_QUOTES) ?>">
        <span class="bottom-label">Student Name</span>
      </div>
      <div class="bottom-field bottom-field-course">
        <div id="courseYearLabel" class="bottom-line"><?= htmlspecialchars($courseYear !== '' ? $courseYear : '—', ENT_QUOTES) ?></div>
        <input id="courseYear" type="hidden" value="<?= htmlspecialchars($courseYear, ENT_QUOTES) ?>">
        <span class="bottom-label">Course &amp; Year</span>
      </div>
      <div class="bottom-field bottom-dean-wrap">
        <div id="bottomDeanSig" class="bottom-line dean-signature<?= $bottomDeanApproved ? ' is-approved' : '' ?>" data-dean-sig aria-live="polite"><?php if ($bottomDeanApproved): ?><strong>Approved</strong><?php else: ?>&nbsp;<?php endif; ?></div>
        <span class="bottom-label">Dean Approval</span>
      </div>
    </div>

  </section>
</main>

<dialog id="profileDialog" style="border:1px solid #d9d0b8;border-radius:10px;padding:0;max-width:420px;width:calc(100% - 32px);max-height:90vh;overflow:auto;box-shadow:0 18px 40px -20px rgba(14,61,36,.35);">
  <form method="dialog" style="padding:22px;min-width:0;">
    <h2 style="margin:0 0 4px;color:#0e3d24;font-family:Georgia,serif;">Student Profile</h2>
    <p style="margin:0 0 12px;color:#5b6b5e;font-size:12px;">Your profile information used for this monitoring chart.</p>
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px;">
      <div id="profilePhotoPreviewWrap" style="width:64px;height:64px;border-radius:50%;overflow:hidden;flex:0 0 auto;background:#eef2ea;border:1px solid #d9d0b8;display:flex;align-items:center;justify-content:center;">
        <img id="profilePhotoPreview" src="<?= $profilePhotoUrl ? htmlspecialchars($profilePhotoUrl, ENT_QUOTES) : '' ?>" alt="" style="width:100%;height:100%;object-fit:cover;<?= $profilePhotoUrl ? '' : 'display:none;' ?>">
        <span id="profilePhotoInitial" style="font-family:Georgia,serif;font-weight:700;color:#14522f;font-size:20px;<?= $profilePhotoUrl ? 'display:none;' : '' ?>"><?= htmlspecialchars($studentName !== '' ? strtoupper(substr($studentName, 0, 1)) : '?') ?></span>
      </div>
      <div>
        <input id="profilePhotoInput" type="file" accept="image/png,image/jpeg,image/webp,image/gif" style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0;">
        <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
          <button id="profilePhotoBtn" type="button" class="btn btn-ghost" style="display:inline-flex!important;visibility:visible!important;opacity:1!important;padding:7px 14px;font-size:11.5px;color:#14522f!important;background:#fff!important;border:1px solid #14522f!important;">Browse</button>
          <button id="profilePhotoRemoveBtn" type="button" class="btn btn-ghost" style="display:inline-flex!important;padding:7px 14px;font-size:11.5px;color:#b3452f!important;background:#fff!important;border:1px solid #b3452f!important;">Remove</button>
        </div>
        <div id="profilePhotoStatus" style="font-size:10.5px;color:#5b6b5e;margin-top:4px;"></div>
      </div>
    </div>

    <div id="fingerprintSection" style="display:block!important;visibility:visible!important;opacity:1!important;position:relative;z-index:20;margin:0 0 14px;padding:10px 12px;border:1px solid #d9d0b8;border-radius:8px;background:#fafbf7;">
      <div style="font-size:12px;font-weight:700;color:#1d271f;margin-bottom:3px;">Fingerprint / Device Biometrics</div>
      <div style="font-size:10.5px;color:#5b6b5e;margin-bottom:8px;">Register your fingerprint for optional quick login. Your device will securely handle the fingerprint/passkey verification; no fingerprint image is uploaded.</div>
      <button id="fingerprintBtn" class="btn btn-ghost" type="button" style="display:inline-flex!important;visibility:visible!important;opacity:1!important;position:relative;z-index:30;padding:8px 12px;font-size:11.5px;color:#14522f!important;background:#fff!important;border:1px solid #14522f!important;">Register your fingerprint</button>
      <span id="fingerprintStatus" style="display:inline;font-size:10.5px;color:#5b6b5e;margin-left:7px;"></span>
    </div>

    <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;color:#1d271f;">Student ID
      <input id="profileStudentId" type="text" value="<?= htmlspecialchars($profileStudentId, ENT_QUOTES) ?>" placeholder="—" readonly tabindex="-1" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;background:#f4f6f2;color:#1d271f;cursor:default;">
    </label>

    <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;color:#1d271f;">Phone Number
      <input id="profilePhone" type="tel" value="<?= htmlspecialchars($profileContact, ENT_QUOTES) ?>" placeholder="09XXXXXXXXX" autocomplete="tel" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;">
    </label>
    
    <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;color:#1d271f;">Student Name
      <input id="profileName" type="text" value="<?= htmlspecialchars($studentName, ENT_QUOTES) ?>" placeholder="—" readonly tabindex="-1" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;background:#f4f6f2;color:#1d271f;cursor:default;">
    </label>
    <label style="display:block;margin-bottom:16px;font-size:12px;font-weight:600;color:#1d271f;">Course &amp; Year
      <input id="profileCourseYear" type="text" value="<?= htmlspecialchars($courseYear, ENT_QUOTES) ?>" placeholder="—" readonly tabindex="-1" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;background:#f4f6f2;color:#1d271f;cursor:default;">
    </label>
    <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;color:#1d271f;">Status
      <input id="profileStatus" type="text" value="<?= htmlspecialchars(ucfirst((string)($profileStatus ?? '')), ENT_QUOTES) ?>" placeholder="Regular / Irregular" readonly style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;background:#f4f6f2;">
    </label>
    <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;color:#1d271f;">Major
      <input id="profileMajor" type="text" value="<?= htmlspecialchars((string)($profileMajor ?? ''), ENT_QUOTES) ?>" placeholder="—" readonly style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;background:#f4f6f2;">
    </label>
    <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;color:#1d271f;">Email
      <input id="profileEmail" type="email" value="<?= htmlspecialchars($profileEmail, ENT_QUOTES) ?>" placeholder="student@example.com" autocomplete="email" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;">
    </label>

    <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;color:#1d271f;">Address
      <input id="profileAddress" type="text" value="<?= htmlspecialchars($profileAddress, ENT_QUOTES) ?>" placeholder="Home address" autocomplete="street-address" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;">
    </label><span id="profileSaveStatus" style="display:block;font-size:10.5px;color:#5b6b5e;margin-bottom:10px;"></span>
    <label style="display:block;margin-bottom:14px;font-size:12px;font-weight:600;color:#1d271f;">Guardian
      <input id="profileGuardian" type="text" value="<?= htmlspecialchars($profileGuardian, ENT_QUOTES) ?>" placeholder="Guardian name" autocomplete="name" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;">
    </label>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px;">
      <button id="saveProfileBtn" class="btn btn-primary" type="button" style="padding:8px 12px;font-size:11.5px;">Save Profile</button>
      <button id="passwordBtn" class="btn btn-ghost" type="button" style="padding:8px 12px;font-size:11.5px;">Password</button>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px;">
      <button id="profileClose" class="btn btn-ghost" type="button" style="background:#14522f;color:#fff;">Close</button>
    </div>
  </form>
</dialog>

<dialog id="passwordDialog" style="border:1px solid #d9d0b8;border-radius:10px;padding:0;max-width:380px;width:calc(100% - 32px);box-shadow:0 18px 40px -20px rgba(14,61,36,.35);">
<form method="dialog" style="padding:22px;"><h2 style="margin:0 0 5px;color:#0e3d24;font-family:Georgia,serif;">Password</h2><p id="passwordHint" style="margin:0 0 14px;color:#5b6b5e;font-size:11px;">Change your account password.</p><label id="currentPasswordWrap" style="display:block;margin-bottom:10px;font-size:12px;font-weight:600;">Current Password<input id="currentPassword" type="password" autocomplete="current-password" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;"></label><label style="display:block;margin-bottom:10px;font-size:12px;font-weight:600;">New Password<input id="newPassword" type="password" minlength="8" autocomplete="new-password" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;"></label><label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;">Confirm Password<input id="newPassword2" type="password" minlength="8" autocomplete="new-password" style="display:block;width:100%;margin-top:5px;padding:9px;border:1px solid #d9d0b8;border-radius:6px;box-sizing:border-box;"></label><div id="passwordStatus" style="min-height:18px;font-size:10.5px;color:#5b6b5e;margin-bottom:10px;"></div><div style="display:flex;justify-content:flex-end;gap:8px;"><button id="passwordSaveBtn" class="btn btn-primary" type="button">Save Password</button><button id="passwordClose" class="btn btn-ghost" type="button">Close</button></div></form></dialog>



<footer class="page-footer">
  Approval shown here is read-only. Only the Instructor Dashboard can mark a subject as Approved.
</footer>

<script>window.CSJ_BASE = "./";</script>
<?php
?>
<script>window.CSJ_SUBJECT_CODES = <?= json_encode($csjSubjectCodes, JSON_UNESCAPED_UNICODE) ?>;</script>

<dialog id="csjSuccessDialog" class="csj-dialog" style="max-width:420px;width:min(420px,92vw);border:none;border-radius:16px;padding:0;box-shadow:0 24px 60px rgba(10,40,22,.4);">
  <div style="background:linear-gradient(135deg,#14522f,#1b6b3f);border-radius:16px 16px 0 0;padding:18px 22px;text-align:center;border-bottom:3px solid #e7b416;">
    <h2 id="csjSuccessTitle" style="margin:0;color:#fff;font-family:Georgia,serif;font-size:18px;font-weight:700;">Success</h2>
  </div>
  <div style="padding:22px 24px 24px;text-align:center;">
    <p id="csjSuccessMessage" style="margin:0;font-size:15px;line-height:1.5;color:#1d271f;font-weight:600;"></p>
  </div>
</dialog>
<script>
(function(){
  var dlg = document.getElementById('csjSuccessDialog');
  if (!dlg) return;
  function closeDlg() {
    if (dlg.open) { try { dlg.close(); } catch (e) { dlg.removeAttribute('open'); } }
  }
  dlg.addEventListener('click', function(){ closeDlg(); });
  dlg.addEventListener('contextmenu', function(e){ e.preventDefault(); closeDlg(); });
  dlg.addEventListener('cancel', function(e){ e.preventDefault(); closeDlg(); });
  window.csjShowSuccessDialog = function(title, message) {
    var t = document.getElementById('csjSuccessTitle');
    var m = document.getElementById('csjSuccessMessage');
    if (t) t.textContent = title || 'Success';
    if (m) m.textContent = message || '';
    if (!dlg.open) {
      if (typeof dlg.showModal === 'function') dlg.showModal();
      else dlg.setAttribute('open', '');
    }
  };
})();
</script>

<script src="js/student.js?v=<?= (int)(@filemtime(__DIR__ . '/js/student.js') ?: time()) ?>"></script>

<dialog id="honestyDialog" class="csj-dialog" style="max-width:440px;width:min(440px,92vw);border:none;border-radius:12px;padding:0;">
  <form method="dialog" style="padding:0;" onsubmit="return false;">
    <div style="background:#14522f;border-radius:12px 12px 0 0;padding:18px 22px;display:flex;align-items:center;gap:12px;">
      <span style="font-size:26px;line-height:1;">🚫</span>
      <h2 style="margin:0;color:#fff;font-family:Georgia,serif;font-size:19px;">Honesty Check</h2>
    </div>
    <div style="padding:20px 22px 22px;">
      <p id="honestyDialogMessage" style="margin:0 0 18px;font-size:14px;line-height:1.5;color:#1d271f;font-weight:600;">Don't copy what others have learned lets be honest what you have learned</p>
      <div style="display:flex;justify-content:flex-end;">
        <button type="button" id="honestyDialogClose" class="btn btn-ghost" style="color:#14522f!important;background:#fff!important;border:1px solid #14522f!important;padding:9px 20px;font-weight:700;">Got it</button>
      </div>
    </div>
  </form>
</dialog>

<dialog id="messagesDialog" class="csj-dialog" style="max-width:560px;width:min(560px,94vw);border:none;border-radius:12px;padding:0;">
  <form method="dialog" style="padding:20px 22px 16px;" onsubmit="return false;">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
      <h2 id="messagesTitle" style="margin:0;color:#0e3d24;font-family:Georgia,serif;">Notifications</h2>
      <button type="button" id="messagesClose" class="btn btn-ghost" style="font-size:18px;min-width:36px;color:#14522f!important;background:#fff!important;border:1px solid #14522f!important;">&times;</button>
    </div>
    <p id="messagesSubtitle" style="margin:6px 0 12px;font-size:12px;color:#5b6b5e;">Announcements and messages from your instructors. Click a conversation to open and reply.</p>

    <!-- INBOX VIEW: one row per instructor conversation -->
    <div id="messagesInboxView">
      <div id="messagesInboxList" style="max-height:360px;overflow:auto;display:flex;flex-direction:column;gap:6px;padding:2px;"></div>
    </div>

    <!-- THREAD VIEW: full conversation with one instructor, with reply box -->
    <div id="messagesThreadView" style="display:none;">
      <button type="button" id="messagesBackBtn" class="btn btn-ghost" style="font-size:11px;padding:5px 10px;margin-bottom:8px;color:#14522f!important;background:#fff!important;border:1px solid #14522f!important;">&larr; Back to messages</button>
      <div id="messagesList" style="max-height:280px;overflow:auto;display:flex;flex-direction:column;gap:10px;padding:4px 2px 8px;"></div>
      <div style="border-top:1px solid #e9e3d0;padding-top:12px;margin-top:8px;">
        <textarea id="studentReplyInput" rows="2" maxlength="2000" placeholder="Type your reply to the instructor…" style="width:100%;box-sizing:border-box;padding:10px;border:1px solid #d9d0b8;border-radius:8px;font:inherit;resize:vertical;"></textarea>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:8px;">
          <span id="studentReplyStatus" style="font-size:11px;color:#5b6b5e;min-height:14px;"></span>
          <div style="display:flex;gap:8px;">
            <button type="button" id="studentReplySend" class="btn btn-primary">Send reply</button>
          </div>
        </div>
      </div>
    </div>
  </form>
</dialog>

<dialog id="feedbackDialog" class="csj-dialog" style="max-width:480px;width:min(480px,94vw);border:none;border-radius:12px;padding:0;">
  <form method="dialog" style="padding:20px 22px 16px;" onsubmit="return false;">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
      <h2 style="margin:0;color:#0e3d24;font-family:Georgia,serif;">Feedback</h2>
      <button type="button" id="feedbackClose" class="btn btn-ghost" style="font-size:18px;min-width:36px;color:#14522f!important;background:#fff!important;border:1px solid #14522f!important;">&times;</button>
    </div>
    <p style="margin:6px 0 12px;font-size:12px;color:#5b6b5e;">Tell us about a problem or a suggestion for the Self-Monitoring Dashboard. This is sent with your name attached.</p>
    <textarea id="feedbackInput" rows="5" maxlength="4000" placeholder="Write your feedback…" style="width:100%;box-sizing:border-box;padding:10px;border:1px solid #d9d0b8;border-radius:8px;font:inherit;resize:vertical;"></textarea>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:10px;">
      <span id="feedbackStatus" style="font-size:11px;color:#5b6b5e;min-height:14px;"></span>
      <button type="button" id="feedbackSend" class="btn btn-primary">Send feedback</button>
    </div>
  </form>
</dialog>

</body>
</html>
