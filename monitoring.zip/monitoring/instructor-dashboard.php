<?php
session_start();
if (empty($_SESSION['instructor_authenticated']) || empty($_SESSION['instructor_key'])) { header('Location: index.php'); exit; }
// Same fix as student.php: without this, the browser's Back/Forward
// button could show a cached copy of this page from before logout
// instead of re-running the session check above.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// The project root is the only dashboard URL. This file used to live at
// /instructor/index.php, so calculate the public project base dynamically.
$requestDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$appBase = $requestDir;
if (basename($requestDir) === 'instructor') {
    $appBase = rtrim(str_replace('\\', '/', dirname($requestDir)), '/');
}
if ($appBase === '/') { $appBase = ''; }

if (empty($_SESSION['instructor_key'])) {
    $cookieKey = preg_replace('/[^a-f0-9]/', '', (string)($_COOKIE['csj_instructor_key'] ?? ''));
    $_SESSION['instructor_key'] = strlen($cookieKey) === 32 ? $cookieKey : bin2hex(random_bytes(16));
}
$instructorKey = $_SESSION['instructor_key'];
setcookie('csj_instructor_key', $instructorKey, [
    'expires' => time() + 31536000,
    'path' => '/',
    'samesite' => 'Lax',
]);

require __DIR__ . '/php/db.php';

// New-semester welcome: shown ONCE per account per transition (remembered in the database),
// never to a teacher who signed up after the semester already changed.
$csjShowInstructorWelcome = false;
$csjWelcomeSemesterLabel = '';
$csjTransitionId = '';
try {
    $wPdo = csj_student_db();
    $welcome = csj_welcome_pending($wPdo, 'instructor', $instructorKey);
    $csjTransitionId = $welcome['transitionId'];
    $csjWelcomeSemesterLabel = $welcome['semester'];
    if (!empty($welcome['pending'])) {
        $csjShowInstructorWelcome = true;
        csj_welcome_mark_seen($wPdo, 'instructor', $instructorKey, $welcome['transitionId']);
    }
} catch (Throwable $e) {
    $csjShowInstructorWelcome = false;
}

$catalogPath = __DIR__ . '/php/subjects_catalog.php';
if (!is_file($catalogPath)) {
    // Fallback so the dashboard still loads if the catalog file is missing.
    $subjectCatalog = ['CC102-1', 'CC102-2', 'SIA101', 'ENG101', 'MATH101', 'FM303'];
} else {
    $subjectCatalog = require $catalogPath;
    if (!is_array($subjectCatalog)) $subjectCatalog = [];
}

// Map normalized key → display code (e.g. mgt302 → "Mgt 302")
$csjCatalogByNorm = [];
foreach ($subjectCatalog as $_c) {
    $_c = trim((string)$_c);
    if ($_c === '') continue;
    $_k = strtolower(preg_replace('/[^a-z0-9]/i', '', $_c) ?? '');
    if ($_k !== '' && !isset($csjCatalogByNorm[$_k])) $csjCatalogByNorm[$_k] = $_c;
}
$csjMapSelection = static function (array $codes) use ($csjCatalogByNorm): array {
    $out = [];
    $seen = [];
    foreach ($codes as $raw) {
        $k = strtolower(preg_replace('/[^a-z0-9]/i', '', (string)$raw) ?? '');
        if ($k === '' || isset($seen[$k])) continue;
        $seen[$k] = true;
        $out[] = $csjCatalogByNorm[$k] ?? preg_replace('/-\d+$/', '', trim((string)$raw));
    }
    return $out;
};

// Prefer official current semester (advanced by Dean when all students are approved).
// After transition, instructor_subject_selections are cleared so Load Subject starts empty.
$defaultSemester = '';
$instructor = ['teacher_id'=>'','full_name' => '', 'program'=>'', 'address'=>'', 'contact_no'=>'', 'email' => '', 'photo_path' => ''];
$mySelections = [];
$hasBiometric = false;

try {
    $pdo = csj_db();
    foreach ([
      'teacher_id VARCHAR(50) DEFAULT NULL',
      'program VARCHAR(150) DEFAULT NULL',
      'address VARCHAR(255) DEFAULT NULL',
      'contact_no VARCHAR(50) DEFAULT NULL',
      'password_hash VARCHAR(255) DEFAULT NULL'
    ] as $col) { try { $pdo->exec('ALTER TABLE instructor_profiles ADD COLUMN '.$col); } catch (Throwable $ignored) {} }

    $stmt = $pdo->prepare('SELECT teacher_id, full_name, program, address, contact_no, email, photo_path FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
    $stmt->execute([$instructorKey]);
    if ($row = $stmt->fetch()) {
        $instructor = $row;
    }

    if (function_exists('csj_get_current_semester')) {
        $defaultSemester = csj_get_current_semester($pdo);
    }

    if ($defaultSemester !== '') {
        $stmt = $pdo->prepare('SELECT subject_code FROM instructor_subject_selections WHERE instructor_key = ? AND semester = ? ORDER BY subject_code');
        $stmt->execute([$instructorKey, $defaultSemester]);
        $mySelections = $csjMapSelection(array_column($stmt->fetchAll(), 'subject_code'));
    }

    // Fallback only if system semester is missing
    if ($defaultSemester === '') {
        try {
            $semStmt = $pdo->prepare(
                "SELECT semester FROM instructor_subject_selections
                 WHERE instructor_key = ? AND semester IS NOT NULL AND TRIM(semester) <> ''
                 ORDER BY selection_id DESC LIMIT 1"
            );
            $semStmt->execute([$instructorKey]);
            $lastSem = $semStmt->fetchColumn();
            if (is_string($lastSem) && trim($lastSem) !== '') {
                $defaultSemester = trim($lastSem);
                $stmt = $pdo->prepare('SELECT subject_code FROM instructor_subject_selections WHERE instructor_key = ? AND semester = ? ORDER BY subject_code');
                $stmt->execute([$instructorKey, $defaultSemester]);
                $mySelections = $csjMapSelection(array_column($stmt->fetchAll(), 'subject_code'));
            }
        } catch (Throwable $ignored) {}
    }

    if ($defaultSemester === '' && function_exists('csj_default_semester')) {
        $defaultSemester = csj_default_semester();
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) AS c FROM instructor_biometric_credentials WHERE instructor_key = ?');
    $stmt->execute([$instructorKey]);
    $hasBiometric = ((int)($stmt->fetch()['c'] ?? 0)) > 0;
} catch (Throwable $e) {
    // MySQL not connected yet / schema not imported -- page still renders.
    if ($defaultSemester === '' && function_exists('csj_default_semester')) {
        $defaultSemester = csj_default_semester();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CSJ Instructor Dashboard</title>
<link rel="icon" href="<?= htmlspecialchars($appBase . "/assets/logos/csj-seal.jpg", ENT_QUOTES) ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($appBase . "/css/style.css", ENT_QUOTES) ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($appBase . "/instructor/css/instructor.css", ENT_QUOTES) ?>">
</head>
<body>

<header class="topbar">
  <div class="brand">
    <img src="<?= htmlspecialchars($appBase . "/assets/logos/csj-seal.jpg", ENT_QUOTES) ?>" alt="Colegio de San Jose seal" class="brand-logo">
    <div class="brand-text">
      <span class="brand-title">CSJ Instructor Dashboard</span>
      <span class="brand-sub">Higher Education Department &middot; Instructor View</span>
    </div>
  </div>
  <div class="topbar-actions">
    <span id="statusMsg" class="save-status" aria-live="polite"></span>
    <button id="chooseSubjectsBtn" class="btn btn-primary" type="button">
      <svg viewBox="0 0 24 24" class="icon"><path d="M4 6h16M4 12h16M4 18h10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
      Load Subject
    </button>
    <button id="profileBtn" class="btn btn-ghost" type="button">Profile</button>
    <button id="feedbackBtn" class="btn btn-ghost" type="button" title="Send feedback">Feedback</button>
    <button id="notifyBtn" class="btn btn-ghost" type="button" title="Student replies" aria-label="Notifications" style="position:relative;">
      🔔<span id="notifyBadge" style="display:none;position:absolute;top:2px;right:2px;min-width:16px;height:16px;padding:0 4px;border-radius:999px;background:#c0392b;color:#fff;font-size:10px;line-height:16px;text-align:center;font-weight:700;">0</span>
    </button>
    <a class="btn btn-ghost" href="logout.php">Logout</a>
</div>
</header>

<main class="sheet-wrap">
  <section class="sheet instr-sheet">

    <div class="letterhead">
      <img src="<?= htmlspecialchars($appBase . "/assets/logos/csj-seal.jpg", ENT_QUOTES) ?>" alt="Colegio de San Jose seal" class="letterhead-logo logo-left">
      <div class="letterhead-text">
        <h1>COLEGIO DE SAN JOSE, JARO, ILOILO CITY, INC.</h1>
        <p class="address">E. Lopez St., Brgy. Our Lady of Fatima, Jaro, Iloilo City</p>
        <h2>HIGHER EDUCATION DEPARTMENT</h2>
        <h3>INSTRUCTOR MONITORING &amp; APPROVAL DASHBOARD</h3>
      </div>
      <img src="<?= htmlspecialchars($appBase . "/assets/logos/dc-slmes-logo.png", ENT_QUOTES) ?>" alt="Daughters of Charity - St. Louise de Marillac Educational System" class="letterhead-logo logo-right">
    </div>

    <div class="instr-toolbar">
      <div class="semester-field">
        <span>Semester</span>
        <span class="semester-label-value" id="semesterLabel" style="font-weight:700;font-size:14px;"><?= $defaultSemester !== '' ? htmlspecialchars($defaultSemester, ENT_QUOTES) : '—' ?></span>
        <input type="hidden" id="semesterInput" value="<?= htmlspecialchars($defaultSemester, ENT_QUOTES) ?>">
      </div>
      <div class="instr-name-pill" id="instructorNamePill">
        <?= $instructor['full_name'] !== '' ? htmlspecialchars($instructor['full_name']) : 'No instructor name set — click Profile' ?>
      </div>
    </div>

    <p class="dear-student">
      Select the subject/section codes you handle this semester, then use
      <strong>View Enrolled Students</strong> on any subject card to see which students have
      listed that subject on their self-monitoring chart and review/approve their entries.
    </p>

    <div id="mySubjectsGrid" class="subjects-grid" data-selections='<?= htmlspecialchars(json_encode($mySelections), ENT_QUOTES) ?>'>
      <!-- populated by instructor.js -->
      <p class="empty-hint" id="emptyHint">You haven't chosen any subjects yet. Click "Load Subject" to get started.</p>
    </div>

  </section>
</main>

<!-- Load Subject dialog -->
<dialog id="subjectsDialog" class="csj-dialog wide">
  <form method="dialog" class="dialog-form">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
      <h2 style="margin:0;">Load Subject(s) You Handle</h2>
      <button type="button" class="btn btn-ghost dialog-x" id="subjectsCloseX" aria-label="Close">&times;</button>
    </div>
    <p class="dialog-sub">Semester: <span id="subjectsDialogSemester"></span></p>
    <input id="subjectSearch" type="text" class="subject-search" placeholder="Search subject code, e.g. FM303 or ENG">
    <div id="subjectCheckList" class="subject-checklist">
      <?php foreach ($subjectCatalog as $code): ?>
        <label class="subject-check-item">
          <input type="checkbox" class="subject-check" value="<?= htmlspecialchars($code) ?>">
          <span><?= htmlspecialchars($code) ?></span>
        </label>
      <?php endforeach; ?>
    </div>
    <div class="dialog-actions">
      <span id="subjectsCountMsg" class="dialog-hint"></span>
      <div>
        <button id="subjectsSave" class="btn btn-primary" type="button">Save Selections</button>
      </div>
    </div>
  </form>
</dialog>

<!-- Profile dialog -->
<dialog id="profileDialog" class="csj-dialog">
  <form method="dialog" class="dialog-form">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
      <h2 style="margin:0;">Instructor Profile</h2>
      <button type="button" class="btn btn-ghost dialog-x" id="profileCloseX" aria-label="Close">&times;</button>
    </div>

    <!-- Optional profile picture -->
    <div class="profile-photo-section">
      <div class="profile-photo-preview" id="profilePhotoPreview">
        <?php if (!empty($instructor['photo_path'])): ?>
          <img id="profilePhotoImg" src="<?= htmlspecialchars($appBase . '/' . ltrim($instructor['photo_path'], '/'), ENT_QUOTES) ?>" alt="Profile photo">
          <span id="profilePhotoInitial" style="display:none;">?</span>
        <?php else: ?>
          <img id="profilePhotoImg" src="" alt="" style="display:none;">
          <span id="profilePhotoInitial"><?= $instructor['full_name'] !== '' ? htmlspecialchars(mb_substr($instructor['full_name'], 0, 1)) : '?' ?></span>
        <?php endif; ?>
      </div>
      <div class="profile-photo-actions">
        <p class="field-label" style="margin:0 0 6px;">Profile Picture <span class="optional-tag">(optional)</span></p>
        <p class="dialog-sub" style="margin:0 0 10px;">You want to add a Profile picture? Browse a file from your device.</p>
        <div class="photo-btn-row">
          <button type="button" id="profilePhotoBrowse" class="btn btn-ghost">Browse</button>
          <button type="button" id="profilePhotoRemove" class="btn btn-ghost" style="color:#b3452f!important;border-color:#b3452f!important;">Remove</button>
          <input type="file" id="profilePhotoFile" accept="image/*" style="display:none;">
        </div>
        <span id="profilePhotoStatus" class="dialog-hint"></span>
      </div>
    </div>

    <label class="field-label">Full Name
      <input id="profileFullName" type="text" value="<?= htmlspecialchars($instructor['full_name'], ENT_QUOTES) ?>" placeholder="e.g. Prof. R. Salcedo">
    </label>
    <label class="field-label">Teachers/ID
      <input id="profileTeacherId" type="text" value="<?= htmlspecialchars($instructor['teacher_id'], ENT_QUOTES) ?>" readonly>
    </label>
    <label class="field-label">Program
      <input id="profileProgram" type="text" value="<?= htmlspecialchars($instructor['program'], ENT_QUOTES) ?>" placeholder="e.g. Bachelor of Education">
    </label>
    <label class="field-label">Address
      <input id="profileAddress" type="text" value="<?= htmlspecialchars($instructor['address'], ENT_QUOTES) ?>" placeholder="Complete address">
    </label>
    <label class="field-label">Contact No
      <input id="profileContactNo" type="tel" value="<?= htmlspecialchars($instructor['contact_no'], ENT_QUOTES) ?>" placeholder="09XXXXXXXXX">
    </label>
    <label class="field-label">Email
      <input id="profileEmail" type="email" value="<?= htmlspecialchars($instructor['email'], ENT_QUOTES) ?>" placeholder="instructor@csj.edu.ph">
    </label>

    <!-- Optional biometric -->
    <div class="biometric-section" id="biometricSection">
      <h3 class="biometric-title">Biometric Authentication</h3>
      <p class="dialog-sub">Your fingerprint / Face / PIN stays on your device. CSJ stores only a public authentication key, not your biometric image.</p>
      <div class="biometric-card">
        <div class="biometric-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="36" height="36"><path d="M12 2a5 5 0 0 1 5 5v1.5a1 1 0 0 1-2 0V7a3 3 0 1 0-6 0v1.5a1 1 0 0 1-2 0V7a5 5 0 0 1 5-5zm0 8a4 4 0 0 1 4 4v1a1 1 0 0 1-2 0v-1a2 2 0 1 0-4 0v3a1 1 0 0 1-2 0v-3a4 4 0 0 1 4-4zm-1 7.5a1 1 0 0 1 2 0V20a1 1 0 0 1-2 0v-2.5z" fill="currentColor"/></svg>
        </div>
        <div class="biometric-body">
          <strong id="biometricStatusLabel"><?= $hasBiometric ? 'Biometric sign-in is registered on this account' : 'Add a biometric sign-in' ?></strong>
          <p id="biometricHelpText"><?= $hasBiometric ? 'You can register another device or remove the existing credential.' : 'Use the fingerprint sensor, Windows Hello, Face ID, PIN, or another passkey supported by this device.' ?></p>
        </div>
        <div class="biometric-actions">
          <button type="button" id="registerBiometricBtn" class="btn btn-primary"><?= $hasBiometric ? 'Register Another' : 'Register Biometric' ?></button>
          <?php if ($hasBiometric): ?>
            <button type="button" id="removeBiometricBtn" class="btn btn-ghost">Remove</button>
          <?php else: ?>
            <button type="button" id="removeBiometricBtn" class="btn btn-ghost" style="display:none;">Remove</button>
          <?php endif; ?>
        </div>
      </div>
      <p id="biometricError" class="biometric-error" style="display:none;"></p>
    </div>

    <div class="dialog-actions">
      <span></span>
      <div>
        <button id="profileSave" class="btn btn-primary" type="button">Save</button>
      </div>
    </div>
  </form>
</dialog>

<!-- Enrolled students dialog -->
<dialog id="enrolledDialog" class="csj-dialog wide">
  <form method="dialog" class="dialog-form">
    <h2>Enrolled Students — <span id="enrolledSubjectCode"></span></h2>
    <p class="dialog-sub" id="enrolledSemesterLabel"></p>
    <div id="enrolledList" class="enrolled-list">
      <p class="empty-hint">Loading…</p>
    </div>
    <div class="dialog-actions">
      <span></span>
      <div>
        <button id="enrolledClose" class="btn btn-ghost" type="button">Close</button>
      </div>
    </div>
  </form>
</dialog>

<!-- Student chart review dialog (a.k.a. "View Self-Monitoring") -->
<dialog id="reviewDialog" class="csj-dialog widest">
  <form method="dialog" class="dialog-form">
    <h2>Self-Monitoring Chart</h2>

    <div class="review-header">
      <div class="review-photo" id="reviewPhotoWrap">
        <img id="reviewPhotoImg" src="" alt="" style="display:none;">
        <span id="reviewPhotoInitial">?</span>
      </div>
      <div class="review-who">
        <div class="review-name" id="reviewStudentName">Student Monitoring Chart</div>
        <div class="review-course" id="reviewCourseYear"></div>
        <div class="dialog-sub" id="reviewStudentMeta"></div>
      </div>
    </div>

    <div class="table-scroll review-table-scroll">
      <table class="chart-table" id="reviewTable">
        <thead><tr id="reviewHeadRow" class="head-row"></tr></thead>
        <tbody id="reviewBody"></tbody>
      </table>
    </div>
    <div class="dialog-actions">
      <span id="reviewApproveMsg" class="dialog-hint"></span>
      <div>
        <button id="reviewClose" class="btn btn-ghost" type="button">Close</button>
      </div>
    </div>
  </form>
</dialog>

<!-- Notifications inbox: one row per student who has messaged this instructor -->
<dialog id="notifyDialog" class="csj-dialog" style="max-width:520px;width:min(520px,94vw);border:none;border-radius:12px;padding:0;">
  <form method="dialog" style="padding:20px 22px 16px;" onsubmit="return false;">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
      <h2 style="margin:0;color:#0e3d24;font-family:Georgia,serif;">Notifications</h2>
      <button type="button" id="notifyClose" class="btn btn-ghost" style="font-size:18px;min-width:36px;">&times;</button>
    </div>
    <p style="margin:6px 0 12px;font-size:12px;color:#5b6b5e;">Replies from students about their self-monitoring chart. Click a conversation to open and reply.</p>
    <div id="notifyList" style="max-height:360px;overflow:auto;display:flex;flex-direction:column;gap:6px;padding:2px;"></div>
  </form>
</dialog>

<dialog id="feedbackDialog" class="csj-dialog" style="max-width:480px;width:min(480px,94vw);border:none;border-radius:12px;padding:0;">
  <form method="dialog" style="padding:20px 22px 16px;" onsubmit="return false;">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
      <h2 style="margin:0;color:#0e3d24;font-family:Georgia,serif;">Feedback</h2>
      <button type="button" id="feedbackClose" class="btn btn-ghost" style="font-size:18px;min-width:36px;">&times;</button>
    </div>
    <p style="margin:6px 0 12px;font-size:12px;color:#5b6b5e;">Tell us about a problem or a suggestion for the Self-Monitoring Dashboard. This is sent with your name attached.</p>
    <textarea id="feedbackInput" rows="5" maxlength="4000" placeholder="Write your feedback…" style="width:100%;box-sizing:border-box;padding:10px;border:1px solid #d9d0b8;border-radius:8px;font:inherit;resize:vertical;"></textarea>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:10px;">
      <span id="feedbackStatus" style="font-size:11px;color:#5b6b5e;min-height:14px;"></span>
      <button type="button" id="feedbackSend" class="btn btn-primary">Send feedback</button>
    </div>
  </form>
</dialog>

<footer class="page-footer">
  Instructor Dashboard — approving here marks the subject as Approved on the student's chart.
</footer>

<script>window.CSJ_BASE_URL = <?= json_encode($appBase) ?>; window.CSJ_SUBJECT_CATALOG = <?= json_encode($subjectCatalog) ?>;</script>
<script src="<?= htmlspecialchars($appBase . "/instructor/js/instructor.js", ENT_QUOTES) ?>"></script>
<script>
document.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var ids={profileCloseX:'profileDialog',enrolledClose:'enrolledDialog',reviewClose:'reviewDialog',subjectsCloseX:'subjectsDialog'};var d=document.getElementById(ids[b.id]);if(d&&d.open){e.preventDefault();d.close();}});
</script>

<?php
require_once __DIR__ . '/php/semester_popup.php';
csj_semester_popup_render([
    'seconds' => CSJ_WELCOME_POPUP_SECONDS,
    'rightClickClose' => true,   // right-click closes the semester dialog
    'show' => !empty($csjShowInstructorWelcome) ? [
        'title'    => 'New Semester',
        'headline' => 'Welcome back! We have officially transitioned to the ' . ($csjWelcomeSemesterLabel !== '' ? $csjWelcomeSemesterLabel : 'new semester') . '.',
        'sub'      => 'Your subject list was cleared. Use “Load Subject” to select the subjects you handle this semester.',
    ] : null,
]);
?>
<script>
// Live check: if the Dean starts a new semester while this dashboard is open,
// reload so the cleared subject list and the welcome popup appear without a manual refresh.
(function () {
  var known = <?= json_encode($csjTransitionId) ?>;
  function check() {
    fetch('php/semester_status.php', { cache: 'no-store', credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (d && typeof d.transitionId === 'string' && d.transitionId !== known) { location.reload(); }
      })
      .catch(function () {});
  }
  setInterval(check, 8000);
})();
</script>


<dialog id="csjSuccessDialog" class="csj-dialog" style="max-width:420px;width:min(420px,92vw);border:none;border-radius:16px;padding:0;box-shadow:0 24px 60px rgba(10,40,22,.4);">
  <div style="background:linear-gradient(135deg,#14522f,#1b6b3f);border-radius:16px 16px 0 0;padding:18px 22px;text-align:center;border-bottom:3px solid #e7b416;">
    <h2 id="csjSuccessTitle" style="margin:0;color:#fff;font-family:Georgia,serif;font-size:18px;font-weight:700;">Success</h2>
  </div>
  <div style="padding:22px 24px 24px;text-align:center;">
    <p id="csjSuccessMessage" style="margin:0;font-size:15px;line-height:1.5;color:#1d271f;font-weight:600;"></p>
  </div>
</dialog>
<script>
(function(){
  var dlg = document.getElementById('csjSuccessDialog');
  if (!dlg) return;
  function closeDlg() {
    if (dlg.open) { try { dlg.close(); } catch (e) { dlg.removeAttribute('open'); } }
  }
  dlg.addEventListener('click', function(){ closeDlg(); });
  dlg.addEventListener('contextmenu', function(e){ e.preventDefault(); closeDlg(); });
  dlg.addEventListener('cancel', function(e){ e.preventDefault(); closeDlg(); });
  window.csjShowSuccessDialog = function(title, message) {
    var t = document.getElementById('csjSuccessTitle');
    var m = document.getElementById('csjSuccessMessage');
    if (t) t.textContent = title || 'Success';
    if (m) m.textContent = message || '';
    if (!dlg.open) {
      if (typeof dlg.showModal === 'function') dlg.showModal();
      else dlg.setAttribute('open', '');
    }
  };
})();
</script>

</body>
</html>
