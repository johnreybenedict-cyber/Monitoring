-- ==========================================================================
-- CSJ Self-Monitoring Dashboard
-- COMPLETE MySQL schema for the CSJ Self-Monitoring Student Dashboard.
-- Import this ONE file into phpMyAdmin. It creates/updates the application
-- tables and standardizes all text tables to utf8mb4_unicode_ci.
-- Existing rows are preserved; no DROP/TRUNCATE statements are used.
--
-- ONE FILE, EVERYTHING: this schema now also contains what used to live in
-- the sql/ folder (dean_accounts, password_reset_requests, audit_trail,
-- instructor_student_messages) plus the default Dean login seeded at the
-- bottom. The sql/ folder has been removed -- you only need this file.
-- Safe to re-run on an existing database (CREATE ... IF NOT EXISTS, no
-- DROP/TRUNCATE).
--
-- Default Dean login (change it after first sign-in):
--     username: dean        password: Dean@CSJ2026
--
-- Old unused tables from an earlier design (`students`, `instructors`,
-- `subjects`, `charts`, `chart_subjects`, `review_entries`) are not created
-- here. If an old database still has them, the optional cleanup block at the
-- very bottom of this file removes them (commented out by default).
-- ==========================================================================

CREATE DATABASE IF NOT EXISTS `csj_self_monitoring`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `csj_self_monitoring`;

CREATE TABLE IF NOT EXISTS `audit_trail` (
  `audit_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `actor_role` VARCHAR(30) DEFAULT NULL,
  `actor_id` VARCHAR(80) DEFAULT NULL,
  `actor_name` VARCHAR(150) DEFAULT NULL,
  `action` VARCHAR(80) NOT NULL,
  `target_role` VARCHAR(30) DEFAULT NULL,
  `target_id` VARCHAR(80) DEFAULT NULL,
  `target_name` VARCHAR(150) DEFAULT NULL,
  `details` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`audit_id`),
  KEY `idx_audit_created` (`created_at`),
  KEY `idx_audit_actor` (`actor_role`, `actor_id`, `created_at`),
  KEY `idx_audit_action` (`action`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------------
-- Student profile + submitted chart records
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `student_profiles` (
  `profile_id` INT UNSIGNED AUTO_INCREMENT,
  `profile_key` CHAR(32) NOT NULL,
  `student_id` VARCHAR(30) DEFAULT NULL,
  `student_name` VARCHAR(150) NOT NULL,
  `course_year` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `contact_no` VARCHAR(50) DEFAULT NULL,
  `guardian` VARCHAR(150) DEFAULT NULL,
  `photo_path` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`profile_id`),
  UNIQUE KEY `uq_profile_key` (`profile_key`),
  KEY `idx_student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- If you already imported this schema before `photo_path` existed, this
-- upgrades an existing table in place (MySQL 8+ / MariaDB 10.0.2+).
ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `photo_path` VARCHAR(255) DEFAULT NULL AFTER `email`;

CREATE TABLE IF NOT EXISTS `monitoring_submissions` (
  `submission_id` INT UNSIGNED AUTO_INCREMENT,
  `profile_key` CHAR(32) NOT NULL,
  `semester` VARCHAR(100) NOT NULL,
  `student_name` VARCHAR(150) NOT NULL,
  `course_year` VARCHAR(100) NOT NULL,
  `chart_json` LONGTEXT NOT NULL,
  `submitted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`submission_id`),
  UNIQUE KEY `uq_profile_semester` (`profile_key`, `semester`),
  CONSTRAINT `fk_submission_profile`
    FOREIGN KEY (`profile_key`) REFERENCES `student_profiles`(`profile_key`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------------------------
-- Per-period monitoring tables (Prelims / Midterms / Finals)
-- One row per review event (1..6). Each of the 9 subject slots gets its
-- own "code" column (the subject box, e.g. FM 303) and "text" column
-- (the actual "What I learned..." cell content). These three tables are
-- populated automatically every time the student clicks Submit -- they
-- sit alongside `monitoring_submissions` (which remains the source of
-- truth the page reads from, including instructor approvals) so you get
-- a plain, query-able table per exam period as well.
-- --------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `TblPrelim` (
  `row_id`        INT UNSIGNED AUTO_INCREMENT,
  `profile_key`   CHAR(32)     NOT NULL,
  `student_id`    VARCHAR(30)  DEFAULT NULL,
  `student_name`  VARCHAR(150) NOT NULL,
  `course_year`   VARCHAR(100) NOT NULL,
  `semester`      VARCHAR(100) NOT NULL,
  `review_event`  TINYINT UNSIGNED NOT NULL,   -- 1..6
  `subject1_code` VARCHAR(30) DEFAULT NULL, `subject1_text` TEXT,
  `subject2_code` VARCHAR(30) DEFAULT NULL, `subject2_text` TEXT,
  `subject3_code` VARCHAR(30) DEFAULT NULL, `subject3_text` TEXT,
  `subject4_code` VARCHAR(30) DEFAULT NULL, `subject4_text` TEXT,
  `subject5_code` VARCHAR(30) DEFAULT NULL, `subject5_text` TEXT,
  `subject6_code` VARCHAR(30) DEFAULT NULL, `subject6_text` TEXT,
  `subject7_code` VARCHAR(30) DEFAULT NULL, `subject7_text` TEXT,
  `subject8_code` VARCHAR(30) DEFAULT NULL, `subject8_text` TEXT,
  `subject9_code` VARCHAR(30) DEFAULT NULL, `subject9_text` TEXT,
  -- Normalized (lowercased/trimmed) copy of each subjectN_text, but only
  -- when it's 8+ characters -- short/blank cells stay NULL, and a unique
  -- index allows unlimited NULLs, so empty cells never collide with
  -- each other. A UNIQUE KEY on each of these means the database itself
  -- refuses two different rows from ever holding the same learned-text
  -- in the same subject slot -- the safety net under php/save.php's own
  -- cross-student duplicate check (which runs first and gives the
  -- friendly message; this only fires on a same-instant race).
  `subject1_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject1_text)) >= 8 THEN LOWER(TRIM(subject1_text)) ELSE NULL END) STORED,
  `subject2_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject2_text)) >= 8 THEN LOWER(TRIM(subject2_text)) ELSE NULL END) STORED,
  `subject3_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject3_text)) >= 8 THEN LOWER(TRIM(subject3_text)) ELSE NULL END) STORED,
  `subject4_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject4_text)) >= 8 THEN LOWER(TRIM(subject4_text)) ELSE NULL END) STORED,
  `subject5_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject5_text)) >= 8 THEN LOWER(TRIM(subject5_text)) ELSE NULL END) STORED,
  `subject6_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject6_text)) >= 8 THEN LOWER(TRIM(subject6_text)) ELSE NULL END) STORED,
  `subject7_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject7_text)) >= 8 THEN LOWER(TRIM(subject7_text)) ELSE NULL END) STORED,
  `subject8_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject8_text)) >= 8 THEN LOWER(TRIM(subject8_text)) ELSE NULL END) STORED,
  `subject9_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject9_text)) >= 8 THEN LOWER(TRIM(subject9_text)) ELSE NULL END) STORED,
  `updated_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `uq_prelim_row` (`profile_key`, `semester`, `review_event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `TblMidTerm` (
  `row_id`        INT UNSIGNED AUTO_INCREMENT,
  `profile_key`   CHAR(32)     NOT NULL,
  `student_id`    VARCHAR(30)  DEFAULT NULL,
  `student_name`  VARCHAR(150) NOT NULL,
  `course_year`   VARCHAR(100) NOT NULL,
  `semester`      VARCHAR(100) NOT NULL,
  `review_event`  TINYINT UNSIGNED NOT NULL,   -- 1..6
  `subject1_code` VARCHAR(30) DEFAULT NULL, `subject1_text` TEXT,
  `subject2_code` VARCHAR(30) DEFAULT NULL, `subject2_text` TEXT,
  `subject3_code` VARCHAR(30) DEFAULT NULL, `subject3_text` TEXT,
  `subject4_code` VARCHAR(30) DEFAULT NULL, `subject4_text` TEXT,
  `subject5_code` VARCHAR(30) DEFAULT NULL, `subject5_text` TEXT,
  `subject6_code` VARCHAR(30) DEFAULT NULL, `subject6_text` TEXT,
  `subject7_code` VARCHAR(30) DEFAULT NULL, `subject7_text` TEXT,
  `subject8_code` VARCHAR(30) DEFAULT NULL, `subject8_text` TEXT,
  `subject9_code` VARCHAR(30) DEFAULT NULL, `subject9_text` TEXT,
  `subject1_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject1_text)) >= 8 THEN LOWER(TRIM(subject1_text)) ELSE NULL END) STORED,
  `subject2_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject2_text)) >= 8 THEN LOWER(TRIM(subject2_text)) ELSE NULL END) STORED,
  `subject3_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject3_text)) >= 8 THEN LOWER(TRIM(subject3_text)) ELSE NULL END) STORED,
  `subject4_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject4_text)) >= 8 THEN LOWER(TRIM(subject4_text)) ELSE NULL END) STORED,
  `subject5_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject5_text)) >= 8 THEN LOWER(TRIM(subject5_text)) ELSE NULL END) STORED,
  `subject6_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject6_text)) >= 8 THEN LOWER(TRIM(subject6_text)) ELSE NULL END) STORED,
  `subject7_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject7_text)) >= 8 THEN LOWER(TRIM(subject7_text)) ELSE NULL END) STORED,
  `subject8_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject8_text)) >= 8 THEN LOWER(TRIM(subject8_text)) ELSE NULL END) STORED,
  `subject9_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject9_text)) >= 8 THEN LOWER(TRIM(subject9_text)) ELSE NULL END) STORED,
  `updated_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `uq_midterm_row` (`profile_key`, `semester`, `review_event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `TblFinal` (
  `row_id`        INT UNSIGNED AUTO_INCREMENT,
  `profile_key`   CHAR(32)     NOT NULL,
  `student_id`    VARCHAR(30)  DEFAULT NULL,
  `student_name`  VARCHAR(150) NOT NULL,
  `course_year`   VARCHAR(100) NOT NULL,
  `semester`      VARCHAR(100) NOT NULL,
  `review_event`  TINYINT UNSIGNED NOT NULL,   -- 1..6
  `subject1_code` VARCHAR(30) DEFAULT NULL, `subject1_text` TEXT,
  `subject2_code` VARCHAR(30) DEFAULT NULL, `subject2_text` TEXT,
  `subject3_code` VARCHAR(30) DEFAULT NULL, `subject3_text` TEXT,
  `subject4_code` VARCHAR(30) DEFAULT NULL, `subject4_text` TEXT,
  `subject5_code` VARCHAR(30) DEFAULT NULL, `subject5_text` TEXT,
  `subject6_code` VARCHAR(30) DEFAULT NULL, `subject6_text` TEXT,
  `subject7_code` VARCHAR(30) DEFAULT NULL, `subject7_text` TEXT,
  `subject8_code` VARCHAR(30) DEFAULT NULL, `subject8_text` TEXT,
  `subject9_code` VARCHAR(30) DEFAULT NULL, `subject9_text` TEXT,
  `subject1_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject1_text)) >= 8 THEN LOWER(TRIM(subject1_text)) ELSE NULL END) STORED,
  `subject2_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject2_text)) >= 8 THEN LOWER(TRIM(subject2_text)) ELSE NULL END) STORED,
  `subject3_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject3_text)) >= 8 THEN LOWER(TRIM(subject3_text)) ELSE NULL END) STORED,
  `subject4_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject4_text)) >= 8 THEN LOWER(TRIM(subject4_text)) ELSE NULL END) STORED,
  `subject5_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject5_text)) >= 8 THEN LOWER(TRIM(subject5_text)) ELSE NULL END) STORED,
  `subject6_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject6_text)) >= 8 THEN LOWER(TRIM(subject6_text)) ELSE NULL END) STORED,
  `subject7_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject7_text)) >= 8 THEN LOWER(TRIM(subject7_text)) ELSE NULL END) STORED,
  `subject8_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject8_text)) >= 8 THEN LOWER(TRIM(subject8_text)) ELSE NULL END) STORED,
  `subject9_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject9_text)) >= 8 THEN LOWER(TRIM(subject9_text)) ELSE NULL END) STORED,
  `updated_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `uq_final_row` (`profile_key`, `semester`, `review_event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Upgrade path: if you already imported an earlier version of this schema
-- (TblPrelim/TblMidTerm/TblFinal exist without the columns above), this
-- adds them in place. Safe to re-run.
ALTER TABLE `TblPrelim`
  ADD COLUMN IF NOT EXISTS `subject1_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject1_text)) >= 8 THEN LOWER(TRIM(subject1_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject2_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject2_text)) >= 8 THEN LOWER(TRIM(subject2_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject3_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject3_text)) >= 8 THEN LOWER(TRIM(subject3_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject4_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject4_text)) >= 8 THEN LOWER(TRIM(subject4_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject5_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject5_text)) >= 8 THEN LOWER(TRIM(subject5_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject6_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject6_text)) >= 8 THEN LOWER(TRIM(subject6_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject7_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject7_text)) >= 8 THEN LOWER(TRIM(subject7_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject8_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject8_text)) >= 8 THEN LOWER(TRIM(subject8_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject9_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject9_text)) >= 8 THEN LOWER(TRIM(subject9_text)) ELSE NULL END) STORED;
ALTER TABLE `TblMidTerm`
  ADD COLUMN IF NOT EXISTS `subject1_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject1_text)) >= 8 THEN LOWER(TRIM(subject1_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject2_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject2_text)) >= 8 THEN LOWER(TRIM(subject2_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject3_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject3_text)) >= 8 THEN LOWER(TRIM(subject3_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject4_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject4_text)) >= 8 THEN LOWER(TRIM(subject4_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject5_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject5_text)) >= 8 THEN LOWER(TRIM(subject5_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject6_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject6_text)) >= 8 THEN LOWER(TRIM(subject6_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject7_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject7_text)) >= 8 THEN LOWER(TRIM(subject7_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject8_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject8_text)) >= 8 THEN LOWER(TRIM(subject8_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject9_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject9_text)) >= 8 THEN LOWER(TRIM(subject9_text)) ELSE NULL END) STORED;
ALTER TABLE `TblFinal`
  ADD COLUMN IF NOT EXISTS `subject1_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject1_text)) >= 8 THEN LOWER(TRIM(subject1_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject2_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject2_text)) >= 8 THEN LOWER(TRIM(subject2_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject3_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject3_text)) >= 8 THEN LOWER(TRIM(subject3_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject4_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject4_text)) >= 8 THEN LOWER(TRIM(subject4_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject5_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject5_text)) >= 8 THEN LOWER(TRIM(subject5_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject6_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject6_text)) >= 8 THEN LOWER(TRIM(subject6_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject7_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject7_text)) >= 8 THEN LOWER(TRIM(subject7_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject8_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject8_text)) >= 8 THEN LOWER(TRIM(subject8_text)) ELSE NULL END) STORED,
  ADD COLUMN IF NOT EXISTS `subject9_text_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN CHAR_LENGTH(TRIM(subject9_text)) >= 8 THEN LOWER(TRIM(subject9_text)) ELSE NULL END) STORED;

-- --------------------------------------------------------------------------
-- Instructor Dashboard
-- A browser/session key identifies the current instructor, the same
-- lightweight pattern used for `student_profiles` -- no login system needed.
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `instructor_profiles` (
  `instructor_row_id` INT UNSIGNED AUTO_INCREMENT,
  `instructor_key`    CHAR(32) NOT NULL,
  `full_name`         VARCHAR(150) NOT NULL,
  `email`             VARCHAR(150) DEFAULT NULL,
  `created_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`instructor_row_id`),
  UNIQUE KEY `uq_instructor_key` (`instructor_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Instructor profile fields (single combined schema)
ALTER TABLE `instructor_profiles` ADD COLUMN IF NOT EXISTS `teacher_id` VARCHAR(50) DEFAULT NULL AFTER `instructor_key`;
ALTER TABLE `instructor_profiles` ADD COLUMN IF NOT EXISTS `program` VARCHAR(150) DEFAULT NULL AFTER `full_name`;
ALTER TABLE `instructor_profiles` ADD COLUMN IF NOT EXISTS `address` VARCHAR(255) DEFAULT NULL AFTER `program`;
ALTER TABLE `instructor_profiles` ADD COLUMN IF NOT EXISTS `contact_no` VARCHAR(50) DEFAULT NULL AFTER `address`;
ALTER TABLE `instructor_profiles` ADD COLUMN IF NOT EXISTS `password_hash` VARCHAR(255) DEFAULT NULL AFTER `contact_no`;
ALTER TABLE `instructor_profiles` ADD COLUMN IF NOT EXISTS `photo_path` VARCHAR(255) DEFAULT NULL AFTER `email`;

-- Dean login is separate from student and instructor accounts. There is no
-- public Dean signup; authorized Dean accounts must be added by an admin.
CREATE TABLE IF NOT EXISTS `dean_accounts` (
  `dean_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(80) NOT NULL,
  `full_name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dean_id`),
  UNIQUE KEY `uq_dean_username` (`username`),
  UNIQUE KEY `uq_dean_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Which subject/section codes (from the master catalog) an instructor
-- has chosen to handle for a given semester.
CREATE TABLE IF NOT EXISTS `instructor_subject_selections` (
  `selection_id`   INT UNSIGNED AUTO_INCREMENT,
  `instructor_key` CHAR(32) NOT NULL,
  `subject_code`   VARCHAR(30) NOT NULL,
  `semester`       VARCHAR(100) NOT NULL,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`selection_id`),
  UNIQUE KEY `uq_instr_subject_sem` (`instructor_key`, `subject_code`, `semester`),
  CONSTRAINT `fk_selection_instructor`
    FOREIGN KEY (`instructor_key`) REFERENCES `instructor_profiles`(`instructor_key`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------------
-- Student account/security upgrade
-- NOTE: student_accounts intentionally does not use a foreign key to
-- student_profiles. This keeps the security upgrade compatible with older
-- CSJ databases whose profile_key column was created with a different
-- VARCHAR/CHAR definition. The PHP application validates the relationship.
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `student_accounts` (
  `account_id` INT UNSIGNED AUTO_INCREMENT,
  `profile_key` CHAR(32) NOT NULL,
  `student_id` VARCHAR(30) DEFAULT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `reset_code` VARCHAR(12) DEFAULT NULL,
  `reset_expires_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `uq_account_profile` (`profile_key`),
  UNIQUE KEY `uq_account_email` (`email`),
  UNIQUE KEY `uq_account_student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `student_accounts` MODIFY COLUMN `email` VARCHAR(150) DEFAULT NULL;

-- Password recovery requests are reviewed by a Dean in the dashboard.
-- Student/teacher passwords are changed only after manual identity verification.
CREATE TABLE IF NOT EXISTS `password_reset_requests` (
  `request_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `account_role` VARCHAR(20) NOT NULL,
  `account_identifier` VARCHAR(150) NOT NULL,
  `requester_name` VARCHAR(150) NOT NULL,
  `requester_note` VARCHAR(500) DEFAULT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
  `reviewed_by` INT UNSIGNED DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `idx_reset_request_status_created` (`status`, `created_at`),
  KEY `idx_reset_request_identity` (`account_role`, `account_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `address` VARCHAR(255) DEFAULT NULL AFTER `email`;
-- IMPORTANT: fixes SQLSTATE[42S22]: Unknown column 'contact_no' in 'field list'.
ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `contact_no` VARCHAR(50) DEFAULT NULL AFTER `address`;
ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `guardian` VARCHAR(150) DEFAULT NULL AFTER `contact_no`;

ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `program` VARCHAR(20) DEFAULT NULL AFTER `course_year`;
ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `year_level` VARCHAR(20) DEFAULT NULL AFTER `program`;
ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `enrollment_status` VARCHAR(20) DEFAULT NULL AFTER `year_level`;
ALTER TABLE `student_profiles` ADD COLUMN IF NOT EXISTS `major` VARCHAR(80) DEFAULT NULL AFTER `enrollment_status`;


-- Student phone numbers (profile contact only — no OTP).
-- Saved from Student Profile → Phone Number.
CREATE TABLE IF NOT EXISTS `student_phone_numbers` (
  `phone_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `profile_key` CHAR(32) NOT NULL,
  `phone_number` VARCHAR(30) NOT NULL,
  `is_primary` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`phone_id`),
  UNIQUE KEY `uq_profile_phone` (`profile_key`, `phone_number`),
  KEY `idx_phone_profile` (`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




-- --------------------------------------------------------------------------
-- --------------------------------------------------------------------------
-- WebAuthn / device biometric credentials
-- The actual fingerprint/face template stays on the device. Only a public
-- key and credential metadata are stored here. No foreign key is used here
-- for the same legacy-database compatibility reason described above.
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `student_biometrics` (
  `biometric_id` INT UNSIGNED AUTO_INCREMENT,
  `profile_key` CHAR(32) NOT NULL,
  `credential_id` VARCHAR(1024) NOT NULL,
  `attestation_object` LONGTEXT NOT NULL,
  `client_data_json` LONGTEXT NOT NULL,
  `public_key_pem` TEXT DEFAULT NULL,
  `sign_count` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `authenticator_type` VARCHAR(80) DEFAULT 'platform',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`biometric_id`),
  UNIQUE KEY `uq_biometric_credential` (`credential_id`),
  KEY `idx_biometric_profile` (`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------------------------
-- Instructor biometric credentials
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `instructor_biometric_credentials` (
  `credential_row_id` INT UNSIGNED AUTO_INCREMENT,
  `instructor_key`    CHAR(32) NOT NULL,
  `credential_id`     VARCHAR(512) NOT NULL,
  `public_key`        TEXT DEFAULT NULL,
  `sign_count`        BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `transports`        VARCHAR(100) DEFAULT NULL,
  `device_label`      VARCHAR(120) DEFAULT NULL,
  `created_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at`      DATETIME DEFAULT NULL,
  PRIMARY KEY (`credential_row_id`),
  UNIQUE KEY `uq_credential_id` (`credential_id`(191)),
  KEY `idx_bio_instructor` (`instructor_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
-- Instructor → student monitoring messages (✉️ / 🔔 inbox)
-- Used by php/messages.php for teacher notes about student monitoring sheets.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `instructor_student_messages` (
  `message_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `instructor_key` CHAR(32) NOT NULL,
  `instructor_name` VARCHAR(150) DEFAULT NULL,
  `profile_key` CHAR(32) NOT NULL,
  `subject_code` VARCHAR(80) DEFAULT NULL,
  `semester` VARCHAR(120) DEFAULT NULL,
  `body` TEXT NOT NULL,
  `sender_role` VARCHAR(20) NOT NULL DEFAULT 'instructor',
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `idx_msg_student` (`profile_key`, `is_read`),
  KEY `idx_msg_instructor` (`instructor_key`),
  KEY `idx_msg_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `feedback` (
  `feedback_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role` VARCHAR(20) NOT NULL,
  `profile_key` CHAR(32) DEFAULT NULL,
  `instructor_key` CHAR(32) DEFAULT NULL,
  `user_name` VARCHAR(150) DEFAULT NULL,
  `message` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`feedback_id`),
  KEY `idx_feedback_role` (`role`),
  KEY `idx_feedback_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------------------------
-- Existing-installation collation repair (part of this single schema)
-- --------------------------------------------------------------------------
-- Only tables that this schema actually creates are converted.
-- Legacy tables (students, instructors, subjects, charts, chart_subjects,
-- review_entries) are intentionally NOT listed here -- they are not part of
-- the current app and would cause #1146 on a fresh import.
-- --------------------------------------------------------------------------
SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `student_profiles` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `monitoring_submissions` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `TblPrelim` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `TblMidTerm` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `TblFinal` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `instructor_profiles` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `instructor_subject_selections` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `student_accounts` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `student_biometrics` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `instructor_biometric_credentials` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `instructor_student_messages` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `feedback` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER DATABASE `csj_self_monitoring` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
SET FOREIGN_KEY_CHECKS=1;

-- ==========================================================================
-- DEFAULT DEAN ACCOUNT  (no public signup exists for Deans)
-- username: dean      password: Dean@CSJ2026
-- INSERT IGNORE: re-importing never overwrites a Dean you already created
-- or a password you already changed.
-- ==========================================================================
INSERT IGNORE INTO `dean_accounts` (`username`, `full_name`, `email`, `password_hash`)
VALUES ('dean', 'CSJ Dean', 'dean@csj.local', '$2y$10$mFldZwaDzQ.bcwoiB6yL2.kt73obo42Vpq02SUjVNxuGq12onTjAy');


-- ==========================================================================
-- System flags (new-semester transition messages)
-- ==========================================================================
CREATE TABLE IF NOT EXISTS `system_flags` (
  `flag_key` VARCHAR(64) NOT NULL,
  `flag_value` TEXT,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`flag_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Remembers which account has already seen the "new semester" welcome popup, so each
-- Dean / Instructor / Student sees it exactly ONCE per semester change (even after
-- logging out and in again). The app also creates this table on demand.
CREATE TABLE IF NOT EXISTS `semester_welcome_seen` (
  `role` VARCHAR(20) NOT NULL,
  `user_key` VARCHAR(80) NOT NULL,
  `transition_id` VARCHAR(40) NOT NULL,
  `seen_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role`, `user_key`, `transition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Archive of every approved period, kept forever across semesters (created on demand
-- by the app as well; listed here so the full structure is visible in phpMyAdmin).
CREATE TABLE IF NOT EXISTS `dean_archived_periods` (
  `archive_id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `profile_key` CHAR(32) NOT NULL,
  `period_key` VARCHAR(20) NOT NULL,
  `student_name` VARCHAR(150) DEFAULT NULL,
  `course_year` VARCHAR(100) DEFAULT NULL,
  `semester` VARCHAR(150) DEFAULT NULL,
  `chart_period_json` LONGTEXT,
  `archived_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `archived_by` VARCHAR(150) DEFAULT NULL,
  UNIQUE KEY `uq_profile_period_semester` (`profile_key`, `period_key`, `semester`),
  KEY `idx_profile_period` (`profile_key`, `period_key`),
  KEY `idx_semester` (`semester`),
  KEY `idx_archived_at` (`archived_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `dean_archived_students` (
  `profile_key` CHAR(32) NOT NULL PRIMARY KEY,
  `student_name` VARCHAR(150) DEFAULT NULL,
  `course_year` VARCHAR(100) DEFAULT NULL,
  `student_id` VARCHAR(50) DEFAULT NULL,
  `semester` VARCHAR(150) DEFAULT NULL,
  `archived_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `archived_by` VARCHAR(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- OPTIONAL: remove unused legacy tables from an OLD database.
-- Uncomment ONLY if your database still contains them.
-- ==========================================================================
-- DROP TABLE IF EXISTS `review_entries`;
-- DROP TABLE IF EXISTS `chart_subjects`;
-- DROP TABLE IF EXISTS `charts`;
-- DROP TABLE IF EXISTS `subjects`;
-- DROP TABLE IF EXISTS `instructors`;
-- DROP TABLE IF EXISTS `students`;
