<?php
require_once __DIR__ . '/php/security.php';   // anti SQL injection + session-cookie hardening
csj_harden_session();
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!empty($_SESSION['dean_authenticated']) && !empty($_SESSION['dean_id'])) { header('Location: dean-dashboard.php'); exit; }
if (!empty($_SESSION['student_authenticated']) && !empty($_SESSION['student_profile_key'])) { header('Location: student.php'); exit; }
if (!empty($_SESSION['instructor_authenticated']) && !empty($_SESSION['instructor_key'])) { header('Location: instructor-dashboard.php'); exit; }

require_once __DIR__ . '/config.php';
$csjSignupSemester = function_exists('csj_signup_semester') ? csj_signup_semester() : 'First Semester, AY 2026-2027';
$csjSignupSubjectCodes = [];
$__cat = __DIR__ . '/php/subjects_catalog.php';
if (is_file($__cat)) {
    $__loaded = include $__cat;
    if (is_array($__loaded)) $csjSignupSubjectCodes = array_values(array_map('strval', $__loaded));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DIGIMON — Colegio de San Jose</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,500;8..60,600;8..60,700&family=Inter:wght@400;500;600;700&display=swap');

  :root{
    --csj-green: #1B6E3C;
    --csj-green-dark: #0E4526;
    --csj-green-tint: #E6F2EA;
    --csj-yellow: #F6D93B;
    --csj-yellow-soft: #FCF3B8;
    --ink: #16231A;
    --ink-soft: #55665B;
    --white: #FFFFFF;
    --border: #DCE6DF;
    --danger: #C0392B;
    --radius: 14px;
    --shadow: 0 20px 50px -20px rgba(14, 69, 38, 0.35);
  }

  *{ box-sizing: border-box; }
  html,body{ margin:0; padding:0; }

  body{
    font-family: 'Inter', -apple-system, sans-serif;
    background: var(--csj-green-tint);
    color: var(--ink);
    min-height: 100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding: 24px;
  }

  .shell{
    width: 100%;
    max-width: 1000px;
    min-height: 620px;
    background: var(--white);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    display: grid;
    grid-template-columns: 0.85fr 1.15fr;
    overflow: hidden;
  }

  /* ---------- LEFT / BRAND PANEL ---------- */
  .brand{
    position: relative;
    background: linear-gradient(165deg, var(--csj-green) 0%, var(--csj-green-dark) 100%);
    color: var(--white);
    padding: 48px 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    overflow: hidden;
  }

  /* scalloped-seal signature motif, echoes the seal's own toothed border */
  .brand::before{
    content:"";
    position:absolute;
    width: 640px; height: 640px;
    left:50%; top:38%;
    transform: translate(-50%,-50%);
    background: repeating-conic-gradient(
      var(--csj-yellow) 0deg 8deg,
      transparent 8deg 20deg
    );
    opacity: 0.07;
    border-radius: 50%;
  }

  .seal-wrap{
    position: relative;
    width: 148px; height: 148px;
    margin-bottom: 22px;
    border-radius: 50%;
    background: var(--white);
    padding: 8px;
    box-shadow: 0 10px 30px -8px rgba(0,0,0,0.35);
    z-index: 2;
  }
  .seal-wrap img{
    width: 100%; height: 100%;
    object-fit: contain;
    display:block;
  }

  .brand h1{
    font-family: 'Source Serif 4', serif;
    font-size: 30px;
    font-weight: 700;
    letter-spacing: 0.06em;
    margin: 0 0 6px;
    z-index: 2;
  }

  .brand .tagline{
    font-size: 14px;
    color: var(--csj-yellow-soft);
    font-weight: 500;
    margin: 0 0 28px;
    z-index: 2;
    max-width: 260px;
    line-height: 1.5;
  }

  .brand .institution{
    font-size: 12.5px;
    line-height: 1.6;
    color: rgba(255,255,255,0.82);
    z-index: 2;
    border-top: 1px solid rgba(255,255,255,0.22);
    padding-top: 18px;
    max-width: 260px;
  }

  .brand .motto{
    margin-top: 14px;
    font-family: 'Source Serif 4', serif;
    font-style: italic;
    font-size: 13px;
    color: var(--csj-yellow);
    z-index: 2;
    letter-spacing: 0.03em;
  }

  /* ---------- RIGHT / FORM PANEL ---------- */
  .panel{
    padding: 48px 46px;
    display:flex;
    flex-direction: column;
  }

  .tabs{
    display:flex;
    background: var(--csj-green-tint);
    border-radius: 999px;
    padding: 4px;
    margin-bottom: 34px;
    width: fit-content;
  }
  .tab{
    border: none;
    background: transparent;
    padding: 9px 26px;
    border-radius: 999px;
    font-family: 'Inter', sans-serif;
    font-weight: 600;
    font-size: 13.5px;
    color: var(--ink-soft);
    cursor: pointer;
    transition: color .2s ease;
  }
  .tab.active{
    background: var(--csj-green);
    color: var(--white);
    box-shadow: 0 6px 16px -6px rgba(27,110,60,0.5);
  }

  .form-head h2{
    font-family: 'Source Serif 4', serif;
    font-size: 25px;
    margin: 0 0 6px;
    color: var(--ink);
  }
  .form-head p{
    margin: 0 0 28px;
    color: var(--ink-soft);
    font-size: 14px;
  }

  .panel > form{ display:none; flex-direction: column; gap: 18px; }
  .panel > form.active{ display:flex; }

  .field{ display:flex; flex-direction: column; gap: 6px; }
  .field label{
    font-size: 12.5px;
    font-weight: 600;
    color: var(--ink);
    letter-spacing: 0.02em;
  }
  .field input, .field select{
    border: 1.5px solid var(--border);
    border-radius: 10px;
    padding: 12px 14px;
    font-size: 14.5px;
    font-family: 'Inter', sans-serif;
    color: var(--ink);
    background: var(--white);
    outline: none;
    transition: border-color .15s ease, box-shadow .15s ease;
  }
  .field input:focus, .field select:focus{
    border-color: var(--csj-green);
    box-shadow: 0 0 0 4px rgba(27,110,60,0.12);
  }
  /* Full Name: show the whole "Last Name, First Name, Middle Name" hint inside the box */
  #fullName::placeholder{ font-size: 12.5px; letter-spacing: -0.1px; white-space: nowrap; text-overflow: clip; }
  @media (max-width: 1100px){ #fullName::placeholder{ font-size: 11px; letter-spacing: -0.15px; } }
  @media (min-width: 761px){ .row-2:has(> #f-fullname){ grid-template-columns: 1.45fr 1fr; } }
  .field .hint{ font-size: 12px; color: var(--ink-soft); }
  .field .error{ font-size: 12px; color: var(--danger); display:none; }
  .field.invalid input, .field.invalid select{ border-color: var(--danger); }
  .field.invalid .error{ display:block; }

  .row-2{ display:grid; grid-template-columns: 1fr 1fr; gap: 16px; }

  .role-picker{ display:flex; gap: 10px; }
  .role-option{
    flex:1;
    border: 1.5px solid var(--border);
    border-radius: 10px;
    padding: 10px 12px;
    text-align:center;
    font-size: 13.5px;
    font-weight: 600;
    color: var(--ink-soft);
    cursor: pointer;
    transition: all .15s ease;
  }
  .role-option input{ display:none; }
  .role-option.selected{
    border-color: var(--csj-green);
    background: var(--csj-green-tint);
    color: var(--csj-green-dark);
  }

  .approval-note{
    display:none;
    align-items: flex-start;
    gap: 10px;
    background: var(--csj-yellow-soft);
    border: 1px solid #E8D670;
    border-radius: 10px;
    padding: 12px 14px;
    font-size: 12.5px;
    line-height: 1.5;
    color: #6B5B0A;
  }
  .approval-note.show{ display:flex; }
  .approval-note svg{ flex-shrink:0; margin-top: 1px; }

  .pending-card{
    display:none;
    flex-direction: column;
    align-items: center;
    text-align:center;
    gap: 14px;
    padding: 28px 10px 10px;
  }
  .pending-card.show{ display:flex; }
  .pending-card .icon{
    width: 56px; height:56px;
    border-radius: 50%;
    background: var(--csj-yellow-soft);
    display:flex; align-items:center; justify-content:center;
    font-size: 26px;
  }
  .pending-card h3{
    font-family: 'Source Serif 4', serif;
    margin: 0;
    font-size: 20px;
    color: var(--ink);
  }
  .pending-card p{
    margin:0;
    font-size: 13.5px;
    color: var(--ink-soft);
    max-width: 320px;
    line-height: 1.6;
  }
  .pending-card .ref{
    font-size: 12.5px;
    background: var(--csj-green-tint);
    color: var(--csj-green-dark);
    border-radius: 8px;
    padding: 8px 14px;
    font-weight: 600;
    letter-spacing: 0.03em;
  }

  .row-between{
    display:flex;
    align-items:center;
    justify-content: space-between;
    font-size: 13px;
  }
  .checkbox-line{ display:flex; align-items:center; gap: 8px; color: var(--ink-soft); }
  .checkbox-line input{ accent-color: var(--csj-green); width:15px; height:15px; }
  .link{ color: var(--csj-green); font-weight: 600; text-decoration: none; }
  .link:hover{ text-decoration: underline; }

  button.submit{
    margin-top: 6px;
    background: var(--csj-green);
    color: var(--white);
    border: none;
    border-radius: 10px;
    padding: 13px 18px;
    font-family: 'Inter', sans-serif;
    font-weight: 700;
    font-size: 14.5px;
    letter-spacing: 0.02em;
    cursor: pointer;
    transition: background .15s ease, transform .1s ease;
  }
  button.submit:hover{ background: var(--csj-green-dark); }
  button.submit:active{ transform: scale(0.99); }

  .divider{
    display:flex; align-items:center; gap:12px;
    color: var(--ink-soft); font-size: 12px;
    margin: 4px 0;
  }
  .divider::before, .divider::after{
    content:""; flex:1; height:1px; background: var(--border);
  }

  .status-msg{
    display:none;
    font-size: 13px;
    padding: 10px 14px;
    border-radius: 8px;
    margin-bottom: 4px;
  }
  .status-msg.show{ display:block; }
  .status-msg.success{ background:#E6F2EA; color:var(--csj-green-dark); }
  .status-msg.error{ background:#FBEAE8; color:var(--danger); }

  @media (max-width: 760px){
    .shell{ grid-template-columns: 1fr; }

    .brand{
      padding: 22px 24px;
      flex-direction: row;
      align-items: center;
      justify-content: flex-start;
      text-align: left;
      gap: 14px;
    }
    .brand::before{ display: none; }

    .seal-wrap{
      width: 56px;
      height: 56px;
      margin-bottom: 0;
      padding: 4px;
      flex-shrink: 0;
    }

    .brand-text{ display:flex; flex-direction: column; }

    .brand h1{
      font-size: 19px;
      letter-spacing: 0.04em;
      margin: 0 0 2px;
    }

    .brand .tagline{
      font-size: 11.5px;
      margin: 0;
      max-width: none;
      line-height: 1.35;
    }

    .brand .institution,
    .brand .motto{
      display: none;
    }

    .panel{ padding: 28px 22px; }
    .row-2{ grid-template-columns: 1fr; }
  }

  :focus-visible{ outline: 2px solid var(--csj-green); outline-offset: 2px; }

  #f-subject.field,
  #f-subject{
    flex-direction: column !important;
    align-items: stretch !important;
    gap: 6px !important;
    width: 100%;
  }
  #f-subject > label{
    display: block;
    width: 100%;
  }
  #f-subject input[type="text"]#subjectCode,
  #f-subject input#subjectCode{
    display: block !important;
    width: 100% !important;
    max-width: 100% !important;
    box-sizing: border-box !important;
  }
  .btn-load-subjects{
    display: inline-flex !important;
    align-items: center;
    justify-content: center;
    align-self: flex-start;
    width: auto !important;
    max-width: 100%;
    margin-top: 2px;
    padding: 7px 14px;
    border: 1px solid var(--csj-green-dark,#0E4526);
    border-radius: 8px;
    background: var(--csj-green,#1B6E3C);
    color: #fff;
    font-weight: 600;
    font-size: 12px;
    cursor: pointer;
    line-height: 1.2;
    flex: 0 0 auto;
  }
  .btn-load-subjects:hover{background:var(--csj-green-dark,#0E4526);}
  .load-subjects-summary{margin:6px 0 0;font-size:11px;color:var(--ink-soft,#55665B);font-weight:600;}
/* ---------- Teacher sign-up: "Choose Subject(s) You Handle" dialog ---------- */
  #signupSubjectsDialog{
    border:none;border-radius:18px;padding:0;
    width:calc(100% - 32px);max-width:640px;max-height:calc(100vh - 32px);
    box-shadow:0 22px 50px rgba(14,69,38,.28);background:#fff;color:var(--ink);
    overflow:hidden;
  }
  #signupSubjectsDialog[open]{display:block;}
  #signupSubjectsDialog::backdrop{background:rgba(14,69,38,.45);}
  #signupSubjectsDialog .dialog-form{
    display:block;padding:24px 26px 20px;background:#fff;
    max-height:calc(100vh - 32px);overflow-y:auto;
  }
  .signup-subj-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;}
  .signup-subj-head h2{
    margin:0;color:var(--csj-green-dark);
    font-family:'Source Serif 4',Georgia,serif;font-size:22px;font-weight:700;
  }
  .signup-subj-x{
    flex:0 0 auto;width:38px;height:38px;border-radius:50%;
    border:1.5px solid var(--csj-green);background:#fff;color:var(--csj-green-dark);
    font-size:22px;line-height:1;font-weight:700;cursor:pointer;
    display:inline-flex;align-items:center;justify-content:center;padding:0;
  }
  .signup-subj-x:hover{background:var(--csj-green-tint);}
  .signup-subj-sub{margin:6px 0 14px;font-size:13px;color:var(--ink-soft);}
  .signup-subj-search{
    width:100%;padding:12px 14px;border:1.5px solid var(--border,#DCE6DF);
    border-radius:10px;font-size:14.5px;margin-bottom:12px;box-sizing:border-box;
    font-family:'Inter',sans-serif;outline:none;color:var(--ink);background:#fff;
  }
  .signup-subj-search:focus{border-color:var(--csj-green);box-shadow:0 0 0 4px rgba(27,110,60,.12);}
  .signup-subj-list{
    height:min(330px,46vh);overflow-y:auto;border:1px solid var(--border,#DCE6DF);
    border-radius:12px;padding:12px;background:#FBF8EE;
    display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:4px 10px;align-content:start;
  }
  .signup-subj-item{
    display:flex;align-items:center;gap:9px;padding:9px 6px;border-radius:8px;
    font-size:13.5px;font-weight:500;color:var(--ink,#16231A);cursor:pointer;user-select:none;
  }
  .signup-subj-item:hover{background:rgba(27,110,60,.07);}
  .signup-subj-item input{accent-color:var(--csj-green);width:16px;height:16px;margin:0;cursor:pointer;flex:0 0 auto;}
  .signup-subj-item.is-checked{font-weight:700;color:var(--csj-green-dark);}
  .signup-subj-empty{grid-column:1/-1;margin:14px 4px;font-size:13px;color:var(--ink-soft);}
  .signup-subj-actions{
    display:flex;justify-content:space-between;align-items:center;gap:10px;
    margin-top:16px;padding-top:16px;border-top:1px solid var(--border,#DCE6DF);
  }
  .signup-subj-count{font-size:12.5px;color:var(--ink-soft);font-weight:500;}
  .signup-subj-actions .btn-save{
    background:#D9A91C;background:linear-gradient(180deg,#E3B72A,#CF9F14);color:#1a2b1f;
    border:none;border-radius:999px;padding:13px 26px;font-weight:700;cursor:pointer;
    font-size:14.5px;font-family:'Inter',sans-serif;
  }
  .signup-subj-actions .btn-save:hover{filter:brightness(.96);}
  .load-subjects-chips{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0 0;}
  .load-subjects-chips:empty{display:none;}
  .load-subjects-chips span{
    background:var(--csj-green-tint);color:var(--csj-green-dark);border:1px solid #BFD8C7;
    border-radius:999px;padding:3px 10px;font-size:11.5px;font-weight:600;
  }
  @media(max-width:620px){.signup-subj-list{grid-template-columns:repeat(2,minmax(0,1fr));}}
  @media(max-width:380px){.signup-subj-list{grid-template-columns:1fr;}}
</style>
</head>
<body>

<div class="shell">

  <!-- BRAND / LEFT PANEL -->
  <div class="brand">
    <div class="seal-wrap">
      <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAT0AAAE7CAYAAACvwlaAAAAQAElEQVR4AexdB5wUNRf/J3v0DndHP0CKKFKULl1ERMSOKCB2xIJwIAo2VPzsgF2xYgF7QbFhARSlg4AoVgQVpIOiiHKTL//Zm9vZ2Wl7t0fRu99lJ3l5eclkMm+S915eJIr+inqgEHug6hVVy6RnZ/XJyK49LiM7a3qXa9qqJlc2UZkj6qhGoxqrI69prapl1/lQp8fr/NPLjayRXojNKSJd1AMoYnpFg6BQeiA9u3YrzcimKqPkZinEG0LIa4UQvb/a9Ss27dlp1rk9Zxe+27URhsBRGjBC579QShXblDEi6930EVnHa1jRf1EPpLwHipheyrv0v02wfHatymR2UsiFuifO1KGkDkn9C4ieEuLNjOw6MytcUadeUoWLkIt6IKAHZED+fz67qAPC90DlETXblRByhS5BZqcvBfsXAl2L5+DzollfwfqxqHR8DxQxvfj+KErlswcyh9c5JQ1ps/UsrUY+SbgW04yvvFB4Iz27zkhXhCJgUQ8k2QNFTC/JDitCT+wBLYPrq4R6WecU1yHl/0L/SYG7dD1XpZx4EcH/XA8UMb3/3CNP7Q2nD6/VVc/uXtR8SaSWciI1AXFbenbtMxJziiBFPRC+B4qYXvi+KsJ09EDG5bUaChGZ5gAXalJCTtaMr1WhVlJE/F/dA0VM71/9eAvx5gbXKI20yHQhUD5MLWWLqy/bHIRZF7XIXHZTl5orHz2+zje3dKv51aWHV1veuZExq2JpLFNKRW1Z/AgKlBBCTKswOquSH1pRXlEPePWA9Mooghf1gF8PZJRNe0gAjbxwyMCOPlR9/Og5WP7DbRLLb4oc+vxg2fWqMzY3H9hrfZPuHX9qdEbP9YeM7Lex2eTz0rouuV42X317pOwLQ7CqX2vMElAb4PEnIGoU/xtPe2TvZ+Ci5uxvPVDE9Pa3J3IAtCcjO2u0ZjyDvJpaL13NnX+d+PuRQZHO3RvLZl54bvDWdWXjW0+VXZffJMp3bmjMdsMhTNd/vFZs3MZ4USjqgWR6oIjpJdNbRbjIyK59rl5e3urVFf1aq08+vCLSPrOsrOyFEwZeprgsNfn8tC5jT8BcKLXLrYxmfFdlZNc53y2vCFbUA149UMT0vHpmL8Ezh9VqlpGdNSwju847mSPq7NLB3JeqZzG/aNhSfX2yyvA6R+2l5vhWk641p0LIJ7yQbj4ZS249NdLJKz8/8LOPlO2fukCuVgrb4fInBB6rPLxOe5esvQ5KH5nVMjO7zgT9DOfq8GNmdtaf+hp9ntlZczJG1Llmf2nrXu8c7wr3ek4R09vrXQ5UHlqzln4hbtQvxA+IRJYJIe4WAsfqppTUwfwXWm6lYS309ZyIxIcZI7LWZoyoc/O+2paVoWdUUsjnzMa5/PzvRCzq31Ye4ZJVYFCnhuLQZ84X670IRaR6q8rI2q298gsTXnZotYz07DojM0dkrZBKLIJAtq6vnQ51IEQpfTX/hRAdBHBzmsRnGSOyturn/1Cl7FpNzcyin73aA0VMby92d6XLa2TpAf9oWrG0n/QLcb2uup4Oof4FRG0BXFPCwA+aAb1dZWSNxqEKpgApfUSd64SeUXmROulwY/aZ7WUrr/xUwDs2EodceSw+c6MlICpJQ3yUnp3Vxy2/MGDpw+tU14zr6dLFSmyk4TQgDkPIP7YXQgwpJiLLM7Kz3kjPrl2ofReyWf8ZtCKmt5cedbqeDRRLK7ZGD/gLClqlZkC9IqrYV5qB3lvu0ppVCkrPq3zloZXL6zpe1oPkJi+cOlppMaFfWhev/FTCh3SVR7arD1flhhCirBTijYwRdR5nu1NZbxyt7FqlMrLrXCuF+h5CnBWXl4+EbncfPYNeqBnoQ7ihbt5MPx+kioqE7AE9nkNi7h9oB1wr0q9ML6eXPjOkwF2pbrxmoENLlUj7OXNEnfGceaSSfkZ21tlpaeW+03Wc6kW3ZJr69q1hhbOk9apz6oWiY4VSxjKvfAGcl1as7PeZw7MKzJDsdVQcXrdienbW9RlC/iIExmmGl7d0RSr+9Mwv4ze1LHNU7fqpIFdEw7sHipied98UOCdjVN1q8p/SnwKiBwrvj7ODEVJiXcaIrKcqj8w6NL9VcYakmd2wjBF1vhZCTIZAhg+tHe9kizKli4kSPjiFkCUiH14h60Sk+tmbuEiHFE/zPng/vC9vXP+c9BG1T9AflanFpdomhbhR6KW0f4n85wqgEfbIuRnDa7bIP5WikkE9UMT0gnqoAPlij/EBhNhrwmoBMShNiZUZI7JmZ47IuiF9RM1uQc2vkl2rjca/KnNE1gdpxcrtEFSq8OULKPjkeVhfp4pMqUeVgCrzsiuXkRVfvVTsBtQfeUCXiND3wfvhfel7jPbJ8Fpdwd0kLvgWKJ2MLjvr6YzsOjskJLfZpcRVlkXf96o/NEJG3ucH0xevKDPfPVDE9PLddf4FM7Jr36cZXhN/LPfcEsXwDQ1zjzsMs486BLMaV1efZpRTC4VQm91LxKCMCYjOgBgrkfZR5og6Sr+827TM6PuM7KyFGdl1ZkVD1kLmRURkvsa/DRDdEfLv+uPVgi6N5F5TpLg1q2lNWf/uM7DSLc8Npu8x2icyMjOzbLE/dH9oJUK0LzJHZH2akZ31jYZtydT9ZTI6Ic4SIbfYWfVpOd/60sXVVxVLYVn5UsYKC578VaTrD+YzyZcrKhGmB4qYXpheShInfWRWSyHkZckUq1JGLR3aQ30yd4zc9NU42YiGufcPlF0eO1t2fXtYpMP8ayKtv781kv7iEKzqeZihhflqW1j6+uWtCCEOEkK0EgJdokHkS2N4yVH49JyOkTZh6y5MvBNaRNqM7Kk+zlcdQjSN9gO0EkYcKYRoqPsoKYPqElqmeVxTzH7uInzFrXbf3Rqp/sVNkUOWjJXNPx+b1nTFTdh166lq4eFZ6uO0iPoxqXYKcbRmxKcnVaYIOVQPFDG9UN2UHJI0xB1hSzSrpT75cKT6eeF1kcOzu0c6Va2ADL+yrerKxg8NTOuy7AaZ1qspZingdz/8VOUphd/u74/PrzhGdkgVzVTQubRbpPPwHtAfgVRQC0eDzG7ciWrhVzdHGt4/QHZpW08e4layTHFZql/rSOtXLol0/uZ/kbofX4lfySTDPjPNiEOPI7f6i2DuPSDdwUXQ/PZAFdrPCRwVVL5GRcyfdSXWvX5ZpFO9jEitIHxnfrmSotwDA2TXJddLpZfAs+GxVctZLj9pKdW66cOw5bhmcr8UsF/eXXa590y1SACbAu+vAAjF0tSP1/ZRc8nsBrSPtE6WVK3KshqZJJ+Zl+mNg2adjBF1jnPAipIF7AFZwPJFxR09EDGKBdrhDWyH2XNGy7ZZlQuuCKhUGuX1ErjLvOvEH5QDppr5HVFXL7mvFiWb1JChDakdXbJXksc3j7Sad61Ay3rGrFRXqJemq0cfh8++vjlS97wOkfYFpc9nNvVC2eV/p2AevdH40lPqXN/8osyke6CI6SXdZf4FlMAAP4y7z1CLbzpJajmSH1byeZllZTrlgGR+px6O2XxRk6cSLcHlV5dGxsefXIUNLw+JdMoooPOAKNXC/80oKzJeuiit65zRWN/lYMzkfRSkViojru6tPtNL03qDO8sjC0LLreyZbWS7Ny+X6wXUVrd8wvQS97SCmNyQRlGI74EiphffHwVKZWTX7qSXWNW8iEw6C0u18L2lV34q4GR+d/aTXfiiTrkQX/ZujtkVS+NzBP6p7Q0yMW/0sWL+l+NEuSfPS+tcs5KsGlhsP0SoUVFWf/Jc2W3lOBS79nj1WZMamKMZi6d/PvstlNNa12O1ouiDkWItlREXdIocac9PdfywmqKhFh1sB5QO7tQjxcr0cs8pDOi/n2YR00vhMxYCnkbIw7VmtkcTeXgKqwsk1b6+PPS+M2UXLUNqQe3iO8Pw412nY9HprTHr3A7q4zv7ivlaG/z1vGux5YfbIhVnjJDtBncVbUsV06w7kPr+j1C6mCx5XsfIkXo21fH72yJVF10nf3r+Inwwto96dmB7Nb1PC8y6oJP65LrjMe/Rs7Gc2tZlWuv6oFYUHZQhsvbWHR5SPXLQ/QPED171CSUCZcReZYvgiT1QxPQS+6QAEHdbt2oVjAWXa81sAQinpOjB1WXdU46QrW47VXa9rk+k86ktRdtWdeXBenZYJT8VbN6psOIXhZmrFF5bovD4JwbGzzBw3WsGLp1iYOBjOTjlAQPH3W2g2505aH9LDg6/MQeHXGvgoNGGeWWacOb3mhjFZzmWJx3Se2KOYdJnPV/o+lhvftpbuQxqt6knjz67Q2TgTSdGjr/nDNn16t6RTud2lO26HyKbUduaH7qpKHNcU3nEEXXctdBaZBLahjIVbfm30yhieil6whmXZJQFhOtS6JGzZVL2X9iP/lZvUnhrucLE9w2MfMHAmY8Y6KoZGJlWm5sVTrxP4fzJCiNfVPjfW8ADHwFT5gPvrAA++07g85+AVb8Ca7YIbPhNYMcugd17ojfIK9OEM//rDVF8lmN50iG9m6fDpM96TtD1sV7WT0bZ/1HdrhcN3K3b984KhR83qyjxA/D3wYE4TDf7Lx3i/gVE/fQra9eIAxYl8t0DBWR6+a73X1dQFS/dxe2mqpYzFh5WQzZwy9vfYKvWK7y0yMANbxjo93AODrs+B93HKwydqnDfh8BrS4H5PwBrNQPbH9pORjnve92uJcC9un2XTlE46i5ltvuMSQZuetPAK4sNfLPhwGCEmeVklaY11QK3vpV7xNFu8CJY8j1QxPSS7zPXEkKil1vGiJ4RN/B+AVuwWuHhWYaeqeWgxQ16GXqPwlUvA09/Biz8UeDPv8V+0c5kG8F2L1gNTP4UGPUScOxEhSP0snrw0wYe/Vhh8Zr9lwlefbzwEjX0SLYfivDde6CI6bn3S9JQzR6OTyyktvdthSMS4fsGsnStoWdsCqfrWRyXh2dMUrjjXWiZnMBvCYuqfdPGwqp1u15Wf/AlcOvbCn0fUqZM8Uw9G3xwpgHKCQur3mTptq0nm0Qk1rqUo2dtF3ARKNkeKGJ6yfaYC3561PNtHWfWwdXxBSD22VSPAv/nFyhcqpUKzfVM7tQHoWVzCov0LA5Ff5ivZ4N3vQdQTsiZIGWWry1V2Pbnvp0Jtj0IPyQ+HpGeTg8xiRlFkCR7oIjpJdlhbugCYqAbvF+rvc/wftpqmEvWk+83QIH/1a8qU6nw+798JufW/8nAOBOkzHLkCwotb+JsMMfURm/4be8zwDPboJxb24WUA9zgRbDkeqCI6SXXX4nYg2uUFsCFiRl6BtECjd3gqYZRw3rfhwq97zHQ5Q6YS9ZlPi42U13/v5He4jXC1Ea3v8UwzW4emW3gl217hwEedahooqByddyx3hVKnFV5aOXyMUhRLD89UMT08tNrtjKZZYpdCiFK20BmtESa8V3lMrKSmSiEn+27FJ6dZ+ilWVTDOvF9ha/WF0JFIUmWLq5QS9/tuipfNwAAEABJREFU4VlA90OAAW2B7B4Ct50GPHUeMFV/FtyCHfb0+QK3a3yWY3nSIb3alQHSD9mUFKNFzWhuewfodLsyGSBFBjt3Fx4DLJUmSpYriVUJNyJQIlKs3NAEeBEgqR6QSWEXIcf1QLlLa1ZRAtfFAXMTLevIX3KjKb3MWGng4mcNrY1UuP51aCG8nmemtAZ3YvolxBFZgFbMYMxxAo+fIzD9cuDT0QI/3CbxxU0RfHyVxCuXSDx6tsS4kyWGdhc4vZVEp0YS7eoHh44NhaYfLcfypEN6s6+M0mc9rO/NywWeOAdmO9getovtc295aqG0O6TIoPU4heHPGfjkGyO1FeRSa3+Q8nIYe1XZodV83Y/lkii6ePRAEdPz6Jgw4JIl0u7QLMdV/nJOB6RsGbLlD4UJMwy0vjkHQ54B3tPqkTDtyy9Oq7oK/fVM7fo+wDMXCMy9WmDZDRIva4Z2+2kSF3YW6NZY4NAaEtUr6h7Ib0X5KMf6mtQQ6No42g62h+1i+9hOtpftZvtb1im82RgNq99YBpz9BHDkrTmmKUwqZ38Dj3Q3aNe9Xa5UsRK35aPriork9kAR08vtiGQvmcPrnKIH4Hnu5dS2ow8VzdzzwkMpRB833UDHWxXu/wjYslPXGL54aEwyucu7RxkcZ1MvDongZj1TO6eDRIcGAlXLF069oRsYEpHtZHvZbrb/pYsjWDlOmIz7sqMA3mdIUkmh/bpDgKYwR2r5313vGaDWPCkCLsidGoimAmozXPL00zivysjaJ7lkFYFC9EAR0wvRSU4UOgrVy9rHnXArfWhN6LlY/jW33EEw4oUctL9F4ck5yNu2ZdEv6DWrssKgIwHK0MgUyOSG94gyuILS3t/K03kCGeGIYyR4n7xf3reeiSOrSmpngjt3Czw4E6bW/LrXDfxcIMWHEIfVxJde/SmVeCLj8loNvfKL4N49IL2zinLceiD9yto1pEr7UAhUhMffqGOkZ55HERO8dqvC0KkGjp1o4PWl+ntuQgv+I4VCm3rA6F56aZwtMOvKCG44QYIyNDKFgtdw4FDg/fK+r+8jMWtUBO+PgCkbbKv7JyJTxwSnzAO63WmYzhc25tPsZWRPb0WYgKgkIpEPModlHpDuv/bliJH7svIDre7MUbXri3/EbD3gani1vUQx45suB4umXvlu8F93KIx6yUDXO7i5nxiCPwUK1HYe21Th7jOBJWMlnr9IYnAXiYZVC047vw3jsq/h1TloOjYHrcbloONtOTh6vGGa2pz2oIEBj0a3xF06Jcd0bnDNq4a5f/aOdw2s2546hmRvf/3MqGzwOd0/i6+XZn+x39h/drz8xHMMYTpfaKdn7BRTJGv03LmRaMrx5Fm3QJaKlJqVPqzGwZ44//qM5G+wiOmF7LMqI7K6qxy5WAjRwK/IXX3lLr98ex4VFNdPM7QgXOGVxfac/MXTtUrlrPbRZSu1qQ8OiOCE5hLlSxaM0f2To/DdRgMffKlMw+d7PjDAQE3yrn/CM6O//gHICP7Qy8CtfwjNyLTmdxNMU5sla4G530e3xL2zQoCGws8tALh/9uFZWp75R/76JJlS7Cf2F/uN/cdlMPuzWoXw9+hVH8UU/Kg9NNPAn3+Hp3fHaXKnF03C9ZNtLCNpi9NH1tafN0KKQlAPFDG9gB6iWUpmdtakCMQHeoBV8EOvU0XN7d1MNvfDYR4ZBY2Ju9xu4Nm5hBQstKsP3NdfYME1EjeeGF225pfivO8NPPaJgeu0TGrQ4wY66zY2vtbAMROAwU9H9+re8wHAMERrktvcbJg+9HhPQXX+lQSDdNIqmeaEFH6ay2D252djInhWa7H7tQZKpoVnWM4WclfMne8BXe4wMGVeOFOXPs3lEbUqQS+WndTsaVFGKjk1IzvrjczhWQfZc4riiT0gE0FFEKsHMkZkXV6yeNoPEGKwBfO6Cq1pe+VS96MA7WVoUExGQmNiegOx5yUTL1VM4ewOMGVSUy+U6N1Ms+RkCHjgPjBT4Za3oF9KYM63wM/bAKW1Nh7o4KyNPu8umKwCZzB/O/YYUJv6+DkC9/YHbj1V4LrjgRHHCFzUFRjYHjjlCKDnYdCyR6Biaa8W7B34kVqLfeupEvOulRjVE8gol3/mRy38da9DizNyTF+FQXfw0hDZQNcWeNSnEKIPpOCh7rdicI3SQXT/q/n/MaYX/JgrjqxeJ3NE7Zs0w/tFQNwjRDh7uzv7ytWVS4uKXjXQEedRd+WYBsUc9F54QXA9mzSZw3z98o3VwnjKpILKJJPfwEPmV1LPcBpVVaDAv0VtICL1a2gjzKXpta/5z17+cLiqyiwnTHu/45tJ9GstcG5HicuOErjqWImb9Iz1rtMlHhootZZZaiYjbLUVLErZ4uI1Cst/VggzQ7XXxiXwxd0k5l8TwZ19gQaZ9tzk4mu3Cq24Uuaumvmr4/vTTqlqBaT/72SstMP84kKI0Rlli63TM7+7K2XXSkq+7Ef335L3r2F6mVqLpaf2HdKH1+rKa+XsrCaVh9asFfVo7PO4bqhbssrwOkfpJeyNepB8XFwV/xGQ1wmIGj6l4rKu7o35p7QUevETBzYTNFugd9+hU+nVV5iw/Px00N96bueaqTWOZA5lS+Sfll/9DRy2/lw6v3IJsHKcxLvZEVDg/+qlfOklejleJ2qcZ63yZny7tUzPXnep4vZU4ccpS7tca8fb3KxM91In3a/Q5DqFDlqhcuFTBl5YqAJnq/ZWntpSYsYIMmUBPh97XjLxL/Tn9cxJCtzh4aXs6N9Wtsvugc/C0tWjo4JmfsOKichy/QFflJ6ddUf68Dq9A/fu6hmixqteZXidQyoPr9M+Xb9PGdm1O/FdClv3/o53wDI92iilZ2ddrx/oJxnZWb8jUupXPbWfI2VkJq9pQnyRViztJ1Gy9O+ZI+ooz/Cb2hWR+FAvYa/Xg6RTsg9s7AmYd0En2datHM926DFegd593fLDwI5vBnO71zMXRMztXGHKFASnvoPpVSqtcHiW1N2jXyMb4cplhClH7NnEBtTRJz7VPx7/ZDr2rJLF7KnCjf/+l8KZkwxMX55Yz/rtAh9+BYx5RaHrnSrprWUdGwrw+bw9TOA4x4cgsTZvyBvLoGWnhueSd2h3eeTo3mAPJ+UzR0C0lEKMkhLT04qV25Exos52/c58q8OcjBFZi/T128wRWZsy+Z6ULfaHxlun34kv0yQ+k/p9EkJ+zHdJ4/2u8RfocEulK2prwYP3vezPOXJ/bpxb26pk16qpO/1FkRb5Rj/IG/UD7aiZVVk33MKECWDTlAvx9dlHynbOer7Xmk6aYPBsB25XcuaHSQ/QVD++Smh5lzS3e4UpkwIcvVzTd2Yj9N0GW8IR1f2PcSfF41MOuOl396Wasy++WgfQk/GU+Qamfa4049EfiB8M0KknPcds1nScjNLRhNDJ/01XWKFnVEEFNmvJ2XlaPjn7a+8ZqxeNxtUF7h/AGbFAj0O9sPzhFH1wVTDkGQO8fyf24E6yw2uXYV1EKL0iceaGS+snVkG/Mw106CAgWuprA0CkI+BP45XV+FoQIcYUM+QKzQSnZ2TX0mUDCu5n2QcU06syPOtoKeQK3fFamrLverJBhvps3rUC7evLg52toElCD63ppAmGMy9MuldThVmjhGYmErUqiTBFUoqTXk6gfMkYyR+3ADmGigEcMeK3rhufTzf0DjQzucuxvGUfcfvWda8B2c8rXPiUQv9HoGVcyjybo83/FA67XmHJ2uQZkFlh7s8fuxVeWRJrY4VSCk+eC3DLHXdoPHxWVFmSi67vV5iytvX5tA1spOWikwZJ0DFC50YW1eSuM1YCR91l4M1liffevJY8aPk4mdGxAWYnRzW12JoJ9gbk0szsWienlnLhUjtgmB6VCxEp3hcQlQq3S7ypp0lj7YMDxfIZIyNHZpQVGXZMWt3zpDCaJNjhYeONq0HLywQeGBBBVhURtlih4NmF8//kCKzRjM+vohZZ8e0lM3PD3/1PPJ4bjhusdAHP4f12Ixl3rO7uhwh0OTg69LlD45gmEpPPE1p8EKudW8qe+DTGKGM54WN0jDD5PIkXhgjw+YYvGcVkG4Y9B1zxoqG15PFtKZUmyjx9gezy+lB8X6YElkdL7P1fIURZiMirmdl19Kd+79efnxqjTz4/JfdiGS5noZULe7HKuKqqlFFLbzgB8765Ja3GsYclOhKg0W7PiQbm/xBXLFQivRxMH3JvD5daMyoCy3DJ894XBiZ/apiefT/7ToG+9QILJoFgZ3os9t3G+BeOMHtoWsueAr7TTCYeEk3RODkai/5mVVE4pDo0k1eoUlaBGuJoTvxvQWV/xSPx7V/+M/czx8O4VB+qNcf2mhe7LCDt+WHjresK8PnSV2DlMvH1hqHx6hLguHsUqG124jerKeuvuFE0va8/ltSqouY68/daWiBbM75X91p9Bahov2d6GSPqvCUg8rOc3VGhlLGsRW31yXGHYfaxhxmz29VXHx9cTX1ao5JaULE0Pq9YCsvcQmZ5tahzQ2N2dg/16YcjxZqF10UOHxSV3aXZ+/qvPQpjpxmm0e6OXcKeFSpOezQuZfu2Cn4MP2xS5la1I281cPGzwE1vwvTsO/AxZfrW6/dwDj7VDDBUxQFI9TPj7+V7DyZmkaleIR5/k5aLWXn2q9M85KIuAm8Nk+Ae2IXXRvDlzRF8d6vAkrECn2h55rvZAi9fAlTzNASyU/eON6omUKFUjNmQKQ96zMDaLTEYS2eW528s7Nwdi6cixuc8c5TE+Z2Sp/bTVoDa5kdmJy53ASF6N5NHfDwq0n7uGLHx6t7qMy1TnFWjglqgNeSrhFC/wvxTf0gdp4PbCqWM5dUrqoV8H1ofpD7uqd8PvieMVyyDpRrPy5+fScn1R+DkjBFZz7vm7UfA4LdtHzY2I7v2OP06HRe2CUrht66NMfu1S/CdltdUWDo2rfmrl0Y63T9QdnlwYFqXqRdGOr8zPNJhzlWRNkuuly2WjJXN3cK8qyOtJp+f1mVo90iHehmijlv9VFacdJ+BZ/Lxbe1yMPDRFcK0RytdXN+hWwW5MG4B45avXncb5la1PYY7Po9sPEu/yNzpkVs03xfnTO/7Tf6kMsrG5zsVFlauU6ZX0mXZyhlXxVICNbU8k7KxI7TmuGSa+z1bdIOuaVLgkm7xQ539xX2/93+ktAwvyvyyKusZmdbAXnu8lqcdonBQRhDl5PPLlRS4preE/piC4yBZCvTgzJ0ytDV0K1u1gsi8oFPkyEmDZNc5YyJtVt4kG39/a6Safh+0DDNS5jsd/+rmtAb63Wj26ehIa74PLwyOdH5Ivx/36/eE8SXXycM1Xvr7I8UvvZtDyw3Vdre63GACop9mfGPc8vYXWPxI2F9apduRObJ2TyHktToa6v/IBpi14kbIJ86RXZpnyULVKL2+VOHE+xW+2SBCtc1Cql0ZeOxsgSfPlaibHlx26x8KfdndO3gAABAASURBVB8yzC1flK1ZdLyvwjztjEzSGyc4x/myBy1vyZjtVCuUtKdi8V1/x+KMlUrj794JF+jZVS+HOQk/IBNmKJz+sMqb9VEDe15HqZ9TBA+flb/Xg+IGrgL87kx/TM1xcM+ZiJuF+pWx8qgh53koXgojC6+g1/oZouZ9Z8ouK8fJisc0MT4ORU8jCYhbMrJr6x7Xif3wP39PtZBvpOzQahlKCS3CDa5IQG148jyx7NkLZNeyJWXZ4BL5x+BAHvOKgREvKCS7hezUlgDtuI7SQvQwLaCpRl/9Mi7/WeShcwbGWchLFwus+p/AwusEuBUtzbE7gvti31vptgzKI+UbqaMVKcUjMRQuB2OpxNj6HbE2MpdyOl6dYfc/8ZBSxVU8oBBTQgjTrnB4D1YSX+/StZSZRY2TmVuQ8ONmBZ5Ed7TWvL6+VEGp+LqctPs0l3gvWyJZLe+m3wXOmKTw4Mz8P2dnW7zSVPY8fFZa5xeHYJWUap0XXjxcPFc+u1bleNj+kdovmV6pYsWvFhCBWtpSxdRXc68Woksj0bywu5PL2RPv5YuRXE3l9KzngQECd/aVKFNChC58x7sKq23LyhNbKLyrZVychbSsI1A8IlCljAC3or12mURlh4D8xjcUyKRDV+hAPMi2vYoM/tcd3i/ve1/E52kRg4NaNOmc6ZUMWNpHS+Xv97e/6KbLiDvDVgqBy7tLc1tbuuPzyHsc84oyHS3kr0ZgzrfRFcCaLQLrtgvz43ji/Qa+3hDfP076meWF1h5LjDsJnsocZxkrzXN7z34i/j6tvFRfW9WVjedfLcuWLaE8nZtadQohapYUkWus9P50lftTY9gWc7uLEpcy7hf0LOGLedfImpnlpe319CuR/zwOZh4I/e3G8EyLtdFx5wcjBXo1Ta4c7cOenRt7UbTAGbedJsGXlnSdgaYRZKp2OF2YPzUnRsOeFyZe3yHPcpvt7daKnDvfMzBlfoxiLf2p6nqw+/06ZX39HzHQbGwO2v4vB9yXfLz+qPTTCplznzTAA8qvfMkwFUV3vJv8bOYH/cEYOhXmGbZ97s3Ba3rWZbWyY0OB2VpRctlRFiR2pfPP/BgmU5t+jmY+9KQSowZwi9miH8M9hwHtpP6wSbSsEw7fqueTb2DaNq5xKGas/FReq5QV5WdfJWsWj6jVIeheljGqbrUQeHsVZd8yPZdbjRSLXCYEirlk5YEiQv2itXvVy5UUDn1bHkrKIq8uMTDocYVdSdqYXXUsTMedGeXcGYBfAz9apWDYPJuc2UaiRJrwK4JujQVOcMx3n54XE9L7FnbJ5FLaDv5Gz1a+Wm+YxrLjZxggY2o9zsBDM+1YwFW99MPTs9B4aDT1p2N5q/Q97twtwKXaj5sFvlwHLPxRM6SvgXdWAC8vhqkoeuzj5JgAa9tp26i1cp3Ap3oWRrgVuGQbcQzt85BwvOSjn4Svb4+hQOZMbbqh78eib79m6Q+BPe0Xz9KiBZ7twfHjh+fM+2UbzGV1QQ25nXTd0pVKiwr6Y15Kj0j9aXHDyIMVF3vUlXmp/SSy3zE9oUQvv75RCv9MHSx+q1xGVvHDS0XevR8auOLF5ChxpjNtqMBFXfPftXz57bW2Cvnlv+Z4Abt8j3tKacdnpxU23sBhtsItdb3vAWgsS1dSszVjIsOK0VOm23U/F1dOmV6srH+sVD6WweVKxdPc4OGyvXMjvdy9QL++NvSVIQ/vpHOAgY8qkznbiusPlD2FfO2s4fjhOOJ4iqfmndq+S2DAI4Cf0wfv0snl1Kosqz1xLtYqKN9puM7vkxzlwsfO/5tZCG3LHJZZFQLN/Eif2xEzWtcL9lvnRyNM3tWvGrj7/TCYMZyeTYC3hgk0rRn/EsUwYMrZqKSww5zx32yzFDPPm5yZbf1wVnm0boOV5nVhPg1s62eydLjQQOPSHT2PhvQrQab8qNZe399fYPzpAjefDNNN1pV6VjzsaGBwF4CKmTPaACcdrkC37d0aK9Ofnh9dtzwqU4pHYjmffqeVP+vdZ3CHVGcHx/KUx4wtRo0G2AZOvE9hgWORx7Yf43gGWfn8PHMccTzRp6C9br84RQjnTYYWOfjyIj8SofO6HCxbnnS4eNevgBCiQeURNWr74eztvP2K6eWIUk38OkDLEVZd30f29MNJRR43ez+/IDlKN2kh9ENnSeglt2fBlesUTriXTjpjL5gbcsW8WUo0l0u/aCz4t8ch8Y/0S48XPYgSZXpCuLVToUZFZWob6UyT+0vpXqlNPTIOf6p8ibkF7LhmAicfIdC/rQTdZA3Rs+JhR0uM7iVNxcwtp0hM6BcB3bY/fk4EDwyIvyf/WqK5xfUSu2/raNz6HfiYgY+/SWQGk2bxPmPtP6SGVcL9ShkvDYV/1kvKGIbS7QfYdhqSW/DM8goRGaNtwcNeOZ4eGihNJUfYMsTjfuaCmi6RTlCY2E92LxZRq/zwIiqtvV/+3s5LfjQVYgulUL6eHq45HrT1TyusJtDebNDjBrjZO2wd1JpyGTJQC6G9ynDD/oMzDVPmQoXAVC34X7yGL5p7CefhPQt9HEw6KTSsGg/Z5XDcGZ/rnSqmmcapmjENOhLmbOyJc4AZI4Cv/ycxZ3TE1DZe3E2CShRvKvs2J7uHMBm01Qqey3HOE3oWeX8O7tQKGDKFUx80cO+HFkb06uceil5hqC2ltjeKDeiXHo+eLfVMVZqgb232m7WTkOeZhT1+qOSgX0OONw+UBDBNl25920iApxhQ4pre5nvpSVZPnAM+I55FCyUj+pQKhXTyRJVCRXj8aYb441ntZSuP7AKDad5x/mQFGn6GJdZCT9rfHiZ9l7OkJfSHnv7aaAzLNMPIF70PiGnl8Fryzorw+2sjDpu9SAGe8B19JXhUJGdjXRtLNMiU+gXXN4MD448+/545X6K6npnaW0zbRypgyBRoo2fP437gfm0S75EKi+znc3Dr21pKpd9iq0yFUkorrAQ4gyWMmve/cxiLhmRkctES3r+HZ0lMu4zPwfuD6Sz96MfAbe8ULuMbdKRspcedY6Efa4nuTS0AiaX3dawAr0Tqm64bs8uLaqeG+Bkg+0DK/7gn9NwnkmN4Jx+utbNDBGhjFdQgqZs9sZ+I0xKu3SJwy1vug/fQGhKH2r6Nf+0RePAjd1xn3c4tY86ZnxP/AE8HNp87H97SHybKCsuU8O/DahUUnjlfmDaQdsI8te6MhxWmfa5fX1tG6eIappkQmZEFXu3YsUpDbysv7JWrAH6E3fBrVhJ47VKJdvXdct1hj8yGafrjnpsKqBA9DlE/eVHSvebYi+OFuXfgcu9UE64WBcMxZGLl+rVByVgqdTEqFc7WS9pkPKRQ8D6+n0x4OfxalVVFmNpNOw6XuW4yJuKc1V7wkhee/FRh1a/+Ly2Rn9NLZ16tcGT9eDoW/L90rVhKmLLCpWMlplwIXNIN4Gw6ulRUpl3cDScIzBwlUbty/Cvx9QaFE+4z4OYui0vci59V+MQmJ/x+U/wzqpHk8naVlsGe9aiB0x8ysH1XPC3rmdHIfeqFEgPaWZDgK/eI3/hm4c34+rWNlPdqhYIIMm3xKloo8PgnXChVhCdqCHh6bmtTT9QNTykcJr+mFzylsOhHEa6AxqLWkYJ3HU36n3KZjg3ji416yX3pesoR0C9gDJfnxWY/Z4D7cWPQ+NiTcwzz7FgLymVdt8ZWquhKxwPt60tc0VPixSERLLouwk34oF3coCMFnLaQM1cpnHK/AZr+ePXeV+uBs5+A6YqeDNI5065VMfzYosfpQXrFwZk9jZrp0MLpCcbejnEnSc3M7RD/+FOfAv97q3AYX5dGONi7du/JjHeZwsuRhUc6ecqimNBLWPdylcvIdPec/EMvnGwkdX7F5PNgah3zXyNwV994N0c0zL3uNZVAkoqE0b3iX5ivtYD8+HsN8wCbHbZZAF9OCuTHTY+Roeb1Tp9dHDHM1Mf4MaEGc+73Bl5bovCQVuJQaRAUiEd82hayPOmkvnXhKD6o23y+lvE6jdKpHHlxiEDj6vF05muJVq+JCq8viYfXrpz4bOMxoqnoikOB7uqjEGDtVr2Ute0kseD269kdJOgF2g6zx53xxz+BqcRxwgueFno+rVxXajmGXFtw+qmjsF8xvc13/LROKbUz8fbcYIlYyUAueCoHtN0KU6aiFla/dplA50YF7y7KAG86KZ6ZvbUccHMLzu1rg7T21N5Gbi/jHtHDb1Q4aLRhBr6cdoE8tYn3nSlxZIP4eux0Chr/doPCe19Q82lgzCsGuAXr2Ik5OPzGHBx6rcLR4xUGPAqMfFHplwympxgqDvwCvU4Tf+Bj0fKk0+IGA6RL+qyHBuOsl/UX9B78ytP20O5thn364ACBod2FXhoLvHW5wN1nAjUdy1enjWWNEDM9Q2vwhjxD8UVii9iORGg8pMvBElMHA6WKhWOwVOLQpVY8lYKn0iJqmxsVVeK3L93g+wpW8Lc4xS0XECsTSYqyibD8Q4Y8Y+Cjr0QoApT7vDBEonktb/y/cxRW/KKwYHXURRFNVPyI92ku0dthgn396wp0Oe8sd30fgQs7O6He6RpaUzlFy3toC+eNlVwOz5h4V2uQr3vdwHF3Gyaj7alnNXRmSgPuFxYCH38D0NVWfpyp+rWGTIR0SZ/1sD7Wy/rJ9NketmvGSm9tuB99r7xjmkjQwcONJ0JrraMa2mNte6iF4LY/iQ+vEKZ9XjkXiTMZYkQKryry4OOmK0+rgQZVg8uTULuDJCZrTTWVK0wHBbrUeuyT1C51c5Qo7qxXT2J+2Xb7th1O+L5My31ZuVvdCu6Gjn6yLDc6XjCaHYS1w8vSS5PXLhVo6DHwuA2JOzdajI1a59PVD48QbK5nJxPfN2BfgjrbM+5kAdK34GQWo15O/FJL/XKNOU6a52fUy7CwE688g+Hq3tAvoTRnIokY4SFcVs7TS9MHPjJwxiQDTccqXDJFgZvxV/0ans7ewGR72K4hz8A8RKi/VgJwmcwPUEHrpwzwrPYSM0ZEYNfQ2unSCHpwF6mVIALcRWLPq+WYBdrzrPiz8wxQ1mal7VcpFOolIdRpXVfg6QsEgrTUVh23vAU8vyBxzFn5yV613Lmis4wevqucsH2djmN6+7oxZv0CX5lXx8+GHVjnACWd5EZ5p9mBF5EGmQovXyK1MsG9i5b9rNBLz3q4c4OCZzsdavUemqmw4Tc7ND5OjeKEMwQoe7Ny6C1jin4JrLT92raewHvZAo8MEuCWLW51OlkrO+iOaOYogbeHS1zQSSYI4+00/OILf+ROEQMn3Z9jLk/766Xp+BnQs1e/Uvtf3rzvKbOCZtbR5T9lnbe+bWDp2tTOapx3TpvAE5qLOHAQ0+POjrHTvJlOnXQBMtU4ogEJeprmTL+8y8zTrejVryo9Sy943+jJipZAooKzDn13Lis3J9beTcu9W11wbYZyn+l9sd5dSBpMMYrxymID3CgfTfkAEUlVAAAQAElEQVT/1k1X4JI2vWz8ILZKTV9uoO+Dhl6OuucT75reAnR3zrhX4AAd3CWexq1vK3i5COLM4+hDyfSk6dV3/OkS1AjnxxaMbaIJDN02dbrdQL+HFR7TQm4a7jLv3xIo66SB7qkPAt3uzMHdegZOJUlh3J/TRs+P6dE0hWIWZTN0psiDszurbY0yrVjilUohL5fxzWoJU8ZHw+nEkomQS57V8sT1mj0lZoWGfLFOuU5KhFKuk5jQhAsBcb9jelBSS4cS73TJGvyZCA0HoS3cqJfC4XLJ+fxgiUql45mRVZq+0bKfV9hjxOc3ralnFrnLT559QK2aVYbL3C/XuX9NqQ08uGpswHGWyCP/NPO3iqf8yg/AcfcYWj6n8PAs4JdtKa9ivyRI557cckYlS9+HcvCW/nilsqE/OHSXtSu7U6dpynmTKYOMjaE29YBLuwnY3VN5OX2g6IQKIWryuZ/brRYauD+nxzGVcG75dhjH3KDHFdbl85xf0lq0WriamxnC+Jr5+1PY75je3//scT17S39J8tVWMpuLtWYsTKdXo0W+lolQw+qGv+l3hcFPGdCyi7zskw5XmHWlwLShEXwwUmLBtQIT9bLVQuDX+MxHFM7SGkl6X7bg1pXLl4la00rtoAVbvEZgkrkJ3oIU/PrLNoXb3zVM7So/AKvWF5zmgUyBfUwno21uNmDOmvSzLej9rN4c+3iRVq1KMabGNAN3/5z3pAFq4ZlmoJaY3md+dDDN+g73XsSlM9T7cvcKb/xN4LQHFTjGmOcMjasLPKmVG2G0upt3AueaTlDj78FJ0yu9YLXh8JYYxZQ57swwmrtvfvPFSAqzqb8/8IvrF+PnLSiXbL3cPkRzDqetlRsdamlp5e60yLfjUs1Pn2UWjLK1Cf0iWiERG9xcElNeRxwymlP1oCSD2fanwADN+Nz8ujWuJjD86BgNlr37g4IvOUhnvtYocxnV6XalGSm0ciW+HuIUZqA2kWYXbfVMJigQj/iF2R4nbb7snDW1+Z/C8OcMfPFL/l560j32MBHn7t3pbEBrMjF0qgE6NSU+A8fd5POE6Z3nu02ExAL7I5YC5v1g4KqX4lcM2T0Ajjk7nj1Oq4P7Q3qpoWfwYXoVYy8fNv7VelHMDfcfZYQ+Sc2tfGHA9jumx5tUUAkLLq3drMG8ZMLQqUorE4Jfcn4JHz9Xwu+EMp658Nz82AvBJSzdIXm1Z/UmhVO03I/nlVo4/DJzxketrwWzrhd1FWhv20/J08+ue92wspO+ckbAJeyZk1RSXmOSrkgXaFJDmb7vBncBru8DPHa2wJuXCyy6TuCLmyJa+0ntc3CYMUKa+Iuvj5YnHdIjXfrWYz26ukL7f2MZcMJ9Clz6vv9l8n0/sJ3EzCslejVVkEKhusNG75a3VZypVMk0hcnnyTwnoz9sMuLu7eBqsSTtEgc/FS9WOa0l8jy7xDATY90aC9zbPxHuBpmlda35OUb01+1GFTd6Qv1VxPTcOiYBplzdxVfYslP56EPjqdzylhF6t8W9/aWvHR4pL10TP+DO60Coe6CQ+rSHDNMNuhODrqW4jKBZiD2Ppim3niJgCZ+POkThHr3steOEib+xzED38QZGvsCZYpgS4XHYtg4NFC7qCozvJ7TGWIDnqb55eQT0fTe6l8Q5HSSOOkSYLqeo0QxPPYZJeWqTGsKkQ3qje0mTPuthfW8PF2b9ZIZsT/mQmspYDf6xxVq8cNHTQG8t9/zoq9iHzr9UNLdqeYEHBkTAE+uikOjvS4sMcDdENMVfhQcGShxWM/ZR5thgDkPNSsjT3HLFQndWO3fHcDlrvvXUWJpl/MLxzaQeT34YsbyJ79NuMJn7Vn/8vUfUj1GIxSI5kXhOHsvaZzG5z2r2qVgId2PkX7aH0+C+tTyqifSpIi+LJh+WW6A8oEtkmWODXNTbbiLiYs0c+z5sgMtZK7elw907NaTRr3b8wKJTgltPkaB857GzI6jhmClY9NyuNB7uMcHQSzTEnaLmhhsWVqm0wumtoDXFeml1tcDSsRE8c0EEVx0rcfLhAlyWh6WVSjzWy/rJDNmez2+Q+GyMwEMDgVOOAMoGeFMJ25avtNzzAj27ohnPfC0mCFuOeHa7PpqmjHkl/llfrbX7nIER1wrf/BpjYtbS1pQBalnbr7ZjNpn3iJ5NhzF8tmjz2qe5NGfijAeFoXoZ/tPWcPxKiwh+ghAO17fRGlTx0kmLpaIlC+93v2N6VbJr1fS63Y2/I3CmxwNsrnTIPbzonaNnazT58Mq3w/90OMdxpi3cx+cY+MP2RR6iZ0Xc0H5ii/hBT7997zqOTiQNWv2HYcLEZeAyetDjhmk8/L2rCohY4UPV8grndoRpDL34+gh4Cht3J3gpd8JTLlzMahUEeh4mcdfpEstvjODp87UMtR1AmVlBa+ZHimKCyzUjcNs1E0R/0Y8qTitL7yi0qbSX4xGbdj98DTMBygCHPaew4pcYM+SH6IlzozJAe/mwcc6cT2sZjK3FSeDOl2BMaEWK4ZBGxkoZEaXnrLH0/hDb75ieUJEWXh2z9Q+vnCicS0baHIVRXNDbyfV9wt9+Tcesa/GaaJ3O37v6xnzhcRl4pZ4VEYfMw/kC0iU78/ITfv9L4YY3uJTlUiQ/FGJlaulhybZyf/HcqyO47niJtvViL1oM88CJdWwoMO4kqeWKEbwwRJiMnK7bC3IH05cDXe8wcH9I34ZWXcN7SNx+GhCRClyO33iisLLyrvalLYENqtIjisIHXzIVDcUjwJM2GWAUmvwvncO2dKw+3KjwgKqx04Jne5t+Ezlu5QnTi9vDeN2fQvi3fm+1WkIvUNwry9mD+OmSA+32dxR+8PzmxJBpmnLPmYkDL4aRGKNZgR367DxlfontMMZLFxegNm7McQJcBhLG8NsuYOsfsTppw8VlGvOSDW9QbneXwtOfJVsyHp8HznBG9PFV0mxr81qx9sVjHtip1nWFycjnaYbOHS1UQuX3jrj7hvtWj7orB1y2hqXTt5XE8xdJTBokQfmts5xz3C74AXhiTjwWTaFoeBwPzV/qYd0OvgdBpemHz+4v0A1f94k3ZxTwnMRgH/3td0xPKHWSV19UKeftSJQPxmsPo5Peo2dLUFjuhPulqVmtUVHlodDS/8GZsXReho7QhODCzvEMhC6TdFbef7/WgJZdIpk/2vmdOcnA8Oe4pEimZAyXygia2tCekAfOcEYUy/33x7ij5UmtqacM8PxOCO2ZxNkzP24W5nnIl00x4GaG5MRnumUdAX4UGXeGbzfGj6VXl8RjXNETWiscP6biMZJLVSkj8Pg5AiXSgstd4eHz0SpZsbSSVjzhqtAjAbaPAd6N3QcNqzKyRmPNCDxnerUqi4S9fWzm9l0Kbpv1mecMd/aFqVl0woPS/Dr3bxs/6MbPUKZ7paCyfCnsS6L0ssCAdvG0gmg89amBHhOA+auDMN3z07U4+drjgc+ulqCpTbrHFjv30vmHnvqgobXoUecLZNhegWY8VBacfL/3pCH/rUgsSRngNb0lPjX7A3la80RMf8jbK4BjJnAZGs+0/Esl5jqdj9oxTmgOXNIt9a/qIdUlJmotvL0utzh9Po5xcYZh4VatgPJW3HnV73OrzFG16zvhXum9AU99Txag1REVOd+v+KHVRQ23fD4Q2sC55dlh/dsCp7bM/y2f00GgvhYwx2gKU9jLE7JisPjY7j0K3BFiNze4rg9fsnBMj84lqUm78c14umFT1fXs9H+nAAuukTivo9Qzm3D1hqVvx6PzT3vaHv9HS33IsL3CHp1vx7fHk1lG2suFidOQnB8BfgwoknDKXcPQ+P0vYPDTCre+nX+G7ZTpWfW2rQfceXrhPTMqzpw+G6267df3VgLcvmiHWfHalWR9zfJ/t9IJ1z1iUAJsHwLyzwFS3OhKV1WqoJQY4kW2XEnjW7c8GuHygbjl2WE8aOfmk91vd/nPCqRjx3eLc2nywAARZ3VPvFvf1jNNrTF27l2k44ABjyh8/hOxouH4ZkCf5u7tiGLEfqmJprEsnYzGoOFiWZUVOKv9dHQEZ7YJV184yu5Y2/Vse8SLBh6elf8X340yPyhX6L7lTNAtP1WwUsUELtQiiTljpGnWka5n48nSpmMDuuLi3tpkytJfod1jslW2brrCI2cL0Iu2BSuM62gtf3bKrN3qGTtNYb3L/lzNkiuUKub+fpp0BC5Bdq1SZnw/+Cn8tyHkTab9U+4SPRX2HGpdDhaOnYmUa2kNpn4QQVVQbkGvt2541PjSFIHGvKP0y8W0G54Fo+eUh85KZHyvLAY63qZML79cwvW5Nwfd7jTiDpRpVFXh9r56iFjEfK7PzjPAMxKcAm6fImYWnVlyxvL+SFmgWa1JLIkfzphevljiqc8UyKiSKOqJSjpPzDFAusnKYD2JBmSUTBOmgTX3U1/cDaDGNKBIXPYCLX7odbcBypjjMnwSv7jsWeCM86nc7Wk+RVOSxXu+v78wtcvw+fvzb62cc9gbWugtaot1VjzxKtIzhLwwEb5vIPsF06s4vG5FocQw+PwNPUo0dGZf95oClxZOuDNNWVZWFXdmc8tbCmvpCUwXIuN6aaGeqOu43z/dc796qYTbbIBefrmEi+6vjNXJZcqzFwYvLzmjuehpA9e/DmitmF8zEvLObAN8NCo6Yyns2UFC5RpQq5LAS5rxkVGRYWlQvv9ZnnRIj3TzTSifBTmrH9VT4v2RMLfYJUOGWnoeFnTz9HCzXn5I7zodSJPRsUdGSy1vbcfJbMm0IVncxtUFnPu/3WjQvtRtVTSsu7dcL5fOFfvLbE/mNmifXooJNQECVb0aUa6k+rJh1fiDgd5erpUIWs7gVcaCd25EpYH7bfJr/OxcCxM4PIu4MUYVy0mMcZC8N0KA56lagzURKzpToLZ0ymChmaQ/bW5f66VnCe9/6UbJG5ZVRZm2aP87RYJaOW/Mws8hgyKjenpu/md8+5rh2XuJjIdb7LhS4OzLnhcUp8nJCfflwMsLir38KUdITBksTYUKTVOo6bXn7434pUdJ8zjMoLpuesPAZodXmrb1I52lgKcbKQFRO1OIm4Jo7418d26wN2rOrSNzZFYPIXBubtL1ctWx2GnP4Gzo+hBGk7Re5+lj9rJWnDKo7BeiX1bC6N3jPj3Fl0IwGSpwyTW2j8SsKyWG94gyzVK5h7M0rg7zeL751wpTWxpElx40Tn/YQBiFjL1xNLt4N1uidd3w7baXL4y4yfiGCJDxUXOdTB0b9cvEcmScpJNM2cLEpcCfDhGOa5pcLTzK8dQHvR3D2qnxGXIs8UAoO3xvxnmeM98Fvzq5W2PsG7F3x8IddSy+teLuV3lF+sislu55ew+6T5le+oiajZQhXvS73bSIWt2/nWxtx7n5TRVn6GvPs8dvOVUgvZw7M7jqpXgaN50kEva6vrrEgJ9G0qqrRkWBy7tLvHKJxMpxPEtV4m3zVH1+w9ULgAAAEABJREFUud3rt8ryyn2z/R8B7Bpewv1CzUoAjyKk2UVJLYdyxd1LwCbX5eCg3JPZrOuRtyr8vFWB8qqwrtqX/WRg3Q6Y5TrfrhJoHnJtuOViYd125TIC9w+QuK8/QNlp2Hp+2gqc+qARym1VhVLB4yVsvfnBy6oscM3xwW14ZwXg9ERzURfRq0Sa4bv+kgZerDA6S4/e/LQuNWX2GdPLHJZZVaq09/TEqqLfrUzsJ34DNBaif0vWGnhtaTTu90vX2z2buN/eC1puZ19Cdj8E4PLCTm/tFoVrXgV4HOE1rxqaISV+2ez4+Y1PmW+Y+2aTKX9GG+Dd4aLABwAlU6cfrsXo6QHFHlbfHsHq2yK4uFsIC1hdweDOUXyWs9Ox4l/d7P48ddG9+t+7mZb1adFGx4bhq6Wcj5rdhT8WzjgK35JgzDO1tr9NvWC8GxNmeyKi5dbFfEsKcVCJ3eIt3FC3pC9eIWbuk1GUMbxmCyVLLoJAXfj8tchSH+sB1tyOckMIbS2n59f3cf9akZmNezM2Y8gopxLsoPYYCpdOMbB7T7TmN5cpcBtZNJW630mzDFz3Wnh6ZUoo0MfcLVp2V6aE+/2Fp5ZazB82KdMImaeouQV6n/GrcfGP8C3P3Sh+5fd2Hh0wPH2+xHXHh6+Z2s9BjynMXLX/M77b9Cop6M7WbRd4aGbsXSJ+yzqyUa/DMJNxzyDQPuM34719NePb60wvc0Tti4WIfCqEqOXZKTqjRMT49pkLRCsdzft/eTGXCMEv+5XHSmS4LGsNFWVmHHwWUe7BpbmFleb13g9UnHfbG05MXPoSryDhzvcM3P5ueAoNMxWmXy5NH3PhS+09TCofeIKaV7j4Gf+28IhJr7KEP/Kxf/n85Ra81LkdpemRpmKpcIyMH9LzJyvQ/VnBay88CnSom90j+F3jTiOn55kHBspuWvn4hV/rBERnPeNbsi9kfHuN6VW6vEZWZnbW+4B8EEKU9u8QtfXdkbJMmeIyD48GnHe841cqmte0psKgI0U04fjlaWhRU5JoxnkdgXYHxXcBl898kFEMgJvynUtf5v2dozTTot+8cIOdZawwbrqhv5BWKvhKT7yvXSaR31PPgmsowihID7StJ/CWluFy7IWlM3SqwpvL4mdJYcva8WhXGjSLtuPb49ztM/plA8/MdW/H0O4CPArVXsYZp0ejO99LfAdmjBTVhHA/IS2Phl7pSSUWZWTXHpcH2wuR+De+kCpMH5E1vFgk7SvN7I4OqkJAbX1uiFhXp7KsYce97yOlVf92iHv8Zr30c8vhObU8AMbKSy8HjDo2njlyEGQ/T4wonDhe3mnpaWPSLOCYCQbeW+k+aEjJGchQn3R4z3Di2NPUCtMTb+ni0TbZ84ri+08PVK8o8MLFEtwnG7ZVw54DZq0KP3acdLf+oXDmwwoDH1VYkeTZHnO/N3D0eK1VWATc9rbCz9sSGRfru+204HFH+1a+X8S3QtVyMl0r9nYKgUAvj0LIa/WE6Iu9NesrNKZXJbtWm4zsOg/osENCTETA7I6dVSyifvhgpPy9TV0Z54OLZg+PzCaGfxh0JNC0ZuJD4tdw2FQjzpEjt/0Mf16BfuksqjdPV6CmzUqP7ws4l77Mo3nJI7Ojg2TLToE3Pic0OHCXBZllMCZAueTDZ8HUCofBL8LZ9z1ALfrdZ0rTfClsa86bDORnpkaPyqdojTA9enPJzCMIwng6ZrnrpxkY8CjyTmTjbO1Kd4cCOCJLYmD74LuhWzcnVovaotHsUdijNboBpiy6pBBNOOvTzO/9jBG1+2lIof3LVFKuOLxuxXQ9q9MNXx4RkflC4BIdPD0wwPbXvDZmLxkrqtbLEHVsYDN6/4dRBmMmPH5oH3e5no67ZafpuzzxcAEe1gLb33ta6sCZGgcdDZWfXxDL5IPu1EgXjIHM2PZdCsOeY3uizJWKkDBCX/rAu/51k0TgD+VDNEehx+JA5CKE/a4HaL50X//o+AjTuPOe5HkmHFNhsKM4PKRq7ZZYHdQOL14TS0ex4n85znvdbcBukG9hGHrCycOvrLT9OvIYgSAX/PO+jyqi7OUYr6VXbEtuiNRqdZDyV24QmUGIowXk8xkj6mzPGJF1b+WRWYcixX+Jb3U+KqgyvM5RGdlZLxWXapuMzupCm3CWKa6+eOp8rHztUtmlTHFZxln9uu0KU+Y7oYnpS7oJ0I4qMQdIkwLZPSR4WEvtyvEYG34T6PuQgUunxAZdvQxgzHHuA4hnHdDVjkXlnjMEypV0x7VwPv1OmT7wrLTftWp5Zdr7HVpD+qEV5e3nPdC7mcDk8xDKXx23UvLgH7qMD3tbHFN23BtPBE7SH3Y7zIpT/nzr24Y5zu2Mkvncl37jiQLPDRYo7zGOaTvI94v4fmHC+7F3yI5XKk2UenFwpNvTF6iVZUqoFfY8r7h+oyoIiKFpSqzMzK4zL3NE1iCkyGlBgd4sPau7KHNEnR8iEh8KIU7zugE3eL0q6tNHzsbyFTdFDuvUUDZxwyEszHF0lL2d31kQ3TfwsJZ3hgtwj2o8osDO3HMtIlKBjIxeN+JxAGqPOTu04Bd0AtrV9+9Cbi0b/JT+jFqFfK51qihzc329jOB78SFTlLWf9EBnvVJ48tyoqCKoSfyQDnrcgNdsy1meH2sLRsewZ7V3H4eU9fW6W4EeYID4cdWmHjBjBHBWewH9/sLv75yOAlzV+OEs+lH4GvN3bBBpsuLGSFO+93WrqM/8aMXlCbQFxFMZIrIhY0TWPRnZtRqgAH/uPRVAsPLwOu0zsuuskhAPa1TddfoXCPyJSPXTKYcbsxddh+0fjop0OPoQ2cyvEGUULyz0w4jmcW8r5SnRlP9vaa0Q+J9WdnAwVimb+GUyNOjNZQr/aO2snRLt++w2ggdXVbjCoQix4zPOWepZeiBTZsK0X6hRUZnuxGtWEn5o+23eradKWEbEbld6avZr/PxrhG/520+TfsX32zx+FB87O9wz/W6jwOCn9AAMcTfVKsTwdv9D5xSxNIvT1nTi+wbolHW14wgFzu7G9oE5u+PeYuIHBb5fl+uFZxAe6wzC4Xv/0ajIkXOvxeYTWmB2RKhfgsowX/diOQFxuRCRbzXzm5h+Jac7zEkuJD2SMrPrjEqT+EwIHBymKi1HW9++vvr4wQFY8u0tkdp39UvrUrmMrBim7H0fBmPRb9yAtjIY0YFBTynvZUtwN4Y9SylhfhVPuNfAtxuiA8lQSi9/DVj2fVrhgvsHCBSPCHvRhPgFegBT0ZGQ4QBwj/CzF0hULe9Pz1Fsv0lSI03NuFs49cEcLFjt4yHUdhcLf9Qv6QN74EaHsDCzfhu5/SZKxvfQWeGaQ9dUY7WiIQi7d1OZh0JvPPd8EB2rBHLrJGd3fH8MPZ4Js0LrugrvZQuc3UFCiOTGG98zOrewaLldKVcM6/S1almZfvcZssu3t0Zq3nqqWqAnIQ4n+W41RGECYrj4p/SSSlfUPiwKCf8rQ6MOrlFac9eXIXBHmDL6EfzeuxlmfTFOVp9yYaTzsU3lEWHKWTjU2L682Ep5X51mJ96YiTmUAT56tgTNUqgttWN8vUGgz70Kj31iwGmsPLqXQP1M/6675lUDq9bbKbrHWe9T50vQGNQd48CFLlitsOwn4MfNejSEuA3Opnnc4XxdLgT6AYXCLZG3nCJCtZmH8Uz73L/PTmgBPQZj5CbNArremaPHbI65ddJ5HChndzecIMzVRJaHm7UYNe/YFT2D7+GhWf5td6Per3WkzcJrI0e8Oxyrm9VSn0CpXW54dpgQokGxHDE/Y3hWUqI1/zfXVkNmmWLPCohTbSDPaL/WmtndAHlff9mV02JPRJ8MWvj7ZJtZ3KXQu1noWzDLuP30ay3wrp71tXQci8dzSG95C7jXNuNsqxfz53b0r/PVJQaeW5BYkxvk4bMkDqsp3LIOGNhlRwnTk8ywo2XelWKEtVsFDqkOZIX0C1dL4x1cFfhJl/vzb+TRsujSWPaA6RSXhp7Rhv3kkuECuvoVA9/krjRcshHRyrm7tRKteCSWSyWF3fjeyuG4puxu0JECmlFY4Hxdj9fvG5+pX+G5WpP7RZJ2gxa9RtVkvdcvi3RaeL3cc3QTBBuqCVFaSPFSJhUdFpGAq//bm1s4Y0TtcyBwcm7S8yKgNjx3EVZq+U7XMiVlGU/EgIwduxSokg9Aw9AQMoYgGlZ+LS1Le2GIxBU9gTStzLDg9isFxvcEHB3JgUpHBfZyXvE7+gIdGwqv7AMWfs8HBkz3UEMEiqcld3/FtcjgJV2OB+5Q43jAdoJHw8nATw6x5qEc+OJnlRapeM+amtQQGN8PKBZxx6lZCZjQT+BFPa7Dyu48mh0Hvrx7XNI18XA+Znt2QlXKiHKPnCW73NcfSzR8hw5B/w9WuKKOnpIEoQEyCCV9eB39rZb3BuGVLKa++nR0JNK2nvTUxAbRsPJ5nisfupV2u/KAHn513PLyC5NCmKdOvXG5RIPMRCp39pXgRvPEnCiERtA0faGxaBTi/Uvly2ktA7vfm8B+mkNGRbHES5px8cSx/DST5Vj+vS9UgQ7byU/de6PM+NMljmzgzqjs9VMBMe5NfzyudOZezRk2TAegWlmIWprZ3XiiwIdXCNOMRQhhJ1vgeM/DJGhp4EeIHy2KK/xwwuTp+zvi7WHYKqVa548vyhQ38Lg/TjQ38K0TQt2ru6xcFN39V3f0z5+OkTWqVUS6O0Z4KG2Knvos2MSDS6rwVJPDbFxNYPowgXM6sFx00J2iv848M5UQr3DD6wpOWYobLpUn/OK75R3IMDI8DnYyLDKupO/FVoDleTbGv5XxPTBAasWVst2xe5TWC++s8MejbJrj6aWLI9DKQnx8lTTNUDhrdqcag67frkB/jpM/NfDIbAMffBm/SymGGR87r6PmCvGghNSjn/i3O6GAB6BxdVnv/WwYmpr3iWu6rG5RNz1J662jvv++TC9zeNZBIoT93ZTBYkel0qKCb00hM19ZHO/c061YvQzgxBb6Ft0yUwTjgLm+j8QzWquqBau46ST/+t77wsCLi4Irp/aLsphgzAMLgztVlq5VSAXDs+48vVx0aUa6W//QQ97K+BdcafA7aZDv65d3l6NeMjz3xuYhJRFRSuGjrxTOfdJAh9sM05/jTW8Ct70D8yjLI24ycPEzRp71ghvpU1sK0OrALc+CvazfB44LK12Qa72MSK1xJ8LXQSnp6xnhbbz6Bd9eV1Kc6VeYeZ0aGrPa1JUFXtKSFsPkOcGD+8JO/gyIdFIVOjQQ0IJVUDDvRZMv5NWvBre7uBY6PzxQYn/zhed1X8nAuUf5xSERVKuQ2mdDcQLpcjaTTHsOBNxmtYR5pEBQW//8W2DUS8HjK4gO87ndsvc9Chc8pTDbPNEi8XnlGAI8VrXnRMMUL+RwjsXCtsD3YWD7xLI2FNMf5Wt6EmOHFSQ+sL1sV6MiAvZnicPSR2Qd71ePL3B/RNQAABAASURBVNODwml+hfUtb3pwgGzlh5NMHjU+327UVH0KlSupZ3mH+yAUMIsOCLjETobMzdMNbPvTv92kd/0JQOPqwXjE/bcEnjdcvlS4u6mgn+1hNcPh/luwaC/XM8SUYf4PwOtL88/4yLhuecsAT2lb9WvY3hOmzSq3XrqVOCuA6bHM8wvy32aWd4anLxA1nDBnWihxhRNmT3syvfLZtSoLgRbw+evUGCu1lrasD0pSWWE0tqe2BNy2iCVVkQ/yIx8rdLvTAN24O3dluBWjIebrS4MZWbfGCv3zYUTtVueBBBt3ksShNTyHWdyt8IMw7uRwuPaC9NpM915Pf6biDJsnzTLAmQ09Oa9aH335vttoJHhonr+a3nWC5cj2OlMZv/U0EbjFi/WNe9PAjl3R+2A6bCDDG/qcgcc+cS9BkcuxTRUu7gZc2Bng7iA7JhVTNMOywxhPLytwRhvGvAMnMfRR6Y2RXM5B6aL2QQFb2DTf6pJ+ZW1P5ug5wkoIGaiYvrKnykquyd7Y9GX3xrLgB3r2kcEMxrsW/xy63Xl2rsL67cJ0435TgOaM1MaEWNZmllfgKVPELwqp6QGKFG5/10D7W3Jw9Hj9wj4D3PAGmR4044sGeqbmzIael4/TSzoeWnTMBIBpezhzkkKXOwDm977HwIQZBtZpAX9qWhpMhaKBif08X8U8AlxN3PJW8DuSVyA38j9d5t0V8e8NzbJ4fOmsKwVmjYrgwQERjOopMeY4iZmjJHhWtN0U5o53lV6uJtZ9bod4urlVxl1eXBCXLHBidG8RuHYQe9DJqyLvnlaiq1chwnWH/HBo9chBjKciTF+u8Efupn8veh0bQqvKRUI29xnyfNEHPgq/YTuBiAZMnaf0lzRGP0hmQXu0X7bpggH/E06X4MAOQCvKDtEDFD9wf2fn2w1MmgXYN96HKB6I8tV64P6PgI63Kdz13t6b/R2pZcecZQU18CWtHPj8p0Tm41WOWymf0jNge37zWgCPsxzbRyKrcmy8WzjFIgLndZTI7hHL49Gk01x2iTSsKnBEllXS/fqGLrdzd/g2u1OJQY8+VB6eJo21MUhezBaR+WB6gK+koUkN8ZOthgJHw3wNBrRzr+bNz4EvfhEYPwM48hYDY6cZSNZGiIzTrmJvXx84WD9Q9xq5a8AwZxRe+RZ8YHvdJj2grXTRNf898OYyA100s+OeUgr37ZQOq6nA3TKH6xeQ+7GD/L/Zy3rFH5wJnDnJQKo0kF71WPDsYwTqpgczh+tfD8+M39SrJ2Xbf0v7wBcuZj3CqtbzelEXLd+qHct+e3ksbo+dHrDE5d7gtzzK2ukkEz+spljjh6/vTgvC3DG8Z3oCVd2LRKEnHo5i0VjBf9fppcSSAL6driWHPQ7Vt+Kojur3+2fGBgpfBu5d7HaXgYufNUJ7pZ22VIFfM4v8kC5WzP1683R3uB1asxLAfbp2WFE8fz1AG0C6V9++KzYGeH7J65cJ0zvLG0MjeO4iafoinHVlBMtvjJjwd7IFJg0CaAyen5rnr9ZyrsnhmUx+6rDKcMvmBHOZGxvPVp79yg/8Cwv9cSz8z76zYtHr6F4y0FFGFBMQQoAydOT+0VGooRLrPb6ZAPeQ56K5XqbrD5ZrRj6BxzVDmm9RheRlekKhih/Rzgejml9+MnlBxpek1U9/TbhjgnF72PAbsMfFiYfSXzf6vuv7kAKXvm8tN+D2wEiLjHPSbMaioXF1wM1rcjQXoLt4+7m5Ftx5vbMv9GAQTnBROskeuFMvM6P+4KIF08sBdNf00EAJmn1Eoe6/nK33OJQ7FiQmnpG/Z7F4jQA19O41pBbaorbA+SFMsrj0phw8qPYNNnPeQ/S41jOkoCJx+XYTJO5F/3lrXLaZoPnKCQF2s59+J1I6Yz62CfQi3aze40dleGR4b0NTQml24lUMqFURdbxzk8sJM/U9rqk7TT6UWaOEFsQKtLBNxe3Y/DIOnQocpbWy1PDlDpY8lA+/Ar6zHV8yxFeaCdz+dl5Rz0if5kA7x0lrnshFGZ498PgnRtzJcY2qKkwfKnDUIckzMBq0h5GbuTXmiTnAV+v3zoyPsrTKZRJnVPZ20WUZlW52mFt8j80v5GH5MAfa/md8O7y2WPYNYbj27gq3FuYPVrOSqK4nK/GNC0nKe3mrvGV2urKdxSIyErIOXzQubT8PkA5yn98h1b2bKoTAsU0FXr1U6iUOXwj2BUN81fT6cYPW8HW41QBnD5t+j+JMmh0bzLX0kpTT9fiSsdTH3xjgYSwxSGKMRsjX9E7+pUyktH9Bps43tBzTABVGLy0yQHMdalELq5U80+F/b8Wot6kHvHyJ9N3/HMN2j1E7GeYFdSvNPeFu8FTDOHMadaz3eLfqo3kVLQ6stNu1duUYNCc2zGPAgJjTLX0VLWZyK0Kv5NwP75Znwd75Ivq+WemCXIWQaUJiOzz+FMSPHlneMz1AeQoKhRAet+5VjTf87YB9hSx5kofvf+Y5Q9t6Qi99IqCDUA7uiIvHlB1aLvSQFlIfqZkft9tw+WLRGaxleW7LaCv/LpczPq0863pxNxToxbTo7G9XGubf8wFMhdFVLwODHldoNU6hw205GPmigRkrDdDpQqraPeaV2FtapazCAwMFypYQBSZPL8xhDIKdFZEJO2GFlaa7Mxp2+9HnYUDPODSzTvxDbMbwc75zNztxlrHSK9cpTNNKQitNJYvfzph+rS1M9+sn3yClS1w9Erx97gloaax7O7w/J8J06eJeSkOtWZKOFug/zJT3+GbJV0FVOgf3Z2OkaXBZtoRKIJKTu93GyqDrqNNb6660AI4rDV25VHaA45I8R+Cirt404pD384SzeQPbSdxzphMK067xtSXAkGeA1uMM/O+tgtu5PTzL0CKHWD/ecIJElTKxdGIrkoM8dJbEpUclVyZ1tYer99rArfNA0Gyv12GxuqioC7PNkyVmrTJMzTVl40wzHNPEvweOPcw/nzQ+/DLxPSQ8P0G3rYZXOa2T0EIr91xPprdL7n5eL2NdVARRQt9v9J4JRjGCf7f8obBkrX8n8CyKIC/FfjVllBOmweWnmvlddSz0DMy7vnM7Cl/N1kM2ZYdXnZd3F6AWziv/QIf3aS7x9PlCK2jc+5G2lo9/AtPO7cY3uT0vipdeVmDqhfAMfE5W32zWYgd6q7bStM/srTWEVjpV15HHSFC7G2RnxvooY7v5FMnoXgvt6stAF1Sc7b28KNrHbg1rrVc+B9lE+nfolQp3r7jhEkZx0+VTDZw3GXmHZRHO+7844GNeq5IAHfsS3yt8uMq7rV5l3OCrNxmb3eAWLAc5L1px59XzKe68a8NGCPGes4CVnvsD1lvx/F453QX8vw7HN/fPR8i/ciUFLuoq8clVEredhgR/eSXTFOhZ1osc9wVTZe+VTzjlJwP0bIjxf0tYu1WB+yenzIstNTs2FFp2KsGZsd99PvUp0O0OZXr0IB5fYq/AfCs8NVfpZXLsuY87KRa3cFJ1pXaXckJ6Fr5djwvagh5SPUqd9n5dGwN3nwksui6C1nULrx3RGhN/r+rl+YrmIT/u46QjIgVG9Ii1W8+OcPEzCjfpD9LP2xT0xAa/6CtdSl38jAEafU9fnkfajAg9bbr7DD7vGB0zw+WnR8BscI5e4roUSxq0/GfluXxVCl9tmfjzAi+i/j2qcu7zKvjCApT2ygsLn/117EXyKnOcVlB45eUHXiwicHorqWV+Ao8MEmhVN/rlOaOtgN+uiUmzo3h+dY7s6Zd7YOX9ukPhoqcNdNVMix5kHnP4RmtaU8tOz5EJ57rW0oogu8uh3/6C6dHjiTnBz9rqoSma6Vnx01u578Kx8lN1bZAp0VePi3EnSbw1LHqyG+39ntD3eIKe3brWsxeA7Oceh/pXRDfxfmZfx+lZcrwMU2Cy/iB1vl2h/hiFTvo6+GllelYxlIirTGqGd2dfEdrD99EutrR2gjt3Cyz8Mfhdspdxiz85B7vd4CZMqYfMq8ePL9PbNPHnd/WXYIZb2Y2/o9mv2+E7xXQrZ4fNMl3b2CHxcWqD6mXEP4R4jPyntDIGfEB0W/TKJYCfuypO+YPMampUVNiXL0f+eyKxJOW1Jz1gwG6L+Mffic+hZR2B8afHwyl8/+AKCZr98DAaizqNucOce0JliN0AeXCXePoWvf/SNUwfPPmp/0flLv2cGldPrtf4AXvxYoFTjvBlE3FEW9QWSA9Qc378TUGZnvpr2S+ieVzFscTqTXev9ZysES3wbgy5ZxgR3cJNb+bk2/Jm6Vojbp+rG327ENYt34LpqS7eWGaALxX3w/KowNeXqtBb0ahur17R++V6OYRPsDCeZK327u/XoVPjd6ewvcU8zmHgLOIim13jjJWAXlHhymP1bHqEiNuXeevbCq8t8R/w9q1OnRsBBxXSR4/3dKAEflya1/Jv7aIftbpyk3ffltFa7xcuEqC3H8Abj7VQSzvuJJju5o/ICmQRLBIXuh8Sl0xIzCqgXO/+j3JmC6BcAmENMGAM1xff/8A72jJ+3SpDqTvdqLy7UrT/cYvxq1teEOzjEGt7ylO86NDnHRlcx9tycNL9CsOfA/hS0aRi4vsKI15Q6Hqnwil6xvLMXP8DVrzqsOAvBmz5Kas1w/1a68dgFTiArzTeXrA68QZoO5YIjUKu0gyOM7xoCnj3i2gsq7LAy5dInGzzfzjyReW7vPngq9gL2TsfWvtozf++3/M7B9/TSwEfZ8q1Hz8ngiVjo3JtflRoClSxlDKZ4ZXHwlTsfHRFBJRNUxQUXGsiRvc8w/HEPEJ4YhuVVYwnG/78x/hj4vviMLdyWkL53uYJP73hlmeHBTI9Im+uIK/Xy1zHLj7moOSgR7HajCX589l3scHtVrSMZiReXxkuN3vfE3UjtG67P7Oh4fPYaQptbjZAg1q3uvxgbGdQHWe0Ef8Kb8jcqXLvh4Zrd6SXcQXnAW89NfYc3loe/2zpVmtg+zxULUg3sPG3eBzmztQzAO6dZpwhyESCOP+VwEOwqpZP7DP7/dPvnT3tFafsmnLtyedJLLyWTDACMsMhWtFHxY5XubDwIxsEY85b7X8vXhQufhofKyVqOvM1td9z/sm5wAl3S4dierjhx78gca4bgZ+3o/1rS9VStzw/2EI9HffLb18/9hLZ8ejYc4jWMoU5gMdeji8TDWrv/0h3jz0jIP7yYncmYC9GpmdPH6jx6A4L937nfle/+6LA/YRcKcucb4Ftju1LN50oQRktadDMYtz0xOfwoW2W17KO0tph97aQxn8xBK0mNv8OzFoVPF4Lu++4KuDz86tnYT6mSl+tM7755Fv0cqOrZ3kjt973y89ueU5YOKanS20av3aOUnhQRxP+R71kVNXTzj8TMjwAC0Jw+SPruxemvM5pINy0psJo3RWTzwOmXAjTowbNDdwoTJihzBOf3PKcMG7xCTKeblvv3yN3Wpq7HfCgDODq3vGPRHWmAAAQAElEQVS9UatyfNotdVn3GHTaUhVL5MauPi7GxKgYWu2QQc36OlamVb0Ybm7x//ylf1v2SayP3DrkzWVu0L0Pa3MQ2+pdb36Y3umT8JcbRb0K/XTzhLWPuuW5wUIzPbPw7j+vgtYPmHHbj2GIGuc8ho9tIN/oIleVdXyRI1180K3frmA3HaGd2BPnANOGRjC4i0TnRhLt60vN9CRobkC3QwPaAlS726mPfsVAGKeGM79CnL2YnYYV79/Oih2YV87IFurnwaX/vFwBxiXdAL5g7F/rrv7eA9PNut8Hi2YfXQ6OlrDketFU9LdbYwHLBo4Q2uPxykAGaBcjHF6b0KJg7wEektTlYGEHJcTfT+GOB4u4lunj1SUGBj9toOHVOWgwJgfXvR4zPLfw7Nf2AUyP53SEeQctmje8mfPyH7vRzErnXZX68x/5z4C8dIiIDIGTh7LpwU07lcDFeQBbZNEaHDvra2ORDeQZ1bieecygYqCRiwPPGSsV/smJPXSeHdq1sfct0O0Qz1x4SavdKawlbQYur8J4qJi+wn+pwHb22Yc2XLyXZMMfuxUe/8TAeZMNU87Z8iaFfg8rcOlPRwo1KwE0UeASZaDt4Jcn52hGqL+lZ0xSaDY2x3SpThmgs/5zO0QhVIZs3pk4K+l+SDSfv9OXxfI/+z4WZ17DzNhzZrooRHvgtJbRq9cv7eDe/9J/3DrLkvlMfN9AjwkGdu+Jfw5UGJ77pMIVL0KvkABu3aQt35R5UcPzZT/H41u06czVintdl6xxL+vE/3GrWv7Up6KnE860EuLK7ePXr2E8bPDmGB4UNk1Y87ZePy92y77oaVXN7UVw4i74wf9mj6jjPuBna1mRRaullvm4zQatfPuVJilTBpNmrF4tG7CjJMR5HzO/YpmErDzA0YfmRQ+IyI+bFY7TCiB6Lpm1Cti8M7HZdH9/0GgDDA98lJhPCF8sulSndpyKHsKswNk2D5phmvtxebWHpjbTC358OMtk/tzv+RsLhWWfGavhwIx107PloJa/lcQSl4cqHaOZHb1RU04+z/HxeWimQnTnVGKtNDw//0kDtOt05tJEpkVtJzQ+vdDTD0o83on3Grv1m5hooqJXnZofPRCPHZxKmumRpCHUzbw6g56F1Rr7utLfAHj+fbNBgUoFTwSd4fWV4EPR2eY/Xy4zEvLnkOpSq+VjyNbpWDFIfOyTb5T+6sXDnKleKd4t4qTvSBcoyVnX6XqW9tPWApGJK0zBeRwgN3FyrlccmgrlgvIu9dLzomaE/czIAtsLQJkiYUUhsQc4Az+mSSLcDgky+rdwufd94GMGft2hWUou8CP9McyNgueRPDzLSkWvNFi2MzN+uCa+H5tMRLGiv20Oil69fpcG7LtnuYkf7Jn1+1+iNePOoJfd/3PCwqTzxfS2jP/pdUB96VbBK0twyM6/jD/c8gjjwSu8+gW3DeDU2nKvoFWOnW/Fw15b2/ZOejlDtGjNtD18C2a/0j12j0Pz1X12MnstTqNfLyaV30bwlDe32Xb3XDutn7dxSRT/QtSqHHvBWO98Pevnc7W3rXqF+DLEKwqxHugZ4M2EMzBrBh0rlRi74x0Vx/CIYV9yMm5/T2ggPXOUMP1WDu5C7Gh4aZECxSbRVOy3bYAyalXg7n315wMfCleVplZerN9899pHYrWFj+X7rdXD8lmPaipc/7q3bO/rX3VJj4IWuGltYUXzrrTyVyoG35GP8z+L2dyekl4ecZfITJsm0SUbQQJltzL7EkZnCnOvFjivY+pa4bUv+rCa9HsXfc7PzoterVrpgcbuiWPhjwJO5UhNn90xFp3/8rW7TS7q1Q+zA8YvxTevL41/NhdrBdYLQ2IsYcUvsfeN9Zx8hAAdGED/DT1KwNqlQzkfffVpcNx/y7pxyYQEZ4luS2ML8X/Tcz7Q8kOPRbJ63MJL9hq7wyRLqpw9r3oVmbZM5OrwEjGCZnr0VELjSWdJdjZnVxZ8VsC+XQvPfv3Z5mc1q0r8A7Xj0Xnipt+984nbxfMOmbt/hqrlBa49XppW94dUL3gb+7Xx7iOLPnfeUJZor61To/hyz3xmzwWqV4xP0037ZVMMfPyNv4A+vtS/N1W+pABl2n53GMT0vvgFcUrBc7QCalRPCS6fLbrcBGDFebWbgVFm19amoeUmAOLYA9vJ99kOc8a//tUJiaWf/FQ0iKUcMSE9+Y8DMyGZb6a3+Z51XysFV9ajlKg27wfDNe+r9fFfF2eL7NuZnHk0gLVgfJk+SeIl+EtrpewC3kOrW5QSr84TpBIxgKNCCJTdyu0PMFrdP3+RCPR95tdWaq6/1C+OF04Dm/Z1yvz4Z84Zg70ctcb2NJmzleZWw973AG+vAOqmxzNLC+e/eKV7L7/75lYvyuS8cJwrpf5tEzF/c/glLlcqvv9rVIiVWbslFrfH/N4z4nlNgr761XhHz/LcVYVRBcZSls9PyDfTMysT+MC8uvw8OQebnWDahNF7qxNuTzeuZk/Fx52KA60txutL41+o+BKx1IMfqThtZQ8fYXAYx6bpZeMHQKymAyPGfZgvXSLRsWH+2ksNLvfRnnhfTsLylBSzbMbMry+Nf0ZNagjwnFriuYWq5aPQ617jmRzROOW8WQ55YDTnv/nLfbNBd774x/h+t+NLET9+3dzw79xtLwE9C4ynt9Gm/f/rn/g8q+TBPu8zcbzEXRPeUx5sVGsTBN5k2fyGAjE9oeBpHzP/ByPD2aivA2Z5xLe2KjHuDH1bA9wgbcF5iPCIF5Tp923JWkNrhRM7nns8edYCTSysctW0oLyLj5HnYpsm0Spjv3Z0LM/seQdSnEsLbhlLts3c/cLT3liOch/a7nFrIM0fCGOoUYm/0cCTu5yCdb8jA7nl7aGZBqbMj5bn74Vd+FsUrB6gGVaZEonj3crnNeEsaQJzg3PZufH33AzbxXnok13s9OYyA/YldLkS8UzUIhNkeuTF9OZ+D0/dr64p4A21ane/FojpGdL42Z0stLpb2oZ9FGu1J++O5vO3ns8SplQxgXvOYJPjHzb9vp32IHDY9Qq0OTpzkmH69+/7UA7a32rghYWkHAvjTpKebuHXbImfEcZKxWIts0QscQDHHtCz3/w0v5kWLd9zpjTdxltyHrqUOnq8Mi31aQpRVcsP7bSX/xT/zA6xHVhjx2N8mca90+azmyKPnk343JlbFKweODxgHC5aY2EmXmkWZJeRv++yk2Pbn/HjvGKu0wk6pRj2nJ5x2RSLLbIS6yCE9fDqFX7YlJijoLb/sRv1EnNyIYbakBvL16VAI0nmiLVeteohrmd6Sl9iGOtsioQYND5Wz2HHFZ8L0ETi8XMkShWLI52HxvNr568GGBavEVC2B0Oks9oD3XNNKph2Br+vo4Xb2vMbZGEcGNdvNrj3YVDrLeegHRsKcLuf/YAdWup3ud3Am7bdFqS32iHsqG6TBzHfHibOiG/X6F7xL58d978cb1nH/+6dHxo7dpoUaGsbx099qj/2v8f6/aetBmiobpXh6oiTDqaLObgGt3k6RU/EY6ivuQCvXmHXPwJO+SIU1gkhPKXuOSjYURWO5ns1zR2eA+Fr6qpnTXH5P2+NdaobxYqllJYbBA9wWqW/Mzx5eRTPP7i+jz/9IKPlevohpvJULrd+2FswDnyvuujEoZ8WJ7jl/+L4ePGAHftWPxqfk/nZy/60zZ4C0iLxaXvKPsPo0EBpuaP/M7OX/S/FW9vsTt3um8/BqTm34x1tc+2+c7fABU8ZoHJw1irDPNnOjtvYNjNv67Cc4+Hkzpm9VZbaYLtIyoLbrzyjw55et92I4xv2PMYlchyfUELDB+mJGiJDD8VSfmjb/9Q824ZAY1VbMiFaPQn7LJqcPH2+xJPnAgP17I1fogSCuYC29YBnLxDgspamL7lg14uXNslCpkDdih/o14ql3T9CZ3cA6MTh1lMlTjo8EefVJYl33rJO1GGoU1ZkYTqfvXO2YOE5r5d206PMCSxKmz3QvLZ58f3xkpmx0KktBew++pb/LHD2E8B5kwHne3DqEbHnwD3tXBrTIcXYPsClR/mzkdqVYmVZrzM4P4gbf0NxJ449rSIRn0+mHdM97t9a9zJ5UP06VMxLuERKOZruHPjOIvnZZdHlYAn6avtsTAQLrhGYOhi48USBMccJ3H0m8PZwYZ7cxWWxsz639FcBypYgbZQbzf0VVtlxjuyRelbF4x3H9okNiwn9IqBIwH4P3Le7VCuO7DDGD8oQeHGIgNtzXO0iu2EZv0B5Ybv6sbb44f4X82grxz7yu3d6M/HKLx4RuOUUCZ525oVDeEet4T+uKWPRwBXCtMsEFl0ncXYHGQX6/NZMkO7HI//qWDmkFRM23X88LlMqR1TgNb8huMU+lPVa3vdbU6mM0HwxRmDDb/4c367xi5UKH0svJ9DuIKlfUoELOwuc0FyicTX/Ou3UuT+VmkY7zBk/1DbNd+YdaOl7+/ODIEAXXF/eLPRsOOK6lLzxRIlHzxagQsG6x9vejnu0FljPHISp4OA5qXnA3AjPMsmNxi8BLKDj2t22/HJkFSVze8C+7MwFxV2+DpDbUlT0QH8Jt+dFQsc3AyaeITRjFEzmBZ5FHbRqspBr+bIw4GcH06taHr6TKS2O1Gs35PuvQExP6wgO9a5Z/ZFRVmgJWBRDy/eiEZ/fmr636lMwRVnfh5iNHFLDquzAv9Jivm09AS5XuD3M746o/Jl+ucQdfWEe9rPwR4Hpy913SNCImK7ILYWHRde+3WxPjgX1vrbSS2ZnLuVNj8w28Ngn7nU78f/t6cbV/O/w+xB6zmObCnwyWuI+/RHkrP7UlsA1vYFZowTu1QyxoDJsuxGzW2t/2R7/Ac0sK9OVgoMVIu9Ps98QG/Hy0BMiBWJ6Au4HdLCWsiVVnLMgmjEQ7hdqVBB+2YWe91OAoiW9LFCp9L5tY6F3QkAFp7WU5mE/C64VKF3Muy+4//aWU+Lz6Q/RIm/fyG7BnNeyNju0RT9GzZEob7rtHYA2hk78/2K6QVX/u3YqnbywqZnt3Uxo0ZDEnX0lzu8kkeWzVdOLjhtcT37cwHmwrTvjxwkzypcyvC1DBPYd09NrFM/t640yRZyGZdsfiTfGm7OHoGmwHbcw4j/76ozgKqsqjHYcCDTTywoc5WP6w3vgdrMz2zAWDYv07JAiBKb2GPFfd8Kc4Rs9S3lxkYHzJ+fg9IcVaI5EHArRR/UMHk/E/beHGgGrI2pwrT7fV32RWcH/WW/7IzFfL5/9rHq1qi3/d5PvmV5Gdu1OQqC8V9Va2xOn2Q0z06tSxotaFK70nJeW/Ve/aiDH56XhQ+YWpi9+SezMKCX336AleNAAc6f6n4WaNz6mt0Cl0mbU/Pn4m+gz4ctoAnx+6Ox09MvAzFUxBqfHHCadJUHX6T5F/zNZtUJYPAStYAq7szL0Csmvjq0up+ucdLi3BlePhgqZw7PyzfjyzfQAcSp8HNNP7AAAEABJREFU/vocjtyzsaJIOxzW3VFo/G/5UvFpe4qbp+m2up/+4j+/gMub6Mtjx7Hi9B03ZT5wwn0Ko182XH19Wbj2a9BSoHYVO3ZRPEwPcE/n2BNjmB/knni26+8YLJnYXacLdGioh30yhf7FuGGY//qAY1ILu3tqV/ZnM27Kwz7NZVPfdglxsm++T6Z/azwKls+uVVkIcZFHNupnGJ+WLSFt33cgzEyPm+DdaNL3F5kdPatY+X47J96yCdhfXAT0vtdAmMOFtwQswWsUSFFutfy/d6UWnUbdvHO64KfDyT/+9v5oEc8ZKN97TGuQLa/Mzvz/ctpyz+/VB0Hv3gq9IuLxn7O/NvCR/ijNWGng3RUKby1XeGOZgdeWKryymNs5FabON/DsPANPfWrgiTkGHv1Y4eFZBh74yAC3p839Pn8KJueuDL06KF+rkprrdU8K6qLKQyt7rjS9yhGeL6ZXUojhunBJHVz/bz9NJuiUtnn6Uo6SKO9JDbh5uoLT3miph5hzvdYEUbMYpRr9XbtFYPDTupv08jgKcf/d7iJbsGNWcdi12fOK4v49cGEnYSJQgfHeSoUwy1uzgP7hSz19mAyUIWrUA+o/VY0NGpfbA1ZZ12px0aDHFc59ErjgKWXuxrhkisLQqQrDnwNGvqAw6iVgzCsK174GXP86cOObfC+BW99WuONdYPwM4O73gblx6svYHXqZxFgYbvzhfydLTws/PekqG0krc5lVPplr0kyv7BVVMwExAh5/jaqqBUfUkfWd2X8GLGfKlHT/8q/6VYHLWTu9y44Crjw2+hLZ4Yxnat7/4ACR4GSRTg7f8DkwhfLCbS6yBdK0QqUy7m208ouu3j3QpVEs79UlCjv/iqX9YnxZnjlfoMitlHcvVYhbUyXibQ/wMh7W3i6RciIkx+MVKVsiEdcO2e7w3ce8To1E45qV1GLGXYOQV3LV6ZrnA0ya6ZU2Sk4ChJfK4ffJ58uD4fIXcedReZjlPTpl2ufxvXjTScCIY6RpBJtX2BbhA6Td0YtDJC7sbMvQ0TeXeU+9owzPv5GVimZ6uhfz919dC9ytPZiffScQtPPFquWO0yRqB8iELNz/6rVSKf873xHwMY/I+HfMn5p/rpf9ZdmS/u/WHw7ffVYtT58ns6CUC0sENMUKJSHvRpJ/Mhn8jOw612p8zXb0r8v//f2xplp54Sr5CtrqUq6UC0ENWviD/sn9b1wdGNguXJP19BdjjpM43ObyZuUvuYRcLkEzURbRcgZeikJAD1B77oZSzibCeMPxMXPDb1wNRUtat45xwCyXTw5wXjJopsdtZRZy23rAsKPjA42VrXxeRx6jl7daOTWhnzB36tjfMS+jijLF/Rmr00sz64H+qZchMq7pLbzXaEKclTE8a6hGDf0fjoNocpkjs3oIgXE66vp/0hF457hm8jDXTA2UUvNlffX6t78Qdhz7C9Q9HyaJJ+UeR0ia3AbHZSzjzlA8xBbmoNmqk+Z/NX3PBwp97s0BBeT2PrD38Z9/+48HlmvvfUICs4tCbg9U8Vp35eYHzfSEjQu0Npme1IwvFvq1jn9Wg7sInNVegu9W90MEqpTNrUhfcjwWU8XTdKbPP09w88o+v7Ns16au0lJDdwwhxb1VhtVq656bCLXdbmKmBUkfVuNgGHjeSjuvTWqqDyecLns54fZ0fLfZc6Lx4h4cJc0GL10sipvMbzWHYeRfe9xLFwt4KCz1d4itU8T7rwd+tXlGw4n3cRdFDrKfz8GEGVqDbnMvHqaPStme93tfGLhkSg6CbCnD0P234VQp6/92bd/ln59m4wJuMjnpWP46cWyvKPZ4MD37e+zW/xwzbnAL9vwQ2T2znDHPSjuvERl5sfKIGrWdcLe07XbdsoH07NqtpEz7DEK4bhtuUVt98OZQ2c29dAwq/fvd079aJZv7ozB7Y2M1RmMbfote+UtL/lLF3BtSIgTT83qgpF0UYj1gF6x/t1Fg2ucCdNfPI/9iWMExbjW7fpqBFjcYuPhZYIfWQtZJ0dao4NoPHIx020zLrdU7AmR69nfTTSaXZkfQFeQ4Pv7SxkWUB9MLer927vZf/gIiMu+aSNPKZQz3c3m0riui0j4zJ2jw/7M1NxGxcnZWEwH5vhfDO7i6sezVSyNaAiB86aAAf01rxZjUOysUaJLiSs4D+NbyWEaTGrG4M1YsxPLWbUA46RSlgTqun8fke+bDr4Bn5wLW0uf45snT+C+UqBLA9ILs9CK2mZybTC7ieLv9ZnrOPKv/7XVYMPt1h6uqwo7BuCjz2Rh5ROkS7hpdIUQtEUn7qHLAjM9xOyQcDRnDa7ZIE5glBFx399XPwNJ3hqWFHoZBnB4ef91sumC6lr7qFYXde4K+CjBxbp5uYL5NEeJ3bGMx+xzdoy1/eyyNPdD/s+B29WMfqlR2wpGFRDeVbdwXtJx+K51tUMr/eURsMzk3mZzz1XDi2Bma18TAOVt0ttGrnBOveJqsrBlfw7Il1dfOPKYFRI0I0mZWHF6tLtNuwZXpZY6oc6QQkc8AkQ6Xv0ZV1ZL3R4oWLlmeoDAyM7fCnRpJNK8Vy+HpXd3vMvDMXANurrDXblFmHnGemBMrx6XtaQ6BbCw3GvM6dyOaqxmpY1pvwYuu8T3QpIYANa/x0IKnipa27n24+x93eFhoxMYF3EQ49uUraSYyPUGwGbxmekHy8LQQKy2zAv1TvqQorxlf3UplsEonE/4FRP3iosQCr6Wu7XajZauMrNFYz6PehhClopD430OrG/PfzY4cAY2AJP6KBdyUH6e/va9AcVv5ddsFxk4DjrpL4aDRRlzoeqcy84hjb97VvbWWKcDOrpjzk2YnoON+bdTZ+/n/3m3eyELwgvJXiBn+3r3L/aO2fwI+xvzg+7XUNtGDm0wuIjRHsBEwHHK7iIxlOuV9Vk7Qu1MihEzdosVr2RKixMdXomH5kupLphOCQIaUxd4tO7RahjPP1lwgI7tWA2mkfSSACk5EpquVV3OmD0sLrRpmGSsE3dRunwfXqKowvbeWTIvvfIt20PXy7kD/tnG36lqkWAD9f4peOtd+cwPSlMHuYtwNJ1nY4gKddppsbQcOftC4LGnTgrvdlf1b7zZTi9i5oibgnOml2V4tt/K6iKdWl3kMQfyBOM5QpoSMfDxa1i4WcV/qQqBu6bQSH5TPrhUnZY41d3CN0kJEPhBCVHcSZ1qrrb//cFSkKeP5CUGzqKApeq+mAu9my7hj64LaQa0Wt6QN7xG7Tb8yxWyzSTe8vwq4jHCj+W+G3XaaQItQRgThemHxmvx99MJRP3Cxdv2jpyk+zQ9aOqZFYv3qNiOzy+xYjdMXon35a6gYLeJaYY8XN8xFKJ7mfw+5aAkXvdQtN2OE0FMm5b67X6BZCSH1ujBWNI8bZJYpdrMGe56k+cx5Yn2pYu4zQF0u8L+4rWPdkMMwlKwqAs8NlrivP9CzCVCxVGIHUy7XRSs/bj4ZmDNGgFvS3Opzg5Uv6QaNwYLsnWKYRTH2gF6C4OkLBHiMI9MFDZts5kcFpeVS/oAFbQ1wlBE0ru0zOTftbe3KEj/cFgtM2ztLKzXBnRwMDTLdmdcfu93hFp0g/mDhuV3rVJGHntlWzHbLI0xAdEwfXucCxhkkf9JH1GwEgWzG3UK1CsbH7RvIjm55YWHF0/wxd/6VyMC8SvRuJvHQWRJLxkbiHgYfzMpxETx5rjSXs8Xt83YvYjZ4pdLClkqMbv8zfBsTS/83IWR8z1wQSdgHnZ/eaFLT//nkh+a/oUx037j3nVQJkGUP6QJMvTAahnT1puOVc04HiecuioZsj1XV7x57ay2a+VneWmV5/d/JopsQ6lfG3YKQ6o4Ko7MqMc9kehJpN8Dn767TZRmf7FBZdoNVtwI7A7ywuJVJNaxyWX+mFs6WKNWt+nfQ4z5onj3std0w6C7TywEnafVZEN5/MX97gPFx0LiunynBozYZGuh4YfThbwGeXsoHTDiC2yRK9W2FFV54AqJS8b9xI/Nl+pW1abJ7JhNuoXjE+P7I+rKlW14ysPIlhS960DYU38IpyqxYyr+Nm5PcRpWiZv1ryPDs4cNq5u92xvQSCDqxLX+UD/xSm3/3v4fKBWYoUfoF+f09wPi4kouoKtn6RvQUQXxqIGlKsUecxYhX6NhIpkRnVilgrhi05vdqXyrhGXo24Udv/Q7/maBf2aK8aA9UCRgHUaz4344NgZOP8P8gxZf4b6XW7fC/X86S/TEKP/evPf7Pr2LAEjxMCzPLysplSyjf2V5mdu1jJBQ6+BE85lBR3i8/bJ6b0sFZNoxLd2eZVKarVfB/MD9vTWVt/01a+XkB2x8E3POBgQdnGqbbcro2/2aDwo6AJdN/pYeDDv6paUqy9l1v/LIteLJQqXRq2ndIDWzzo2QIaRqvHe6HdHA1uNrs+ZVxywvDyff18rFWwOD4xfP4Ybc7/u/CvttowGsDeeV8fNHvfI9MD7hLX+m2nK7Nj52oMPBRh5Xsf7TL12zx/1jXct1Iuvc6a1MIsVDQSjBsaw+rBd+FtFBoIYVw32pmVVKiGPJ1BphV3rpWKSOsqOf11328fAxielyCF80uPB9fXsaPmwW63G7ggy8Tv/C0ncxDLGDk2j6ygBQO/OIbfkvsY+dd7euZ3qbfg9sYJPN33pNXum4V+FvbCtTjqPG1TtuTo4K5lVcLHHC7myhHlpnc1zOpuunBt/rdRrOpRT8+PVCrMrDtT2EexjTkGQOzVsVmZP/kBL8APqTzsno1VWhbL/h55RX4l0a++TW4P2tX5mu+7zpgU4CiJaNc8D2EbX3QrFZA1Q7sjd/+UlvCVhiEVyNgmr0+QCAbRD8V+UGzvVXrU/eAUtHe/ZFGHdvaYMZK4LzJQMubctDulhxzX3RB20wD9Gt7Bw7dglZzQJRf9as/4z8oYefp3r+tjQFG5bUr+d9DMi3+J0f4z/Qg0vXI8di+kVuT5tIpk2QFHZYdRuCZ26xCu2gZpi/tVZ7mj77FEjP/xZBSxQQaZMZ/HDjz2/hbagb3racJVK+YGloH+mMI+ggHjee9cf9B3q5rV44fKwVp05Y/UNyvvFL4Teqf9X5IK34R7nva/Ap55NUKGKhrt+77gRw0SIIGmcet/+fALWoXzrO89VSBE5rrb/V/rkfdb/jLdf4Mo3G1wnkO7q1xhwa917Uqp66NK3+Br9dLIbBFQsDVJ5XV/M/XagwrUcBrrYBpbNAXoYDVhyoexPR0pyJVcqlQDTpAkfwctubnlhpXAyYNApyH1OSH1r+lzM7dCt8EyJgPrubPFPdGXwS91zUDJkPJtHHZTwGKDKW+l5qgpzGfzsP3G1VK7PRIq7YWcPPqFXiGwp9/79uHdEh1r9ZF4TSyXLkuGi/69e6BzgcDFQpkZR+lnaWXPo+eLfD2cIkeh3K4RuFFv8DSNQoqQM9Ih677sq/4PvO99mtDnSqpe+dXb1b+XEaI5adDt6YAABAASURBVFIYYpFfg3bsEofv2IUAUaQfhVherUqxuFfs24Avl1e5VMG59zBIy7z4x9Q9pFS1e3+jU7q4wPmdCsakqLB46nwJ+ubb3+5vf2jPwoC9UtUqKNQMWF0V9n2EsXYIwxfCtPPX7Wrjn3+LQ/1wDQNLpPr7zxl+SMx7dm7O57wWNDSsGrx2/3bDvmcorQNMIRYFDLaC9tO/pfxlRwk0Dpg5+90rz1etUyV4zPjR+DfnLVztf3dt6/nn741c7pwJqqd2ikxqnpijvgqq65+S6m256UHaS6v3/ZAf+Aj+U0a/wo48p1bPkY0wXwZnmVSnW9X1p/jpd/ueMfu3cP/Jffo8AfsZJ8m0rEODIobn1V+7/lGYH8D02hy07/vvmwBrh2a1UvUuKfXUXOXrslYLA+bsuG3tNnP9YRjiHq/OJVzLsQ6bvixnEeMFDQcHaJNW+eqSC1p7uPJBM72duwWWro0Z3Iaj+t/ESi8nMGWwQNXyyQ/uzJRJk/99ff/Zd8H31Cbg4x1MoeAYQSZejQP4QdgWPPWZmvtPjjjID1+/sZOYbzK9zXeveUtzwcUEeIVhL6DGtj9Vgc2HG2stnFcdhH8dwsKceIUZmtcSKFPC/yX9+JvCbMG/izble/nZc1slHx5Z/l095303s7/xH5/8yNBPnjeFvZMT9D4XRPxh3cGGHdh005tKq84sSOJV99Y3WyasfZY5JtNjBBAXwudPGaLGsROMAr/qQTO9Db8JaObq05K9k9W5kX89nxS4J/zp/9tynecshLm/aZ8rXDolB9nP5+D5BXrYhin0H8H5+Gv//ujcaN8vbenGftPv/u0oKNPjCXk9JuRs1FrsKs5Hb08bhrrUSucxvU0T1izVs73RVobbddNO0frkB3I+dssLCwtzk7SFC0uvsPCC5ElL1gL72kFCYd17YdBV/u+oa5XXvga8s0Jg2ucCz8xVmL86H0RcKR/YwC/XGVi71Z+ZdA74aO+NHljxc/DzCpoEBbXzmAlqnhY3NfHD03zt3i13r/3AwsljegRsmrD2dij1MONeYdlPonOP8Tmf6fx8nQ1WS6vQg5aOSzVD0fT36X/HEEL06cuDH+o+vYn9qHJVABv3CzsDbw2TRQ4Gcp/ntBC2FPRSnYu+zy4LAqwcaFJTqbQ/8/Zq/B9/GTtbjctZ+PNWtPPCIVwzvOmarw1j3ApxTI/AjRPXXqwRb2XcK3y/SRzZ+LqcH5asVd964fjBj6jjf6NLf1J+xfdKXlYVgXoZ/lW9qZdf/hhFuVYPCOTvmd50EsDzNSw6RVfgzWX+fdmyjkJ+mUkq+3fBD/7tPCLLnw94teWdL9SKFjdh69Y/RGsvHML16uLVTeVlX8btIYHpMXPThLVXG8Lor+N/6eD6//c/4uDTHlQNr389Zw6S/Dsiy7/Aon2wjHFrUZ9mbtAYbMUvAj9u9n+wMeyiWLI90K4+MLCd6xBNltS/Bp9L/F93+DOL3s388/dGZ+z6R2HxGv92BJmGOdu55Q9j87ETc+Zc+qxqmmPAl4vot/LaTRPXnIobfkzgYZ4javP4n577RxqtNbf0nUw/O0907HKbMX/9drXJ2UivdKu6/p2h1+hYtR9ocY8LMXhe05JQr/ssgsd6QOVjedu7Wax8USzaA68tVtGIz+9xTf3fL5+iKctaFmK11jKAD9gb89ZyY0mbm5X4ZoPoaIcnxBU25Biqh9ZR/C8hLxfgyfSYv+2un77Q3PJwKONiwNsF1U/b0bbDrUbZa1/N+YTlgkILXxPCaOmZXwU/3Chm4f02qirQINOf/mtL/POLcqM9QO8o1tmqYa89D933L2+09fvHL2dPb63wfy84O84sv+/7beFq/zZwi2HTmv447PXfdxl/9Hsk5+OhU3GEUqIKYZ5BYeKePb83sist3HB9mZ5VYOPEnx5WewzN/NQCC5ZwFaLU1AWi06HXGl9/v9H4OSHfBihTQgRuT/polf/DtZEr1OgJLfwfzM/bgHnfG4Xahv2CeAEbwQHerr5EMiG9nH/fF7BJB1zxd78AeGSBX8NPaL5/9NmC1f7vRPMQ8rz3VuYsbXGj2rnwB6FVWT53rUDVZ4eNE9eM2Hrf1t98MM2sUEyPmJvu/fnbjRPXtlUKF+hZ32bC3MJfe3Dw0eNVxanzc7wZpC7YMkv/+PxTHrDlj33P+E5v5dPI3KwXF+37duY2pejyL+6BFwJsFWkVcXzz/aMDlqzxb0eQXH/483tmXfyMOFxBVPWjpJS6TUT+OnTjhDW0KPFDzcsLzfSsEpsmrnncSFPNtYbX015PCFH22tdEm4uf3TPbKue8tqsf/EWaHWCA6aRZGGkuFXr6WgEBry8V+CXEMXeF0b4imv+NHuC2xwUBe21POlygbIng96qwe4x703f949+O9h7v/x9/G390uDVnwRufy67+7VRfGDn/NN40ce2YDXdt+MMfNz5XxifDpTbf8dO6TRPWdtGM7zG/Eu99IbuMftlwZXydQhhPfhjoM8Gv9tTl9W8bTOvRT1QwUhHGv7gHCvfWHpgZPL7Oau/PaAq3hTHq77ucghfLBUoXV3Az/tcM70+tG/hu/Q7Rxo6fGFdTNk5Y23TzPeu+TswLhuSL6VlkNeO7EArjrbTb9cVF6PLyIrXQmVe+pEDLOv4P8pOA/YVOmoWV7tRIIsjR4YsLFPaH5Xhh9UER3X3XA19vUPjoK3+G1rquAhVv+66VsZqDJituDI+lj77TWPnbLum7QFdK3aMZ3kDi5zcUiOmx0o0T11yhZ3wvMO4VRr1kHLJmS6Jyo2ND/wdJ05U53/ozRq86Uw0/r6N/W//aI/B40Wwv1d1eRE/3wH0fBL8D53fyH5+azF755xa5X7b5V+W2yrvrPWPOht+lr7Gx1iU8u2ni2uH+1INzC8z0WIWe8Z0B5a3ZpYzvxPuNhK7o1jj4Qe0vWtzTWglULuM/+J7+TGH7Ln8c9ldRKOqBsD1Ap7pvr/DHplnVMU1S8ir7VxQi9/0vPZHyMrodHP/eb9xpbH5gJnxneJrhva9neGflESlAJHU9pXCmbpinQFFPW5u+sDDeJ1/TmkC5kv6tD5oq+5dOXS6PNQySmfz5t8BTnxYxvdT1ehGlBz4KHk/7yyyPT+uDAHle/UwkuLAfOkV9qdlgOZZ3D2rzLrGHO8Tcs5OEpozpbbx77Q8K4iq/+m94XVWw5+sZIHr4erQHftoKhHE5badbWHEyPRpV+tGfrJkeT6nyw0k2b/EahSnzjKJT2JLtuL2Ez9Pxut6Zg7b/ywHlb6mqdvUmhTeW+VPLLK/2mxPi6HVo5TrNvnyafLTjfV+/Q/26cLW/HZ5hiHN+H79usw/ZpLJSxvRY66YJax5Qmkcx7hZ258iG05bmLLbn9QmY1BL3lRBbb4hX2KFyGYGzjvR/qDt2Cdz3oe6FFDWGS+b+jxi47nVoxpc6uilqXhEZ3QOr9eu4dosAfced+oCBeT/4G+bqIqH+b30n+Hlf2s1/PIaqKEVIM1YGEzresbVz/HvK9wharS94b/Pda94KphweI6VMj9UKA2N49Qo3O5rf5WCJiqUSHm5c8f1pq9eFnQWCZnuPfswZasEG/m9/KVz8jIEb3lB6hieQXhZoWmv/GeB8QJM/NXDQaAPvf5l4r5//FG1/u1ty0HRsDs6YZODlxTE82nKxrHfIYRVm2L1H4Z4PDPSYYOCQaw1wVnX9NAPsIxNhH/9QazroyGgjKOI46zGF6ctj9xrNSe537vcGPgiQj9E78lntU/4KJ9dQG3aQkX5WFQXnkZTTlyvfbQqG2FNgxYWtiWY05T228e41r2mlxg8mdZefLTtFyy0745UavQI2SG/eCXy4H+zF5e1U0bO9QR2Cmc//HMydZcOGFb8o9LrbwHu5X06a9rw9XKCC/jjsD8tcQyks+lHlzWiFw5nAD3pZ1l8zuTnfKdBg9gKtWdyqpb1XvgRMnR9lBhVLAzytyxl4r+ynciUFL2a4fCqZnpYY62/jGW2BCloO/Oxc4KxHDT3UNNDE2rc/N5wgceOJAlIo5BgCbPMjs6P3iiT/cgyFsdOC7+uy7rE+cqti3XaFxz/JXxvc6PnBvtBj9st1fhjAyYfHt/ebDcaav/d4n2uhh9k7W8av850J+tfonptypqer0U9L+druTV+OrzRe3n+oJe6SvfPw8hrlExmsZ3s0sPRBAaf6+TG3efRjBS6R1m+PDpALOwPPXyT1TE/giTkwl7mD9EyCbrL96i+svHHTDTQYo3D6wwrb/oy2US9B4qqbsVKBJjxkdqN7SQw7WuKu06O4ry/Vw0Nj84v/nL4vZzgn94NyQguNpP8546FG8HA9H/hgpMTYPhLThkbQsSFA114f7CcfQ91UUOb75LnR+wQEbnsHmnkZSTPmJ7Vc+LuNFh24/vEQ9AFt/V/fa15TuPdDgAduuxJJIfCFhdHn6keyj2Nf8LSlynezmv5+POZHL795/r2WT6pq919P+xV9cxnivC63qy+RUc6/095dIUCf+35091YeHTSOPMZ/ULItV71i4I/d/vdFPAaaugx63MCtbyvs0TMF7qOcNAigA82IjNZ1VnuY1uzzVwMXTDbwd0442qSfqsCl3CXdgJtPBizXT1JE22fV8Vfu07WDZS7Krr8tLPcrZZjMOSt3d8H6HTBnhFaaeQytck/6+ibgiEHi7s0w23F2yjN6RjrkGQUu0cO0g/4Zx78XjHmdZv5+WDNWGpj9NfD7XwA/pH64qch743N/KofWAA7KyB0Euah6JRPJjSZc9Mj+Xa8aX03ISAGgUJjepgc36QWpet+rfd9tVBnOvBMDvJkQf3/yVHxuR4kGmfrRsGEegbO1W97yx2HRxWsUjp1oYM63TAGNqmqZ0OVSa7bjH88h1SVevkSiSlmFz74TGPyU2uuMr19rgSt6SvTXs4ziadH2GnodEo1Ff3s0EUiTCpPnKKxcp8yP1djc5RqXu1GsxN9vNigs/FGYO3XIXIlxyhESnA06y321nrlIMH+IQgvvl3Zzh16bo2e6OXBq6Z9bYJizcdY+tDtAOSzjnKkO1EvxMDLIUS8ZmkGylHfg+RfdD4lnIE5syoIt2GOfKOwoRPvRV/UqjMzVqs/tetLhidCftqraiVALot61Yqm+xr9VKaSuxRJ6MeZO8M/dSovl4/NObx2fdktNnR/MQNzKFRbsRi3DCaL93AJoZubdbnOG95iBjb9FB/HJRwCvXSZRp0o07aTfuJrACbkfCB5DeemznBl603eW3xtpLl1fGCIg9eg66X4Dx2gFBBUb404Czu+kgXD/e1IzSeb0D/CWPO1zhfe+gGnjGWTyRHqpDPO0tJpL90WaOffTS3xr9cFl+LV6Ocm6hh0NZPfQy/DLhP4wEgLTizAZXzTl/ssZGb0LuefGoGHGXWubg066o3pEi01iFFIbC3NS3SlHJI7nv/fIit4tEa579r3xw+fI8KhJYgrlOeGvbXCRAAAQAElEQVT9J0cm3GyDTIlWdZVvJd9qOQe3ufgi7cXM9npZflzT4ApHvBid7bhhcigU1zMmyghv0kxh/OlSa4cJdcMGHppp4Enb54TG25doxkfht3uJvQ9VSmGmFj9zmUuh/tY/hJZrCcz5Dtj8u/sz/l1rq6mlL1tCwa9P39Ja0REvROW7t50qQN+MrndYSMBTWwJt6kWJc7ZJ2SZNVAY/rSWbSqBvK5gyTGJUryj0zFzkjetftlEZ437/X62PijZYzi9wBun1QbSXu7p3dLZtwZ74BOaM20qn6vrdRkMrtbzHK+s5vhlAcy/GY0H9KQTKx9LxMUPlLIyHpC4lU0cqnpIyZO5iLR7OlNfNcunEfL/AmZNfvjOPspRPvom+JM68VKTHniDMGYcfrc2/A1e+7N6GCqUEPrxCYs4YGXgexKRZBu7MlfeUSANG9YzK+GjaMOw595fJr12FlTfhfYX7PwJKFQfu6w+8PSz64nN2ds6T7u18Xs+I/84BzmwrUCLN/SV6bYnC5fo+NU8FPTEHaf1TdX8cQ/NXKyzQoVQx4JkLBDgjJ/0fNgH9H4k69+x+CHDLKfFtp2MNKqLu1f3w0sUSQsTnkwaVUkOnMuYf6PSCM0h/rGhu1fIC52mteTQFc8n84Ez3vrdw8nOd/GlwqX5tEu955198it5l5e7dX3rnFixHFqy4d2mV8/svXrm6Cza65fFMinIl3XJisGla+xdWOUCV/XH3KJz9hAL9kcWohI9t+E2BX2GvEhnlhFY26DvyQsiF00vG1FxzjVxQ3oVfwYqa+eUBXCKPfWLg9lwpR4k04PFzBC7uJk3NLu0cuT9zfzHrmTov+nK9qLWzvZtJNK4u8NxgaS71aNZAkxz7LSo9/id/xo+CwqBcBYY939D5t79rYKSeMVcsRaYj99ouBG6r6ny7gTMnKZyhA5n2H1oZwxn5yGPsrQSOaQJYSid7jtSM7njdD05BvoVz85sKZJ5W2ut6R9/kXlcaLnNsWPR4dvAmj5m2hZPMdfNOhanz/UvQNs/Nq0rZkrKMV0k9HnZG9QJeGAWDJ9eLSdTl57a5eDGlFR2JxEoVo7wqEW6H0POKpeGzw51xPpABWni8Wn+JAYHs51VSqvudWuvKF63L7QpXvRx9ieHxd4b+krUKWJqz6Lg3ka8tdU/OMXDLW6QAPQsCJp8vYJ1relhNgRkjJUb3AmpUUBj8tKGVHP7tjVIqnF89YLWAny+/Qp30WB1kBnWqRNOc+UZj0d+P9FJ4/XaBDg3gqpj431sKk2ZR+wfz/NsOIc4kjlLO/y/FBbe+bej+VOZOC4vSJ9/o2ejDBsiILz1K4sEBAsUi0f7mOOFs3MINc31zmRHIOEjnzDZAa5ucjrCgUK6kwHAtW7Tw/skRuDdvt5AFzf/12bnR+/ajcEZr4Zmtc8y304mgvxFa5+yEpi5daEwPg2uU9mpm1bLY4pXnNE1ww3vi0+DOHv+ewpotultzCazdqpeRIWy6uI+SOw0632aYLxqXXF/8IvD2cv867zgtuCt374F+iQzNFPxp5TbZvDw7z8C46WbUNFd59kKBtvVi98Wc9LICp2vGy1kIl7oDtWLktncM8MVl/t4MQgjT6p6yvKk2xdOaLUordAAhFA6ribi/p3NfHje7M4omKMPkjOVyrSCgSQfPJLEC03HEUpCgcmLAowrcWUNTqocGAstuEFoJEyX+9QaBaUuj8WObCj3bFlpmxWcqzNn4da9HmWIUw/uX8rDRAR9Ulq5eUWGMltExnmwY0A6om862RUu+uFBh3fZYOgpN/peHFHHmGFSS3om8cMqVMtZ55On5vEdOCsAyBTRcSVQsl2iWYiEe2VDkWnJZkNiVpgrt6sfSbrEtOwWmaGbglmfB3rd5e+CL9sQ5QJ/m/rf7hv7qcqvTTW8C23fFM5a7ZvgzkbrpAtf3sWr3vnKP5sgXwg26KXo5fP3rUVrlSgLPXijRsk58u6K5Wr6nl37c+xlNCzyidV8Usm/Uy/MobO/93n6aMM1q2Pa+D+XopaGBPvca4AflllMkKBKwWkNm+Mk3CunlgGMOs6Cx6+NzonE+j+HPafnZo/HBYphRrIL/ctP8SfcrLb+LzizfHCrR8zCp5bYC1/SWIANiLTTF4ZXh8CyJaVrj3jDXhGnKPOC2t/2fMQ2GL3kWCHKrTvrj+4p8u4HnDHt0r9iY4WzvnhD++VivX3h5EfKM073wqPThB9krv2kNscM9T5TBDXVLuucVHOrPBQpAP7InUs2reO9m8D3s44IAh52k+9gn3oOKA4oaQ+Ix9NQvU9fG3re66EeFUx80wJeKTIll7KFmJSC7h4CMjR24/Z3TQeZp9tzyLRjtth74iDIsC5J4XbtV4bpcEwhuP5s6WKBFbfcGvLLYALW4pMKdCy9dLPQyEVqOCfScaOCTQlLkUIZF84yD0llzLDSsKjBzlMSVxwLVKgiUKgFTQUGFjVNZxS2Gw44W+N/J0P0rYkRyY90PEVobSo2oe+jSKBcxRZeZXyvwhDuSo3yRZ6QwzsAlrRYvMopKpc1L3k/NSgKvXir1Ej06Ltd4rmWiRShu+c5Vsh3Nt365p5fG+1ba7crdEPd8YJj7k92u1DKXTIu2i+VfXqwKfK7041rkQlp+Icjl1bGHwXNGV2XHnlxhiF8N+cvz5gRx9JJP6C/M4W6lpFC/dmgg67vlWbCj9EC3T8ktuP26Ri9dpy93ZxwU9Ot68tCLeXArzjIunZIDzoiWrs1Dz4vQaShnbx9dIcxZohCJL2Uecm5kYj8B7qbITXpexs8AaG/mhcC9qelaScI2PKeVALR9c8Mlcxw7LTqg0/VsadJZwpwNvq01picdTqNUoRU5wC1vGSk3ZO7ZRGqGJFE/M3EY8YCaIV2l1t5KPHGOBHeW1HGxPeTMddjRiYbY1r1S3MF8r0CHFRZufq/b/lSmKRDlwMceJsA+Jy1uueMymnHKKmnw++sOYYoZ3DSSNJ958jyJqRcCt+vZGcu5hbHTDPDD55Znh1EJcJVtlmbPs+K0fxzzitIMD77hrz2xsauUwIn3GaDMkrJri1bY67srFNwmB/byHRooNK4Wq9OeZ8VPaim06geu8ruIlIdaeKm+Jo7WFNWghLvr53b1xaowVZyrZ01BePd7CGU1w8URdWKlZ65SsC/zftmmZ1Fa7tL9LgPvrEh8MPSiMuxo4OOrJDh7KxZJxIlRj49Vryhwf/9w+Pzaz/NwQ1ReC6EXXCOx6LoIqP2MryWa4sxj+HNKK2ii9TXMBEoWj+aV0+Un9IuAphJkwo99AjwfoGmLlvzv/HK5/YSesXTR2tk739P9swB6BifwmGbS/GhSLjn4aQXumOEWQTo54IflxSECXsu2NP2B5cysooc2ng4AuDUtqJfLllB4UreDyj0/3KtfjX7w/HDc8rjMpcyy250GaFxMpu6G5wa7N4Rj0/M6BrOWMsVl6ZqV1GK3OpRCKzd4KmDBLctnLfo17OZW9Krj4FgMuWEBlAeUL+meZ0G/0QJlr9ne5d1jt0aN74DHFCjc5+DtfIehZYLQGjjdSouYvkakwlntgdma2XFmUbp4fL5GCfXP2cc1vUOh4sKn8m9OQ799n/8Uq2fu9zBlZ19viL0INJV4L1ua2t3TCm0YxdpwoMQ4W6H89ubpURs2ii8Gd4m2nmKEG06MPnuOnb4PKXz6nTC3B745VODQGrGxFS0R7pfL0LDedx4cKFHPsVfVWcuIF3Kwar0Tmlya8nEyzt73KlDME1Sacu+gOg/KALqFOAqCdV3cVXjJ949kfmGE/D29gJZkjqjZXKPU0yHuv1QxY0nTGvKwOKBHggyH8gyP7Dywl8C4Y0OBgZqBWYjfa/kJhfvc36r09N6CR69KL18BLmNvPFF6fsWjuK6/CcDzO0mTcSdkOADcIjTo8eQZ35K1Rp75AY1WX71UmHZwXPafrJcu9qVzDT37HNxF6mVZ9EV2NOE/laTN5ZmTDFwyJbpE4yE1H4wUGNpdoLhtRj+wXfzz48zrlUskaPSbnw7jbIrL0DBlb9QMl+PXD5f+CLmDJaK14ae3VrijL7QoAXj0bIEpenn98iXAW8OAD/W9fTZGYPH1Al/eLDBjBNDORbhERkYxz6Va3LNzd+yj6WxDGGcIQ7o6S3mnz2wr+SnWb2c8joA42s8CJB47uZRMDj0ctlLyNDfM8zuKzW5wL9gFnQWCZnvrtgs8PMtdtnft8SJvC5BXHRz00y8XuOdMidqVU9sdd/aVgfWzXckyPipqsp8HyLwpv3zoLGkqOaZrOR4ZPeU32c8rXK9lR4byHsCs+78UnplroPc9wPzV0AoWZdrYPaVlcF7PnbsrDq0R7SHO+PJr4zZVa+E5m4pS8v8d0BZ6tSF8kWimQwezQgjk6A/428uBHocK0BCcip/29SWO0BrlQ6pHZ4tUJlUqLVAyjR9GyhwlJp6hl+haBuys6NsNQJniTmg0/cxcBR7fEE25/zbQIpbTWoZ/j/Sdlm1XH0tcqJXMLF3sWBd4gUHhWxe+KgEhzktAV+rPS44SbRLgPoDyWi51cYivBpd5FEI7SfHLPVUrAQa0Y078y9/2IGDqYICDPpnlCoXeLy82cPGzBo6ZkKPV9vF0WZM9cJlSvaI/DvHJ+Ohxd8HqYNyXFsYGX3YPwBIY835v0jPVp3TvUxj/ssYL8n7Buq2gNINk/fR2YsH+TdflP8fu5tGzJWhjZ0Hoposb/g+7PgdchhJOWe4T54g8xQZlYO+tdP/AEt8tUGZ47WtuOYmwlnUUbtCzvMScGIS7kS7QIhEyYUKFnulxjHE7I9Nhw4ktBGZqBd3ZHaC15rExd9NJQr++IoEMP7QTZwTf+4geiWUTiDkA1/RWtRygaFIiJaefRYnFflPO9NKH1+oiIGrEqojGDqulFpYsJitGU+F/z+4oQANRvxK0dZo4I/bg7LgULI87SWLOaH7hNKPTU/95VwtzW1S7g6Qd1TNOd0KcTdLmrNU4A/QAzH2k320UuPgZpWWD7nWTIAXej+sXjDMypv0CXY2f87iBIBOTY5oI1KoUpfTwLIWPHEbXPJx8xgiJd7UsL+zLsH2XlmfqurnV6tiJSmsXgwd4tAXhfvcWFh0XcJeDZbpBBw3WB/Hy7sjbPXHLW9FnpjSjf32pwlFaoH/r20ozACCjbKy1NFmZNEiC8l5CR+gZ9Not0bJM+4WJ7xugzNAPx8qjU9BHteIiohUhFsztetnU+C1ro3oKBC2F3egQRm3z2D4S0y+XaK7ZTs8mgNc78bhWhNFWkuW8QrNaKu5D4oXnhDepETmsZDG1wgnX6ZPSh9eprq8p/ZcppaaJSSH1PENHHP9Du8ukGR5JcEp++dGCUd9ARwSrfvUejDW0XItaNQYOZD9i3MlAV0E3TzfQ9c4c9NRM4I53obV4wlxS2ssu0EulCR4M18JrXJ3LZyvlf+XS9OwnoLXK3vdSVnPedAAAEABJREFUXd/LO8OF6Y2EA5FffraV2kiLeuUyAlkuJiJWvv26x1C46qWojz4LTqWIFT9Qrg/ONNDmZoVhzyHPfONOrZWlW3nuIOAy9pwO0bHE+xuvZy597lMY8QJ3KQjQG8hHV0jQZMp+zzSruTF3BsYP7LKfvZ+NVe6mNw3c96GV8r+WLwkti5Pw0vhapcnI6RjUStP+dEhXaSXzfeX4pEz4llOjfeMkxB0qj3xsOMEJabsRdEJmAOCEFsLVslFIdU5A0aSzC95jtirLXVqzip4bJ0xJtfp/c49DZXMbalJRbk/ilzCo0P80kwrC8crnDIGaqeHPGTj8RgMDHgXonj3IHon0nl/gP9sjzjFNpBY0uw8q5jvDpVrQTqeUTriV5lf6/gESt2vpKd1Ssa0n3s9lb/DgtGjwSoZ3ma6LdmM0YD0ii1Do2Wv0av/l4KfdGs/AsMP3hziZ/l2awfF+zu8EU5h/bFOlm6bwtdbyz/1OR/X/ZUcJ0NhbR/HARwAdIFDb+NxFAvf2l0gv5/6M+reVuFMrC649Huh5mDsOaTJkP5+DMN5HiFuxlDK3sdGgm2mvQMcH93wQy+XRj+NzXfDHoPmPCSFMcx03Cne+q0Dxi1ueBevYUM8StSzRSid7HdxZ1HcvIwa5w/MPTSnTK1Ui7Vy3phyUiR/c4MnArjw2uKk0K6BNXli6P29T5sEp/R+NMjruyHhjGWDJS5x0NPOGFrqiVDG+TLHckXqJIfWgiUHcY72bidA2fKRwzavQs4X4ugi3h76tJLhV6tAaMM0Xet+jsCCEXJA0yCAuetowz/PgvU0aJPKcBLjdzg3TFPrrj8HR4xVajcsx5Zp0hsA9pKRXGMHQy0/KGMlsGWiMy5m4vS7aYJLpE/aElsFxu1h7/QI+OCCCN/XSjeeMtKzLXJjbyUYcE2NaRx2itBhAJOxn5pJ49MsG7rfZpJ2qBfTndZSg7DRKLf6Xcq9BWkQw7XMRn+GRotz1uSESnGnBA4fg7zcaGP58/MeMTme5HOczJE5hBZqxvLAwmPqY44Jx/DAOyhC19Rh00eKicfrIrJZ+ZZPNC+YkSVFUrkzv6MYq/oklRTOKfJxmGNxiFU15/974hgEuZdwwKL9ZvEar99+NKiE6365Au6l533Nm4z5QOYvijGF8P4ElYyUGtBWafgyXLuP9PEk428H7eGigE+qdnvi+wphX/LuP9lyvXSpwXkeYDPv7Tf6MkrXxZSHDm7mK96IwQWvzKAv882/mwpRtRWOx30++jdHlNj/KNekM4ZgJwBUvGuBLH8MOFyNTIzPb6WImQXdglLVRxkhmy3DKAwqdbjfAWblVw7e5rwqF+m3rCwtsXpvUEOZuELtss79+ho2qRu+Fz377nyaq+UOGSuVD97sUXlwEXzGDWSD3Z/12Ze4xpklULsj3Qpf/VLIdXDW+vc5CVFycPzlmgG7P5x7ffg8rkEHb4amM0319EL3TNEs6RGuKg/CC8utlIHc+Ho8pDTEgHlKwVMqYXuawWs0A4bp1pEFVWR4p+LtGLy2CyKzdKkAPK254f+0BrtYM5OFZAJUQbjgWjPKdx/WsgYyOMwYeXxfR45OyGguH15tPlnpFrzOYCBm4gX3yeQCXk2GK8Et70v054IzGC5+axmuPl/jhNokz20gvNBNO2V+M4QHjtMbuhFxnDBbT472ayLk/nG3tyHXCcKOWb70/AnhggDB9yBHl1SXA5Vo0wHgygbscyMzGvRllQlZZOgylUTCfZ5rUM8u6CtGltwK3gnFWPkHL5IhviT6UEqaxN2Vf5zxhmEyINnkMA/Rsftrn0TqoLLi6d/SZ/fm3wF16+UY6lOP2uluZyoff/wJ4FsWjZ0fxmO8V5uuZdZ/7DPN0Ni8cO7y61ua/fLEEnWvY4c44P9LsU/aBlUf5nxXnldsnj7/XwPIQckbiJxPYv7T79CtDBd2oY4P7yI+GldcgA7uteNxVYP9keoaM9IhrqC2RUQ4pYXq0PeKsy0baNcqlDo13nZmligk8qjVkzoFDvBp6IPJqhTIlYFqV25cynHXFPJnAVCS0cbh5ssoHXTs3knj6AgnOJINwmb/8Zy1oD2k1T3yvYDI8rXGOzvBgLtX35EDLbKIMYdff0WskEk+BM2QL0roezP22vZoKPHyWxNW9ozl0lDprlf+sNIoZ+7WUAvYlOesaqWeOhmZiR+vP6MLrJF4cEgEPRaJGum6uqyR6Z+bLTgUFl6mkSn93lH3x/BDa41mBiotsrXklMyUe+//IBtF75YzuwqcMU477nZ41cizQT97k8yRqaKUR8b3CY5+QuSpw5uuFY4ez7a9ohue2D9mOx/g9HyjMNGfiTAG9mwEfXCFALWkUEv3lUrfvQwase4tCC/bLXT3s3yAqFB1keMhBg8o682tXcULy0pnpI1O3xPWfEuTVGRyRAnpx5Y63Zw9S8ynQ5K/sGa7JV72skV3+syoL3K9nKIDCQRnA0O4wZTpzRkfQ/ZBYAc6uXlsafSkIpWZ4ss2PX3HNFMYcV7DbalVXgEscCrNZR1CgRxJazXM7XRCuVz7tC2fl7n6uWl6ZS/Ub3wTa3WLoGY6hl0rRkmmObl6yJgrnPt5GVaNx6/eCTlQARFMf5tKOpkL85nbxP5rxWthPmAcECbBf7jlTaMVDrJ8b6eXgE/rDxaUs8SfNjjLZB7RShzsB2mqGbIVeTQHuoaadpuXo83GTNksC1/fhTUYbQC81lNUO15/uD7UG127DF8WO/6VH7UFafmc5d43PdU81qaFAl/HVKsTuxx0TmKU/Hvd+GMulzPYurbigCdSLmmme2CLabgvjnxyBkS8qjJ1mgEt0C57f61UvRfvVrzyX6EO6Bt+LHw17XoWSsAka7DmAyMGRSNEfn3qKSKG5F6Etf8Jrf51XEU84/dad68leY8W47ezO99wfXMeGArOulPhgpER2D5m3zJig5XbWUomUrn5FmS54uMwY87LSGs3YA76oK1CzUixNfHu49jUDdABqh7nFm9US5gyGSx63fDcYt9Mdd4+htZLxA98N1w6j7IyzMcK6HAx8Mlri9csETj4C4CE+nCH/uDl6T9FfYkYDZ1+MtdYzW+mi5aimGSjznV6RCfMLMncE5tge1RItd2UZ7t/k7Jxxe+AYOPawKIQzO8onS6QJUNnF4yKtQEY47Gipl+8S1hKM2lqeScHSZKB8/oz30pre9/V44J5t0iLMK/BjeMwEZTpF9cJxwttr3STPyqhSxtmz8ZgcazwqcsGPMTgVHo/pZbbVruJa9jDxjAioSebHO4YJ0JnBwEeVnnkmNzbsNKic4srCDnOLX6EnINwu6paXH9im3+DZOXrItc4PTbcyuUPOLStZmMr0KqFnCZ4c3KuMH/wKrS3lLMUPh3mTZil4nZ7GGR9x7KFcSb1cGyRNl+yE09PxkGcMcHawzGbNT3MBvy/cQzMN0wX49a8Dd3kwXtK3wkEZAq9dIvWS0YIEX7lX8gQty6F2kS99cAmA9omczfTUDIOa2jQp9FJJYPzpEnPHSHNWRPkZaUVsI4OCcosZtsw1aSGOPXAWyrS9HNNBQb+/Jgq3U5kR/bPpd/2j/9PL6R+Pf8uIduduEXe+xOtL6U4r8YW3GAbFCSX0LN0iO7S7Lq/loA9oTW/QUpYnuQ3W2u6RLyjzEG2LRtCVM87J5wmUKSF8UcnwrnhJYcAjBi7szOciTPHDY3pm6zY7pCb56fMlypaIv18u6Snn4z5j3wpdMqkppk2qS1YcqJWWsTp9I8Yh5CPx+S/K9mTiCeg7PCgekv+UbWjnn0i0pCgTvSb+6lmC580kYgdD+PXnvlZvzGgOZUIcoNFUuN/G1QRu0IJ6C5t2es4lzFW9pB6M7gOYXl/ufM8qDTw4E8h+PidwyUGG9PLFwjSJiZX2j3FJM2GGwikPGKHO3iBzXTkugocGygSzi3Qtl+GsqGSxxDqtmRdzWumZHq/2QA3jht+ikKwq0WvYX4tJGoYe1rmFypWMRuxa1Sgk9ssPj5XasSsam7lKmYbGx2vZ58/bYvQo97sv1/Skb2sBIUS0QBK/nN11H69Ad/xJFAM16g/opTcVTX7llFIgw3ttCbByncCgxwxTSfTZ1RL0+uJVlquWaZdxj208BpU99ACdrJzv8ucAfuzjqcWnqIC7q28KWUcu+e82yOq50YSLgKidAMwnIPUtd2nIdxtE3fyYM7iQygPxYfdtlZf0jNAw9Z4PbGsnT8xYBr9gJx0ee2liOdADEKAm1w6z4nO+1S+dFpZbaetKuy1qE61llQV3XmlWMfVCCRrXOvP80jzDg2Ydd7ybP7MRO21rmRnRs0ALvjhXnsetWM1qWdDYdcaXepGllQ6EtEvye+y2vK2XLkgKS1wcu5oZ+ue3XEanoyhTPPqsmuq2cSbH82WPGW+Y2tuj7soBX34uu2nyNEqvElgmbFi9SeG8yQb48aRGN2y5EmkwjdGpUQ9TZup8pRURMUwyPo6ZtBBvaD29Unj9UgE67oxRAPhRpJyPFgdh5HwcP/SybKfhFh+p+zAr5G4ft/JusM2/G+v+/BvN3PIIU1Aun2PmJB9CdGlIokpt8cLUQ7LEe1+opDyseNGyw6/uLZBu2ydpz7PHqc2jzZcdFhS/9VRpumpy4t18shMSTVPRccmzBvYY0Rc2Co390nC6n9aw0WFBDOoeu6a3NL1g8MVxx3CH0hSn250F0+KV0Ut8Uq9Zib/RsHStfoI62kzLHznL1tG8f+7SuP2d6EeFOx3aO+zk8hB15MVFRsKe3rTcNYCRyzQ1mmkqwivlsnShxLgz0L6OMCkU+NIznl5W4IlzJbhX+689AvNXA+u2CdOFP5/bC0OE1pa7Px+Wt4cduxRueMMAZ3ezklTO1K4MvD5UaG1ruLpYLz0xU67IuBUWrxE490kjT7Nuwd2u5fRze0ovdd0+mNwd0l8vmf0Y38IfFTh+3GjbYfxwnK8VV3ZYKuIPz8ZyPzp6cr7NLz+ZvJQxPQWxwq/i298zUtZoqx7OjOj+x0r7XYc/j6SMZ0towThnDXaaFPgf6uJA8he9lDpLL0coX7LwS6QBT58vQM8ZFmzFLwJ9H1IgvgXzup7YQmCafnEaZHphuMM3/S5MLd7xWt7HrUvuWPAE0/bu6t7xs9nVuZ8r7obgWSLUHtMJ54dfKZymGTlNJkiQOx28lnG08xv9MvRSX+kPgyK6GWguw0jxtBjstFYCZGbQf2O0MsnZX3TI8PrnUfw+Wn1mZ8Rt9PJ7jlbQ0J/cG7r/Vo4ToAKhf1uJNNvsFR5/XJHQ2wqNop/+zAPJB0x5KesNMjp2kmDb6N7MyfgW/Rie8UnNGa7RH8wJWiFnaautehpVE7DP3mH727lbJez4sGXHRe84LS6ZooQytNLPc2kbrUR8E70W/DdlTA9CzfVrzsYdsuG7K4yv/XDyk3f0oQKnaO1jUFn6ARulhcRBeFb+S1yJ2lEAABAASURBVHpWYtdgUQFwlYsRJr2TnPukAj3QWmX1Yg9kHlyCP6uXqz2bxHJ+2ASc8qARivFRuzhjhDTlQjEK4WLUUg5+WuE4reVNxh1S67oCNEGx13JuB4HDakaZDI1hqT2+ZIoyDYEtBQf9+J3V3ns4WbOMP/8WsGZprGPV+ijd9DJMRUMtrRWnfJGpn/Wn8sT7Ddz6dvTgGyqW6JBB6ZkhZ5aUrxLPHsh4j8iSus3C80WH448aUyqgOt7KuhS2/Rl+lkZS5UpCK4SEKS/lx5iwZEMQ4wsSj1j1nXS4AM1aaFJCWGPNTq7v430/N76hsH67dz5pMFBbXN/lPBTmFSS8vhSf/r1H6s+XDxWFfHyC3Ol5j1J3fE+oIVSg17Ds542U1WdvyA0nijxXS3a4M/6Onos+kmvX5cyzp3fopc3t70RfRgt+STdhaj+tNK+79ygMfsoADVqZtsJNJ4k8Tx0l9IzxwYEC/VpbuQBnYxdoOREVADGod4xyoWcvEKbjS28s9xxqeS9+BjhmQv6XvZd0k3hjaARf3CTBdtD2rX19gPZwPQ6Nzmjpx8+9BVHowXqmYZnlUMZE+efYaYbpuYYYXRzuxYdqrSpPUyujNZM0/KUvO4opZqyE6R6K/fnWMKn7JPhlJX2vsPl3ZTLUI28xcKdWQNFrjReuF7yd7ot3hgucfES4tmz5Q+GJOVEmfu+HBj7+xoDF0CzGx90g9voW6RnfEP0Rs/DseW7x5rUE6DKqTT1g0lnsM/e20TfkK4vdKMTDaMhNbXE8NDWp614zKgZRypH/vBmEEzZfhkUMwtsy/qeFSinXvXNW2d05suGlz+6ZZaVTdeXJW9wbG4bebe/AHGR+uHe9p8AXzcKpUVGBXpytNK/6XrWm0AAHI9NW4MtIV+NWmlchBCgjvLAzU9Hw9QZhuiwnnSjE//fIBgLcjeA0SvUvFcslY6ZQu/PtBp6Zmz+FB5eRbAdnYVP0DJb2cPQ1xxltrCb3GJded54mTYb13UaBQY8r3Q6Yf4fomciFnRNfyiFdJT4bI8Ftb2S0DDeeCHCHBvuzRsBuCZO4xw+9D1/9qoE2/4se6s0ZqB01TLyEFmGM7QNQ+RSmLeu2K1w6xUDbmw3Qzx6Z+N3vA+c8AbT/n4FpuUt2Mr6HB4k82abVFu4ySYbx0bU9l/bcsWLRsF+5G4a+Ie0wt3h5PYudcHrKWEVcFddNM2b98bdoGgd0JPQ7smTL+HVJSlYdRGzJlN6JXnHcZaPtGn3nC9l1zrc5+nvtmp1vYGu9LLu4W7jidKXk5xmkRoV4OpSTlNAzNjv0pukK76xIfFGnL+fWofhZolWOxyC2qG2lABrW2u3/YjnusfJaWE2j1MfPEUgv544TBOVycew0oI1+8WhA7WXHGEQnP/lkmNztwBkcd7/w8CeeHDf9cgEvo91y+p7Pai9ARsvAJTT7IT/1swwdjNKrzlF3KTy/gJD8hdZ1Fd7LFji7Q7hXaJFWFPTRctZ39GrD0C+Ks9YduwTotMFy20U/kn6ML6xtprMeK/3rDoULJ7uPUwvHuv7vlMRVjpVXkOvXv+b8MGUu2gXR0N31cBBOMvnhnlhIipsnrJ2kufK3QeiDHkeNrzcYPgYJQRTc80f1lKD8wj03BqXC4YKnFCiPi0FjsYv1cu6YXDkclwe9msYzN+63fOrTGL49Rr9j5+vBxGWLHW7F2zewYtHr57ma0Wgq3C93KswYIeCmqQtHAVqpI0wD6uPvBaj0eHiWgTUhPQKHrcMNr5aW13EG9+jZErS1pNcZIeL7161cQWBUfJDBN7/BMB2M2mWKydKlfeD/TgFeGBIJ7aT1nRUK1J4GyQnv6CtBW0qrTRbja6UZrAXjlTO+Yc/RUiAc02IZZxj8tJG35dCZZ0+frOXlvZul/vls3Kk2HX+v0HNllLTXlxBX6gfNVx5NgBcAkFKmZ7ZDGcPMq++PqNT7blX8m18N22Yb3wKhM7lR3Kl1dStMo+MLtVzNLY8wHpxycFWFm7R8jmkrvKVnck5jZW4An3IhULFUbBBy2XKZXsrYv8iGUrB7viXNSD6fAL3scgb62RiBM9uQUv4DlR60wu92p0JvrfigXeM8j/N481/L3ivJHSRvLDMw6iUDLTSjo+Jj6nwktYvC2dpKpRWuOx6Yd3VE93f4h0atNT0z202ZOEuk1QG3lnHJXq4kcIlepbjZf5LxPXmuTDhg6h29ysgv46OjXNp2Ou/RmT4oAxjnGP95OAWIbP3D2N7ltpxtOQayAskIcWUgTpII4Z9eSMKb7v5ZqwDUS0HohhLVet2tyn/6nZHSpS73Zd59RrjbWrxGgLsl3NpK+dUrl8q8fbnEISPIdjhzpNeMx/WgbF9fYupF0pRZIffvbb2UOVvLrn7aamDpWgP05EEGk5ttXlrrZbkZyecPtyf97xSJj67QgvTD80nEVozGqZQ19X8EOORaA3TJRCZI90k2tP0qSibH2dR1rxumwqbNzQp0PUUB/W9/Fayp/JCN6qlFEaMlzu0okyY26kUjbofD6F7RWeIZbaLKLi7ZPxolMNLm2NRZCbevpYrxcZXyxjJnDYlpThyoAEnl3lrWsnpTzs/tblHbd++RjZj2Cwpq+sYJa17xw8lPXvJPMUQtyhDD9KRmexCqgqh81mNocvIDOR//ul1tDMIPm08zlkuPCoc97XOBu983XJHtD5xf7IueBuxfbG4Ef+o8kSeP4ha2Y5rELwXo0qjLHcCpDyLOTRArpPazcfV4fMLzE8jsx/eTeH8EQNu1/NBwluF2JLafTPDMScpkgpSHsb9oA7h2q3IW2StpfkDoSv86zeS6jze0fFJpBYHClHlI0KTnt0E0h+EsjE4ZKO6wj4WwNKmhpm2mhU9HGYO7SCuZd6U8Uwj/cWAxPnpqySuoI9aMj6sInfT95wFSzlWKVwFuM0u1ecr103I+OeouVNyTI+p61WvBtZhsZ84/ORdb6VReE59ACqhvvnvNegM5+vuo/ghDbtlPovORt6nMHnflzJ06z5i/8y9jZ5hyfjgjj5Ho2NAPI5ZHFz5U3ccgibFxbxpxyyN+CWl87NSMNayaWNYNQqv9u88UeVncHE5btKP1S3zQaAMMdMlObR8ZTB5iQIQD9Z4zpSlk790sADnJbDJBysPYX4OfVuh6hwKPTOz7UI45Y54ww9ByQkMraAxQM/jDJqXlRuEZI88pWac1nKt+VVorrkBRAg2Fx06LzpKtvuEHhK70yeRWb0ryJgLQObMboWddH18lTeUJmU1AEc/sWV/H7p1b+PJzPKKdONtCH4x0M2WHk/G9uiRWlz3Piq/4RWHoVPePu4VjXelBKMi1loUbdF2zxfh5+PPG7PpjctY9O1d0EkKUDSrDfCHVaVvv+8Xm5oPQ1IRCYXps2paJPy8wDON4/Sh+BwEhwvebRftrX0fbZjegbPOxOSv1cnD2Ax8an360Si3/ZZvxawgScSj39heoWSkO5Jmg6v69L7wHxX0DYnIV7hZ4+CwJt90Z9k3ylIk47a04+OkIlVb7NCmgUSxlM73vAWiLRuNlq5E0m3lnBUAGQ1kbd0RYeUHXhlUF7usfnfmd6PC9FlQ2mXyaelBMwBnz/R8B174GUIZ28v0KR49X5iyMDJyBTLzrHTmm3PCMSYZpON3pdgNUMDC/+Q0KHW9TOO5uBfoNHDpV4da3o6Yt9Hdn75tk2hgGl7N2apXnjJG47ChhnqURppwfzjcbYrmZ5QEyrRgkXIymNWRYFnal0gLPXCBgn/FR2XCqj40gVynnPmGYvhMtOl5X2l9eFeI8Gq/yX28w1jw3P2dBv0k5Hze+Juf7bnei1hufo4tSooZXGSdcz1pP2Dj+p/ec8FSlC43psYGb7/551h6V00FBrWM6mfD7btFED/Qu499Hhwsmq2adbke1elfl7Gx+Q87MMyflPPvAR3ve/XaDWuNHk8J+mndwVuaHZ+Vd/CzAJYmVtl9J69kLJU5oDvM8iY4NY7M0O94v22KpddsUnjxX4PXLBMadDHOXxrIbJOh+nlb79ARy6oMKb4aQsVDWdtqDRigffbEWAJz50cyFMj+a9FSroD9DdoS9GCcTX7tVgPeyYDXMg4zYX8ls5E91c1vWUeaz4TJ2SFcZem9umHbssX1Dd/wJKBWu7//OUXh1iYF+D+eApjXUrNvrI+N7+gJpMj4yvLv6CugZlB0lL06GR80x+z4P6BGhfPp+08GuB0IumAbSM1bmfD70OWN2r7tzPj38xj3LGozJ+ZUfrl4TUeea10SbhatF579zRP3cIqEuunu2K2V03jxx7ZuhCuQTqVCZHtu0beLPK3b983cL/cjfYLogQT/Ysr//JbrNXy0Gjp8hj+05UdVpPnbPirtmqE/0kth1Kc2tXJyVha2XZ0e4uZpneTpvvFsvHU9o7t1t63fEBvZfewS26IU6N+oPaCtB0xdLNsQ9ngMfNcBN9aRtBc4EyViHdofpjt7aSsR8Qwlc/zrgZQ5DHK9AmR9Nej4bEzF3VfRtBf2Cx9rqVe7fCOcMPLuHwGytF3zp4gj4bKi4SvW9VtQaX4smZ8QrfrFS/ld+FK54EVj4ozAR57ucJUjGR6/bqWJ4nOlO1go50jUrdfl59wvj89735Hx26LXqryHPiBZvLUOXr38VHXbsks312KzmUiQ8SKkFQqmWmyb+9En4QvnD9H5780fPtdTO+37dtHHC2hNh4FTN/D50Rcon8PfdsumDH6lOzW5AZMCjOR//8behv6nxxDgru6NvPMwrxcOcz30CWLkufwzhx9zN+Xn0o+M2L2lFbpimwFlPNB395dJi9pUSZKz06Hu/XlLPu1riTt324rneSIhJc5gZK23TCAKTCDQSvv00iS9uiuA+LQI4JtcmMQkSBxxqRjmFCzrBnHXTY/bQ7gJOeWyqb6ppjfiHT4/EYergFrIaFWPjj7M0ikGcZcuVFJ4zPL0KMm0DWdZZzpkukQbQAiHLxV3Utj/xG2d0Da/O+fmSZ9Hiq/XiSF2+pA4p+Vd6FWgoXLFx4tq2G+9e68LeU1JNHJG9wvSsGjfeveZVzfyO/vOf3ZmGMs7UDPBRfdPfW/kFvJac+73o3Gys+u0d/UVy0jqtpdSCaSfUPf37X8BZjxpJu2On2ygaPltUhVCoWNpKxa6ffqfw8uJYmjHK+agYqeHYWhWRAqfqtj95HsBZIHEZbnpTIUePFsYLEno3E+bhPp/fIMwN88c1BcqnbEgXpGUFL8tjHi/sDEy9EJh/TQRX95amp+iCUw5HoWvjeDzKPfns46HuqYyyIi7j7z1xSd8Edxv11+M3DMMjoXv7A2S0jNvDiOeNmUfcZIi39IwuxxC17HkFiSul9OJd3QGhjtk0YW3NzRPXjC8IvWTL7lWmZzWOM7/NE396fuOEtYP1TTf4p9hvFZWx53DDwPEGVLah1J1QeE2v8b+yyoS9KiWqXaq/SJc8s+cQv5DbAAAQAElEQVRjzVTjpkO0iaIMJAyt7bsE6LabAygMPnEodObVClxSch+llbaud+UeOWileXbuxH5SM7X4gW7l80o7wJMOj+Wv2y4wN1WfC11BeT1rOFkLwzm7/FzLHV+6WOByvcRup6Uy9JSrUfb7fyqtejcDbjoJmDNa4N3siHnmbbv6+2SY45DqEp0axXcblVa024yHJqb+yD2Vjjns/8plGAsO1JjzSM0tO2Njxa/UjScCPQ6N75+NO9Smw2/KWfz65+imqeRrw6OezKzTzO1TpfC8DrdAGRfr0JPv+qaJa1tunrD2qo3j177v17bCyou/28KqJYDuttu37dh09y+fb757zVu6M+7ePHHtlRsnrjll08Q1h3JWqDvvHM3AkloWv7tSdu5wmzFXl4tb7vI8iJ6HBTQoN5tfShrpUhicC/K9rNmih4gNo36GLZEbnb9awbnfdoJmeCUce3tz0eMuJ7aIpz9HzxjjEFKYaFlHYHgPqWdJEl/eHAG1zWP7AKdrWSDPny1bIrb8SmG1XqQS4LUqAZxJDe4CrRgSeiYn8MlVUi/XJQa2k3DOmBMI+ABy9Ayap5HRbyBPjzt/cg7oVZhKLvsOGx8SeVk0RuaM3wJwTJ0/GaCnFQvmvNLch04ZLDi3LkoR/+ytPPuVS9ozHlGgl2g73Ct+5bEA9zLb87k9TL83f+74U7S0wwPjWlqj39PbdN/12LjznzJ6MlNz08S1HfU7fKYO12yc+NPDOszgux5Iq5AR9gum53ePnBXqzntKzwqPNtKMmhp3lP5yhPLLt3676NDiRmM+lFqvy+X9PzRQ4qhDwr20PPCm38OGuaMij4BHZFPugTZWdv1MKxa7TlsaX+8pR8D0+xbD8I5Vd2he12/3xk11zmE1hbm5/jYtC3z5EonlN0bwqZ5NcUlOP2tntIG5Vap8ipfGdaooHH0oQNuxu06PyuToGJR2dE+cIzG6lwRtyjLKBTOFoD6hq68HPjLQ/haF8zRjemQ28N4XwMxVwvQqTM8w3e9S4F7eIFpWPmd7F3eNb9t3G4EzJinQFb2FZ11po3iBY3vkBZ3iy1u49isZ5el6nIZleDS8HtI1/vXf+qfa3vlW47ccJerYaXvF9XuoR6B6VAnVaePENXU2TVw7Zsvdaz/AI+viJhpe5fcVPP6u91UrQta7+Y6f1m2csOauTRPXNDZgjNSzOFeNrZ3cb7tEt7a3qGUaFncM5WNnR0IbL9MDxsBHgwf7IC3i7dhQ15T73zAzN2K70FTDlsTxzewp//j6HfGDXw86/wKFnFtdyx87NhSgn7VbTpF4cUgEn98g9cxQYMG1wtwaxxnicxcJPWOMytYoX/MKXFK/m80Zm8DSsQI/3CYxc1QEjwySuOpYiVOOkKAmvDA0re9/aYBut8bPAPih8+o6OqOlHeL4GXGSEy90Ez5ca4qdH1lq7fvcZ2DkiwYe+8TAuysUrntNy3fuMWBfmnJnUfuA5fnMVQr9JxngODUrDPjhB4Sinng0ZXS/y1j9d2gzE3XDpgqi+kaKqMavnRNPa/9OHVBMz96Vmyf8NOFv4+/D9IsfKPfTM7BjR7+05yV7ecYnDRLm+QmMBwVqdTnYp30eP1Ozl+MS9YlzRR4jo4GwPZ/x9dtj5bnsaVs/npERxyt8/E2sLHGqB7peJNbeD9wkz/MqKNPkDLFtPQHK1YICl9Q0MapZSYB2jHur5dSqcovhNoe3ZHqLblsPmtHG9zvb9cBHwO3vhmN8lOtSVsqzhlnWCjRjeW0JwK1hl0xRmDIfcWcrn6JXASOP8X9FedrZ+ZMVOD4tun7XczvC/IA4cc5/Sn2sl7SBu7f1EvbTv43d9TSzuxE3/KhVfk5K+3/av0f38/Zvv/vXH3P2/N5OPwj9ffZv7IuL5SnLf8qJswHijIFMql19/7L23OznFfy8L3OA33OmAJd7B7tYLlmnf5FmqWJAqWLhmN6ufxReXRL/8rUuoLMCtuG/Hnggzrjp8f3KXTRvXi60HDMCOkp9/bIIXr1UgIfi2Ptr0izgreXxZe359jg/BDSUD+sO7GTN8G4/zX9sPDSTM8Vw9bMtrPu64xNf+enLchbN/ApdEfCnJxjX6SVsR753Aaj7dXZiD+zXzU1s3Nb7tv62qcLa3vqBPJ+YGwcp2fdhlDFU/L5eGgtz1wTdnsdh+yToffm61w0tKnQfcEII3HKKRPGISKCSVTkG45ee7soTkFwAz81Xcd6cuUf0/+xdB5wURdb/V6965nBGBD0BQYIgKjmDggmVz0M5FUU5A4qcWQFFQFAU3ZklCYhKEkwgJyinApKRKJKzMLNLmtldwi6wsNNV33szDNMz0z1hmYWdZfa3NV316lXs7tdVL1XoysGkWEwgHgvb+E6jF5iVpmMqVAqQ6GPp3VICgXvyRCNgdCcN1a8OwEB/ta4R+PJpQRJZShj++0xVx129G8CmURZGvHWPhknPAywMMkNiNZtvO7P6kLU0n48pYAELu7c3q8MM9jJtsbnt0LyDBTL/xa9QNhQemiZpbDe33dEvFJ6MaS0ZOx3W597w0A15GAr2sDwDoFAXt2TMELMMIG+Ut6UjiG/U7lZvMqYfNnZ/7kuFeIlEYwPPjxuautKccHKeP7AqjO3XYLzHGgqcaUJU/WVivfKL/xvxhNjG94UJCnX6SmTtDW4r1rqSDW/RXwqb9gSIW61rgJ5tAunQ8fCqfPhjgFFyzYKDsQvim6+br9UwkYRBS3sG8zpnvS68aja1I6zg9xxQeHCY9ApYQvtnlebjL7veZj6ul79VSxVEGauyDJfAMLfN+SHHS0MoHUTv2J1w2R2v0Bdp0rGk6WXkbHk1aI1mljngQQ3M8zDLM4PxITWPfBofkQh1FDl0lkIkvS32FUf8FiKugYf2DE3hsQaBtFnfYoWtyFRBJ2FdeA5Q9hivcP5mBdYr+/gXiW/o1TCTNsbaTnHh8bZ/7ibp5a/N2UivZxwNzd0cjNy+roAQIhgYkmIrjk6Ng3Em0Co8BC2mJLuUMvI5/2FiEWGsiM0j2fFELA5A/eUGPwI8Us/yNffMXI/IojSlZmTbHLQ29deY/FfL2UjWobnzPY8TTVtt1f8jurh1VRaWWOUzz+PV1la54fBVWQKt0hWYoRyeGw6pUkZ4+X3+HNbbenC4Auvv+WH+65JtCnz8Yaj7pFdbC7CgwI93Ilc+p8NYvtH14viLz+2zM4RPaG3M588Wp16gsQ+h8dyDCquylJd/xgeG+/N5O35TLwk+WIf5a9PX+XOOXaNcduQGI1S6UgUDLFIdGwkYrWOcuSRtdsZHcBHn35gFEu0+QRCLI1IVZ5+hwOpE99S0fsVHztMXKyUutaqHdgFbCs/Ka2eVn6xw6xlJ1hF9uvNQYZqi75v1AAbPVDnWuUCXlprXJCsSjjGP/cy9+q1C7ymSVmTRX5y3aQtVr0KgBtcBAXbS2com0W2iBDvpfHiE9Opy7donAogUYz7eM82CYQQu8n+o+3qu31/ZZoNrJIZVupJ/4w+FugKrVYymF7f/NIku43U8/rlE90kSI+cqsC9Bq1p1qVC3n0TbIQrsauq9HwOY5S9X8MjAXCyK03LzqB6oi2PE/uBL1MBG+cZ54gJ/Ovk38YFtbjuPk+gzNfa62XnAd89raFwpMDdmpcctFGlmcD+MpqdtSVAm9vcnUdfSR/RoZvZ+nLmGLjYKpv8Ltiji3phmHQf+3y0CYzoB/MU8DowSGbsQuMOusNUV+avPwhOWGre9OZhAsu7Wt8vYiwpo5RfeGEsPhz4qjq/EwjHig/ALZfTRd2aaQrMbxPFKNu4J7t8NVwXyjiNFiSx3KLQmYv7v0Qrv0os7ci68p8jNp63lN0uB/tMU2Jcg4/xgog7Etses+uJvJq+Azw329atqGS3IUwz722P7Zz9utGuZY9t4P94Wl69efzrStV754Fdna4KdmXLbPHd32iWYjcLpWEL5y4H/vqCFCWLMymbtRS1Y/EmoAbl251qL7KQGB9+5pB5KcOflGQd7K4UDwVBfqqBQ1CC+XlSt8SaVNWI4CxjdO/lqsP5l/3D3DVbew5ytseBVVbG1TwOf1xvLcY58XOLoToJe8vgJj1U/5ng9+wbqu+VagQvP9qXZp9v2bF+cy/Mc8AqH47EGVrhla5ZQ8zyz8myl8PLXCk+N0cHE2IgTas631UCc2GOMEXfhFmMqcvy6vwfnz1gXnI6UKmPwgsJ48TgEYPxoYchvigQWCrtDFNIjleOP4sTnBMpdErhvVvhLtst1gPlJZET6d2fne/pYlU12eKkletkDsvPo1n9udYOIRxTTZqja1Romd9FgZlJmVffhQoF+tA17mIQcu/fTI2SFSHAWbLA51wftAHZoeTW9TLzioixUuQpg3apJxEb+iIQsFxwjSJyXiBC6gmD9NH+9oVtbVhr258VyXbdT4sWvJaSiu2AoUOkK5XVkwGZQrB5yfogN72/rBV4jVoGhCMpeYkwBWfsC6brlA3GOMR+Sr7GEViHnmfBWf1PI6taqnvyC4HGdc5YVZnxwZw4TOx2h0vpotbDK1fhnBGL9MM1er0KdoBmbGFLSTcmMnY03XmqJHk+Egk6sX46Fh617lOkqMBwT3i/n988L2vqZ5VrD2PnjnbTdjeSGnkuz6slDtTWwQ8v53dKw8b00sAnWtJc0sG4VqzgwXiIDManB56ca62xVPZDaFOKcP15+Hjs7NfLImM+U8TDw88saXmqlgc2g3rlXw9xuGkmiud3Ax4FXXFNXBlgE5UKIHq+muQSHehWCic+SvwL1cH6kcPXFwvuhMeKMmB1beZZsG8vdep0xVbT4uN+Vlz2y3BE8pmi1dWkJsMoVK0BHw/Xnb3KJwAT7gceuBaJwxLFoqbyUaqLntmdtoS2uqZnaXzk4Es8d5VXWqCc1dL0tnlKgrRrAbuj5DFY2aI+vtDk2e9OwT5dgdRZzjOhQVlVh/pgfk1dT118ReBw2GbaQjBMP0WNe1B8Gxj6r2HzXWQN7nBYi+IVmN/x97tfwMhFCbscfPp0TID7cNz+cr5kGqWv1q0Fb/gDuxj0C8czzE40CY+a6J6+AV0rMcavA4/t5TaDNC88GWlYJHpdVWTP4zn0KfNRmrx9U0HGRZrhG2DlnKiJ2QDRTNWMZfzwzR53hjxuv9L78nJe+M9Iq0IielPHgOx5xCMmZSY/iNLOe5+bD8ktnhu+H8cs54vHgF82fF+k6aTkLOZgpXaRmg6pmiefgmUDD9yWYmBaF+IWqdzSrHNQENu0OvNScE8/2dsb64LKsSF3+croTXJFFeKYZcPE5gXJrdwqwUjajXxNhpcdWDnUrBNdNgiouFlNgp6m85TYid50gwSoiRpg/vnS7QkeSPBu37S+1As7/W3Af/PjRrmMXKrRKl3H7RmTvM+zMoVW1or3CeUfUWaZ9E/jRFF6KgEWbsWSaAAWSqYZ3eO/hcFisEH7Qvu+if9x4lwAAEABJREFUgR+8WMsw3s59Ap3HAR2/kKZuhRgnWmCN/MkrfMSB1TWmrwXO+1u0UuH5zL8yQpknZExvphWTMc0rKmM6Unx+iGOEu2tEJwhsFdO0cjAer6i4nbIhjHkjT4/z64VsLZduZ2hsQQiBD4lf6uej+koJr4oIH205cIYkNoD0Hhj10S8SrErE5oM+PKBxJbqfDYP77c+LdHUQ7+5fIyR6T1ExnVJmrOu2qsCUrsxnLvrre/CIuRBDF2qWsa3SGC/6rCXJbBxNO0prrPDOkrAh/ifVUA2vfJjn1qGBARhjlBWCb0tXYEuHeM3Y1u0Ezj4z0NBTTYVXEhyARI+xcGXDLh/hZGx+4RtcH5gO7lOW4VQ3Pl+C1WwYN5awa38wVtUywWmrVMUrAn1gHL8aCHtcueBshvgCe6ph/T1fCqhTwR/zXRfHwdfjErWuIcLXLvxVYN7awBnwKj8//rnCMCIHxhVerWsAdi4hRHC/uU6rkH9Egb2ztPhIIdTNmFUZP5yFPu8/IDCyo3bCR1R6pBa20lNK5eemO+OQYft7llzX8DudXP2P2tt96bscZkiH6eEzg8cDY1vMd4kfNf5p4KqLVDxFvbhs6cA+3NjEywuI4acF8Y74FCxGveRcBZaAcjyeMNO7/Qy8qPUriiDnCJtClJLj0c+jFwe5Bi+H7D4rVoJ5yXkBQszj2W9QKipr2OIy4WE+GONwYB97fzuDY76wlj4M8fD1uBS74h/WAfQBCe4D54UHhYfrAhOejV1aynXwfW4+QGLEbE7FFxpdrzD9VQ3/qhu4b/HVEIxdqCuz/cGGYKzSmdJK57CCR6Wg6DUIhuUViISNvUFFDb++ooF16YJbiZ7KPSjQfZJCm0ES/u1cpFK7iOnN9rCM83JrUSReUqjUNoyfF6K2EY8Q47DXVWvgxdQCUe5yxBC6YCrwBNBDdfWMElx251WnfABXKYFlxHsLQGKL3XGjBj4pjQ9p0kQ48WPCet9NwC8kgX7vAQ2xSkuXUl/4/vJ95vsdW298WOeepcAOA8Y9lYYrL4xjMn3FLX91Kc4LzRRCZIXCSmM6YS9+SZ4cen7DzM72FcgzEtlnZmSzLh3bO155YfgLE60t3rY+OEyBXTzxS2KGX6mHjkYfKGLwC/A5H4/Wi/8lYKXjUHOtpiFCjM0hK71KIdtOs775YbyqMxIMerliMs3j8jn5/BsIxpPkrg/xQu3f+vqx6xmIHsOWbOdf68COCljtZNHWYMFSmYsFPnk0DX/00oK9PT8DLH9HIONhDZWujG3e+RjRJ4h/2364At9f696Y5zSoCDAL5ZF6iX9NlULIjHIfVMidZ1jpC4mfzZI4RwIhp1cAeYdwQXF0tXElgZmvaXi0PtceP/FjF0/8ktxl1/HfFQpG3tWDtQVYqfeHrvxiCtCXmRuJK/xBq468gkARPvj6eoOqCudsPEEdvUvP51oCga0tOBUtbAyRGF9hqMe4veV6Qole3RAJbqi+3r7DtD1cJ9F/msT/DZGo2UuC+XSfWGw1LzxbBHt7rqCBCTq3HS2wgvMzYyXuHaQQuqqOVpbzmX/53gPA+Kc1XGvwv8h5iQiufGmqkkLkP4Qbm4jWSl4dpwXRo69afujU5x8Rl4fCEpXml6NvWw1fP6vhmhBTp1jbYH2zV75RaE4M7++W0eNIBdkxKSv11ihbNIJHVWDOZv4NhNBVHuewHiBf/SFWQYQfv3aIP7hf10Yn/vuJKIVKlG/+h/BXiXIXH496I8btLQNYqGC0k/4zkyScKyV6/leCPyC39FF4dizAtr98Gh2vQLncCmfwh4VhRQ18qM8L4yXutCuwgnVR6mHJ7IxXBfEMtaIUj6nMVpcK+az5itFs7/PFSvdv8c1sCZo3IWBY2/g7Jq7es19u9aeK41q3vMCcNzSwDlpR6+eX+82JwD0DfaoTRa3HX+78s4CLzgkQoVClWrZ73XOAHv9jBZiQsNss3ga68wLljmWbXnjrbcwYNV/BmRu5rH26om1woF3W2WNbUn89ZQ2CDIZlGqTLnGarFiORZKL20le0WloE8AeEcczCGfQG7DjBV539+T32mY67MxSmrTZrJTqMLVbY9x1LZhNxslukFmetF2HsHi++RNjiwAsvZT90y0vZiEyGo5QwyAEDCD+uUsVK9Pwt8TGFP78swDwaPyze6/pdPtWJu2jbO2m5b+UXbx2M36WlhmU9NXz+hAB7iq5bgaGBEGp+VuARtFoC+ADpeu8p1Oot0e4TiTe+YymkBJ8ixgdM6zJA1O66UeAKA1/zcKEAK/SyXWmgJV+Mpb2sbM0eanwQ32+XlgJMyHwpeM+xNfIK+WPgz/Nf64bw9fzwwFWBD1ZvXwcY8CBIaCGwoldakbeQfB/upPvB/vwWbAkQ7EB7scXYce1vr2u4J4Lvu9hqig1r+jpFnz4TXKFSRM9kWpIVZFCiCAzhmyWBFzUALZ4Y6/Uxj+aTR0WYAX08LfKq5fXvgDr9dPSZKrEyK/4xsLsmVn1hT9FnhbicD3UnFdq3A7RmZhOzicuBD3+Gd8t4e7ry8h/9uEys+twfTATY08pt6ZIENbrX2mE68dc++kXiDrskPlvwGG4qB7CjTn99fOU+s5CB4xyYL8lbYo77Q6gwgyWf/KF5oSXwxRPAn701krKnof8/NSL4GipEsRLx12u8svfiXj9I1O6rg+/DphAlbiNutDj3dyZtZXu20Y57t4lW5kTz+eO0PUdUM61HiTDetylekgNPj5WeUDlm92mzW9TJOyxN9fjM8BMBu7OGwHR60FkgcSL15eQLIh4gprxCi490sOWA32zrROptX0eAV6WDH/EJTe6qoWh1BKRpwYQptI1QieYd1TV0IWJjxOMt5/9W+6wdmL82bBawxSWMKOBt3kBq+wwTXZdyYXy94D7VIh7gXTWAd+4FWNizkogcf2heaa2heZWiExaeV/t0ieY0z+y9eNzvsXswDhrcscTVFysMewzek9aimecdK5Kwy+gFciHN+EVmFSqYCzjMcJMZdloQPSgrxq245D9fqaUn+wayfhcLJJa8JcBbG9b/OpE+8CqKLQdafqxw7yAdfHg0m6sVpU4mNrwqvacmEz0NQx9No9WRhnV9NfyPtuiDHgHY6QLz7SqQKMi/5axSJrw1NoTvfjdvU4OJUzimD8I2sJO7CMvt5nWXgfIUGl6v0J62qKwc7ivp++V5HfqohicaaWBhD68OfTnx//L88TzeN1gHz+vgmYAzh8hF/FUdL8HeYvq2BdiTDn8UjmecxMhHP+NKq+aExA6rvJIBT0wvTg+iJ7DVarpIYnjPuh36PKv84oRfdoEAb23mdxd4vgXA27ETbW/tToH3fwIavK+IDyfx5SIJVtc40Xp5y3rDlQJtiO/0cisNwzpoxBMjYthPw7SXBEK3yf72nm4qsKCb5vWhV/3qcOLH6hmsDMweodntFB+84y8beuVt6ew30vDlU74taqJXSex1efxi6Z03nj+ex3gO4Qntrz9dnj4O6Q8JzH1Tw6P1NT/4pF9fmCBnH9VFRauG3YOyQmT7VpjJDT91d+AkzptHeFZaNifEOW2H4oKDR9U2S5xizuBTsV67Q8PCHppXD4/NyxLR5CIi9ezXjtU17h+sY8DPPsP5RNTtr4OJXZUobuSZuLMPvan/SfP6CWRfgf7AW1BWBr6Ltv1CnNhKyt+neK6sZjJitkT74TpufVeh52SA5y2eOqxwefU7mFbGM1/VwMcPWOGdDPjsjWrltFVoDss/tcYyq5RlnBZEb1/6LoeCyrS6dx4patXtpxOJgMsK52TAWSGWt73zu2u0AkSR7Hmt+rl6h8Dw2fAq5NYiCWyP730qMLGqoVjVm2xwdsP1v9VE3P4r0fgDn5oJC2SWbk8cwa1PaykWnEx7UUOk08hO1tz9mSk3PjlKhfiiCW5dKbE4GFJ6U6WY6AXfNAXxYzAkOHX4qHZ7zV766rzD1sQxuETxpZhX9WRjWvl1T/OqVjDvLJGtsQT26yU+FRhWQ2GpKktSf1wlYfS+ksg2T1VdbB3Byt1M5G8n6XHdfookyArjFwE79yWO0PH47qgOTH5BYMLTPsEJw051WLpNrv/nJ+oyGulFkfqihJwSKb805Z02RI9u+shoNy7/iLit1rvy6IbdeonhbbS71cc7Yw8gda5T0YZQpPxtbnjdJv1nAnD3QIUK3SSYED47VoKllvM2SbCtapEqP0mFuH/LtiuM+12CCRybmlV922cdwcrdTOT5tLTi6M6DtUHCHprDxzTcVI6etOJopAh1fr9MLms/XP2DVnGXRiyusCfblpkiehEnKQkz3TbHCqXUxGhdpwek4t0ZolLXCXJWNNx48hfTF/ezefrvr38rZ7cbps9r2N+z+JY+ciWHdsP1eeN+15fkHJSWto/sAeSbzmleocEj9YATlfhG6zsTQvauPJiklh2/AKr3VHhgqMSbEyVYmXj2BokVTonM3KIrSkfrg1n+rn1svC+95+jyiWF8JmzLj3Vv/x4artDrB4AJHJua8XnEZnUkAnbtpQpvtwFW9BL4sJ2GUPvl0DYcuXKnfYa+4IUv5RwOfafqc79arC9Ztl2uy8mXJ2gTEtwa1Zfbdog+77WJqA0hzg3ODU8pgb7h0NIL0Urv0MJH5tE9r0IpU+uMUOyfVqFFpR561uiF0tTzcih+aHrJNrmhxyQ5p0F/fWmFbvrBh0eg6vs/iQaT/kDzPxyiye79Wr19h3EThz+2iya9fhB16/TFRVV76lt6/lfOOVggTRWqq5DQoN//aVjytkCvewGWDIa2HWM6bjS2Z/1uGbzKxJ1GA//8BGg2AN6VYY1eOpp/pOMhEgiwd+EOn+neFRfrD8YaMqZLr8I1W3s8P14n/qOkNiTY5+CN7+jedtjLTJtBwL9HK++JYXyi2/bsk7e6Yg/To54EZr+ehk6NNbCDU7OJPFQoC76Yry9sla4vrNxD39FiAK4ePEM0mrYGzTiMWiCavjVZ1H1oOKrV6YeLK3bXc5oN8Cz6cJo+b90ufZtZnbHA3p0q59Tpp7RVWaJJLPj0PqymBcHQmHBLCZJWSsYR0zD2DtrpVArdYkImJF2Kcu9OQcPq78gNXy+Wi60IUXa+3Ltom1zXe4o+l17QxbQ9PPCvEajy9VI027Nf1AHCfZfB4u9Iobie+E3NbuwN2XmsZ/beQ8p09XfB2QIdG2lgySDzkdi+99q/K4taix988Ijw6rEtI4HAYnplF24R3hUX6w/GGgbRqnLMAmDicuDn1QLzicmwwglk7UWQXW7xjya4BdYLZAuTxW8J8KljzW6wfm2ycuWuB4bqc298W8l+P4qGW92iIQnKygbXGJ5SSlyamavVHzFXNGkzUJSv2E3fc+dAff7Q3/T5u/ZHdvnkzpc5tl/VvErd9R2jF6AZIC5GjH9SA5HwGJFLCZr13SslAwwdhjvDORgK9lB4pPTho6jSYzLq1YcN2CUAAA5USURBVOiN86r3lJt4S8qh2tv65vJv6vl1++GSR0ag2tiFoim9oLT5xIWR6oslTwAX/LpOa37ru0rQymdOpDLMR2L7XtZhm/of4bWEiPf8jkj1n455TSrTivafwutDj/UCH2sgEMkRwMGj8vCDwz1zmg5AmT8zRVPEsK2MNK8K4spNu0Tj9F9F40b91ZW0W9hLq911/NwZQ+UeHme9frh0yG+qia5E2Uh1huVJ9Xh2upM+MWE5pRpw2hE9vpsuu+MVQH7M8XjD4UJU5i0phwKPqCSEOD/eOuLEv5BWPs1u7qOvIH4WiRwil65+tfAeCTiLtl9s19n7PoFmNwBnn6EiFzzNc8tdArAPxGEdgNV9BMZ00tC+Tmzu4P9wyE0395bu5ds1WmUV10SKSw4dFdX4uTMGj9SuLUqLSslOrgznuKKUTfYypyXR45vmsmW+LiWe5ngyhP2Hxc2NP5Tij+1yY6z9LX+5wOMNBUY9qWFdvzSMe0rg6abAjWVTBPC8vym0qKK8drpsa8zWEuwDkQVG5/2N1tkxTvL4xXJZu2GoXFTiE2MzCUWTSj7stmeOSmilSVTZaUv0+B5lZzg+k0pvrpRKCptD4vtc1m6YunbWRrWK+x9vaHS9QPe7NUzpmuZdzYzuBK95WL0K8daUfPh8ottdNYA+9wv89CJo/Gn4/Ik0r50u2xoXZUTv/yjn9JxMEtKiFD41ZQok1L3Z9syvT03zJaPV05ro8S3ItmfN0T351UiKNZzTiQi0jtoEqJFSyVcU1EMeeBp4UHity+YQ/iCJ2BJObwrTlVKx+zET4pynRsly23PlCRFqXs00rayBzcO+ekYDm4VNeh74oB3QuTlwezUg0UrRiZjbaHVceDZQ6xrggVtA23yQ4AGY+6bA4rfSMPRRDcybq1rmxB/7gTPk75/NR3zbWYU9UJgsFV7Thazrfxb4CqkqKiWb0u6jg4LqppSaSM/R7mjjjT1fzSz0FN6QbXP+GHuZKJhJmn3idz9JB27sdu7g3AMuu/M5Jk5EhMYb82KKK7WaHtRBkPjn4SOey9w2xw0um/MZ+qLa3Tbnd7m2HYtybTuDzOCY2BJOHwqt3XbnBfQiPEoPubWNsKEjCuLvd2cg4b7Pbr5Ww0O1Nbxxp4ZPH9cw41UfMZxOHNDPOgqCg/KB2tcpXHq+MvTo5EeZIN9WFXiWCPT7Dwh801mA1Xj+7K3h+y4aPn5II4GOhlbVNJS7JPbtaiwjWbBFX0MS6Qax4Ppw1BRd4jaX3XEVhQey7Y70nPTMpb483y/x1/5y2zPnZWc4xtMz86Hb7nzQbXOU0UVhVSnVs/R8jSVMB4W4/ukubSIC+oTL5rydtRfiKlxKkVNEz3BjmTjRw9HhsCi8HJC07lHTDdnHo/QQLaOETSp1X+GZBy4mglmTHtQXXRmO7/OG7sihvLj/6UWY4LY5atEXvzE9qNOiVVBAEuX7BnvmRsNLRH7FKzS0rCpoBajRSlDDt53TsPTtNNoiCvDqcPhjIDjQ7S7guRbwun1ikyzeNrOjzHgDS07vuwnEj4TXAQMLYzIeBvikuZmvCu+qdAYR5JEdNbxJBJrPgq1zncBl5yeWuJnPnSp4chTOM88LhjKhknphFZfNeX9OhuO34NzYUjnpOzdkZzg/peero8vmuE6eIcvyBxK0k1AKFvxdtZBWlHYlVBM3fYDddueY2Fo7PbBSRM/kPuel78x22TKHuWzO1vSgHd+S+uP0ENWh+KvZdufUvR/uNdWjM6k2JhB98Re4bY57eNVJxHVLpEJrdmhNZ22QayPhFGceb5F5ddi6ukYrQA3PNNPw+h2a1zPxsMc08Lb5q2fpGmcY00kDH7XY+z6NiJ5GxE/gvps0NK4kwMKZ4hxTtLq7TlC/e3QR2TG9wm9HNFRw25wdswfutCBM0Voyz88ekLmTP5Au2km47Y4qrvzC8wo1WUPX9fq60su5vCwUZyOX3fGKO90537yW0xt68oje6T3PcY+eV53ui7QatOqLqC3/wgSkxV15qkCRZmDnfrWLLXUiFaYP1UtEcG7b/7FjWyS8hOV9uvPQ3o8z1+QMzFqcY886IT5vwvpUwitKEb2SfIN6by9w2xwvUBdfp2D6z4rToxbIRaaZKWBCZ6DzWN165a1wRIe63W13Dkxoo6nKEj4DKaKX8ClNfIW0ZfmYeH1vWtX84TRFPEir3BQ8ETOweY/aRuyEJlZ16Uq1ybE5Z1rlp+AlZwZSRK/E3IvIHSFe3wAo9akZFrsA/3JhyVztzdko17zxnZzVdqg+v/57+rKq78hNFbvp2RW6SVTsru+u+Y6+tsmH+pKHhnnmvvejZ/aqLPmX2RhPNazrBJll1Qcp0SEnwznDKj8FL1kzkCJ6Jet+ROyNy+58lqR2pl5f+v+MmI3MUcx/29x6Zvvh+qzy3eR+knTeOHE5WqzKFI1deaL2kaOorCAu4y4oJa7KPyqq79gr6i5zaE0/n681bzsEFdi++adVssTYhPIqb9MeK68l8uPsDEf8ak48AalwSmYgRfROybQXvdEjmuhAzPIwZWbm7X27TJ5yl99dvpSzbksX1yzdLloIIKK3XqtZYPvmrhNw60299TXfLj31K1irVZ5S+NNly3zdahwpeMmcgRTRK5n3xbJXXqmgEKbusfr8gEssCxZzxtxNalXlt/Tt/1uDFolqKq9A3NhtEurX768v3XNARXW2kKh2jfWs2aE2Wa3ypFb4sBE3FU+OGUgRveS4T0G9dNscQxWwMghICV4hZczQT7pu1pNfyN+e+ELV9OjiOupGwv9d+0Wdhv2lvmaX2pzwyqNU+OTnMt8MRUINYMVhs7wUrGTPQIrolez7Y9k7BfmOWebA6aJmZq7caZaXaNhhjzpU5139jzmb0DLRdYfWp4j/d2+GLDNqgf57aF5xpfv8IOfkHBK3hNbP7AWP1PqHwlPp5JiBFNFLjvsU1sts70Euak1ohhC48A67ymOnlqF5iUxv3i3/urm3nmVGFBLZjrEuIcT5faeKBk+PkRGdqhrLFDU+d7NcM+Z3WDkUGLIvY3tCz7Uoaj+N5VLx2GYgRfRim6cSiiV6m3WsoFDc0NomVxV4aBNshnCCsFkb5IrWdlx21KNVjqUqpTAHSo1TUP0pvEgrpfYQqrWU6CAVXpNKfUTwbwjONs1Rq5y5Hs3uytAXFNf4/syUG574XJl6IaYZzTsC+VHUTqYQSuwMpIheib010Tvmsjkm0UsYxtvjkrv2afVufVeuc+bKhJom2Wd45vx7lKoiaEXJ7VgGhcXE93rmyFnq7267o7nL7nzcbXP2oDDIbXd+60p3TmdVj2y7Iz3b7nyD4P8ieB1IVVECvHWPaMa1cbdoVKuX3LYqS0bEs+yfRcanc+XCB4aoawFhLhRSGHDAnpWL1F/SzkCK6CXtrfN1XEm85YuF/x4+Kqo1H4Cyj39GvKl8eUIv6mqSYtZ7T186eIbWDEKcE96aH6KmeISq7rI76mfbnCP3f+Dc68+J5erKcP6VbXP0ddkcFaREG0Ctsyp3VBfl2w5B+T5T9HlWOLHCZ29UK2/q7Vn1wTQ0pPGda1pOqRwcOZRhmpcClvwZONbDFNE7NhHJeqHV0k/U90UULP/nb0GzOv1wbtsh+jw+z8ES0SRjuUOtb9JfX3L/YFXZnSfqmKB4QbTi3CThaemyOe/PTXdaEiovcow/PDaqrzptj7tSOGBVbMxC0aRWH8/qX9bKMB6nVRmGHyqUBWy3zMSu0yh1U16BVpPhVkEJ0cv9idtUmmtVJgUveTOQInol757E3SNd6S/GUOhsPguVz3Oo2F3PudMmF3f/3jN7zEK5aOFWudaVJ3NI+HFo9U65ZeJytaTHZM+cW/rKFQ8OU1V37Bd1I9WvoDLcNscN2bYdsyLhFTXPbXcMIaJXBQqWktsDh7Uaz43DjZV76I4OI+Uc269ywa9r9T+3uqXXfCwrV+6es0Gtou3r7699I2fXf19fdmNPnN13KupHI3bcb2p/vdvmGMrxVEjuGUgRveS+f97e59izlhDh+cybiOFHKXHpJhfqfbNEa95nCup3GInq9d/DpTXewbn3D8L1b3yn6n69WGu27yBujlidUodp+9nRbXO+HBEvAZnZGY5dLrujoYL6LFJ1Hin+sXArmg35DY06jxO1WqWjHNv5Nh2Aq54crWrS9rXB9yvQ3HVA1I5UT3iefDYcloIk4wykiJ7VXUsyuOfMvNfUSTzgiLazK2jldaPL5mQ35idttojAPq0r2ZbGetK2mTTWoW575ryTNshUQ8U6AymiV6zTe/IqZw/OQuj3nAxiQG38ioJDTVnocPJGGGgpx575A5TObp5cAWhxxdR0t8+nYXE1kKr3JM9Aiuid5AkvzuZcth0rhcKdtOXMLq52lMLnbrvzjlPN0Hdn7PjzqDxSj/qTUHfsxnkj4v6TKjj8gBGWiif/DKSIXvLfw6AR0OprgZSiJhGD2UEZJ5xQB6nOp0io8JSvqlP/uy9j93bdk0dCFvVlontDvMMeRNzbnGrinuhxpeoDUkSvFD4F2RmOXUScWkiJp4nvlgDvJGq6B56qVOfnJW26vMd32pyP0VjbEO9t94n3T81UHr0y8Q77n3hdqRpK4gykiF5JvCsJ6hMRv89cdscVtN3tSMTPUt3Dqjla2f0MoVq7bM7WubadQef2WpU5VXAa60/u/MKKSqr/UL/Xx9MPwj9AYRTgqUVjvd09KGtzPOVTuMk1Aymil1z3q0i9pRd5LBG/hvKMgxfSaugeCTWA+FVB0kiC7ybYAmrARvF7hFZwPq3s7mJzMYIlx/+nOw+5M5yDqd/VjmioACWfozFNJKK/hojacQcBNL48gv8qlerlkWhI+BdR6MQ80QQONFVVCZ2B/wcAAP//uVR2yAAAAAZJREFUAwDFot+hiny2+gAAAABJRU5ErkJggg==" alt="Colegio de San Jose Seal">
    </div>
    <div class="brand-text">
      <h1>DIGIMON</h1>
      <p class="tagline">Digital Self-Monitoring System for the Higher Education Department</p>
    </div>
    <div class="institution">
      Colegio de San Jose<br>
      Jaro, Iloilo City<br>
      Administered by the Daughters of Charity of St. Vincent de Paul
    </div>
    <div class="motto">"Ite ad Joseph" &middot; est. 1872</div>
  </div>

  <!-- FORM / RIGHT PANEL -->
  <div class="panel">

    <div class="tabs">
      <button class="tab active" id="tabLogin" onclick="switchTab('login')">Log In</button>
      <button class="tab" id="tabSignup" onclick="switchTab('signup')">Sign Up</button>
    </div>

    <div class="status-msg" id="statusMsg"></div>

    <!-- LOGIN FORM -->
    <div class="form-head" id="headLogin">
      <h2>Welcome back</h2>
      <p>Log in with your Student ID or Teacher ID and password to continue.</p>
    </div>
    <form id="loginForm" class="active" novalidate onsubmit="return handleLogin(event)">
      <div class="field" id="f-login-id">
        <label for="loginId" id="loginIdentityLabel">Student ID or Teacher ID</label>
        <input type="text" id="loginId" name="loginId" placeholder="Enter Student ID or Teacher ID" autocomplete="username" maxlength="64" autocapitalize="off" spellcheck="false" required>
        <span class="error">Please enter your ID.</span>
      </div>
      <div class="field" id="f-login-pass">
        <label for="loginPassword">Password</label>
        <div style="position:relative;display:flex;align-items:center;">
          <input type="password" id="loginPassword" name="loginPassword" placeholder="Enter your password" autocomplete="current-password" required style="width:100%;padding-right:42px;box-sizing:border-box;">
          <button type="button" id="toggleLoginPassword" aria-label="Show password" title="Show / hide password" style="position:absolute;right:8px;background:transparent;border:0;cursor:pointer;font-size:16px;line-height:1;padding:4px;opacity:.85;">👁️</button>
        </div>
        <span class="error">Please enter your password.</span>
      </div>
      <div class="row-between">
        <label class="checkbox-line">
          <input type="checkbox" id="rememberMe">
          Remember me
        </label>
        <a href="forgot-password.php" class="link">Forgot password?</a>
      </div>
      <button type="submit" class="submit">Log In</button>
      <button type="button" class="submit" id="fingerprintLogin" style="margin-top:8px;">Log In with Biometrics</button>
    </form>

    <!-- SIGN UP FORM -->
    <div class="form-head" id="headSignup" style="display:none;">
      <h2>Create your account</h2>
      <p>Register to start using DIGIMON for self-monitoring.</p>
    </div>
    <form id="signupForm" novalidate onsubmit="return handleSignup(event)">
      <div class="field" id="f-role">
        <label>I am a</label>
        <div class="role-picker">
          <label class="role-option selected" id="roleStudentLabel">
            <input type="radio" name="role" value="student" checked onchange="selectRole('student')">
            Student
          </label>
          <label class="role-option" id="roleTeacherLabel">
            <input type="radio" name="role" value="teacher" onchange="selectRole('teacher')">
            Teacher
          </label>
        </div>
        <div class="approval-note show" id="approvalNote">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 9v4M12 16.5h.01M12 3l9 16H3L12 3z" stroke="#6B5B0A" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span id="approvalNoteText">Student accounts are created immediately. No Dean approval is required.</span>
        </div>
      </div>

      <div class="row-2">
        <div class="field" id="f-fullname">
          <label for="fullName">Full Name</label>
          <input type="text" id="fullName" name="fullName" placeholder="Last Name, First Name, Middle Name" title="Format: Last Name, First Name, Middle Name" maxlength="150" autocomplete="name" required>
          <span class="error">Full name is required.</span>
        </div>
        <div class="field" id="f-schoolid">
          <label for="schoolId" id="schoolIdLabel">Student ID</label>
          <input type="text" id="schoolId" name="schoolId" placeholder="2023-00123" maxlength="64" autocapitalize="off" spellcheck="false" required>
          <span class="error">This field is required.</span>
        </div>
      </div>

      <div class="field" id="f-course">
        <div class="row-2">
          <div>
            <label for="courseSignup">Course</label>
            <select id="courseSignup" name="courseSignup" required onchange="updateMajorOptions()">
              <option value="">Select course…</option>
              <option value="BSBA">BSBA</option>
              <option value="BEED">BEED</option>
              <option value="BSEd">BSEd</option>
              <option value="BSIT">BSIT</option>
            </select>
          </div>
          <div>
            <label for="yearLevelSignup">Year Level</label>
            <select id="yearLevelSignup" name="yearLevelSignup" required>
              <option value="">Select year…</option>
              <option value="1">1st</option>
              <option value="2">2nd</option>
              <option value="3">3rd</option>
              <option value="4">4th</option>
            </select>
          </div>
        </div>
        <div class="row-2" style="margin-top:12px;">
          <div class="field" id="f-major" style="margin:0;">
            <label for="majorSignup">Major</label>
            <select id="majorSignup" name="majorSignup">
              <option value="">—</option>
            </select>
            <span class="error">Please select a major for this course.</span>
          </div>
          <div class="field" id="f-status" style="margin:0;">
            <label for="statusSignup">Status</label>
            <select id="statusSignup" name="statusSignup" required>
              <option value="">Select status…</option>
              <option value="regular">Regular</option>
              <option value="irregular">Irregular</option>
            </select>
            <span class="error">Status is required.</span>
          </div>
        </div>
        <input type="hidden" id="courseYearSignup" name="courseYear" value="">
        <span class="error">Course &amp; Year is required.</span>
      </div>

      <div class="field" id="f-subject" style="display:none;">
        <label for="subjectCode">Department Handled</label>
        <input type="text" id="subjectCode" name="subjectCode" placeholder="e.g. Computer Studies / Education">
        <button type="button" id="loadSubjectsBtn" class="btn-load-subjects">Load Subjects</button>
        <p id="loadSubjectsSummary" class="load-subjects-summary">0 subjects selected</p>
        <div id="loadSubjectsChips" class="load-subjects-chips"></div>
        <span class="error">Please click Load Subjects and choose at least one subject you handle.</span>
        <input type="hidden" id="loadSubjectsValues" name="loadSubjectsValues" value="">
      </div>

      <div class="field" id="f-email">
        <label for="signupEmail">Email Address</label>
        <input type="email" id="signupEmail" name="signupEmail" placeholder="you@csj.edu.ph" autocomplete="email" required>
        <span class="error">Enter a valid email address.</span>
      </div>

      <div class="row-2">
        <div class="field" id="f-pass1">
          <label for="signupPassword">Password</label>
          <div style="position:relative;display:flex;align-items:center;">
            <input type="password" id="signupPassword" name="signupPassword" placeholder="At least 8 characters" autocomplete="new-password" required minlength="8" style="width:100%;padding-right:42px;box-sizing:border-box;">
            <button type="button" id="toggleSignupPassword" aria-label="Show password" title="Show / hide password" style="position:absolute;right:8px;background:transparent;border:0;cursor:pointer;font-size:16px;line-height:1;padding:4px;opacity:.85;">👁️</button>
          </div>
          <span class="error">Minimum 8 characters.</span>
        </div>
        <div class="field" id="f-pass2">
          <label for="signupPassword2">Confirm Password</label>
          <div style="position:relative;display:flex;align-items:center;"><input type="password" id="signupPassword2" name="signupPassword2" placeholder="Re-enter password" autocomplete="new-password" required><button type="button" id="toggleSignupPassword2" aria-label="Show password" title="Show / hide password" style="position:absolute;right:8px;background:transparent;border:0;cursor:pointer;font-size:16px;line-height:1;padding:4px;opacity:.85;">👁️</button></div>
          <span class="error">Passwords do not match.</span>
        </div>
      </div>

      <button type="submit" class="submit" id="signupSubmitBtn">Create Account</button>
    </form>
  </div>
</div>

<script>
'use strict';
const API='php/account.php';
const STUDENT_APP_URL='student.php';
const INSTRUCTOR_APP_URL='instructor-dashboard.php';

const ID_PATTERN=/^[A-Za-z0-9._\-]{1,64}$/;
function $(id){return document.getElementById(id)}

const MAJORS_BY_COURSE = {
  BSBA: ['Operations Management', 'Financial Management'],
  BSEd: ['English', 'Filipino'],
  BSED: ['English', 'Filipino']
};
function updateMajorOptions(){
  const course = ($('courseSignup')||{}).value || '';
  const majorEl = $('majorSignup');
  if (!majorEl) return;
  const opts = MAJORS_BY_COURSE[course] || MAJORS_BY_COURSE[String(course).toUpperCase()] || [];
  const prev = majorEl.value;
  majorEl.innerHTML = '';
  if (!opts.length) {
    const o = document.createElement('option');
    o.value = '';
    o.textContent = '—';
    majorEl.appendChild(o);
    majorEl.disabled = true;
    majorEl.required = false;
    majorEl.value = '';
  } else {
    majorEl.disabled = false;
    majorEl.required = true;
    const blank = document.createElement('option');
    blank.value = '';
    blank.textContent = 'Select major…';
    majorEl.appendChild(blank);
    opts.forEach(function(m){
      const o = document.createElement('option');
      o.value = m;
      o.textContent = m;
      majorEl.appendChild(o);
    });
    if (prev && opts.indexOf(prev) >= 0) majorEl.value = prev;
  }
  markInvalid('f-major', false);
}


function showStatus(message,type){const el=$('statusMsg');el.textContent=message||'';el.className='status-msg show '+(type||'error')}
function hideStatus(){const el=$('statusMsg');el.className='status-msg'}
function switchTab(which){
  const login=which==='login';
  $('tabLogin').classList.toggle('active',login);$('tabSignup').classList.toggle('active',!login);
  $('headLogin').style.display=login?'block':'none';$('headSignup').style.display=login?'none':'block';
  $('loginForm').classList.toggle('active',login);$('signupForm').classList.toggle('active',!login);hideStatus();
}
function selectRole(role){
  const student=role==='student';
  $('roleStudentLabel').classList.toggle('selected',student);$('roleTeacherLabel').classList.toggle('selected',!student);
  $('schoolIdLabel').textContent=student?'Student ID':'Teacher ID';
  $('f-course').style.display=student?'':'none';$('schoolId').placeholder=student?'2023-00123':'T-00045';
  $('f-subject').style.display=student?'none':'flex';
  $('f-course').style.display=student?'':'none';
  $('approvalNoteText').textContent=student?'Student accounts are created immediately. No Dean approval is required.':'Teacher accounts are created immediately. No Dean approval is required.';
  $('signupSubmitBtn').textContent='Create Account';
}
function markInvalid(id,bad){const el=$(id);if(el)el.classList.toggle('invalid',!!bad)}
async function post(action,payload){
  const r=await fetch(API+'?action='+encodeURIComponent(action),{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify(payload||{})});
  let d={};try{d=await r.json()}catch(e){throw new Error('Server returned an invalid response.')}
  if(!r.ok||!d.ok)throw new Error(d.message||'Request failed.');return d;
}
function b64urlToBytes(v){v=String(v).replace(/-/g,'+').replace(/_/g,'/');while(v.length%4)v+='=';const s=atob(v),a=new Uint8Array(s.length);for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);return a}
function bytesToB64url(b){let s='';new Uint8Array(b).forEach(x=>s+=String.fromCharCode(x));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function publicKeyFromOptions(pk){const out={...pk};out.challenge=b64urlToBytes(pk.challenge);if(pk.allowCredentials)out.allowCredentials=pk.allowCredentials.map(c=>({...c,id:b64urlToBytes(c.id)}));return out}
function credentialJSON(c){const r={id:c.id,rawId:bytesToB64url(c.rawId),type:c.type,response:{}};if(c.response.clientDataJSON)r.response.clientDataJSON=bytesToB64url(c.response.clientDataJSON);if(c.response.authenticatorData)r.response.authenticatorData=bytesToB64url(c.response.authenticatorData);if(c.response.signature)r.response.signature=bytesToB64url(c.response.signature);if(c.response.userHandle)r.response.userHandle=bytesToB64url(c.response.userHandle);return r}
$('fingerprintLogin').addEventListener('click',async()=>{const btn=$('fingerprintLogin');try{if(!window.PublicKeyCredential||!navigator.credentials)throw new Error('This browser or device does not support fingerprint/device biometrics.');if(!window.isSecureContext)throw new Error('Use the same HTTPS site address where you registered your fingerprint. With ngrok, keep using the same ngrok URL/domain when logging in.');btn.disabled=true;btn.setAttribute('aria-busy','true');btn.dataset.originalText=btn.textContent;btn.textContent='Opening fingerprint / passkey…';showStatus('Opening your device fingerprint / passkey prompt…','success');const r=await fetch('php/biometric.php?action=login_options',{cache:'no-store',credentials:'same-origin'});const raw=await r.text();let d;try{d=JSON.parse(raw)}catch(e){throw new Error('Server returned an invalid response (not JSON). Check that MySQL is running and schema.sql is imported, then reload the page.')}if(!r.ok||!d.ok)throw new Error(d.message||'Could not start biometric login.');const pk=publicKeyFromOptions(d.publicKey);showStatus('Touch your fingerprint sensor now. If your device shows a Passkey prompt, choose your registered fingerprint/device credential.','success');let c=null;try{c=await navigator.credentials.get({publicKey:pk,mediation:'optional'});}catch(firstErr){c=await navigator.credentials.get({publicKey:pk});}if(!c)throw new Error('Biometric login was cancelled.');showStatus('Fingerprint accepted. Verifying your biometric credential…','success');const v=await fetch('php/biometric.php?action=login_verify',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify(credentialJSON(c))});const vraw=await v.text();let vd;try{vd=JSON.parse(vraw)}catch(e){throw new Error('Server returned an invalid verification response. Check PHP/MySQL errors and that schema.sql is imported.')}if(!v.ok||!vd.ok)throw new Error(vd.message||'Biometric verification failed.');showStatus('Login successfully! Fingerprint verified. Redirecting…','success');setTimeout(()=>location.href=vd.redirect||(vd.role==='instructor'?INSTRUCTOR_APP_URL:STUDENT_APP_URL),1200)}catch(err){showStatus(err.message||'Biometric login failed.','error');btn.disabled=false;btn.removeAttribute('aria-busy');btn.textContent=btn.dataset.originalText||'Log In with Fingerprint / Biometrics'}});

async function handleLogin(e){
  e.preventDefault();
  const id=$('loginId').value.trim(), pass=$('loginPassword').value;
  const remember = !!( $('rememberMe') && $('rememberMe').checked );
  markInvalid('f-login-id',!id);markInvalid('f-login-pass',!pass);if(!id||!pass){showStatus('Please fill in all required fields.','error');return false}
  if(!ID_PATTERN.test(id)){markInvalid('f-login-id',true);showStatus('Log in with your Student ID or Teacher ID (letters, numbers, . _ - only) — not an email address.','error');return false}
  showStatus('Logging in…','success');
  try{
    const d=await post('login',{identity:id,password:pass});
    // Remember me: save ID + password for next visit on this browser
    try {
      if (remember) {
        localStorage.setItem('csj_remember_login', JSON.stringify({ id: id, password: pass, savedAt: Date.now() }));
      } else {
        localStorage.removeItem('csj_remember_login');
      }
    } catch (storeErr) {}
    showStatus('Login successful. Redirecting…','success');
    setTimeout(()=>location.href=d.redirect||STUDENT_APP_URL,350);
  }catch(err){showStatus(err.message,'error')}
  return false;
}

/** Restore Remember-me credentials into the login form on page load. */
function csjRestoreRememberMe(){
  try {
    const raw = localStorage.getItem('csj_remember_login');
    if (!raw) return;
    const data = JSON.parse(raw);
    if (!data || typeof data !== 'object') return;
    const idEl = $('loginId');
    const passEl = $('loginPassword');
    const cb = $('rememberMe');
    if (idEl && data.id) idEl.value = String(data.id);
    if (passEl && data.password != null) passEl.value = String(data.password);
    if (cb) cb.checked = true;
  } catch (e) {}
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', csjRestoreRememberMe);
} else {
  csjRestoreRememberMe();
}
async function handleSignup(e){
  e.preventDefault();
  const role=document.querySelector('input[name="role"]:checked').value;
  const fullName=$('fullName').value.trim(), schoolId=$('schoolId').value.trim(), courseCode=($('courseSignup')||{}).value||'', yearLevel=($('yearLevelSignup')||{}).value||'', course=(courseCode&&yearLevel)?(courseCode+' '+yearLevel):($('courseYearSignup').value.trim()), email=$('signupEmail').value.trim(), p1=$('signupPassword').value, p2=$('signupPassword2').value;
  const major=($('majorSignup')||{}).value||'';
  const status=($('statusSignup')||{}).value||'';
  const needsMajor = role==='student' && !!(MAJORS_BY_COURSE[courseCode]||MAJORS_BY_COURSE[String(courseCode).toUpperCase()]||[]).length;
  if($('courseYearSignup')) $('courseYearSignup').value=course;
  const emailPattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const needsCourse = role==='student';
  markInvalid('f-fullname',!fullName);markInvalid('f-schoolid',!schoolId);markInvalid('f-course',needsCourse&&!course);markInvalid('f-major',needsMajor&&!major);markInvalid('f-status',needsCourse&&!status);markInvalid('f-email',!emailPattern.test(email));markInvalid('f-pass1',p1.length<8);markInvalid('f-pass2',!p2||p1!==p2);
  const pickedSubjects=(typeof window.CSJ_GET_SIGNUP_SUBJECTS==='function')?window.CSJ_GET_SIGNUP_SUBJECTS():[];
  const needsSubjects=role==='teacher';
  markInvalid('f-subject',needsSubjects&&pickedSubjects.length===0);
  if(needsSubjects&&pickedSubjects.length===0&&fullName&&schoolId&&emailPattern.test(email)&&p1.length>=8&&p1===p2){showStatus('Please click “Load Subjects” and choose the subject(s) you handle before signing up.','error');return false}
  if(schoolId&&!ID_PATTERN.test(schoolId)){markInvalid('f-schoolid',true);showStatus('Your '+(role==='student'?'Student':'Teacher')+' ID may contain only letters, numbers, . _ - (no spaces or symbols).','error');return false}
  if(!fullName||!schoolId||(needsCourse&&!course)||(needsMajor&&!major)||(needsCourse&&!status)||!emailPattern.test(email)||p1.length<8||p1!==p2||(needsSubjects&&pickedSubjects.length===0)){showStatus('Please review the highlighted fields.','error');return false}
  showStatus('Creating account…','success');
  try{const loadSubjects=(typeof window.CSJ_GET_SIGNUP_SUBJECTS==='function')?window.CSJ_GET_SIGNUP_SUBJECTS():[];
  const dept=($('subjectCode')&&$('subjectCode').value||'').trim();
  const payload=role==='student'?{studentId:schoolId,studentName:fullName,courseYear:course,program:courseCode,yearLevel:yearLevel,major:major,enrollmentStatus:status,email,password:p1}:{teacherId:schoolId,fullName,email,password:p1,department:dept,subjects:loadSubjects};
  const d=await post(role==='student'?'signup':'instructor_signup',payload);showStatus(d.message,'success');setTimeout(()=>location.href=d.redirect||(role==='instructor'?INSTRUCTOR_APP_URL:STUDENT_APP_URL),500)}catch(err){showStatus(err.message,'error');return false}
  return false;
}
function forgotPassword(){location.href='forgot-password.php';return false}
selectRole('student');
</script>


<script>
(function(){
  function wireToggle(btnId, inputId){
    var btn = document.getElementById(btnId);
    var inp = document.getElementById(inputId);
    if(!btn || !inp) return;
    btn.addEventListener('click', function(){
      var show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      btn.textContent = show ? '🙈' : '👁️';
    });
  }
  wireToggle('toggleLoginPassword','loginPassword');
  wireToggle('toggleSignupPassword','signupPassword');
  updateMajorOptions();
  wireToggle('toggleSignupPassword2','signupPassword2');
  // Support #signup / #login deep links
  if (location.hash === '#signup') {
    try { if (typeof switchTab === 'function') switchTab('signup'); } catch(e) {}
  }
})();
</script>



<dialog id="signupSubjectsDialog" class="csj-dialog" aria-labelledby="signupSubjectsTitle">
  <div class="dialog-form" id="signupSubjectsForm">
    <div class="signup-subj-head">
      <h2 id="signupSubjectsTitle">Choose Subject(s) You Handle</h2>
      <button type="button" id="signupSubjectsCloseX" class="signup-subj-x" aria-label="Close">&times;</button>
    </div>
    <p class="signup-subj-sub">Semester: <span id="signupSubjectsSemester"><?= htmlspecialchars($csjSignupSemester, ENT_QUOTES) ?></span></p>
    <input type="text" id="signupSubjectSearch" class="signup-subj-search" placeholder="Search subject code, e.g. FM303 or ENG" autocomplete="off">
    <div id="signupSubjectList" class="signup-subj-list">
      <?php if (empty($csjSignupSubjectCodes)): ?>
        <p class="signup-subj-empty">No subject codes found. Check that php/subjects_catalog.php exists, then reload.</p>
      <?php else: foreach ($csjSignupSubjectCodes as $code): ?>
        <label class="signup-subj-item" data-code="<?= htmlspecialchars(strtoupper((string)$code), ENT_QUOTES) ?>">
          <input type="checkbox" class="signup-subject-check" value="<?= htmlspecialchars((string)$code, ENT_QUOTES) ?>">
          <span><?= htmlspecialchars((string)$code) ?></span>
        </label>
      <?php endforeach; endif; ?>
      <p class="signup-subj-empty" id="signupSubjectNoMatch" style="display:none;">No subject matches your search.</p>
    </div>
    <div class="signup-subj-actions">
      <span id="signupSubjectsCount" class="signup-subj-count">0 subjects selected</span>
      <button type="button" class="btn-save" id="signupSubjectsSave">Save Selections</button>
    </div>
  </div>
</dialog>

<script>
(function(){
  'use strict';
  var saved = new Set();   // committed by "Save Selections"
  var draft = new Set();   // live ticks while the dialog is open
  var dlg = document.getElementById('signupSubjectsDialog');
  var btn = document.getElementById('loadSubjectsBtn');
  var summary = document.getElementById('loadSubjectsSummary');
  var chips = document.getElementById('loadSubjectsChips');
  var hidden = document.getElementById('loadSubjectsValues');
  var list = document.getElementById('signupSubjectList');
  var search = document.getElementById('signupSubjectSearch');
  var countEl = document.getElementById('signupSubjectsCount');
  var noMatch = document.getElementById('signupSubjectNoMatch');

  function label(n){ return n + ' subject' + (n === 1 ? '' : 's') + ' selected'; }

  function renderSaved(){
    if (summary) summary.textContent = label(saved.size);
    if (hidden) hidden.value = Array.from(saved).join(',');
    if (chips) {
      chips.innerHTML = '';
      Array.from(saved).sort().forEach(function(code){
        var s = document.createElement('span'); s.textContent = code; chips.appendChild(s);
      });
    }
    var f = document.getElementById('f-subject');
    if (f && saved.size) f.classList.remove('invalid');
  }
  function renderDraft(){
    if (countEl) countEl.textContent = label(draft.size);
    list.querySelectorAll('.signup-subj-item').forEach(function(lab){
      var cb = lab.querySelector('input');
      lab.classList.toggle('is-checked', !!(cb && cb.checked));
    });
  }
  function applyFilter(){
    var q = (search.value || '').trim().toUpperCase().replace(/\s+/g,'');
    var shown = 0;
    list.querySelectorAll('.signup-subj-item').forEach(function(lab){
      var code = (lab.getAttribute('data-code') || '').replace(/[\s-]/g,'');
      var hit = !q || code.indexOf(q.replace(/-/g,'')) !== -1;
      lab.style.display = hit ? '' : 'none';
      if (hit) shown++;
    });
    if (noMatch) noMatch.style.display = shown ? 'none' : '';
  }

  function openDlg(){
    if (!dlg) { alert('Subject picker is not available. Please reload the page.'); return; }
    draft = new Set(saved);
    list.querySelectorAll('.signup-subject-check').forEach(function(cb){ cb.checked = draft.has(cb.value); });
    search.value = ''; applyFilter(); renderDraft();
    if (typeof dlg.showModal === 'function') dlg.showModal();
    else { dlg.setAttribute('open','open'); }
    list.scrollTop = 0;
    setTimeout(function(){ try { search.focus(); } catch(e){} }, 30);
  }
  function closeDlg(){
    if (!dlg) return;
    if (typeof dlg.close === 'function') dlg.close(); else dlg.removeAttribute('open');
  }

  if (btn) btn.addEventListener('click', function(e){ e.preventDefault(); e.stopPropagation(); openDlg(); });
  document.getElementById('signupSubjectsCloseX').addEventListener('click', closeDlg);   // discards unsaved ticks

  // click on the dark backdrop closes (discarding), clicks inside do nothing
  dlg.addEventListener('mousedown', function(e){
    if (e.target === dlg) closeDlg();
  });

  list.addEventListener('change', function(e){
    var t = e.target;
    if (!t.classList || !t.classList.contains('signup-subject-check')) return;
    if (t.checked) draft.add(t.value); else draft.delete(t.value);
    renderDraft();
  });
  search.addEventListener('input', applyFilter);
  search.addEventListener('keydown', function(e){ if (e.key === 'Enter') e.preventDefault(); });

  document.getElementById('signupSubjectsSave').addEventListener('click', function(){
    saved = new Set(draft);
    renderSaved();
    closeDlg();
  });

  renderSaved();
  window.CSJ_GET_SIGNUP_SUBJECTS = function(){ return Array.from(saved); };
})();
</script>

</body>
</html>
