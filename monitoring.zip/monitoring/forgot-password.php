<?php require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Request Password Help - CSJ Self-Monitoring</title>
  <link rel="icon" href="assets/logos/csj-seal.jpg">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <img src="assets/logos/csj-seal.jpg" class="brand-logo" alt="Colegio de San Jose seal">
      <div class="brand-text">
        <span class="brand-title">CSJ Self-Monitoring Dashboard</span>
        <span class="brand-sub">Password Recovery</span>
      </div>
    </div>
  </header>
  <main style="min-height:calc(100vh - 100px);display:flex;align-items:center;justify-content:center;padding:24px;">
    <section style="width:min(460px,100%);background:var(--paper);border:1px solid var(--line);border-radius:var(--radius-lg);padding:26px;box-shadow:var(--shadow-card);">
      <h1 style="margin:0 0 5px;color:var(--pine-900);font-family:var(--font-display);">Request password help</h1>
      <p style="margin:0 0 18px;color:var(--ink-soft);font-size:12px;line-height:1.6;">Submit a request to the Dean’s office. A Dean will verify your identity and reset the account. No OTP or email notification is sent.</p>
      <form id="forgotForm">
        <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;">Account type
          <select id="forgotRole" required style="display:block;width:100%;margin-top:5px;padding:10px;border:1px solid var(--line);border-radius:6px;background:var(--paper);">
            <option value="student">Student</option>
            <option value="teacher">Teacher</option>
          </select>
        </label>
        <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;">Student ID / Teacher ID or account email
          <input id="forgotIdentity" required maxlength="150" autocomplete="username" style="display:block;width:100%;margin-top:5px;padding:10px;border:1px solid var(--line);border-radius:6px;box-sizing:border-box;">
        </label>
        <label style="display:block;margin-bottom:12px;font-size:12px;font-weight:600;">Note for the Dean’s office (optional)
          <textarea id="forgotReason" maxlength="500" rows="3" style="display:block;width:100%;margin-top:5px;padding:10px;border:1px solid var(--line);border-radius:6px;box-sizing:border-box;resize:vertical;"></textarea>
        </label>
        <button class="btn btn-primary" type="submit" style="width:100%;">Send request</button>
      </form>
      <div id="forgotStatus" role="status" aria-live="polite" style="min-height:18px;margin-top:10px;font-size:12px;color:var(--ink-soft);"></div>
      <div style="text-align:center;margin-top:12px;font-size:11px;"><a href="index.php" style="color:var(--pine-800);">Back to login</a></div>
    </section>
  </main>
  <script src="js/auth.js?v=2"></script>
</body>
</html>
