/*
 * CSJ Self-Monitoring Dashboard - client logic
 * Existing visual design is kept. This file only adds functionality:
 * - text gets SMALLER when a learning cell becomes full
 * - Prelims / Midterms / Finals sheets are separate panels, paged with
 *   Previous / Next, each printing on its own single page
 * - Submit saves the profile + ALL THREE monitoring sheets to MySQL
 * - Profile opens the current student's profile
 * - Print keeps the existing print layout (only the active sheet prints)
 */
(function () {
  'use strict';

  
  let CSJ_CHART_LOCKED = false;

  function isPeriodDeanApproved(panel) {
    if (!panel) return false;
    return panel.dataset.deanApproved === '1';
  }

  /* A period is LOCKED until the Dean approves the one before it:
     Midterms needs Prelims approved, Finals needs Midterms approved.
     The server decides (data-locked / php/load.php "access"); this only mirrors it. */
  function isPeriodLocked(period) {
    const panel = document.querySelector('.period-panel[data-period="' + period + '"]');
    return !!panel && panel.dataset.locked === '1';
  }

  const LOCK_HINTS = {
    midterms: 'Midterms unlocks after the Dean approves your Prelims.',
    finals: 'Finals unlocks after the Dean approves your Midterms.'
  };

  /* Keeps the little step dots and the Next button in step with the lock state. */
  function updateTabsUI() {
    const order = ['prelims', 'midterms', 'finals'];
    const active = document.querySelector('.period-panel.is-active');
    const activeKey = active ? active.dataset.period : order[0];
    order.forEach((key) => {
      const dot = document.querySelector('.period-step[data-step="' + key + '"]');
      if (dot) dot.classList.toggle('is-locked', isPeriodLocked(key));
    });
    const idx = order.indexOf(activeKey);
    const nextBtn = document.getElementById('periodNext');
    if (nextBtn) {
      const nextKey = order[idx + 1];
      nextBtn.disabled = !nextKey || isPeriodLocked(nextKey);
      nextBtn.title = (nextKey && isPeriodLocked(nextKey)) ? (LOCK_HINTS[nextKey] || '') : '';
    }
  }

  function updatePeriodLockUI() {
    const banner = document.getElementById('chartLockedBanner');
    const active = document.querySelector('.period-panel.is-active');
    const locked = isPeriodDeanApproved(active);
    CSJ_CHART_LOCKED = locked;
    if (banner) {
      banner.style.display = locked ? '' : 'none';
    }
    // Only lock cells inside approved periods; unlock others
    document.querySelectorAll('.period-panel').forEach((panel) => {
      const on = isPeriodDeanApproved(panel) || panel.dataset.locked === '1';
      panel.querySelectorAll('.cell-text').forEach((c) => {
        c.setAttribute('contenteditable', on ? 'false' : 'true');
        c.style.cursor = on ? 'default' : '';
      });
      panel.querySelectorAll('.subject-code-input').forEach((i) => {
        i.readOnly = on;
        i.disabled = on;
      });
    });
    const sb = document.getElementById('submitBtn');
    // Submit still allowed for other periods; disabled only if ALL visible? Keep enabled so student can submit unlocked periods.
    if (sb) sb.disabled = false;
  }

  const BASE = window.CSJ_BASE || '';
  const MAX_FONT = 12.5;
  const MIN_FONT = 6;
  const STEP = 0.25;

  // Order the Previous/Next control pages through the sheets in.
  const PERIOD_ORDER = ['prelims', 'midterms', 'finals'];
  const PERIOD_LABELS = { prelims: 'Prelims', midterms: 'Midterms', finals: 'Finals' };

  // Allowed subject codes (from php/subjects_catalog.php via window.CSJ_SUBJECT_CODES)
  const ALLOWED_SUBJECT_CODES = (Array.isArray(window.CSJ_SUBJECT_CODES) ? window.CSJ_SUBJECT_CODES : []).map((c) =>
    String(c || '').trim().toUpperCase().replace(/-\d+$/, '').replace(/\s+/g, '')
  );
  const ALLOWED_SUBJECT_SET = new Set(ALLOWED_SUBJECT_CODES);

  function normSubjectCode(s) {
    // Uppercase, drop spaces, drop trailing section suffix (-1, -2, …)
    return String(s || '').trim().toUpperCase().replace(/-\d+$/, '').replace(/\s+/g, '');
  }

    function isValidSubjectCode(code) {
    const n = normSubjectCode(code);
    if (!n) return true; // empty allowed
    // If no catalog was loaded, do not block the student
    if (!ALLOWED_SUBJECT_CODES.length) return true;
    if (ALLOWED_SUBJECT_SET.has(n)) return true;
    for (const c of ALLOWED_SUBJECT_CODES) {
      if (normSubjectCode(c) === n) return true;
    }
    // Accept value that exists as an option in any subject select (chosen from dropdown)
    try {
      const opts = document.querySelectorAll('select.subject-code-input option');
      for (const o of opts) {
        const v = (o.value || '').trim();
        if (v && normSubjectCode(v) === n) return true;
      }
    } catch (_) {}
    return false;
  }

  /** First subject-code input that has a non-empty invalid code, or null. */
  function findDuplicateSubjectCodeInput() {
    // A code may appear only once on a SINGLE period sheet. The same subject is of course
    // allowed on Prelims, Midterms and Finals, so each sheet is checked on its own.
    const panels = document.querySelectorAll('.period-panel');
    for (const panel of panels) {
      const seen = new Set();
      for (const input of panel.querySelectorAll('.subject-code-input')) {
        const n = normSubjectCode(input.value);
        if (!n) continue;
        if (seen.has(n)) return input;
        seen.add(n);
      }
    }
    return null;
  }

  function findInvalidSubjectCodeInput() {
    const inputs = document.querySelectorAll('.subject-code-input');
    for (const input of inputs) {
      const v = (input.value || '').trim();
      if (!v) continue;
      if (!isValidSubjectCode(v)) return input;
    }
    return null;
  }

  function flagInvalidSubjectInput(input) {
    if (!input) return;
    const panel = input.closest('.period-panel');
    if (panel && panel.dataset.period && typeof showPeriod === 'function') {
      try { showPeriod(panel.dataset.period); } catch (_) {}
    }
    input.classList.add('subject-code-invalid');
    input.style.outline = '2px solid #b3452f';
    input.scrollIntoView({ behavior: 'smooth', block: 'center' });
    input.focus();
    setTimeout(() => {
      input.classList.remove('subject-code-invalid');
      input.style.outline = '';
    }, 4000);
  }

  function autosize(el) {
    if (!el) return;
    let size = MAX_FONT;
    el.style.fontSize = size + 'px';

    let guard = 0;
    while (
      (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1) &&
      size > MIN_FONT &&
      guard < 40
    ) {
      size -= STEP;
      el.style.fontSize = size + 'px';
      guard++;
    }
  }

  function autosizeAll(scope) {
    (scope || document).querySelectorAll('.cell-text').forEach(autosize);
  }

  function debounce(fn, wait) {
    let t;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  /* --------------------------------------------------------------- */
  /* Prelims / Midterms / Finals navigation                           */
  /* --------------------------------------------------------------- */

  function getPanel(period) {
    return document.querySelector('.period-panel[data-period="' + period + '"]');
  }

  function currentPeriod() {
    const active = document.querySelector('.period-panel.is-active');
    return active ? active.dataset.period : PERIOD_ORDER[0];
  }

  function showPeriod(period) {
    if (PERIOD_ORDER.indexOf(period) === -1) return;
    // A locked sheet can never be opened (buttons, arrow keys, focus helpers all end up here).
    if (isPeriodLocked(period)) return;

    document.querySelectorAll('.period-panel').forEach((panel) => {
      panel.classList.toggle('is-active', panel.dataset.period === period);
    });

    const panel = getPanel(period);
    const titleEl = document.getElementById('chartTitle');
    if (panel && titleEl) {
      titleEl.textContent = panel.dataset.chartTitle || titleEl.textContent;
    }

    const labelEl = document.getElementById('periodLabel');
    if (labelEl) labelEl.textContent = PERIOD_LABELS[period] || period;

    document.querySelectorAll('.period-step').forEach((step) => {
      step.classList.toggle('is-current', step.dataset.step === period);
    });

    // Update Dean signature (bottom, right of Course & Year) for active period
    if (panel) {
      const approved = panel.dataset.deanApproved === '1';
      const sig = document.getElementById('bottomDeanSig') || document.querySelector('[data-dean-sig]');
      if (sig) {
        sig.classList.toggle('is-approved', approved);
        if (approved) {
          sig.innerHTML = '<strong>Approved</strong>';
        } else {
          sig.innerHTML = '&nbsp;';
        }
      }
    }

    const index = PERIOD_ORDER.indexOf(period);
    const prevBtn = document.getElementById('periodPrev');
    const nextBtn = document.getElementById('periodNext');
    if (prevBtn) prevBtn.disabled = index <= 0;
    if (nextBtn) nextBtn.disabled = index >= PERIOD_ORDER.length - 1 || isPeriodLocked(PERIOD_ORDER[index + 1]);

    // Cells in the panel that just became visible need their font
    // re-measured now that they actually have real width/height.
    if (panel) autosizeAll(panel);
  
    updatePeriodLockUI();
    updateTabsUI();
  }

  function stepPeriod(delta) {
    const index = PERIOD_ORDER.indexOf(currentPeriod());
    const nextIndex = index + delta;
    if (nextIndex < 0 || nextIndex >= PERIOD_ORDER.length) return;
    if (isPeriodLocked(PERIOD_ORDER[nextIndex])) { updateTabsUI(); return; }
    showPeriod(PERIOD_ORDER[nextIndex]);
  }

  /* --------------------------------------------------------------- */
  /* Collecting / saving all three sheets                              */
  /* --------------------------------------------------------------- */

  /** Current date-time in Philippine Standard Time (Asia/Manila), wall-clock string. */
  function philippineNowStamp() {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Manila',
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      hour12: false
    }).formatToParts(new Date());
    const g = (t) => (parts.find((p) => p.type === t) || {}).value || '00';
    return g('year') + '-' + g('month') + '-' + g('day') + ' ' + g('hour') + ':' + g('minute') + ':' + g('second');
  }

  function collectPeriodFromPanel(panel) {
    const subjects = [];
    panel.querySelectorAll('.subject-code-input').forEach((input) => {
      const id = parseInt(input.dataset.subject, 10);
      const approveCell = panel.querySelector('.approve-cell[data-subject="' + id + '"]');
      subjects.push({
        id,
        code: input.value.trim(),
        // Approval is read-only on this dashboard.
        instructor: approveCell ? approveCell.querySelector('.instructor-name').textContent.trim() : '',
        approved: approveCell ? approveCell.querySelector('.approve-box').classList.contains('is-approved') : false
      });
    });

    const rows = [];
    const nowStamp = philippineNowStamp();
    panel.querySelectorAll('.entry-row').forEach((tr) => {
      const event = parseInt(tr.dataset.event, 10);
      const entries = {};
      const entryTimes = {};
      tr.querySelectorAll('.cell-text').forEach((cell) => {
        const sid = String(cell.dataset.subject || '');
        const text = (cell.textContent || '').trim();
        entries[sid] = text;
        if (text) {
          const prev = cell.dataset.lastSavedText || '';
          const prevTime = cell.dataset.lastSavedAt || '';
          // New or changed text → stamp now; unchanged → keep previous time
          entryTimes[sid] = (text !== prev || !prevTime) ? nowStamp : prevTime;
        }
      });
      rows.push({ event, entries, entryTimes });
    });

    return {
      chartTitle: panel.dataset.chartTitle || '',
      subjects,
      rows,
      deanApproved: panel.dataset.deanApproved === '1',
      deanApprovedBy: panel.dataset.deanBy || ''
    };
  }

  function collectChart() {
    const periods = {};
    document.querySelectorAll('.period-panel').forEach((panel) => {
      periods[panel.dataset.period] = collectPeriodFromPanel(panel);
    });

    return {
      meta: {
        college: document.querySelector('.letterhead-text h1')?.textContent.trim() || '',
        department: document.querySelector('.letterhead-text h2')?.textContent.trim() || '',
        semester: document.querySelector('.letterhead-text .semester')?.textContent.trim() || '',
        studentName: document.getElementById('studentName')?.value.trim() || '',
        courseYear: document.getElementById('courseYear')?.value.trim() || ''
      },
      periods
    };
  }

  function collectProfile() {
    return {
      studentId: document.getElementById('profileStudentId')?.value.trim() || '',
      studentName: document.getElementById('profileName')?.value.trim() || document.getElementById('studentName')?.value.trim() || '',
      courseYear: document.getElementById('profileCourseYear')?.value.trim() || document.getElementById('courseYear')?.value.trim() || '',
      email: document.getElementById('profileEmail')?.value.trim() || '',
      address: document.getElementById('profileAddress')?.value.trim() || '',
      contactNo: ((document.getElementById('profilePhone')||{}).value||'').trim(),
      guardian: document.getElementById('profileGuardian')?.value.trim() || ''
    };
  }

  function b64urlToBytes(v) {
    v = v.replace(/-/g, '+').replace(/_/g, '/');
    while (v.length % 4) v += '=';
    const s = atob(v), a = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i);
    return a;
  }
  function bytesToB64url(b) {
    let s = '';
    new Uint8Array(b).forEach(x => s += String.fromCharCode(x));
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function webauthnOptions(pk) {
    const o = Object.assign({}, pk);
    o.challenge = b64urlToBytes(pk.challenge);
    if (pk.user) o.user = Object.assign({}, pk.user, {id:b64urlToBytes(pk.user.id)});
    if (pk.excludeCredentials) o.excludeCredentials = pk.excludeCredentials.map(c => Object.assign({}, c, {id:b64urlToBytes(c.id)}));
    if (pk.allowCredentials) o.allowCredentials = pk.allowCredentials.map(c => Object.assign({}, c, {id:b64urlToBytes(c.id)}));
    return o;
  }
  function credentialPayload(c) {
    const r = {id:c.id, rawId:bytesToB64url(c.rawId), type:c.type, response:{}};
    if (c.response.clientDataJSON) r.response.clientDataJSON = bytesToB64url(c.response.clientDataJSON);
    if (c.response.attestationObject) r.response.attestationObject = bytesToB64url(c.response.attestationObject);
    if (c.response.authenticatorData) r.response.authenticatorData = bytesToB64url(c.response.authenticatorData);
    if (c.response.signature) r.response.signature = bytesToB64url(c.response.signature);
    if (c.response.userHandle) r.response.userHandle = bytesToB64url(c.response.userHandle);
    return r;
  }

  async function saveProfile() {
    const status = document.getElementById('profileSaveStatus');
    if (status) status.textContent = 'Saving profile…';
    try {
      const payload = collectProfile();
      const res = await fetch(BASE + 'php/account.php?action=save_profile', {method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify(payload)});
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.message || 'Could not save profile.');
      if (status) status.textContent = '✓ ' + (data.message || 'Profile saved successfully.');
      // Re-load profile so Phone Number stays visible (from student_phone_numbers)
      try {
        const r2 = await fetch(BASE + 'php/profile.php', { cache: 'no-store', credentials: 'same-origin' });
        const d2 = await r2.json();
        if (d2 && d2.ok && d2.profile) {
          const phoneEl = document.getElementById('profilePhone');
          if (phoneEl) phoneEl.value = d2.profile.contact_no || payload.contactNo || '';
        }
      } catch (_) {}
      setTimeout(() => { if(status) status.textContent=''; }, 2500);
    } catch (err) { if (status) status.textContent = err.message || 'Could not save profile.'; }
  }

  async function openProfile() {
    const dialog = document.getElementById('profileDialog');
    try {
      const res = await fetch(BASE + 'php/profile.php', { cache: 'no-store', credentials:'same-origin' });
      const data = await res.json();
      if (data.ok && data.profile) {
        const p=data.profile;
        document.getElementById('profileStudentId').value = p.student_id || '';
        document.getElementById('profileName').value = p.student_name || document.getElementById('studentName').value || '';
        document.getElementById('profileCourseYear').value = p.course_year || document.getElementById('courseYear').value || '';
        const stEl = document.getElementById('profileStatus');
        if (stEl) stEl.value = p.enrollment_status ? (p.enrollment_status.charAt(0).toUpperCase() + p.enrollment_status.slice(1)) : '';
        const mjEl = document.getElementById('profileMajor');
        if (mjEl) mjEl.value = p.major || '';
        document.getElementById('profileEmail').value = p.email || '';
        document.getElementById('profileAddress').value = p.address || '';
        document.getElementById('profilePhone').value = p.contact_no || '';
        document.getElementById('profileGuardian').value = p.guardian || '';
        setPhotoPreview(p.photo_path || '', document.getElementById('profileName').value);
        
      }
    } catch (_) {
      document.getElementById('profileName').value = document.getElementById('studentName').value || '';
      document.getElementById('profileCourseYear').value = document.getElementById('courseYear').value || '';
    }
    dialog.showModal();
  }

  function escapeHtml(v){ return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }


  async function openPasswordDialog() {
    const d=document.getElementById('passwordDialog');
    document.getElementById('currentPassword').value='';document.getElementById('newPassword').value='';document.getElementById('newPassword2').value='';document.getElementById('passwordStatus').textContent='';
    try { const r=await fetch(BASE+'php/account.php?action=profile_status',{credentials:'same-origin'}); const x=await r.json(); const legacy=!r.ok||!x.ok; document.getElementById('currentPasswordWrap').style.display=legacy?'none':'block'; document.getElementById('passwordHint').textContent=legacy?'Set your first password.':'Change your account password.'; } catch(_) { document.getElementById('currentPasswordWrap').style.display='none'; }
    if(!d.open)d.showModal();
  }
  async function savePassword() {
    const cur=document.getElementById('currentPassword').value,newP=document.getElementById('newPassword').value,newP2=document.getElementById('newPassword2').value,st=document.getElementById('passwordStatus');
    if(newP.length<8){st.textContent='Password must be at least 8 characters.';return} if(newP!==newP2){st.textContent='Passwords do not match.';return}
    const legacy=document.getElementById('currentPasswordWrap').style.display==='none';st.textContent='Saving…';
    try{const action=legacy?'set_password_legacy':'change_password';const body=legacy?{newPassword:newP}:{currentPassword:cur,newPassword:newP};const r=await fetch(BASE+'php/account.php?action='+action,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify(body)});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.message||'Could not save password.');st.textContent='✓ '+d.message;setTimeout(()=>document.getElementById('passwordDialog').close(),700)}catch(e){st.textContent=e.message}}

  async function refreshFingerprintStatus() {
    const status = document.getElementById('fingerprintStatus');
    const button = document.getElementById('fingerprintBtn');
    if (!status || !button) return;
    try {
      const r = await fetch(BASE + 'php/biometric.php?action=status', {cache:'no-store', credentials:'same-origin'});
      const d = await r.json();
      if (r.ok && d.ok && d.enrolled) {
        status.textContent = '✓ Fingerprint/device biometric is ready on this account.';
        button.textContent = 'Fingerprint Registered';
      } else {
        status.textContent = 'Register your fingerprint for optional quick login. Your device will open its fingerprint/passkey prompt.';
        button.textContent = 'Register your fingerprint';
      }
    } catch (_) {
      status.textContent = '';
    }
  }

  async function enableFingerprint() {
    const status = document.getElementById('fingerprintStatus') || document.getElementById('emailVerificationStatus');
    const button = document.getElementById('fingerprintBtn');
    try {
      if (!window.isSecureContext) {
        throw new Error('Fingerprint/device biometrics requires a secure browser context (HTTPS or an allowed secure origin).');
      }
      if (!window.PublicKeyCredential || !navigator.credentials) {
        throw new Error('This browser does not support fingerprint/device biometrics. Try the latest Chrome or Edge on a device with Windows Hello or a fingerprint sensor.');
      }
      if (button) button.disabled = true;
      if (status) status.textContent = 'Preparing fingerprint registration…';
      const r = await fetch(BASE + 'php/biometric.php?action=options', {cache:'no-store', credentials:'same-origin'});
      const d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.message || 'Could not start fingerprint login. Save Student Name and Course & Year first.');
      if (status) status.textContent = 'Touch your fingerprint sensor now to register your fingerprint. Your device may show a Passkey prompt.';
      const c = await navigator.credentials.create({publicKey: webauthnOptions(d.publicKey)});
      if (!c) throw new Error('The biometric prompt was cancelled. Click the button again and complete the fingerprint/device prompt.');
      const vr = await fetch(BASE + 'php/biometric.php?action=register', {
        method:'POST', headers:{'Content-Type':'application/json'}, credentials:'same-origin',
        body:JSON.stringify(credentialPayload(c))
      });
      const vd = await vr.json();
      if (!vr.ok || !vd.ok) throw new Error(vd.message || 'Fingerprint/device biometric setup failed.');
      if (status) status.textContent = '✓ Your fingerprint is registered for optional quick login. You can still log in with your password.';
      if (button) button.textContent = 'Fingerprint Registered';

    } catch(e) {
      if (status) status.textContent = e.message || 'Fingerprint/device biometric setup failed.';
    } finally {
      if (button) button.disabled = false;
    }
  }

  /* --------------------------------------------------------------- */
  /* "What I learned" honesty check                                    */
  /*                                                                   */
  /* A simple, explainable rule to discourage copy-pasting someone     */
  /* else's entry: a capital letter is only "expected" right where a   */
  /* new sentence/clause naturally starts -- the very first letter of  */
  /* the cell, or the first letter after a period or comma. A capital  */
  /* letter anywhere else (a stray Proper Noun, an ALL-CAPS word, a    */
  /* trailing acronym...) usually means the text was pasted in rather  */
  /* than typed, so it flags the cell instead of silently accepting it.*/
  /* --------------------------------------------------------------- */
  function normalizeCellText(s) {
    return String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
  }

  /**
   * Each "What I learned" cell (subjects 1–9, all periods) must be unique —
   * like a password: the same text must not appear in any other cell.
   * Empty cells are allowed; any non-empty entry must be one-of-a-kind.
   */
  function findDuplicateCell() {
    const cells = Array.from(document.querySelectorAll('.cell-text'));
    const seen = new Map(); // normalized text -> first cell
    for (const cell of cells) {
      const raw = (cell.textContent || '').trim();
      if (!raw) continue;
      // Skip pure placeholder if the cell still shows the default hint only
      if (/^what i learned\.?\.?\.?$/i.test(raw)) continue;
      const key = normalizeCellText(raw);
      if (!key) continue;
      if (seen.has(key)) return cell; // second occurrence is the duplicate
      seen.set(key, cell);
    }
    return null;
  }

  /** Returns true if `cell`'s text already exists in another cell (password-style unique). */
  function isCellTextDuplicate(cell) {
    const raw = (cell.textContent || '').trim();
    if (!raw || /^what i learned\.?\.?\.?$/i.test(raw)) return false;
    const key = normalizeCellText(raw);
    if (!key) return false;
    const cells = document.querySelectorAll('.cell-text');
    for (const other of cells) {
      if (other === cell) continue;
      const otherKey = normalizeCellText((other.textContent || '').trim());
      if (otherKey && otherKey === key) return true;
    }
    return false;
  }

  /** True if `text` has an uppercase letter that isn't the first letter or right after "." / ",". */
  function hasDisallowedCapital(text) {
    let seenLetter = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (!/[A-Za-z]/.test(ch)) continue;
      if (ch === ch.toLowerCase()) { seenLetter = true; continue; } // lowercase letter -- fine
      if (!seenLetter) { seenLetter = true; continue; } // first letter of the cell -- fine
      let j = i - 1;
      while (j >= 0 && text[j] === ' ') j--;
      const prevChar = j >= 0 ? text[j] : '';
      if (prevChar === '.' || prevChar === ',') { seenLetter = true; continue; } // starts a new sentence/clause
      return true; // capital letter in a spot that isn't expected
    }
    return false;
  }

  /**
   * Missing space after comma/period before the next letter.
   * e.g. "Hello,John" (should be "Hello, John") or "Hi.There"
   * Pattern: letter/digit  +  "," or "."  +  letter  (no space in between)
   */
  function hasMissingSpaceAfterCommaOrPeriod(text) {
    const t = String(text || '');
    // letter/digit, then , or ., then letter with nothing in between
    return /[A-Za-z0-9][,.][A-Za-z]/.test(t);
  }

  function findDishonestCell() {
    // Block capitals in the middle/end of words, and comma/period glued to the next word
    // (e.g. "Hello,John" instead of "Hello, John").
    const cells = document.querySelectorAll('.cell-text');
    for (const cell of cells) {
      const text = (cell.textContent || '').trim();
      if (!text) continue;
      if (/^what i learned\.?\.?\.?$/i.test(text)) continue;
      if (hasDisallowedCapital(text)) return cell;
      if (hasMissingSpaceAfterCommaOrPeriod(text)) return cell;
    }
    return null;
  }

  /** Flag the first cell whose text matches the server-reported copied text. */
  function flagCopiedText(copiedText) {
    if (!copiedText) return;
    const target = normalizeCellText(copiedText);
    if (!target) return;
    const cells = document.querySelectorAll('.cell-text');
    for (const cell of cells) {
      if (normalizeCellText((cell.textContent || '').trim()) === target) {
        flagDishonestCell(cell);
        return;
      }
    }
  }

  function flagDishonestCell(cell) {
    const panel = cell.closest('.period-panel');
    if (panel && panel.dataset.period) showPeriod(panel.dataset.period);
    cell.classList.add('cell-flagged');
    cell.scrollIntoView({ behavior: 'smooth', block: 'center' });
    cell.focus();
    setTimeout(() => cell.classList.remove('cell-flagged'), 4000);
  }

  /** A proper, easy-to-see dialog for the "don't copy" honesty message --
      replaces cramming that message into the thin header status text. */

  // Live honesty check while typing/leaving a cell (comma without space, etc.)
  (function wireHonestyBlur() {
    if (window.csjHonestyBlurWired) return;
    window.csjHonestyBlurWired = true;
    document.addEventListener('focusout', function (e) {
      const cell = e.target && e.target.closest ? e.target.closest('.cell-text') : null;
      if (!cell) return;
      const text = (cell.textContent || '').trim();
      if (!text || /^what i learned\.?\.?\.?$/i.test(text)) return;
      if (hasDisallowedCapital(text) || hasMissingSpaceAfterCommaOrPeriod(text)) {
        flagDishonestCell(cell);
        showHonestyDialog("Don't copy what others have learned lets be honest what you have learned");
      }
    }, true);
  })();

  function showHonestyDialog(message) {
    const dlg = document.getElementById('honestyDialog');
    if (!dlg) return;
    const msgEl = document.getElementById('honestyDialogMessage');
    if (msgEl) msgEl.textContent = message || "Don't copy what others have learned lets be honest what you have learned";
    if (!dlg.open) dlg.showModal();
  }

  async function submitChart() {
    // Period-level lock: approved periods are sent as-is (server preserves them).
    // Student may still submit other periods that are not Dean-approved.

    const statusEl = document.getElementById('saveStatus');
    const btn = document.getElementById('submitBtn');
    const studentName = document.getElementById('studentName').value.trim();
    const courseYear = document.getElementById('courseYear').value.trim();

    if (!studentName || !courseYear) {
      statusEl.textContent = 'Add your Student Name and Course & Year in Profile first.';
      const profileDlg = document.getElementById('profileDialog');
      if (profileDlg && !profileDlg.open) profileDlg.showModal();
      const nameInput = document.getElementById('profileName');
      if (nameInput) nameInput.focus();
      setTimeout(() => { statusEl.textContent = ''; }, 4000);
      return;
    }

    // Same subject code cannot be selected more than once on the chart
    const dupCodeInput = findDuplicateSubjectCodeInput();
    if (dupCodeInput) {
      statusEl.textContent = 'The subject code is already selected.';
      flagInvalidSubjectInput(dupCodeInput);
      setTimeout(() => { statusEl.textContent = ''; }, 6000);
      return;
    }

    // Subject code must match the official catalog (or be left empty).
    const badCodeInput = findInvalidSubjectCodeInput();
    if (badCodeInput) {
      statusEl.textContent = 'Your subject code is wrong, please enter your Subject code.';
      flagInvalidSubjectInput(badCodeInput);
      setTimeout(() => { statusEl.textContent = ''; }, 6000);
      return;
    }

    // Capital-letter honesty check (middle/end of words not allowed).
    const dishonestCell = findDishonestCell();
    if (dishonestCell) {
      flagDishonestCell(dishonestCell);
      statusEl.textContent = '';
      showHonestyDialog("Don't copy what others have learned lets be honest what you have learned");
      return;
    }

    // Keep the profile dialog synchronized with the bottom fields.
    document.getElementById('profileName').value = studentName;
    document.getElementById('profileCourseYear').value = courseYear;

    btn.disabled = true;
    statusEl.textContent = 'Submitting…';

    try {
      const res = await fetch(BASE + 'php/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile: collectProfile(), chart: collectChart() })
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        if (data && data.copiedText) flagCopiedText(data.copiedText);
        const isHonestyViolation = /Don.t copy what others have learned/i.test(String(data.message || ''));
        if (isHonestyViolation) {
          statusEl.textContent = '';
          showHonestyDialog(data.message);
          btn.disabled = false;
          return;
        }
        throw new Error(data.message || 'Submission failed.');
      }
      statusEl.textContent = '';
      if (typeof window.csjShowSuccessDialog === 'function') {
        window.csjShowSuccessDialog('Submit Successfully', 'Your monitoring chart was submitted successfully.');
      } else {
        statusEl.textContent = 'Submit Successfully';
      }
      const savedStamp = philippineNowStamp();
      document.querySelectorAll('.cell-text').forEach((cell) => {
        const text = (cell.textContent || '').trim();
        cell.dataset.lastSavedText = text;
        if (text) cell.dataset.lastSavedAt = savedStamp;
        else delete cell.dataset.lastSavedAt;
      });
    } catch (err) {
      statusEl.textContent = err.message || 'Submission failed. Start MySQL and import schema.sql.';
    } finally {
      btn.disabled = false;
      setTimeout(() => { statusEl.textContent = ''; }, 6000);
    }
  }


  async function refreshFromServer() {
    try {
      const res = await fetch(BASE + 'php/load.php', { cache: 'no-store', credentials: 'same-origin' });
      if (!res.ok) return;
      const chart = await res.json();
      if (!chart || !chart.periods) return;

      // The Dean started a new semester while this page was open: reload so the
      // fresh (blank) monitoring sheet and the welcome popup appear automatically.
      if (typeof chart.transitionId === 'string' &&
          chart.transitionId !== String(window.CSJ_TRANSITION_ID || '')) {
        window.location.reload();
        return;
      }

      // Sequence lock coming from the server (Dean approvals unlock the next sheet live).
      if (chart.access && typeof chart.access === 'object') {
        PERIOD_ORDER.forEach((key) => {
          const panelForAccess = getPanel(key);
          if (!panelForAccess) return;
          const nowLocked = chart.access[key] === false;
          panelForAccess.dataset.locked = nowLocked ? '1' : '0';
        });
        // If the sheet being viewed just became locked (Dean cleared an approval), go back to the last open one.
        if (isPeriodLocked(currentPeriod())) {
          const lastOpen = PERIOD_ORDER.filter((k) => !isPeriodLocked(k)).pop() || PERIOD_ORDER[0];
          document.querySelectorAll('.period-panel').forEach((pn) => pn.classList.toggle('is-active', pn.dataset.period === lastOpen));
        }
      }

      Object.keys(chart.periods).forEach((periodKey) => {
        const panel = getPanel(periodKey);
        if (!panel) return;
        const period = chart.periods[periodKey];
        // Dean period-level approval
        const deanApproved = !!period.deanApproved;
        panel.dataset.deanApproved = deanApproved ? '1' : '0';
        panel.dataset.deanBy = period.deanApprovedBy || 'Dean';
        if (periodKey === currentPeriod()) {
          showPeriod(periodKey); // refresh signature display
        }
        if (!Array.isArray(period.subjects)) return;

        period.subjects.forEach((s) => {
          const id = Number(s.id);
          const cell = panel.querySelector('.approve-cell[data-subject="' + id + '"]');
          if (!cell) return;
          const box = cell.querySelector('.approve-box');
          const word = cell.querySelector('.approve-word');
          const name = cell.querySelector('.instructor-name');
          const icon = cell.querySelector('.approve-icon');
          const approved = !!s.approved;
          const instructorName = (s.instructor && String(s.instructor).trim() && s.instructor !== '—')
            ? String(s.instructor).trim()
            : '';
          box.classList.toggle('is-approved', approved);
          box.classList.toggle('is-pending', !approved);
          // Status word on top; instructor name always sits below (class="instructor-name")
          word.textContent = approved ? 'Approved' : 'Pending';
          if (name) {
            name.textContent = approved
              ? (instructorName || 'Instructor')
              : '—';
            name.style.fontWeight = approved ? '600' : '';
            name.style.fontStyle = approved ? 'normal' : 'italic';
            name.style.color = approved ? 'var(--pine-700, #1a4d2e)' : '';
          }
          // Keep the check / clock icon in sync with approval state
          if (icon) {
            if (approved) {
              icon.innerHTML = '<circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.12"/><path d="M7 12.5l3 3 7-7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>';
            } else {
              icon.innerHTML = '<circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-dasharray="3 3"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>';
            }
          }
        });
      });
      showPeriod(currentPeriod());   // re-sync label, pills, Next button and cell locks
    } catch (_) {
      // Keep the current page visible if the server is temporarily unavailable.
    }
  }

  function setPhotoPreview(url, nameForInitial) {
    const img = document.getElementById('profilePhotoPreview');
    const initial = document.getElementById('profilePhotoInitial');
    if (url) {
      img.src = url;
      img.style.display = '';
      initial.style.display = 'none';
    } else {
      img.style.display = 'none';
      initial.textContent = (nameForInitial || '?').trim().charAt(0).toUpperCase() || '?';
      initial.style.display = '';
    }
  }

  async function openProfile() {
    const dialog = document.getElementById('profileDialog');
    try {
      const res = await fetch(BASE + 'php/profile.php', { cache: 'no-store' });
      const data = await res.json();
      if (data.ok && data.profile) {
        document.getElementById('profileStudentId').value = data.profile.student_id || '';
        document.getElementById('profileName').value = data.profile.student_name || document.getElementById('studentName').value || '';
        document.getElementById('profileCourseYear').value = data.profile.course_year || document.getElementById('courseYear').value || '';
        document.getElementById('profileEmail').value = data.profile.email || '';
        setPhotoPreview(data.profile.photo_path || '', document.getElementById('profileName').value);
      }
    } catch (_) {
      document.getElementById('profileName').value = document.getElementById('studentName').value || '';
      document.getElementById('profileCourseYear').value = document.getElementById('courseYear').value || '';
    }
    dialog.showModal();
    refreshFingerprintStatus();
  }

  function uploadPhoto(file) {
    const statusEl = document.getElementById('profilePhotoStatus');
    const fd = new FormData();
    fd.append('photo', file);
    statusEl.textContent = 'Uploading…';
    fetch(BASE + 'php/upload_photo.php', { method: 'POST', body: fd })
      .then((res) => res.json())
      .then((data) => {
        if (!data.ok) throw new Error(data.message || 'Upload failed.');
        setPhotoPreview(data.photoPath, document.getElementById('profileName').value);
        statusEl.textContent = 'Photo saved.';
        setTimeout(() => { statusEl.textContent = ''; }, 3000);
      })
      .catch((err) => {
        statusEl.textContent = err.message || 'Could not upload photo.';
      });
  }


  function removeProfilePhoto() {
    const statusEl = document.getElementById('profilePhotoStatus');
    if (statusEl) statusEl.textContent = 'Removing…';
    const fd = new FormData();
    fd.append('remove', '1');
    fetch(BASE + 'php/upload_photo.php', { method: 'POST', body: fd, credentials: 'same-origin' })
      .then((res) => res.json())
      .then((data) => {
        if (!data.ok) throw new Error(data.message || 'Could not remove photo.');
        const img = document.getElementById('profilePhotoPreview');
        const initial = document.getElementById('profilePhotoInitial');
        if (img) { img.src = ''; img.style.display = 'none'; }
        if (initial) {
          const name = (document.getElementById('profileName') || {}).value || '';
          initial.textContent = name ? name.charAt(0).toUpperCase() : '?';
          initial.style.display = '';
        }
        if (typeof setPhotoPreview === 'function') setPhotoPreview('', (document.getElementById('profileName') || {}).value || '');
        if (statusEl) {
          statusEl.textContent = 'Photo removed.';
          setTimeout(() => { statusEl.textContent = ''; }, 3000);
        }
      })
      .catch((err) => {
        if (statusEl) statusEl.textContent = err.message || 'Could not remove photo.';
      });
  }


  const profilePhotoRemoveBtn = document.getElementById('profilePhotoRemoveBtn');
  if (profilePhotoRemoveBtn) {
    profilePhotoRemoveBtn.addEventListener('click', function () {
      if (!confirm('Remove your profile picture?')) return;
      removeProfilePhoto();
    });
  }
  function closeProfile() {
    document.getElementById('profileDialog').close();
  }

  function syncBottomFromProfile() {
    const name = document.getElementById('profileName').value.trim();
    const course = document.getElementById('profileCourseYear').value.trim();
    if (name) {
      document.getElementById('studentName').value = name;
      const nameLabel = document.getElementById('studentNameLabel');
      if (nameLabel) nameLabel.textContent = name;
    }
    if (course) {
      document.getElementById('courseYear').value = course;
      const courseLabel = document.getElementById('courseYearLabel');
      if (courseLabel) courseLabel.textContent = course;
    }
  }

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const id = btn.id || '';
    const map = { profileClose:'profileDialog', passwordClose:'passwordDialog', honestyDialogClose:'honestyDialog' };
    const dialogId = map[id];
    if (dialogId) { const d=document.getElementById(dialogId); if(d && d.open){ e.preventDefault(); d.close(); } }
  });

  document.addEventListener('DOMContentLoaded', () => {
    updatePeriodLockUI();

    // Make sure the nav (labels/dots/button states) matches whichever
    // panel was rendered active by the server.
    showPeriod(currentPeriod());
    autosizeAll();

    refreshFromServer();
    window.setInterval(refreshFromServer, 5000);

    document.querySelectorAll('.cell-text').forEach((cell) => {
      cell.addEventListener('input', debounce(() => autosize(cell), 80));
    });

    /* --------------------------------------------------------------- */
    /* Block copy / cut / paste ONLY inside the "What I learned" cells  */
    /* (.cell-text) of every period. The rest of the page -- the sheet  */
    /* header, subject codes, name fields, Profile, etc. -- keeps       */
    /* normal copy / paste.                                             */
    /* On an attempt -> Honesty dialog.                                 */
    /* --------------------------------------------------------------- */
    const HONESTY_COPY_MSG = "Don't copy what others have learned lets be honest what you have learned";

    function elementOf(node) {
      if (!node) return null;
      return node.nodeType === 1 ? node : node.parentElement;
    }

    // True when the event happened inside a learning cell.
    function isCellTextTarget(node) {
      const el = elementOf(node);
      return !!(el && el.closest && el.closest('.cell-text'));
    }

    // True when the user's current selection includes any learning cell
    // (e.g. Ctrl+A on the whole page, then Ctrl+C would otherwise copy the cells).
    function selectionTouchesCellText() {
      const sel = window.getSelection ? window.getSelection() : null;
      if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return false;
      const cells = document.querySelectorAll('.cell-text');
      for (const cell of cells) {
        try { if (sel.containsNode(cell, true)) return true; } catch (_) {}
      }
      return false;
    }

    function stopWithHonesty(e) {
      e.preventDefault();
      e.stopPropagation();
      showHonestyDialog(HONESTY_COPY_MSG);
      return false;
    }

    // paste: only when pasting INTO a cell
    document.addEventListener('paste', (e) => {
      if (isCellTextTarget(e.target)) stopWithHonesty(e);
    }, true);

    // copy / cut: from a cell, or from a selection that includes a cell
    ['copy', 'cut'].forEach((evt) => {
      document.addEventListener(evt, (e) => {
        if (isCellTextTarget(e.target) || selectionTouchesCellText()) stopWithHonesty(e);
      }, true);
    });

    // Ctrl/Cmd + C / V / X (and Ctrl+Insert / Shift+Insert / Shift+Delete)
    document.addEventListener('keydown', (e) => {
      const key = (e.key || '').toLowerCase();
      const mod = e.ctrlKey || e.metaKey;
      const isCopyCut = (mod && (key === 'c' || key === 'x')) || (e.ctrlKey && key === 'insert') || (e.shiftKey && key === 'delete');
      const isPaste = (mod && key === 'v') || (e.shiftKey && key === 'insert');
      if (!isCopyCut && !isPaste) return;
      const inCell = isCellTextTarget(e.target || document.activeElement);
      if (isPaste && inCell) return stopWithHonesty(e);
      if (isCopyCut && (inCell || selectionTouchesCellText())) return stopWithHonesty(e);
    }, true);

    // Right-click menu (Copy / Paste) inside a cell
    document.addEventListener('contextmenu', (e) => {
      if (isCellTextTarget(e.target)) stopWithHonesty(e);
    }, true);

    // Other ways text gets into a cell without Ctrl+V: drag & drop, and the
    // phone / browser "Paste" menu (reported as an input of type insertFromPaste/Drop).
    document.addEventListener('drop', (e) => {
      if (isCellTextTarget(e.target)) stopWithHonesty(e);
    }, true);
    document.addEventListener('dragstart', (e) => {
      if (isCellTextTarget(e.target)) { e.preventDefault(); }
    }, true);
    document.addEventListener('beforeinput', (e) => {
      if (!isCellTextTarget(e.target)) return;
      const t = e.inputType || '';
      if (t === 'insertFromPaste' || t === 'insertFromDrop' || t === 'insertFromYank' || t === 'deleteByCut') {
        stopWithHonesty(e);
      }
    }, true);

    /* Mobile: discourage long-press callout; any Copy/Paste still hits the
       clipboard listeners above and opens the Honesty dialog. */
    document.querySelectorAll('.cell-text').forEach((cell) => {
      cell.setAttribute('autocomplete', 'off');
      cell.setAttribute('autocorrect', 'off');
      cell.setAttribute('spellcheck', 'false');
    });

    // Subject comboboxes: prevent selecting a code already used on this chart
    function isSubjectCodeTaken(code, exceptInput) {
      const n = normSubjectCode(code);
      if (!n) return false;
      // Only the SAME period sheet counts. Scanning every sheet meant a subject used in
      // Prelims could never be chosen again in Midterms or Finals.
      const sheet = exceptInput && exceptInput.closest ? exceptInput.closest('.period-panel') : null;
      const inputs = (sheet || document).querySelectorAll('.subject-code-input');
      for (const other of inputs) {
        if (other === exceptInput) continue;
        if (normSubjectCode(other.value) === n) return true;
      }
      return false;
    }

    document.querySelectorAll('.subject-code-input').forEach((input) => {
      input.addEventListener('change', () => {
        const v = (input.value || '').trim();
        const statusEl = document.getElementById('saveStatus');
        if (!v) {
          input.style.outline = '';
          return;
        }
        if (isSubjectCodeTaken(v, input)) {
          input.value = '';
          input.style.outline = '2px solid #b3452f';
          if (statusEl) {
            statusEl.textContent = 'The subject code is already selected.';
            setTimeout(() => {
              if (statusEl.textContent.indexOf('already selected') !== -1) statusEl.textContent = '';
            }, 5000);
          }
          return;
        }
        input.style.outline = '';
        if (statusEl && statusEl.textContent.indexOf('already selected') !== -1) statusEl.textContent = '';
      });
    });

    window.addEventListener('resize', debounce(() => autosizeAll(getPanel(currentPeriod())), 200));

    updateTabsUI();

    document.getElementById('periodPrev').addEventListener('click', () => stepPeriod(-1));
    document.getElementById('periodNext').addEventListener('click', () => stepPeriod(1));

    document.getElementById('submitBtn').addEventListener('click', submitChart);
    document.getElementById('profileBtn').addEventListener('click', openProfile);
    document.getElementById('profilePhotoBtn').addEventListener('click', () => {
      document.getElementById('profilePhotoInput').click();
    });
    document.getElementById('saveProfileBtn').addEventListener('click', saveProfile);
    document.getElementById('passwordBtn').addEventListener('click', openPasswordDialog);
    document.getElementById('passwordSaveBtn').addEventListener('click', savePassword);
    document.getElementById('passwordClose').addEventListener('click', () => document.getElementById('passwordDialog').close());
    document.getElementById('fingerprintBtn').addEventListener('click', enableFingerprint);
        // verifyPhoneOtpBtn/newPhoneNumber) were removed from the Profile dialog
    // along with the OTP system, so they are no longer wired up here.
    document.getElementById('profilePhotoInput').addEventListener('change', (e) => {
      const file = e.target.files && e.target.files[0];
      if (file) uploadPhoto(file);
    });
    document.getElementById('profileClose').addEventListener('click', () => {
      syncBottomFromProfile();
      closeProfile();
    });

    document.getElementById('printBtn').addEventListener('click', () => {
      autosizeAll(getPanel(currentPeriod()));
      window.print();
    });

    document.getElementById('profileDialog').addEventListener('close', syncBottomFromProfile);

    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        submitChart();
      }
      // Left/Right arrows also page between sheets, as long as the user
      // isn't typing inside one of the editable cells.
      if (document.activeElement && document.activeElement.classList.contains('cell-text')) return;
      if (e.key === 'ArrowLeft') stepPeriod(-1);
      if (e.key === 'ArrowRight') stepPeriod(1);
    });
  });


  /* -------------------------------------------------------------- */
  /* Instructor ↔ Student conversation (🔔)                          */
  /* -------------------------------------------------------------- */
  async function refreshUnreadCount() {
    const badge = document.getElementById('notifyBadge');
    if (!badge) return;
    try {
      const r = await fetch(BASE + 'php/messages.php?action=unread_student', { credentials:'same-origin', cache:'no-store' });
      const d = await r.json();
      const n = (r.ok && d.ok) ? (d.unread || 0) : 0;
      if (n > 0) {
        badge.style.display = '';
        badge.textContent = n > 99 ? '99+' : String(n);
      } else {
        badge.style.display = 'none';
      }
    } catch (_) {
      badge.style.display = 'none';
    }
  }

  function formatMsgTime(v) {
    if (!v) return '';
    const d = new Date(String(v).replace(' ', 'T'));
    if (isNaN(d)) return v;
    return d.toLocaleString(undefined, { year:'numeric', month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' });
  }

  function escapeHtmlMsg(s) {
    return String(s || '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function renderConversation(msgs) {
    const list = document.getElementById('messagesList');
    if (!list) return;
    if (!msgs || !msgs.length) {
      list.innerHTML = '<p style="font-size:12px;color:#5b6b5e;text-align:center;padding:16px 8px;">No messages yet. When an instructor messages you about your monitoring chart, the conversation will appear here.</p>';
      return;
    }
    list.innerHTML = msgs.map((m) => {
      const fromStudent = String(m.sender_role || 'instructor') === 'student';
      const name = fromStudent ? 'You' : (m.instructor_name || 'Instructor');
      const align = fromStudent ? 'flex-end' : 'flex-start';
      const bg = fromStudent ? '#e8f5ee' : '#fffdf5';
      const border = fromStudent ? '#b7dcc6' : '#e5decc';
      const meta = [m.subject_code, m.semester].filter(Boolean).join(' · ');
      return `<div style="display:flex;justify-content:${align};">
        <div style="max-width:88%;border:1px solid ${border};border-radius:12px;padding:10px 12px;background:${bg};">
          <div style="display:flex;justify-content:space-between;gap:10px;font-size:11px;color:#5b6b5e;">
            <strong style="color:#0e3d24;">${escapeHtmlMsg(name)}</strong>
            <span>${escapeHtmlMsg(formatMsgTime(m.created_at))}</span>
          </div>
          ${meta ? `<div style="font-size:10px;color:#7a6f55;margin-top:2px;">${escapeHtmlMsg(meta)}</div>` : ''}
          <div style="font-size:13px;line-height:1.45;color:#1a2e1f;white-space:pre-wrap;margin-top:6px;">${escapeHtmlMsg(m.body || '')}</div>
        </div>
      </div>`;
    }).join('');
    list.scrollTop = list.scrollHeight;
  }

  let allInboxMessages = [];
  let currentThreadInstructorKey = '';

  /* Group the flat message list (all instructors mixed together) into
     one row per instructor conversation, newest message first. */
  function groupMessagesByInstructor(msgs) {
    const byInstructor = new Map();
    (msgs || []).forEach((m) => {
      const key = m.instructor_key || 'unknown';
      if (!byInstructor.has(key)) {
        byInstructor.set(key, { instructorKey: key, instructorName: m.instructor_name || 'Instructor', messages: [], unread: 0, lastAt: m.created_at });
      }
      const g = byInstructor.get(key);
      g.messages.push(m);
      g.lastAt = m.created_at; // messages arrive sorted oldest->newest, so this ends up as the latest
      if (String(m.sender_role || 'instructor') === 'instructor' && !Number(m.is_read)) g.unread++;
    });
    return Array.from(byInstructor.values()).sort((a, b) => new Date(b.lastAt) - new Date(a.lastAt));
  }

  function showInboxView() {
    document.getElementById('messagesInboxView').style.display = '';
    document.getElementById('messagesThreadView').style.display = 'none';
    document.getElementById('messagesTitle').textContent = 'Notifications';
    document.getElementById('messagesSubtitle').textContent = 'Announcements and messages from your instructors. Click a conversation to open and reply.';
    currentThreadInstructorKey = '';
  }

  function renderInboxRows() {
    const box = document.getElementById('messagesInboxList');
    const groups = groupMessagesByInstructor(allInboxMessages);
    if (!groups.length) {
      box.innerHTML = '<p style="font-size:12px;color:#5b6b5e;text-align:center;padding:16px 8px;">No announcements or instructor messages yet.</p>';
      return;
    }
    box.innerHTML = groups.map((g) => {
      const last = g.messages[g.messages.length - 1];
      const preview = escapeHtmlMsg((last.body || '').slice(0, 80)) + ((last.body || '').length > 80 ? '…' : '');
      const unreadBadge = g.unread > 0
        ? `<span style="background:#c0392b;color:#fff;border-radius:999px;font-size:10px;font-weight:700;padding:2px 7px;margin-left:6px;">${g.unread}</span>`
        : '';
      return `<div class="notif-row" data-instructor-key="${escapeHtmlMsg(g.instructorKey)}" style="display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid #e5decc;border-radius:10px;padding:10px 12px;cursor:pointer;background:${g.unread > 0 ? '#fffaf0' : '#fff'};">
        <div style="min-width:0;">
          <div style="font-size:13px;font-weight:700;color:#0e3d24;">${escapeHtmlMsg(g.instructorName)}${unreadBadge}</div>
          <div style="font-size:11.5px;color:#5b6b5e;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:340px;">${preview || '(no message text)'}</div>
        </div>
        <div style="font-size:10.5px;color:#8a8571;white-space:nowrap;">${escapeHtmlMsg(formatMsgTime(g.lastAt))}</div>
      </div>`;
    }).join('');
    box.querySelectorAll('.notif-row').forEach((row) => {
      // One click/tap opens the conversation.
      row.addEventListener('click', () => openThreadForInstructor(row.dataset.instructorKey));
    });
  }

  function openThreadForInstructor(instructorKey) {
    const group = groupMessagesByInstructor(allInboxMessages).find((g) => g.instructorKey === instructorKey);
    currentThreadInstructorKey = instructorKey;
    document.getElementById('messagesInboxView').style.display = 'none';
    document.getElementById('messagesThreadView').style.display = '';
    document.getElementById('messagesTitle').textContent = 'Conversation';
    document.getElementById('messagesSubtitle').textContent = group ? `With ${group.instructorName}` : 'Conversation';
    renderConversation(group ? group.messages : []);
    markInstructorThreadRead(instructorKey);
    const input = document.getElementById('studentReplyInput');
    if (input) { input.value = ''; input.focus(); }
  }

  async function markInstructorThreadRead(instructorKey) {
    try {
      await fetch(BASE + 'php/messages.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark_read_student', instructorKey }),
      });
      refreshUnreadCount();
    } catch (_) { /* non-fatal */ }
  }

  async function openMessagesInbox() {
    const dlg = document.getElementById('messagesDialog');
    if (!dlg) return;
    showInboxView();
    document.getElementById('messagesInboxList').innerHTML = '<p style="font-size:12px;color:#5b6b5e;">Loading…</p>';
    if (!dlg.open) dlg.showModal();
    try {
      const r = await fetch(BASE + 'php/messages.php?action=thread_student', { credentials: 'same-origin', cache: 'no-store' });
      const d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.message || 'Could not load messages.');
      allInboxMessages = d.messages || [];
      renderInboxRows();
    } catch (err) {
      document.getElementById('messagesInboxList').innerHTML = `<p style="font-size:12px;color:#b3452f;">${escapeHtmlMsg(err.message || 'Could not load messages.')}</p>`;
    }
  }

  async function sendStudentReply() {
    const input = document.getElementById('studentReplyInput');
    const status = document.getElementById('studentReplyStatus');
    if (!input) return;
    const body = (input.value || '').trim();
    if (!body) {
      if (status) status.textContent = 'Type a reply first.';
      return;
    }
    if (!currentThreadInstructorKey) {
      if (status) status.textContent = 'Open a conversation first.';
      return;
    }
    if (status) status.textContent = 'Sending…';
    try {
      const r = await fetch(BASE + 'php/messages.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'send_student', body, instructorKey: currentThreadInstructorKey }),
      });
      const d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.message || 'Could not send reply.');
      input.value = '';
      if (status) status.textContent = '✓ Sent';
      // Refresh just this thread in place (stay in the conversation view).
      const rr = await fetch(BASE + 'php/messages.php?action=thread_student', { credentials: 'same-origin', cache: 'no-store' });
      const dd = await rr.json();
      if (rr.ok && dd.ok) {
        allInboxMessages = dd.messages || [];
        const stayKey = currentThreadInstructorKey;
        openThreadForInstructor(stayKey);
      }
      setTimeout(() => { if (status) status.textContent = ''; }, 1500);
    } catch (err) {
      if (status) status.textContent = err.message || 'Could not send reply.';
    }
  }

  function wireMessagesUi() {
    const btn = document.getElementById('notifyBtn');
    if (btn) btn.addEventListener('click', openMessagesInbox);
    ['messagesClose'].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.addEventListener('click', () => {
        const d = document.getElementById('messagesDialog');
        if (d && d.open) d.close();
      });
    });
    const backBtn = document.getElementById('messagesBackBtn');
    if (backBtn) backBtn.addEventListener('click', showInboxView);
    const sendBtn = document.getElementById('studentReplySend');
    if (sendBtn) sendBtn.addEventListener('click', sendStudentReply);
    const input = document.getElementById('studentReplyInput');
    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendStudentReply();
        }
      });
    }
    refreshUnreadCount();
    setInterval(refreshUnreadCount, 45000);
  }


  function wireFeedbackUi() {
    const btn = document.getElementById('feedbackBtn');
    const dlg = document.getElementById('feedbackDialog');
    const closeBtn = document.getElementById('feedbackClose');
    const sendBtn = document.getElementById('feedbackSend');
    const input = document.getElementById('feedbackInput');
    const status = document.getElementById('feedbackStatus');
    if (!btn || !dlg) return;

    btn.addEventListener('click', () => {
      if (status) status.textContent = '';
      if (!dlg.open) dlg.showModal();
      if (input) input.focus();
    });
    if (closeBtn) closeBtn.addEventListener('click', () => { if (dlg.open) dlg.close(); });

    async function sendFeedback() {
      const message = (input ? input.value : '').trim();
      if (!message) {
        if (status) status.textContent = 'Please write your feedback first.';
        return;
      }
      if (sendBtn) sendBtn.disabled = true;
      if (status) status.textContent = 'Sending…';
      try {
        const res = await fetch(BASE + 'php/feedback.php', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'send', message })
        });
        const data = await res.json();
        if (!res.ok || !data.ok) throw new Error(data.message || 'Could not send feedback.');
        if (status) status.textContent = data.message || 'Thanks for your feedback!';
        if (input) input.value = '';
        setTimeout(() => {
          if (dlg.open) dlg.close();
          if (status) status.textContent = '';
        }, 1200);
      } catch (err) {
        if (status) status.textContent = err.message || 'Could not send feedback.';
      } finally {
        if (sendBtn) sendBtn.disabled = false;
      }
    }
    if (sendBtn) sendBtn.addEventListener('click', sendFeedback);
    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
          e.preventDefault();
          sendFeedback();
        }
      });
    }
  }

  // wireMessagesUi() looks up elements (messagesClose, messagesBackBtn,
  // studentReplySend, etc.) that live in the <dialog> markup placed AFTER
  // this <script> tag in student.php. Calling it immediately here ran
  // before that HTML existed, so every getElementById() for those buttons
  // returned null and no click handlers were ever attached -- clicking
  // Close / Back to messages / Send reply did nothing. Deferring to
  // DOMContentLoaded (same pattern the rest of this file already uses)
  // guarantees the whole page, including that dialog, has been parsed.
  document.addEventListener('DOMContentLoaded', () => {
    try { wireMessagesUi(); } catch (_) {}
    try { wireFeedbackUi(); } catch (_) {}
  });
})();
