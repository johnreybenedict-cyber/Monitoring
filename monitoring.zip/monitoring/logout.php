<?php
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!empty($_SESSION['dean_authenticated']) || !empty($_SESSION['instructor_authenticated']) || !empty($_SESSION['student_authenticated'])) {
    try {
        require_once __DIR__ . '/php/audit.php';
        $pdo = csj_student_db();
        csj_audit_log($pdo, 'logout');
    } catch (Throwable $e) {
        error_log('Could not write logout audit event: ' . $e->getMessage());
    }
}
$_SESSION = [];
if (ini_get('session.use_cookies')) { $p=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']); }
session_destroy();
setcookie('csj_student_profile_key','',time()-3600,'/');
setcookie('csj_instructor_key','',time()-3600,'/');
header('Location: index.php'); exit;
