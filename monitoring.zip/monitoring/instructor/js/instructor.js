(function () {
  'use strict';

  const BASE = String(window.CSJ_BASE_URL || '').replace(/\/$/, '');
  const api = (path) => BASE + '/instructor/' + path;

  const grid          = document.getElementById('mySubjectsGrid');
  const emptyHint      = document.getElementById('emptyHint');
  const semesterInput  = document.getElementById('semesterInput');
  const statusMsg      = document.getElementById('statusMsg');
  const namePill       = document.getElementById('instructorNamePill');

  const subjectsDialog     = document.getElementById('subjectsDialog');
  const subjectsDialogSem  = document.getElementById('subjectsDialogSemester');
  const subjectSearch      = document.getElementById('subjectSearch');
  const subjectCheckList   = document.getElementById('subjectCheckList');
  const subjectsCountMsg   = document.getElementById('subjectsCountMsg');

  const profileDialog  = document.getElementById('profileDialog');
  const enrolledDialog = document.getElementById('enrolledDialog');
  const reviewDialog   = document.getElementById('reviewDialog');
  const notifyDialog   = document.getElementById('notifyDialog');
  const notifyBadge    = document.getElementById('notifyBadge');
  const notifyList     = document.getElementById('notifyList');


  let mySubjects = [];
  try {
    mySubjects = JSON.parse(grid.dataset.selections || '[]');
  } catch (_) { mySubjects = []; }

  let currentEnrolledSubject = '';
  let currentReview = null; // { profileKey }

    function flash(msg, isError) {
    if (!isError && typeof window.csjShowSuccessDialog === 'function' && /Subject list saved/i.test(String(msg || ''))) {
      if (statusMsg) statusMsg.textContent = '';
      window.csjShowSuccessDialog('Subjects Saved', msg);
      return;
    }
    if (statusMsg) {
      statusMsg.textContent = msg;
      statusMsg.style.color = isError ? '#b3452f' : '';
      setTimeout(() => { statusMsg.textContent = ''; }, 3500);
    }
  }

  function semester() {
    return semesterInput.value.trim();
  }

  /* -------------------------------------------------------------- */
  /* My subjects grid                                                */
  /* -------------------------------------------------------------- */

  function renderGrid() {
    grid.querySelectorAll('.subject-card').forEach((el) => el.remove());
    emptyHint.style.display = mySubjects.length ? 'none' : '';

    mySubjects.slice().sort().forEach((code) => {
      const card = document.createElement('div');
      card.className = 'subject-card';
      card.innerHTML = `
        <div class="code">${escapeHtml(code)}</div>
        <div class="counts" data-role="counts">Loading counts…</div>
        <button type="button" class="view-enrolled-btn">View Enrolled Students</button>
        <button type="button" class="remove-subject-btn">Remove from my list</button>
      `;
      card.querySelector('.view-enrolled-btn').addEventListener('click', () => openEnrolled(code));
      card.querySelector('.remove-subject-btn').addEventListener('click', () => removeSubject(code));
      grid.appendChild(card);
      loadCounts(code, card.querySelector('[data-role="counts"]'));
    });
  }

  async function loadCounts(code, el) {
    try {
      const res = await fetch(api(`php/enrolled.php?subject=${encodeURIComponent(code)}&semester=${encodeURIComponent(semester())}`));
      const data = await res.json();
      if (!data.ok) { el.textContent = ''; return; }
      const total = data.students.length;
      const approved = data.students.filter((s) => s.approved).length;
      el.innerHTML = `<b>${total}</b> student${total === 1 ? '' : 's'} &middot; <b>${approved}</b> approved`;
    } catch (_) {
      el.textContent = '';
    }
  }

  function removeSubject(code) {
    mySubjects = mySubjects.filter((c) => c !== code);
    renderGrid();
    saveSelections(false);
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  /* -------------------------------------------------------------- */
  /* Choose Subjects dialog                                          */
  /* -------------------------------------------------------------- */

  function normSubjectKey(s) {
    return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  }
  const TAKEN_SUBJECT_KEYS = new Set(
    (Array.isArray(window.CSJ_TAKEN_SUBJECTS) ? window.CSJ_TAKEN_SUBJECTS : [])
      .map(normSubjectKey)
      .filter(Boolean)
  );

  document.getElementById('chooseSubjectsBtn').addEventListener('click', () => {
    subjectsDialogSem.textContent = semester();
    subjectCheckList.querySelectorAll('.subject-check').forEach((cb) => {
      const key = normSubjectKey(cb.value);
      const taken = TAKEN_SUBJECT_KEYS.has(key);
      // Own selections remain selectable; others' taken subjects stay disabled
      if (taken && !mySubjects.some((m) => normSubjectKey(m) === key)) {
        cb.disabled = true;
        cb.checked = false;
        const item = cb.closest('.subject-check-item');
        if (item) item.classList.add('is-taken');
      } else {
        // Do not re-enable server-disabled taken items that are not mine
        if (taken && !mySubjects.some((m) => normSubjectKey(m) === key)) {
          cb.disabled = true;
        }
        cb.checked = mySubjects.includes(cb.value) || mySubjects.some((m) => normSubjectKey(m) === key);
      }
    });
    subjectSearch.value = '';
    filterSubjectList('');
    updateSubjectsCount();
    subjectsDialog.showModal();
  });

  document.getElementById('subjectsCloseX').addEventListener('click', () => subjectsDialog.close());

  subjectSearch.addEventListener('input', () => filterSubjectList(subjectSearch.value));

  function filterSubjectList(term) {
    const q = term.trim().toLowerCase();
    subjectCheckList.querySelectorAll('.subject-check-item').forEach((item) => {
      const code = item.querySelector('.subject-check').value.toLowerCase();
      item.classList.toggle('is-hidden', q !== '' && !code.includes(q));
    });
  }

  subjectCheckList.addEventListener('change', updateSubjectsCount);

  function updateSubjectsCount() {
    const n = subjectCheckList.querySelectorAll('.subject-check:checked').length;
    subjectsCountMsg.textContent = n + ' subject' + (n === 1 ? '' : 's') + ' selected';
  }

  document.getElementById('subjectsSave').addEventListener('click', async () => {
    const chosen = Array.from(subjectCheckList.querySelectorAll('.subject-check:checked:not(:disabled)')).map((cb) => cb.value);
    mySubjects = chosen;
    renderGrid();
    subjectsDialog.close();
    await saveSelections(true);
  });

  async function saveSelections(showFlash) {
    try {
      if (!semester()) {
        throw new Error('Enter the semester first (must match the student chart), then save subjects.');
      }
      const res = await fetch(api('php/select_subjects.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ semester: semester(), subjects: mySubjects })
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.message);
      if (showFlash) flash('Subject list saved for ' + semester() + '.');
    } catch (err) {
      flash(err.message || 'Could not save subjects. Check MySQL.', true);
    }
  }

  semesterInput.addEventListener('change', () => {
    renderGrid();
  });
  // Persist semester text so a refresh still keeps the typed value in this browser
  semesterInput.addEventListener('blur', () => {
    try {
      if (semester()) localStorage.setItem('csj_instructor_semester', semester());
    } catch (_) {}
  });
  // If PHP left the field empty but this browser had a prior value, restore it
  if (!semester()) {
    try {
      const saved = localStorage.getItem('csj_instructor_semester') || '';
      if (saved) {
        semesterInput.value = saved;
        const lab = document.getElementById('semesterLabel');
        if (lab) lab.textContent = saved;
      }
    } catch (_) {}
  }

  /* -------------------------------------------------------------- */
  /* Profile dialog                                                   */
  /* -------------------------------------------------------------- */

  const profilePhotoImg     = document.getElementById('profilePhotoImg');
  const profilePhotoInitial = document.getElementById('profilePhotoInitial');
  const profilePhotoStatus  = document.getElementById('profilePhotoStatus');
  const profilePhotoFile    = document.getElementById('profilePhotoFile');
  const biometricErrorEl    = document.getElementById('biometricError');
  const registerBiometricBtn = document.getElementById('registerBiometricBtn');
  const removeBiometricBtn  = document.getElementById('removeBiometricBtn');
  const biometricStatusLabel = document.getElementById('biometricStatusLabel');
  const biometricHelpText   = document.getElementById('biometricHelpText');

  document.getElementById('profileBtn').addEventListener('click', () => {
    profileDialog.showModal();
    refreshBiometricStatus();
  });
  document.getElementById('profileCloseX').addEventListener('click', () => profileDialog.close());

  document.getElementById('profileSave').addEventListener('click', async () => {
    const fullName = document.getElementById('profileFullName').value.trim();
    const email = document.getElementById('profileEmail').value.trim();
    const program = document.getElementById('profileProgram').value.trim();
    const address = document.getElementById('profileAddress').value.trim();
    const contactNo = document.getElementById('profileContactNo').value.trim();
    if (!fullName) {
      flash('Enter your full name.', true);
      return;
    }
    try {
      const res = await fetch(api('php/save_instructor.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, email, program, address, contactNo })
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.message);
      namePill.textContent = fullName;
      // Update initial letter if no photo
      if (profilePhotoInitial && profilePhotoImg && profilePhotoImg.style.display === 'none') {
        profilePhotoInitial.textContent = fullName.charAt(0).toUpperCase() || '?';
      }
      profileDialog.close();
      flash('Profile saved.');
    } catch (err) {
      flash(err.message || 'Could not save profile. Check MySQL.', true);
    }
  });


  const profilePhotoRemoveBtn = document.getElementById('profilePhotoRemove');
  if (profilePhotoRemoveBtn) {
    profilePhotoRemoveBtn.addEventListener('click', async () => {
      if (!confirm('Remove your profile picture?')) return;
      if (profilePhotoStatus) profilePhotoStatus.textContent = 'Removing…';
      const fd = new FormData();
      fd.append('remove', '1');
      try {
        const res = await fetch(api('php/upload_instructor_photo.php'), {
          method: 'POST', body: fd, credentials: 'same-origin'
        });
        const data = await res.json();
        if (!data.ok) throw new Error(data.message || 'Could not remove photo.');
        if (profilePhotoImg) {
          profilePhotoImg.src = '';
          profilePhotoImg.style.display = 'none';
        }
        if (profilePhotoInitial) {
          const nameEl = document.getElementById('profileFullName');
          const name = nameEl ? nameEl.value : '';
          profilePhotoInitial.textContent = (name || '?').charAt(0).toUpperCase();
          profilePhotoInitial.style.display = '';
        }
        if (profilePhotoStatus) {
          profilePhotoStatus.textContent = 'Photo removed.';
          setTimeout(() => { profilePhotoStatus.textContent = ''; }, 2500);
        }
      } catch (err) {
        if (profilePhotoStatus) profilePhotoStatus.textContent = err.message || 'Could not remove photo.';
      }
    });
  }

  /* ---- Profile picture (Browse) ---- */

  document.getElementById('profilePhotoBrowse').addEventListener('click', () => {
    profilePhotoFile.click();
  });

  profilePhotoFile.addEventListener('change', async () => {
    const file = profilePhotoFile.files && profilePhotoFile.files[0];
    if (!file) return;
    profilePhotoStatus.textContent = 'Uploading…';
    const fd = new FormData();
    fd.append('photo', file);
    try {
      const res = await fetch(api('php/upload_instructor_photo.php'), {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.message || 'Upload failed');
      if (profilePhotoImg) {
        profilePhotoImg.src = (BASE ? BASE + '/' : '') + String(data.photoPath).replace(/^\/+/, '');
        profilePhotoImg.style.display = '';
      }
      if (profilePhotoInitial) profilePhotoInitial.style.display = 'none';
      profilePhotoStatus.textContent = 'Photo saved.';
      setTimeout(() => { profilePhotoStatus.textContent = ''; }, 2500);
    } catch (err) {
      profilePhotoStatus.textContent = err.message || 'Could not upload photo.';
    }
    profilePhotoFile.value = '';
  });

  /* ---- Biometric (WebAuthn / passkey) ---- */

  function showBioError(msg) {
    if (!biometricErrorEl) return;
    if (!msg) {
      biometricErrorEl.style.display = 'none';
      biometricErrorEl.textContent = '';
      return;
    }
    biometricErrorEl.style.display = '';
    biometricErrorEl.textContent = msg;
  }

  function setBiometricUI(registered) {
    if (biometricStatusLabel) {
      biometricStatusLabel.textContent = registered
        ? 'Biometric sign-in is registered on this account'
        : 'Add a biometric sign-in';
    }
    if (biometricHelpText) {
      biometricHelpText.textContent = registered
        ? 'You can register another device or remove the existing credential.'
        : 'Use the fingerprint sensor, Windows Hello, Face ID, PIN, or another passkey supported by this device.';
    }
    if (registerBiometricBtn) {
      registerBiometricBtn.textContent = registered ? 'Register Another' : 'Register Biometric';
    }
    if (removeBiometricBtn) {
      removeBiometricBtn.style.display = registered ? '' : 'none';
    }
  }

  async function refreshBiometricStatus() {
    showBioError('');
    try {
      const res = await fetch(api('php/biometric.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'status' }),
        credentials: 'same-origin'
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.message);
      setBiometricUI(!!data.registered);
    } catch (err) {
      // Non-fatal — table may not exist yet
      showBioError(err.message || 'Could not check biometric status.');
    }
  }

  function bufferToBase64url(buf) {
    const bytes = new Uint8Array(buf);
    let str = '';
    for (let i = 0; i < bytes.length; i++) str += String.fromCharCode(bytes[i]);
    return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function randomChallenge(len) {
    const arr = new Uint8Array(len || 32);
    crypto.getRandomValues(arr);
    return arr;
  }

  if (registerBiometricBtn) {
    registerBiometricBtn.addEventListener('click', async () => {
      showBioError('');
      if (!window.PublicKeyCredential || !navigator.credentials || !navigator.credentials.create) {
        showBioError('This browser or device does not support biometric / passkey registration (WebAuthn).');
        return;
      }
      registerBiometricBtn.disabled = true;
      registerBiometricBtn.textContent = 'Waiting for sensor…';
      try {
        const challenge = randomChallenge(32);
        const userId = randomChallenge(16);
        const publicKey = {
          challenge: challenge,
          rp: { name: 'CSJ Instructor Dashboard', id: location.hostname === 'localhost' ? 'localhost' : location.hostname },
          user: {
            id: userId,
            name: (document.getElementById('profileEmail').value || 'instructor@csj.edu.ph').trim(),
            displayName: (document.getElementById('profileFullName').value || 'Instructor').trim()
          },
          pubKeyCredParams: [
            { type: 'public-key', alg: -7 },   // ES256
            { type: 'public-key', alg: -257 }  // RS256
          ],
          authenticatorSelection: {
            authenticatorAttachment: 'platform',
            userVerification: 'required',
            residentKey: 'discouraged',
            requireResidentKey: false
          },
          timeout: 60000,
          attestation: 'none'
        };

        const cred = await navigator.credentials.create({ publicKey });
        if (!cred || !cred.rawId) throw new Error('No credential returned by the authenticator.');

        const credentialId = bufferToBase64url(cred.rawId);
        let publicKeyB64 = '';
        try {
          if (cred.response && cred.response.getPublicKey) {
            publicKeyB64 = bufferToBase64url(cred.response.getPublicKey());
          }
        } catch (_) { /* optional */ }

        const transports = (cred.response && cred.response.getTransports)
          ? (cred.response.getTransports() || []).join(',')
          : '';

        const res = await fetch(api('php/biometric.php'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'register',
            credentialId,
            publicKey: publicKeyB64,
            transports,
            deviceLabel: 'This device'
          }),
          credentials: 'same-origin'
        });
        const data = await res.json();
        if (!data.ok) throw new Error(data.message || 'Server rejected the credential.');

        setBiometricUI(true);
        flash('Biometric registered successfully.');
      } catch (err) {
        let msg = err && err.message ? err.message : String(err);
        if (err && err.name === 'NotAllowedError') {
          msg = 'Registration cancelled or not allowed by the device / browser.';
        } else if (err && err.name === 'InvalidStateError') {
          msg = 'A credential may already exist for this authenticator. Try Remove first, or register on another device.';
        }
        showBioError(msg);
      } finally {
        registerBiometricBtn.disabled = false;
        registerBiometricBtn.textContent = removeBiometricBtn && removeBiometricBtn.style.display !== 'none'
          ? 'Register Another' : 'Register Biometric';
      }
    });
  }

  if (removeBiometricBtn) {
    removeBiometricBtn.addEventListener('click', async () => {
      showBioError('');
      if (!confirm('Remove all biometric credentials for this instructor on the server?')) return;
      try {
        const res = await fetch(api('php/biometric.php'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'remove' }),
          credentials: 'same-origin'
        });
        const data = await res.json();
        if (!data.ok) throw new Error(data.message);
        setBiometricUI(false);
        flash('Biometric credentials removed.');
      } catch (err) {
        showBioError(err.message || 'Could not remove credentials.');
      }
    });
  }

  /* -------------------------------------------------------------- */
  /* Enrolled students dialog                                        */
  /* -------------------------------------------------------------- */

  async function openEnrolled(code) {
    currentEnrolledSubject = code;
    document.getElementById('enrolledSubjectCode').textContent = code;
    document.getElementById('enrolledSemesterLabel').textContent = semester();
    const list = document.getElementById('enrolledList');
    list.innerHTML = '<p class="empty-hint">Loading…</p>';
    enrolledDialog.showModal();
    await refreshEnrolled();
  }

  async function refreshEnrolled() {
    const list = document.getElementById('enrolledList');
    try {
      const res = await fetch(api(`php/enrolled.php?subject=${encodeURIComponent(currentEnrolledSubject)}&semester=${encodeURIComponent(semester())}`));
      const data = await res.json();
      if (!data.ok) throw new Error(data.message);

      if (!data.students.length) {
        list.innerHTML = '<p class="empty-hint">No students have listed this subject on their chart yet.</p>';
        return;
      }

      list.innerHTML = '';
      data.students.forEach((s) => {
        const row = document.createElement('div');
        row.className = 'enrolled-row';
        const periods = s.periods || {};
        const chips = ['prelims','midterms','finals'].map((pk) => {
          if (!periods[pk]) return '';
          const status = periods[pk].status || (periods[pk].approved ? 'approved' : 'pending');
          const label = pk === 'prelims' ? 'Prelim' : (pk === 'midterms' ? 'Midterm' : 'Final');
          const statusLabel = status === 'approved' ? '✓' : (status === 'denied' ? 'Denied' : '…');
          return `<span class="status-chip ${status}" style="margin-right:4px;font-size:10px;">${label}: ${statusLabel}</span>`;
        }).join('');
        row.innerHTML = `
          <div class="who">
            <div class="name">${escapeHtml(s.studentName)}</div>
            <div class="meta">${escapeHtml(s.courseYear || '—')} &middot; submitted ${escapeHtml(formatDate(s.submittedAt))}</div>
            <div class="period-chips" style="margin-top:4px;">${chips || `<span class="status-chip ${s.status || (s.approved ? 'approved' : 'pending')}">${s.status === 'denied' ? 'Denied' : (s.approved ? 'Approved' : 'Pending')}</span>`}</div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
            <button type="button" class="msg-btn btn btn-ghost" title="Message student about monitoring" aria-label="Message student" style="min-width:40px;padding:6px 10px;font-size:16px;">✉️</button>
            <button type="button" class="review-btn">View Self-Monitoring</button>
          </div>
        `;
        row.querySelector('.review-btn').addEventListener('click', () => {
          openReview(s.profileKey, s.studentName, currentEnrolledSubject, s.periods);
        });
        row.querySelector('.msg-btn').addEventListener('click', () => {
          openMessageComposer(s.profileKey, s.studentName, currentEnrolledSubject || '');
        });
        list.appendChild(row);
      });
    } catch (err) {
      list.innerHTML = `<p class="empty-hint">${escapeHtml(err.message || 'Could not load students.')}</p>`;
    }
  }

  function formatDate(v) {
    if (!v) return '—';
    const d = new Date(v.replace(' ', 'T'));
    if (isNaN(d)) return v;
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  document.getElementById('enrolledClose').addEventListener('click', () => {
    enrolledDialog.close();
    renderGrid(); // refresh counts after any approvals
  });

  /* -------------------------------------------------------------- */
  /* Student chart review + approve dialog ("View Self-Monitoring")  */
  /* -------------------------------------------------------------- */

  async function openReview(profileKey, studentNameFallback, subjectCode, subjectPeriods) {
    // subjectCode is the subject the instructor came here from (via "View
    // Enrolled Students"). Since enrolled.php already matched this student
    // to that exact subject, the Approve control for that subject must
    // always be available here too -- regardless of whether the code's
    // punctuation/case matches the instructor's saved "My Subjects" list
    // character-for-character. See currentReview.subjectCode below.
    currentReview = { profileKey, subjectCode: subjectCode || '', semester: semester() };
    document.getElementById('reviewStudentName').textContent = studentNameFallback;
    document.getElementById('reviewCourseYear').textContent = '';
    document.getElementById('reviewStudentMeta').textContent = 'Loading…';
    document.getElementById('reviewHeadRow').innerHTML = '';
    document.getElementById('reviewBody').innerHTML = '';
    document.getElementById('reviewApproveMsg').textContent = '';
    setReviewPhoto('', studentNameFallback);

    // Jump straight to whichever period sheet actually has this subject
    // filled in, so the Approve button is visible immediately instead of
    // requiring the instructor to click through Prelims/Midterms/Finals.
    currentReviewPeriod = 'prelims';
    if (subjectPeriods && typeof subjectPeriods === 'object') {
      const found = PERIOD_ORDER.find((pk) => subjectPeriods[pk]);
      if (found) currentReviewPeriod = found;
    }

    reviewDialog.showModal();

    try {
      const res = await fetch(api(`php/student_chart.php?profile_key=${encodeURIComponent(profileKey)}&semester=${encodeURIComponent(semester())}`));
      const data = await res.json();
      if (!data.ok) throw new Error(data.message);

      // Use the semester actually stored on the student's submission (flexible)
      if (data.semester) currentReview.semester = data.semester;

      document.getElementById('reviewStudentName').textContent = data.studentName;
      document.getElementById('reviewCourseYear').textContent = data.courseYear || '—';
      const semLabel = data.semester ? (' · ' + data.semester) : '';
      document.getElementById('reviewStudentMeta').textContent =
        `Submitted ${formatDate(data.submittedAt)} · last updated ${formatDate(data.updatedAt)}` + semLabel;
      setReviewPhoto(data.photoPath ? BASE + '/' + String(data.photoPath).replace(/^\/+/, '') : '', data.studentName);

      renderReviewTable(data.chart);
    } catch (err) {
      document.getElementById('reviewStudentMeta').textContent = err.message || 'Could not load this chart.';
    }
  }

  function setReviewPhoto(url, nameForInitial) {
    const img = document.getElementById('reviewPhotoImg');
    const initial = document.getElementById('reviewPhotoInitial');
    if (url) {
      img.src = url;
      img.style.display = '';
      initial.style.display = 'none';
    } else {
      img.style.display = 'none';
      initial.textContent = (nameForInitial || '?').trim().charAt(0).toUpperCase() || '?';
      initial.style.display = '';
    }
  }

  function normCode(s) {
    // Strip everything except letters/digits (not just whitespace) so
    // small formatting differences -- "FM 303" vs "FM-303" vs "fm303" --
    // are still recognized as the same subject code. Used consistently
    // here and on the server (approve.php / enrolled.php) so a subject
    // that shows up under "View Enrolled Students" can always be approved.
    return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  }

  const PERIOD_ORDER = ['prelims', 'midterms', 'finals'];
  const PERIOD_LABELS = { prelims: 'Prelims', midterms: 'Midterms', finals: 'Finals' };
  let currentReviewPeriod = 'prelims';
  let currentReviewChart = null;

  function getPeriodBlock(chart, period) {
    if (!chart) return { subjects: [], rows: [] };
    if (chart.periods && chart.periods[period]) {
      return {
        subjects: chart.periods[period].subjects || [],
        rows: chart.periods[period].rows || [],
        chartTitle: chart.periods[period].chartTitle || ''
      };
    }
    // Legacy flat chart → treat as prelims
    if (period === 'prelims' && (chart.subjects || chart.rows)) {
      return { subjects: chart.subjects || [], rows: chart.rows || [], chartTitle: '' };
    }
    return { subjects: [], rows: [] };
  }

  function ensureReviewPeriodTabs() {
    let tabs = document.getElementById('reviewPeriodTabs');
    if (tabs) return tabs;
    const host = document.getElementById('reviewApproveMsg');
    if (!host || !host.parentElement) return null;
    tabs = document.createElement('div');
    tabs.id = 'reviewPeriodTabs';
    tabs.style.cssText = 'display:flex;gap:6px;margin:8px 0 12px;flex-wrap:wrap;';
    PERIOD_ORDER.forEach((pk) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'period-tab-btn';
      btn.dataset.period = pk;
      btn.textContent = PERIOD_LABELS[pk];
      btn.style.cssText = 'padding:6px 12px;border-radius:999px;border:1px solid #ccc;background:#f5f5f5;cursor:pointer;font-size:12px;';
      btn.addEventListener('click', () => {
        currentReviewPeriod = pk;
        if (currentReviewChart) renderReviewTable(currentReviewChart);
      });
      tabs.appendChild(btn);
    });
    host.parentElement.insertBefore(tabs, host);
    return tabs;
  }

  function highlightPeriodTab() {
    const tabs = document.getElementById('reviewPeriodTabs');
    if (!tabs) return;
    tabs.querySelectorAll('.period-tab-btn').forEach((btn) => {
      const on = btn.dataset.period === currentReviewPeriod;
      btn.style.background = on ? '#1a4d2e' : '#f5f5f5';
      btn.style.color = on ? '#fff' : '#222';
      btn.style.borderColor = on ? '#1a4d2e' : '#ccc';
    });
  }

  function renderReviewTable(chart) {
    currentReviewChart = chart;
    ensureReviewPeriodTabs();
    highlightPeriodTab();

    const block = getPeriodBlock(chart, currentReviewPeriod);
    const subjects = block.subjects;
    const rows = block.rows;
    const myCodes = mySubjects.map(normCode);
    const reviewSubjectNorm = (currentReview && currentReview.subjectCode) ? normCode(currentReview.subjectCode) : '';

    const headRow = document.getElementById('reviewHeadRow');
    headRow.innerHTML = '';
    const body = document.getElementById('reviewBody');
    body.innerHTML = '';

    if (!subjects.length) {
      body.innerHTML = '<tr><td colspan="9" style="padding:16px;text-align:center;opacity:.7;">No subjects for this period yet.</td></tr>';
      return;
    }

    subjects.forEach((s) => {
      const codeNorm = normCode(s.code);
      const isMine = codeNorm !== '' && (myCodes.includes(codeNorm) || (reviewSubjectNorm !== '' && codeNorm === reviewSubjectNorm));
      const th = document.createElement('th');
      th.className = 'subject-head' + (isMine ? ' is-mine' : '');
      const isApproved = !!s.approved;
      const status = ['approved', 'denied', 'pending'].includes(s.reviewStatus)
        ? s.reviewStatus
        : (isApproved ? 'approved' : 'pending');
      let reviewer = String(s.reviewedBy || s.instructor || '').trim();
      if (/^[—\-–_\s]+$/.test(reviewer)) reviewer = '';
      const statusLabel = status === 'approved'
        ? '✓ Approved'
        : (status === 'denied' ? 'Denied' : 'Pending');
      th.innerHTML = `
        <span class="subject-label">Subject ${s.id}</span>
        <div style="font-family:var(--font-display);font-weight:700;">${escapeHtml(s.code || '—')}</div>
        <div class="head-status" style="font-size:9.5px;margin-top:3px;opacity:.85;">${statusLabel}${reviewer ? ' — ' + escapeHtml(reviewer) : ''}</div>
        ${isMine ? `
          <button type="button" class="approve-chip-btn ${status === 'approved' ? 'is-approved' : ''}" data-choice="approved" data-status="${status}" data-code="${escapeHtml(s.code)}" data-period="${currentReviewPeriod}">${status === 'approved' ? 'Approved ✓' : 'Approve'}</button>
        ` : ''}
      `;
      headRow.appendChild(th);
    });

    headRow.querySelectorAll('.approve-chip-btn').forEach((btn) => {
      btn.addEventListener('click', () => setReviewDecision(btn));
    });

    rows.forEach((r) => {
      const tr = document.createElement('tr');
      tr.className = 'entry-row';
      subjects.forEach((s) => {
        const val = (r.entries && r.entries[String(s.id)]) || '';
        const td = document.createElement('td');
        td.className = 'entry-cell';
        td.innerHTML = `<div class="cell-inner"><div class="cell-text">${escapeHtml(val)}</div></div>`;
        tr.appendChild(td);
      });
      body.appendChild(tr);
    });
  }

  async function setReviewDecision(btn) {
    if (!currentReview) return;
    const code = btn.dataset.code;
    const period = btn.dataset.period || currentReviewPeriod || 'prelims';
    const choice = btn.dataset.choice;
    const currentStatus = btn.dataset.status || 'pending';
    const decision = currentStatus === choice ? 'pending' : choice;
    const msg = document.getElementById('reviewApproveMsg');
    const subjectHeader = btn.closest('.subject-head');
    subjectHeader.querySelectorAll('.approve-chip-btn').forEach((button) => { button.disabled = true; });
    msg.textContent = 'Saving…';

    try {
      const res = await fetch(api('php/approve.php'), {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({
          profileKey: currentReview.profileKey,
          semester: currentReview.semester || semester(),
          subjectCode: code,
          period: period,
          decision: decision
        })
      });
      const raw = await res.text();
      let data;
      try { data = JSON.parse(raw); } catch (_) {
        throw new Error('Server returned an invalid response. Check PHP/MySQL and try again.');
      }
      if (!res.ok || !data.ok) throw new Error(data.message || ('Approval failed (HTTP ' + res.status + ').'));

      const status = data.status || decision;
      const reviewer = status === 'pending' ? '' : (data.reviewer || data.instructor || '');
      subjectHeader.querySelectorAll('.approve-chip-btn').forEach((button) => {
        button.dataset.status = status;
        const isActive = status === 'approved';
        button.classList.toggle('is-approved', isActive);
        button.classList.remove('is-denied');
        // Approve only (Deny button removed)
        button.textContent = isActive ? 'Approved ✓' : 'Approve';
      });
      const statusEl = subjectHeader.querySelector('.head-status');
      if (statusEl) {
        let revName = String(reviewer || '').trim();
        if (/^[—\-–_\s]+$/.test(revName)) revName = '';
        statusEl.textContent = (status === 'approved' ? '✓ Approved' : (status === 'denied' ? 'Denied' : 'Pending'))
          + (revName ? ' — ' + revName : '');
      }
      // Keep local chart in sync so period tab switches stay accurate
      if (currentReviewChart) {
        const block = getPeriodBlock(currentReviewChart, period);
        block.subjects.forEach((s) => {
          if (normCode(s.code) === normCode(code)) {
            s.reviewStatus = status;
            s.approved = status === 'approved';
            s.instructor = status === 'approved' ? (data.instructor || '') : '';
            if (status === 'pending') {
              delete s.reviewedBy;
              delete s.reviewedAt;
            } else {
              s.reviewedBy = reviewer;
              s.reviewedAt = data.reviewedAt || new Date().toISOString();
            }
          }
        });
      }
      msg.textContent = 'Marked as ' + status + ' (' + (PERIOD_LABELS[period] || period) + ').';
      if (currentEnrolledSubject) await refreshEnrolled();
      renderGrid();
    } catch (err) {
      msg.textContent = err.message || 'Could not save approval.';
    } finally {
      subjectHeader.querySelectorAll('.approve-chip-btn').forEach((button) => { button.disabled = false; });
    }
  }

  document.getElementById('reviewClose').addEventListener('click', () => reviewDialog.close());

  // Reliable close handling for every dialog Close/Cancel button.
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const map = { profileCloseX:'profileDialog', enrolledClose:'enrolledDialog', reviewClose:'reviewDialog', subjectsCloseX:'subjectsDialog' };
    const dialogId = map[btn.id];
    if (dialogId) { const d=document.getElementById(dialogId); if(d && d.open){ e.preventDefault(); d.close(); } }
  });

  /* -------------------------------------------------------------- */
  renderGrid();



  function openMessageComposer(profileKey, studentName, subjectCode) {
    let dlg = document.getElementById('messageDialog');
    if (!dlg) {
      dlg = document.createElement('dialog');
      dlg.id = 'messageDialog';
      dlg.className = 'csj-dialog';
      dlg.innerHTML = `
        <form method="dialog" class="dialog-form" onsubmit="return false;">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
            <h2 style="margin:0;">Conversation</h2>
            <button type="button" class="btn btn-ghost dialog-x" id="messageCancelTop" aria-label="Close">&times;</button>
          </div>
          <p class="dialog-sub" id="messageStudentLabel"></p>
          <div id="instructorChatList" style="max-height:280px;overflow:auto;display:flex;flex-direction:column;gap:8px;margin:8px 0 12px;padding:4px;"></div>
          <label style="display:block;font-size:12px;font-weight:600;margin:0 0 4px;">Your message
            <textarea id="messageBody" rows="3" maxlength="2000" placeholder="Write about their self-monitoring chart…" style="display:block;width:100%;margin-top:6px;padding:10px;border:1px solid #d9d0b8;border-radius:8px;box-sizing:border-box;resize:vertical;font:inherit;"></textarea>
          </label>
          <p id="messageStatus" class="dialog-hint" style="min-height:16px;"></p>
          <div class="dialog-actions">
            <span></span>
            <button type="button" class="btn btn-primary" id="messageSend">Send ✉️</button>
          </div>
        </form>`;
      document.body.appendChild(dlg);
      const closeMsg = () => { if (dlg.open) dlg.close(); };
      document.getElementById('messageCancelTop').addEventListener('click', closeMsg);
      document.getElementById('messageSend').addEventListener('click', sendStudentMessage);
    }
    dlg.dataset.profileKey = profileKey;
    dlg.dataset.subjectCode = subjectCode || '';
    dlg.dataset.studentName = studentName || 'Student';
    document.getElementById('messageStudentLabel').textContent =
      (studentName || 'Student') + (subjectCode ? (' · ' + subjectCode) : '');
    document.getElementById('messageBody').value = '';
    document.getElementById('messageStatus').textContent = '';
    document.getElementById('instructorChatList').innerHTML = '<p class="empty-hint">Loading conversation…</p>';
    if (!dlg.open) dlg.showModal();
    loadInstructorThread(profileKey);
  }

  function escapeChat(s) {
    return String(s || '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function formatChatTime(v) {
    if (!v) return '';
    const d = new Date(String(v).replace(' ', 'T'));
    if (isNaN(d)) return v;
    return d.toLocaleString(undefined, { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' });
  }

  async function loadInstructorThread(profileKey) {
    const list = document.getElementById('instructorChatList');
    if (!list) return;
    try {
      const res = await fetch(BASE + '/php/messages.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ action: 'thread_instructor', profileKey })
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.message || 'Could not load conversation.');
      const msgs = data.messages || [];
      if (!msgs.length) {
        list.innerHTML = '<p class="empty-hint">No messages yet. Send the first note about their monitoring.</p>';
      } else {
        const studentName = (document.getElementById('messageDialog') || {}).dataset?.studentName || 'Student';
        list.innerHTML = msgs.map((m) => {
          const fromInst = String(m.sender_role || 'instructor') !== 'student';
          const name = fromInst ? (m.instructor_name || 'You') : studentName;
          const align = fromInst ? 'flex-end' : 'flex-start';
          const bg = fromInst ? '#e8f5ee' : '#fffdf5';
          return `<div style="display:flex;justify-content:${align};">
            <div style="max-width:90%;border:1px solid #e5decc;border-radius:10px;padding:8px 10px;background:${bg};">
              <div style="font-size:10px;color:#5b6b5e;display:flex;justify-content:space-between;gap:8px;">
                <strong style="color:#0e3d24;">${escapeChat(name)}</strong>
                <span>${escapeChat(formatChatTime(m.created_at))}</span>
              </div>
              <div style="font-size:12.5px;line-height:1.4;margin-top:4px;white-space:pre-wrap;">${escapeChat(m.body || '')}</div>
            </div>
          </div>`;
        }).join('');
        list.scrollTop = list.scrollHeight;
      }
      // mark student replies as read
      await fetch(BASE + '/php/messages.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark_read_instructor', profileKey })
      });
      refreshInstructorUnread();
    } catch (err) {
      list.innerHTML = `<p class="empty-hint">${escapeChat(err.message || 'Could not load conversation.')}</p>`;
    }
  }

  async function sendStudentMessage() {
    const dlg = document.getElementById('messageDialog');
    if (!dlg) return;
    const bodyEl = document.getElementById('messageBody');
    const status = document.getElementById('messageStatus');
    const body = (bodyEl.value || '').trim();
    if (!body) { status.textContent = 'Please write a message.'; return; }
    status.textContent = 'Sending…';
    try {
      const res = await fetch(BASE + '/php/messages.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({
          action: 'send_instructor',
          profileKey: dlg.dataset.profileKey,
          subjectCode: dlg.dataset.subjectCode || currentEnrolledSubject || '',
          semester: semester(),
          body: body
        })
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.message || 'Could not send message.');
      bodyEl.value = '';
      status.textContent = '✓ Message sent.';
      await loadInstructorThread(dlg.dataset.profileKey);
      setTimeout(() => { status.textContent = ''; }, 1200);
    } catch (err) {
      status.textContent = err.message || 'Could not send message.';
    }
  }


  /* -------------------------------------------------------------- */
  /* 🔔 Notifications: student replies, across all students          */
  /* -------------------------------------------------------------- */

  async function refreshInstructorUnread() {
    if (!notifyBadge) return;
    try {
      const r = await fetch(BASE + '/php/messages.php?action=unread_instructor', { credentials: 'same-origin', cache: 'no-store' });
      const d = await r.json();
      const n = (r.ok && d.ok) ? (d.unread || 0) : 0;
      if (n > 0) {
        notifyBadge.style.display = '';
        notifyBadge.textContent = n > 99 ? '99+' : String(n);
      } else {
        notifyBadge.style.display = 'none';
      }
    } catch (_) {
      notifyBadge.style.display = 'none';
    }
  }

  /* Group the flat message list (all students mixed together) into one
     row per student, newest message first -- same approach as the
     student-side inbox, keyed by profileKey instead of instructorKey. */
  function groupMessagesByStudent(msgs) {
    const byStudent = new Map();
    (msgs || []).forEach((m) => {
      const key = m.profile_key || 'unknown';
      if (!byStudent.has(key)) {
        byStudent.set(key, { profileKey: key, studentName: m.student_name || 'Student', subjectCode: '', messages: [], unread: 0, lastAt: m.created_at });
      }
      const g = byStudent.get(key);
      g.messages.push(m);
      g.lastAt = m.created_at; // messages arrive sorted oldest->newest
      if (m.subject_code) g.subjectCode = m.subject_code;
      if (String(m.sender_role || 'instructor') === 'student' && !Number(m.is_read)) g.unread++;
    });
    return Array.from(byStudent.values()).sort((a, b) => new Date(b.lastAt) - new Date(a.lastAt));
  }

  async function openNotifyInbox() {
    if (!notifyDialog || !notifyList) return;
    notifyList.innerHTML = '<p class="empty-hint">Loading…</p>';
    if (!notifyDialog.open) notifyDialog.showModal();
    try {
      const r = await fetch(BASE + '/php/messages.php?action=inbox_instructor', { credentials: 'same-origin', cache: 'no-store' });
      const d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.message || 'Could not load notifications.');
      const groups = groupMessagesByStudent(d.messages || []);
      if (!groups.length) {
        notifyList.innerHTML = '<p class="empty-hint">No student replies yet.</p>';
        return;
      }
      notifyList.innerHTML = groups.map((g) => {
        const last = g.messages[g.messages.length - 1];
        const preview = escapeChat((last.body || '').slice(0, 80)) + ((last.body || '').length > 80 ? '…' : '');
        const unreadBadge = g.unread > 0
          ? `<span style="background:#c0392b;color:#fff;border-radius:999px;font-size:10px;font-weight:700;padding:2px 7px;margin-left:6px;">${g.unread}</span>`
          : '';
        return `<div class="notif-row" data-profile-key="${escapeChat(g.profileKey)}" data-student-name="${escapeChat(g.studentName)}" data-subject-code="${escapeChat(g.subjectCode)}" style="display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid #e5decc;border-radius:10px;padding:10px 12px;cursor:pointer;background:${g.unread > 0 ? '#fffaf0' : '#fff'};">
          <div style="min-width:0;">
            <div style="font-size:13px;font-weight:700;color:#0e3d24;">${escapeChat(g.studentName)}${unreadBadge}</div>
            <div style="font-size:11.5px;color:#5b6b5e;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:340px;">${preview || '(no message text)'}</div>
          </div>
          <div style="font-size:10.5px;color:#8a8571;white-space:nowrap;">${escapeChat(formatChatTime(g.lastAt))}</div>
        </div>`;
      }).join('');
      notifyList.querySelectorAll('.notif-row').forEach((row) => {
        // One click opens the conversation with that student.
        row.addEventListener('click', () => {
          if (notifyDialog.open) notifyDialog.close();
          openMessageComposer(row.dataset.profileKey, row.dataset.studentName, row.dataset.subjectCode || '');
        });
      });
    } catch (err) {
      notifyList.innerHTML = `<p class="empty-hint">${escapeChat(err.message || 'Could not load notifications.')}</p>`;
    }
  }

  const notifyBtn = document.getElementById('notifyBtn');
  if (notifyBtn) notifyBtn.addEventListener('click', openNotifyInbox);
  const notifyCloseBtn = document.getElementById('notifyClose');
  if (notifyCloseBtn) notifyCloseBtn.addEventListener('click', () => { if (notifyDialog.open) notifyDialog.close(); });
  // Reload the badge once the per-student conversation dialog gets closed,
  // so replying/reading from the notifications list clears it right away.
  document.addEventListener('close', (e) => {
    if (e.target && e.target.id === 'messageDialog') refreshInstructorUnread();
  }, true);

  refreshInstructorUnread();
  window.setInterval(refreshInstructorUnread, 45000);

  /* -------------------------------------------------------------- */
  /* Feedback                                                        */
  /* -------------------------------------------------------------- */

  (function wireFeedbackUi() {
    const btn = document.getElementById('feedbackBtn');
    const dlg = document.getElementById('feedbackDialog');
    const closeBtn = document.getElementById('feedbackClose');
    const sendBtn = document.getElementById('feedbackSend');
    const input = document.getElementById('feedbackInput');
    const status = document.getElementById('feedbackStatus');
    if (!btn || !dlg) return;

    btn.addEventListener('click', () => {
      if (status) status.textContent = '';
      if (!dlg.open) dlg.showModal();
      if (input) input.focus();
    });
    if (closeBtn) closeBtn.addEventListener('click', () => { if (dlg.open) dlg.close(); });

    async function sendFeedback() {
      const message = (input ? input.value : '').trim();
      if (!message) {
        if (status) status.textContent = 'Please write your feedback first.';
        return;
      }
      if (sendBtn) sendBtn.disabled = true;
      if (status) status.textContent = 'Sending…';
      try {
        const res = await fetch(BASE + '/php/feedback.php', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'send', message })
        });
        const data = await res.json();
        if (!res.ok || !data.ok) throw new Error(data.message || 'Could not send feedback.');
        if (status) status.textContent = data.message || 'Thanks for your feedback!';
        if (input) input.value = '';
        setTimeout(() => {
          if (dlg.open) dlg.close();
          if (status) status.textContent = '';
        }, 1200);
      } catch (err) {
        if (status) status.textContent = err.message || 'Could not send feedback.';
      } finally {
        if (sendBtn) sendBtn.disabled = false;
      }
    }
    if (sendBtn) sendBtn.addEventListener('click', sendFeedback);
    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
          e.preventDefault();
          sendFeedback();
        }
      });
    }
  })();

})();
