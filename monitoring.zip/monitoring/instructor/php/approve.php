<?php
/**
 * POST approve.php
 * body: { profileKey, semester, subjectCode, period?, approve: true|false }
 */
header('Content-Type: application/json; charset=utf-8');
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require __DIR__ . '/../../php/db.php';
require_once __DIR__ . '/../../php/audit.php';

if (empty($_SESSION['instructor_key'])) {
    $cookieKey = preg_replace('/[^a-f0-9]/', '', (string)($_COOKIE['csj_instructor_key'] ?? ''));
    if (strlen($cookieKey) === 32) {
        $_SESSION['instructor_key'] = $cookieKey;
    }
}
if (empty($_SESSION['instructor_key'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Instructor session not found. Open the Instructor Dashboard first.']);
    exit;
}
// Mark session authenticated if key is present (dashboard already required login).
if (empty($_SESSION['instructor_authenticated'])) {
    $_SESSION['instructor_authenticated'] = true;
}

$instructorKey = (string)$_SESSION['instructor_key'];
setcookie('csj_instructor_key', $instructorKey, [
    'expires' => time() + 31536000,
    'path' => '/',
    'samesite' => 'Lax',
]);

$payload = json_decode(file_get_contents('php://input'), true);
$payload = is_array($payload) ? $payload : [];

$profileKey = trim((string)($payload['profileKey'] ?? ''));
$semester   = trim((string)($payload['semester'] ?? ''));
$subject    = trim((string)($payload['subjectCode'] ?? ''));
$periodIn   = strtolower(trim((string)($payload['period'] ?? '')));
$decisionValue = $payload['decision'] ?? '';
$decision = is_string($decisionValue) ? strtolower(trim($decisionValue)) : '';
if ($decision === '') {
    $decision = filter_var($payload['approve'] ?? false, FILTER_VALIDATE_BOOLEAN)
        ? 'approved'
        : 'pending';
}

if ($profileKey === '' || $subject === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Missing student or subject.']);
    exit;
}
if (!in_array($decision, ['approved', 'denied', 'pending'], true)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Choose a valid review decision.']);
    exit;
}

function csj_norm_code(string $s): string {
    // Strip everything except letters/digits (not just whitespace) so a
    // subject typed as "FM 303", "FM-303", or "fm303" all normalize the
    // same way. Must stay identical to enrolled.php's csj_norm() and the
    // instructor dashboard's normCode() in instructor.js, since the
    // Approve button's visibility and this permission check both rely on
    // the same student-appears-in-"View Enrolled Students" match.
    return strtolower(preg_replace('/[^a-z0-9]/i', '', trim($s)));
}

function csj_approve_expand_periods(array $chart): array {
    $periodKeys = ['prelims', 'midterms', 'finals'];
    if (!isset($chart['periods']) || !is_array($chart['periods'])) {
        $chart['periods'] = [];
    }
    if ((!empty($chart['subjects']) || !empty($chart['rows'])) && empty($chart['periods']['prelims'])) {
        $chart['periods']['prelims'] = [
            'chartTitle' => 'SELF-REVIEW MONITORING CHART FOR THE PRELIMS',
            'subjects' => is_array($chart['subjects'] ?? null) ? $chart['subjects'] : [],
            'rows' => is_array($chart['rows'] ?? null) ? $chart['rows'] : [],
        ];
    }
    foreach ($periodKeys as $pk) {
        if (!isset($chart['periods'][$pk]) || !is_array($chart['periods'][$pk])) {
            $chart['periods'][$pk] = [
                'chartTitle' => 'SELF-REVIEW MONITORING CHART FOR THE ' . strtoupper($pk),
                'subjects' => [],
                'rows' => [],
            ];
        }
        if (!isset($chart['periods'][$pk]['subjects']) || !is_array($chart['periods'][$pk]['subjects'])) {
            $chart['periods'][$pk]['subjects'] = [];
        }
        if (!isset($chart['periods'][$pk]['rows']) || !is_array($chart['periods'][$pk]['rows'])) {
            $chart['periods'][$pk]['rows'] = [];
        }
    }
    return $chart;
}

try {
    $pdo = csj_db();
    $pdo->beginTransaction();

    // Ensure instructor profile row exists; name can be empty → use fallback.
    $pdo->prepare(
        'INSERT INTO instructor_profiles (instructor_key, full_name)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE instructor_key = instructor_key'
    )->execute([$instructorKey, 'Instructor']);

    $stmt = $pdo->prepare('SELECT full_name FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
    $stmt->execute([$instructorKey]);
    $instructorName = trim((string)$stmt->fetchColumn());
    if ($instructorName === '') {
        $instructorName = 'Instructor';
        $pdo->prepare('UPDATE instructor_profiles SET full_name = ? WHERE instructor_key = ?')
            ->execute([$instructorName, $instructorKey]);
    }

    // Instructor may approve any subject they selected (any semester — flexible school year).
    $needle = csj_norm_code($subject);
    $stmt = $pdo->prepare(
        "SELECT subject_code, semester FROM instructor_subject_selections WHERE instructor_key = ?"
    );
    $stmt->execute([$instructorKey]);
    $allowed = false;
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $sel) {
        if (csj_norm_code((string)$sel['subject_code']) === $needle) {
            $allowed = true;
            break;
        }
    }
    if (!$allowed) {
        $pdo->rollBack();
        http_response_code(403);
        echo json_encode([
            'ok' => false,
            'message' => 'You can only approve subjects you loaded under Load Subject.',
        ]);
        exit;
    }

    // Load student chart: exact semester → case-insensitive → latest for this student
    $chartJson = false;
    $studentName = '';
    if ($semester !== '') {
        $stmt = $pdo->prepare(
            'SELECT chart_json, student_name, semester FROM monitoring_submissions
             WHERE profile_key = ? AND semester = ? LIMIT 1 FOR UPDATE'
        );
        $stmt->execute([$profileKey, $semester]);
        $submission = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($submission) {
            $chartJson = $submission['chart_json'];
            $studentName = (string)($submission['student_name'] ?? '');
            $semester = (string)$submission['semester'];
        }
    }
    if ($chartJson === false) {
        $stmt = $pdo->prepare(
            'SELECT chart_json, semester, student_name FROM monitoring_submissions
             WHERE profile_key = ? ORDER BY updated_at DESC FOR UPDATE'
        );
        $stmt->execute([$profileKey]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($semester !== '') {
            foreach ($rows as $row) {
                if (strcasecmp(trim((string)$row['semester']), $semester) === 0) {
                    $chartJson = $row['chart_json'];
                    $semester = (string)$row['semester'];
                    $studentName = (string)$row['student_name'];
                    break;
                }
            }
        }
        if ($chartJson === false && $rows) {
            $row = $rows[0];
            $chartJson = $row['chart_json'];
            $semester = (string)$row['semester'];
            $studentName = (string)$row['student_name'];
        }
    }

    if ($chartJson === false) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'The student has no submitted chart. Ask them to click Submit.']);
        exit;
    }

    $chart = json_decode($chartJson, true);
    if (!is_array($chart)) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'The student chart data is invalid.']);
        exit;
    }

    $chart = csj_approve_expand_periods($chart);
    $matched = false;
    $targetPeriods = ($periodIn !== '' && in_array($periodIn, ['prelims', 'midterms', 'finals'], true))
        ? [$periodIn]
        : ['prelims', 'midterms', 'finals'];

    foreach ($targetPeriods as $pk) {
        if (empty($chart['periods'][$pk]['subjects']) || !is_array($chart['periods'][$pk]['subjects'])) {
            continue;
        }
        foreach ($chart['periods'][$pk]['subjects'] as &$s) {
            $code = (string)($s['code'] ?? '');
            if ($code === '' || csj_norm_code($code) !== $needle) {
                continue;
            }
            $s['approved'] = $decision === 'approved';
            $s['reviewStatus'] = $decision;
            $s['instructor'] = $decision === 'approved' ? $instructorName : '';
            if ($decision !== 'pending') {
                $reviewedAt = date('Y-m-d H:i:s');
                $s['reviewedBy'] = $instructorName;
                $s['reviewedAt'] = $reviewedAt;
            } else {
                unset($s['reviewedBy'], $s['reviewedAt']);
            }
            if ($decision === 'approved') {
                $s['approvedAt'] = $reviewedAt;
            } else {
                unset($s['approvedAt']);
            }
            $matched = true;
            // only this period when period specified; continue to allow multi if not
            if ($periodIn !== '') {
                break 2;
            }
        }
        unset($s);
    }

    if (!$matched) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode([
            'ok' => false,
            'message' => 'That subject code was not found on the student chart for period: ' . ($periodIn ?: 'any') . '.',
        ]);
        exit;
    }

    $newJson = json_encode($chart, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($newJson === false) {
        throw new RuntimeException('Could not encode the updated chart.');
    }

    $upd = $pdo->prepare(
        'UPDATE monitoring_submissions
         SET chart_json = ?, updated_at = CURRENT_TIMESTAMP
         WHERE profile_key = ? AND semester = ?'
    );
    $upd->execute([$newJson, $profileKey, $semester]);

    csj_audit_log(
        $pdo,
        $decision === 'approved'
            ? 'instructor_approval'
            : ($decision === 'denied' ? 'instructor_denial' : 'instructor_approval_removed'),
        'student',
        $profileKey,
        $studentName,
        [
            'subject_code' => $subject,
            'semester' => $semester,
            'period' => $periodIn !== '' ? $periodIn : 'all',
            'decision' => $decision,
        ],
        'teacher',
        $instructorKey,
        $instructorName
    );
    $pdo->commit();

    echo json_encode([
        'ok' => true,
        'approved' => $decision === 'approved',
        'status' => $decision,
        'reviewer' => $decision !== 'pending' ? $instructorName : '',
        'instructor' => $decision === 'approved' ? $instructorName : '',
        'subjectCode' => $subject,
        'period' => $periodIn !== '' ? $periodIn : null,
    ]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => 'Approval could not be saved: ' . $e->getMessage(),
    ]);
}
