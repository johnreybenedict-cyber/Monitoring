<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['instructor_authenticated']) && empty($_SESSION['instructor_key'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Instructor login required.']);
    exit;
}
// OTP verification for contact numbers has been removed from this system.
http_response_code(410);
echo json_encode(['ok' => false, 'message' => 'Phone OTP is no longer used. Save your contact number in Profile.']);
