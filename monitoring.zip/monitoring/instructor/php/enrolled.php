<?php
/**
 * GET enrolled.php?subject=CODE&semester=SEM[&period=prelims|midterms|finals]
 * Returns every student who listed the given subject on their chart for the
 * semester. Approval status is reported per period (and as a summary).
 */
header('Content-Type: application/json');
require __DIR__ . '/../../php/db.php';

$subject  = trim((string)($_GET['subject'] ?? ''));
$semester = trim((string)($_GET['semester'] ?? ''));
$periodIn = strtolower(trim((string)($_GET['period'] ?? '')));

if ($subject === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Subject is required.']);
    exit;
}

function csj_norm(string $s): string {
    // Kept identical to approve.php's csj_norm_code() and instructor.js's
    // normCode() -- strips all non-alphanumeric characters, not just
    // whitespace, so minor formatting differences in how a subject code
    // was typed don't break the enrolled-list match or the Approve action.
    return strtolower(preg_replace('/[^a-z0-9]/i', '', $s));
}

function csj_periods_from_chart(array $chart): array {
    $keys = ['prelims', 'midterms', 'finals'];
    $out = [];
    if (isset($chart['periods']) && is_array($chart['periods'])) {
        foreach ($keys as $k) {
            if (!empty($chart['periods'][$k]['subjects']) && is_array($chart['periods'][$k]['subjects'])) {
                $out[$k] = $chart['periods'][$k]['subjects'];
            }
        }
    }
    // Legacy flat
    if (empty($out) && !empty($chart['subjects']) && is_array($chart['subjects'])) {
        $out['prelims'] = $chart['subjects'];
    }
    return $out;
}

function csj_norm_semester(string $s): string {
    return strtolower(trim(preg_replace('/\s+/', ' ', $s)));
}

try {
    $pdo = csj_db();
    $needle = csj_norm($subject);

    // Always scan submissions by subject code. Semester is a soft preference:
    // if the instructor semester string does not exactly match the student
    // chart semester, students who listed this subject still appear.
    $stmt = $pdo->query(
        'SELECT profile_key, student_name, course_year, chart_json, submitted_at, updated_at, semester
         FROM monitoring_submissions
         ORDER BY updated_at DESC'
    );
    $rows = $stmt->fetchAll();

    $students = [];
    $semNorm = $semester !== '' ? csj_norm_semester($semester) : '';

    foreach ($rows as $row) {
        $chart = json_decode($row['chart_json'], true);
        if (!is_array($chart)) continue;

        $periodSubjects = csj_periods_from_chart($chart);
        if (empty($periodSubjects)) continue;

        $periodStatus = [];
        $anyMatch = false;
        $anyApproved = false;
        $anyDenied = false;
        $slotId = null;
        $instructorName = '';

        foreach ($periodSubjects as $pk => $subjects) {
            if ($periodIn !== '' && $pk !== $periodIn) continue;
            foreach ($subjects as $s) {
                if (($s['code'] ?? '') === '' || csj_norm($s['code']) !== $needle) continue;
                $anyMatch = true;
                $status = in_array($s['reviewStatus'] ?? '', ['approved', 'denied', 'pending'], true)
                    ? $s['reviewStatus']
                    : (!empty($s['approved']) ? 'approved' : 'pending');
                $approved = $status === 'approved';
                $periodStatus[$pk] = [
                    'approved' => $approved,
                    'status' => $status,
                    'instructor' => $s['instructor'] ?? '',
                    'slotId' => $s['id'] ?? null,
                ];
                if ($approved) {
                    $anyApproved = true;
                    $instructorName = $s['instructor'] ?? $instructorName;
                }
                if ($status === 'denied') $anyDenied = true;
                if ($slotId === null) $slotId = $s['id'] ?? null;
                break;
            }
        }

        if (!$anyMatch) continue;

        // If a specific period was requested, surface that period's status as primary
        $primaryApproved = $anyApproved;
        $primaryStatus = $anyApproved ? 'approved' : ($anyDenied ? 'denied' : 'pending');
        $primaryInstructor = $instructorName;
        if ($periodIn !== '' && isset($periodStatus[$periodIn])) {
            $primaryApproved = !empty($periodStatus[$periodIn]['approved']);
            $primaryStatus = $periodStatus[$periodIn]['status'];
            $primaryInstructor = $periodStatus[$periodIn]['instructor'] ?? '';
            $slotId = $periodStatus[$periodIn]['slotId'] ?? $slotId;
        }

        $students[] = [
            'profileKey'  => $row['profile_key'],
            'studentName' => $row['student_name'],
            'courseYear'  => $row['course_year'],
            'semester'    => $row['semester'] ?? '',
            'submittedAt' => $row['submitted_at'],
            'updatedAt'   => $row['updated_at'],
            'approved'    => $primaryApproved,
            'status'      => $primaryStatus,
            'instructor'  => $primaryInstructor,
            'slotId'      => $slotId,
            'periods'     => $periodStatus,
        ];
    }

    usort($students, fn($a, $b) => strcasecmp($a['studentName'], $b['studentName']));

    
    // Prefer students whose submission semester matches the instructor field
    if ($semNorm !== '') {
        usort($students, function ($a, $b) use ($semNorm) {
            $am = csj_norm_semester((string)($a['semester'] ?? '')) === $semNorm ? 0 : 1;
            $bm = csj_norm_semester((string)($b['semester'] ?? '')) === $semNorm ? 0 : 1;
            return $am <=> $bm;
        });
    }

echo json_encode([
        'ok' => true,
        'subject' => $subject,
        'semester' => $semester,
        'period' => $periodIn !== '' ? $periodIn : null,
        'students' => $students,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'MySQL not connected. Start MySQL and import schema.sql.']);
}
