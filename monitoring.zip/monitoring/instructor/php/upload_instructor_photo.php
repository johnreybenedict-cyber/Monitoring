<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require __DIR__ . '/../../php/db.php';
if (empty($_SESSION['instructor_authenticated']) || empty($_SESSION['instructor_key'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Please log in as an instructor.']);
    exit;
}
$key = (string)$_SESSION['instructor_key'];

// Remove profile picture
if (isset($_POST['remove']) && (string)$_POST['remove'] === '1') {
    try {
        $pdo = csj_db();
        $st = $pdo->prepare('SELECT photo_path FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
        $st->execute([$key]);
        $old = (string)($st->fetchColumn() ?: '');
        if ($old !== '' && strpos($old, '..') === false) {
            $file = __DIR__ . '/../../' . ltrim($old, '/');
            if (is_file($file)) @unlink($file);
        }
        $dir = __DIR__ . '/../../uploads/instructors';
        // best-effort: nothing else to clean by key since names are random
        $pdo->prepare('UPDATE instructor_profiles SET photo_path = NULL, updated_at = CURRENT_TIMESTAMP WHERE instructor_key = ?')
            ->execute([$key]);
        echo json_encode(['ok' => true, 'removed' => true, 'photoPath' => '']);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Could not remove the profile picture.']);
    }
    exit;
}

if (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Choose a valid image.']);
    exit;
}
$f = $_FILES['photo'];
if ($f['size'] > 5 * 1024 * 1024) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Image must be 5 MB or smaller.']);
    exit;
}
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
$allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
if (!isset($allowed[$mime])) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Only JPG, PNG, WEBP or GIF images are allowed.']);
    exit;
}
$dir = __DIR__ . '/../../uploads/instructors';
if (!is_dir($dir)) mkdir($dir, 0755, true);
$name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not save image.']);
    exit;
}
$path = 'uploads/instructors/' . $name;
try {
    $pdo = csj_db();
    foreach (['photo_path VARCHAR(255) DEFAULT NULL'] as $col) {
        try { $pdo->exec('ALTER TABLE instructor_profiles ADD COLUMN ' . $col); } catch (Throwable $e) {}
    }
    // delete previous file if any
    $st = $pdo->prepare('SELECT photo_path FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
    $st->execute([$key]);
    $old = (string)($st->fetchColumn() ?: '');
    if ($old !== '' && strpos($old, '..') === false) {
        $file = __DIR__ . '/../../' . ltrim($old, '/');
        if (is_file($file)) @unlink($file);
    }
    $st = $pdo->prepare('UPDATE instructor_profiles SET photo_path = ?, updated_at = CURRENT_TIMESTAMP WHERE instructor_key = ?');
    $st->execute([$path, $key]);
    echo json_encode(['ok' => true, 'photoPath' => $path]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'message' => 'Could not update profile photo.']);
}
