<?php
/**
 * Optional WebAuthn / passkey credential management for instructors.
 *
 * Actions (JSON POST body or ?action=):
 *   status   – return whether this instructor already has credentials
 *   register – store a new credential_id (+ optional public_key / label)
 *   remove   – delete all credentials for this instructor
 *
 * The biometric image itself never leaves the user's device.
 * Full cryptographic assertion verification is left to a future upgrade;
 * this endpoint focuses on reliable storage so the missing-table error
 * is fixed and registration succeeds.
 */
header('Content-Type: application/json');
session_start();
require __DIR__ . '/../../php/db.php';
require_once __DIR__ . '/../../php/audit.php';

if (empty($_SESSION['instructor_key'])) {
    $cookieKey = preg_replace('/[^a-f0-9]/', '', (string)($_COOKIE['csj_instructor_key'] ?? ''));
    $_SESSION['instructor_key'] = strlen($cookieKey) === 32 ? $cookieKey : bin2hex(random_bytes(16));
}
$instructorKey = $_SESSION['instructor_key'];
setcookie('csj_instructor_key', $instructorKey, [
    'expires' => time() + 31536000,
    'path' => '/',
    'samesite' => 'Lax',
]);

$payload = json_decode(file_get_contents('php://input'), true) ?: [];
$action  = strtolower(trim((string)($payload['action'] ?? $_GET['action'] ?? 'status')));

try {
    $pdo = csj_db();
    try { $pdo->exec('ALTER TABLE instructor_biometric_credentials ADD COLUMN sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0'); } catch (Throwable $ignored) {}
    try { $pdo->exec('ALTER TABLE instructor_biometric_credentials ADD COLUMN public_key TEXT DEFAULT NULL'); } catch (Throwable $ignored) {}
    try { $pdo->exec('ALTER TABLE instructor_biometric_credentials ADD COLUMN last_used_at DATETIME DEFAULT NULL'); } catch (Throwable $ignored) {}

    // Make sure the instructor profile row exists (needed for FK).
    $pdo->prepare(
        'INSERT IGNORE INTO instructor_profiles (instructor_key, full_name) VALUES (?, \'\')'
    )->execute([$instructorKey]);

    if ($action === 'status') {
        $stmt = $pdo->prepare('SELECT credential_row_id, device_label, created_at FROM instructor_biometric_credentials WHERE instructor_key = ? ORDER BY created_at DESC');
        $stmt->execute([$instructorKey]);
        $rows = $stmt->fetchAll();
        echo json_encode([
            'ok' => true,
            'registered' => count($rows) > 0,
            'count' => count($rows),
            'credentials' => $rows,
        ]);
        exit;
    }

    if ($action === 'register') {
        $credentialId = trim((string)($payload['credentialId'] ?? ''));
        $publicKey    = trim((string)($payload['publicKey'] ?? ''));
        $transports   = trim((string)($payload['transports'] ?? ''));
        $deviceLabel  = trim((string)($payload['deviceLabel'] ?? 'This device'));

        if ($credentialId === '') {
            http_response_code(422);
            echo json_encode(['ok' => false, 'message' => 'Missing credentialId from the authenticator.']);
            exit;
        }

        // Avoid duplicates for the same credential id.
        $stmt = $pdo->prepare(
            'INSERT INTO instructor_biometric_credentials
               (instructor_key, credential_id, public_key, transports, device_label)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
               public_key = VALUES(public_key),
               transports = VALUES(transports),
               device_label = VALUES(device_label)'
        );
        $stmt->execute([
            $instructorKey,
            $credentialId,
            $publicKey !== '' ? $publicKey : null,
            $transports !== '' ? $transports : null,
            $deviceLabel !== '' ? $deviceLabel : 'This device',
        ]);
        $nameStmt = $pdo->prepare('SELECT full_name FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
        $nameStmt->execute([$instructorKey]);
        $instructorName = (string)($nameStmt->fetchColumn() ?: 'Teacher');
        csj_audit_log($pdo, 'teacher_biometric_registered', 'teacher', (string)$instructorKey, $instructorName, ['method' => 'webauthn'], 'teacher', (string)$instructorKey, $instructorName);

        echo json_encode(['ok' => true, 'message' => 'Biometric credential registered.', 'registered' => true]);
        exit;
    }

    if ($action === 'remove') {
        $stmt = $pdo->prepare('DELETE FROM instructor_biometric_credentials WHERE instructor_key = ?');
        $stmt->execute([$instructorKey]);
        $nameStmt = $pdo->prepare('SELECT full_name FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
        $nameStmt->execute([$instructorKey]);
        $instructorName = (string)($nameStmt->fetchColumn() ?: 'Teacher');
        csj_audit_log($pdo, 'teacher_biometrics_removed', 'teacher', (string)$instructorKey, $instructorName, [], 'teacher', (string)$instructorKey, $instructorName);
        echo json_encode(['ok' => true, 'message' => 'Biometric credentials removed.', 'registered' => false]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Unknown action. Use status, register or remove.']);
} catch (Throwable $e) {
    $msg = $e->getMessage();
    // Helpful message when the table is still missing.
    if (stripos($msg, 'instructor_biometric_credentials') !== false || stripos($msg, '42S02') !== false) {
        $msg = 'Table instructor_biometric_credentials does not exist. Import the latest schema.sql into MySQL (phpMyAdmin → Import).';
    }
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => $msg]);
}
