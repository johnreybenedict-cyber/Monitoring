<?php
header('Content-Type: application/json');
session_start();
require __DIR__ . '/../../php/db.php';
require_once __DIR__ . '/../../php/audit.php';

if (empty($_SESSION['instructor_key'])) {
    $cookieKey = preg_replace('/[^a-f0-9]/', '', (string)($_COOKIE['csj_instructor_key'] ?? ''));
    $_SESSION['instructor_key'] = strlen($cookieKey) === 32 ? $cookieKey : bin2hex(random_bytes(16));
}
$instructorKey = $_SESSION['instructor_key'];
setcookie('csj_instructor_key', $instructorKey, [
    'expires' => time() + 31536000,
    'path' => '/',
    'samesite' => 'Lax',
]);

$payload = json_decode(file_get_contents('php://input'), true) ?: [];
$fullName = trim((string)($payload['fullName'] ?? ''));
$email    = trim((string)($payload['email'] ?? ''));
$program  = trim((string)($payload['program'] ?? ''));
$address  = trim((string)($payload['address'] ?? ''));
$contact  = preg_replace('/[^0-9+]/', '', trim((string)($payload['contactNo'] ?? '')));

if ($fullName === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Full name is required.']);
    exit;
}

try {
    $pdo = csj_db();
    foreach ([
      'teacher_id VARCHAR(50) DEFAULT NULL',
      'program VARCHAR(150) DEFAULT NULL',
      'address VARCHAR(255) DEFAULT NULL',
      'contact_no VARCHAR(50) DEFAULT NULL',
      'password_hash VARCHAR(255) DEFAULT NULL'
    ] as $col) { try { $pdo->exec('ALTER TABLE instructor_profiles ADD COLUMN '.$col); } catch (Throwable $ignored) {} }
    $pdo->exec("CREATE TABLE IF NOT EXISTS instructor_phone_numbers (phone_id INT UNSIGNED AUTO_INCREMENT, instructor_key CHAR(32) NOT NULL, phone_number VARCHAR(30) NOT NULL, is_primary TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(phone_id), UNIQUE KEY uq_instr_phone(instructor_key,phone_number)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->beginTransaction();
    $stmt = $pdo->prepare(
        'INSERT INTO instructor_profiles (instructor_key, full_name, email, program, address, contact_no)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
            full_name = VALUES(full_name),
            email = VALUES(email),
            program = VALUES(program),
            address = VALUES(address),
            contact_no = VALUES(contact_no),
            updated_at = CURRENT_TIMESTAMP'
    );
    $stmt->execute([$instructorKey, $fullName, $email !== '' ? $email : null, $program !== '' ? $program : null, $address !== '' ? $address : null, $contact !== '' ? $contact : null]);
    if ($contact !== '') {
        $q=$pdo->prepare('SELECT COUNT(*) FROM instructor_phone_numbers WHERE instructor_key=? AND phone_number=?'); $q->execute([$instructorKey,$contact]);
        if (!(int)$q->fetchColumn()) $pdo->prepare('INSERT INTO instructor_phone_numbers(instructor_key,phone_number,is_primary) VALUES(?,?,1)')->execute([$instructorKey,$contact]);
    }

    $_SESSION['instructor_authenticated'] = true;
    $_SESSION['instructor_name'] = $fullName;
    csj_audit_log(
        $pdo,
        'teacher_profile_updated',
        'teacher',
        (string)$instructorKey,
        $fullName,
        [],
        'teacher',
        (string)$instructorKey,
        $fullName
    );
    $pdo->commit();
    echo json_encode(['ok' => true, 'fullName' => $fullName, 'email' => $email]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'MySQL not connected. Start MySQL and import schema.sql.']);
}
