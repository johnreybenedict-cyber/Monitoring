<?php
header('Content-Type: application/json');
session_start();
require __DIR__ . '/../../php/db.php';
require_once __DIR__ . '/../../php/audit.php';
$catalogPath = __DIR__ . '/../../php/subjects_catalog.php';
$catalog = is_file($catalogPath) ? require $catalogPath : [];
if (!is_array($catalog)) $catalog = [];

/** Alphanumeric-only key so "Mgt 302", "MGT302-1", "mgt-302" match. */
function csj_sel_norm(string $s): string {
    return strtolower(preg_replace('/[^a-z0-9]/i', '', trim($s)) ?? '');
}

// Map normalized key → preferred display code from catalog
$catalogByNorm = [];
foreach ($catalog as $c) {
    $c = trim((string)$c);
    if ($c === '') continue;
    $k = csj_sel_norm($c);
    if ($k !== '' && !isset($catalogByNorm[$k])) {
        $catalogByNorm[$k] = $c;
    }
}

if (empty($_SESSION['instructor_key'])) {
    $cookieKey = preg_replace('/[^a-f0-9]/', '', (string)($_COOKIE['csj_instructor_key'] ?? ''));
    $_SESSION['instructor_key'] = strlen($cookieKey) === 32 ? $cookieKey : bin2hex(random_bytes(16));
}
$instructorKey = $_SESSION['instructor_key'];
setcookie('csj_instructor_key', $instructorKey, [
    'expires' => time() + 31536000,
    'path' => '/',
    'samesite' => 'Lax',
]);

$payload  = json_decode(file_get_contents('php://input'), true) ?: [];
$semester = trim((string)($payload['semester'] ?? ''));
$subjectsIn = is_array($payload['subjects'] ?? null) ? $payload['subjects'] : [];

// Accept any submitted code that matches a catalog entry by normalized key;
// always store the clean catalog display form (e.g. "Mgt 302" not "MGT302-1").
$subjects = [];
$seen = [];
foreach ($subjectsIn as $raw) {
    $k = csj_sel_norm((string)$raw);
    if ($k === '' || !isset($catalogByNorm[$k]) || isset($seen[$k])) continue;
    $seen[$k] = true;
    $subjects[] = $catalogByNorm[$k];
}

if ($semester === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Semester is required.']);
    exit;
}

try {
    $pdo = csj_db();
    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'INSERT INTO instructor_profiles (instructor_key, full_name)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP'
    );
    $stmt->execute([$instructorKey, 'Instructor']);

    $del = $pdo->prepare('DELETE FROM instructor_subject_selections WHERE instructor_key = ? AND semester = ?');
    $del->execute([$instructorKey, $semester]);

    if (!empty($subjects)) {
        $ins = $pdo->prepare(
            'INSERT INTO instructor_subject_selections (instructor_key, subject_code, semester) VALUES (?, ?, ?)'
        );
        foreach ($subjects as $code) {
            $ins->execute([$instructorKey, $code, $semester]);
        }
    }

    $nameStmt = $pdo->prepare('SELECT full_name FROM instructor_profiles WHERE instructor_key = ? LIMIT 1');
    $nameStmt->execute([$instructorKey]);
    $instructorName = (string)($nameStmt->fetchColumn() ?: 'Teacher');
    $_SESSION['instructor_authenticated'] = true;
    $_SESSION['instructor_name'] = $instructorName;
    csj_audit_log(
        $pdo,
        'teacher_subjects_updated',
        'system',
        $semester,
        $semester,
        ['subject_codes' => $subjects],
        'teacher',
        (string)$instructorKey,
        $instructorName
    );
    $pdo->commit();
    echo json_encode(['ok' => true, 'subjects' => $subjects, 'semester' => $semester]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'MySQL not connected. Start MySQL and import schema.sql.']);
}
