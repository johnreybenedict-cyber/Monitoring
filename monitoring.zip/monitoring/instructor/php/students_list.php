<?php
/**
 * GET students_list.php?semester=SEM
 * Returns every student who has a submitted monitoring chart for the given
 * semester, regardless of subject -- backs the instructor's "All Students /
 * View Self-Monitoring" list (as opposed to enrolled.php, which filters to
 * one subject code at a time).
 */
header('Content-Type: application/json');
session_start();
require __DIR__ . '/../../php/db.php';

$semester = trim((string)($_GET['semester'] ?? ''));

if ($semester === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Semester is required.']);
    exit;
}

$instructorKey = $_SESSION['instructor_key'] ?? '';
$mySubjects = [];

function csj_norm(string $s): string {
    return strtolower(preg_replace('/\s+/', '', $s));
}

try {
    $pdo = csj_db();

    if ($instructorKey !== '') {
        $stmt = $pdo->prepare('SELECT subject_code FROM instructor_subject_selections WHERE instructor_key = ? AND semester = ?');
        $stmt->execute([$instructorKey, $semester]);
        $mySubjects = array_map('csj_norm', array_column($stmt->fetchAll(), 'subject_code'));
    }

    $stmt = $pdo->prepare(
        'SELECT sp.profile_key, sp.student_id, sp.photo_path,
            ms.student_name, ms.course_year, ms.chart_json, ms.submitted_at, ms.updated_at
         FROM monitoring_submissions ms
         LEFT JOIN student_profiles sp ON sp.profile_key = ms.profile_key
         WHERE ms.semester = ?
         ORDER BY ms.student_name'
    );
    $stmt->execute([$semester]);

    $students = [];
    foreach ($stmt->fetchAll() as $row) {
        $chart = json_decode($row['chart_json'], true);
        $subjects = is_array($chart) && !empty($chart['subjects']) ? $chart['subjects'] : [];

        $mineTotal = 0;
        $mineApproved = 0;
        foreach ($subjects as $s) {
            $code = $s['code'] ?? '';
            if ($code === '' || !in_array(csj_norm($code), $mySubjects, true)) continue;
            $mineTotal++;
            if (!empty($s['approved'])) $mineApproved++;
        }

        $students[] = [
            'profileKey'    => $row['profile_key'],
            'studentId'     => $row['student_id'],
            'studentName'   => $row['student_name'],
            'courseYear'    => $row['course_year'],
            'photoPath'     => $row['photo_path'],
            'submittedAt'   => $row['submitted_at'],
            'updatedAt'     => $row['updated_at'],
            'subjectCount'  => count($subjects),
            'mineTotal'     => $mineTotal,
            'mineApproved'  => $mineApproved,
        ];
    }

    echo json_encode(['ok' => true, 'semester' => $semester, 'students' => $students]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'MySQL not connected. Start MySQL and import schema.sql.']);
}
