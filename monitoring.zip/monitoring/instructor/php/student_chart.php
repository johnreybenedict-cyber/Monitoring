<?php
/**
 * GET student_chart.php?profile_key=...&semester=...
 * Loads a student's submitted Self-Monitoring Chart (Prelims / Midterms / Finals).
 * Semester is optional: exact match is tried first, then latest submission for the student.
 */
header('Content-Type: application/json');
require __DIR__ . '/../../php/db.php';

$profileKey = trim((string)($_GET['profile_key'] ?? ''));
$semester   = trim((string)($_GET['semester'] ?? ''));

if ($profileKey === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'profile_key is required.']);
    exit;
}

try {
    $pdo = csj_db();
    $row = null;

    // 1) Exact semester match when provided
    if ($semester !== '') {
        $stmt = $pdo->prepare(
            'SELECT ms.student_name, ms.course_year, ms.chart_json, ms.submitted_at, ms.updated_at, ms.semester,
                sp.student_id, sp.photo_path
             FROM monitoring_submissions ms
             LEFT JOIN student_profiles sp ON sp.profile_key = ms.profile_key
             WHERE ms.profile_key = ? AND ms.semester = ?
             LIMIT 1'
        );
        $stmt->execute([$profileKey, $semester]);
        $row = $stmt->fetch();
    }

    // 2) Case-insensitive semester match
    if (!$row && $semester !== '') {
        $stmt = $pdo->prepare(
            'SELECT ms.student_name, ms.course_year, ms.chart_json, ms.submitted_at, ms.updated_at, ms.semester,
                sp.student_id, sp.photo_path
             FROM monitoring_submissions ms
             LEFT JOIN student_profiles sp ON sp.profile_key = ms.profile_key
             WHERE ms.profile_key = ?'
        );
        $stmt->execute([$profileKey]);
        foreach ($stmt->fetchAll() as $candidate) {
            if (strcasecmp(trim((string)$candidate['semester']), $semester) === 0) {
                $row = $candidate;
                break;
            }
        }
    }

    // 3) Latest submission for this student (flexible semester / school year)
    if (!$row) {
        $stmt = $pdo->prepare(
            'SELECT ms.student_name, ms.course_year, ms.chart_json, ms.submitted_at, ms.updated_at, ms.semester,
                sp.student_id, sp.photo_path
             FROM monitoring_submissions ms
             LEFT JOIN student_profiles sp ON sp.profile_key = ms.profile_key
             WHERE ms.profile_key = ?
             ORDER BY ms.updated_at DESC
             LIMIT 1'
        );
        $stmt->execute([$profileKey]);
        $row = $stmt->fetch();
    }

    if (!$row) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'No submission found. Ask the student to click Submit on their chart.']);
        exit;
    }

    $chart = json_decode($row['chart_json'], true);
    if (!is_array($chart)) $chart = [];

    if (!isset($chart['periods']) || !is_array($chart['periods'])) {
        $chart['periods'] = [];
    }
    if ((!empty($chart['subjects']) || !empty($chart['rows'])) && empty($chart['periods']['prelims'])) {
        $chart['periods']['prelims'] = [
            'chartTitle' => 'SELF-REVIEW MONITORING CHART FOR THE PRELIMS',
            'subjects' => is_array($chart['subjects'] ?? null) ? $chart['subjects'] : [],
            'rows' => is_array($chart['rows'] ?? null) ? $chart['rows'] : [],
        ];
    }
    foreach (['prelims', 'midterms', 'finals'] as $pk) {
        if (!isset($chart['periods'][$pk]) || !is_array($chart['periods'][$pk])) {
            $chart['periods'][$pk] = [
                'chartTitle' => 'SELF-REVIEW MONITORING CHART FOR THE ' . strtoupper($pk),
                'subjects' => [],
                'rows' => [],
            ];
        }
        if (!isset($chart['periods'][$pk]['subjects']) || !is_array($chart['periods'][$pk]['subjects'])) {
            $chart['periods'][$pk]['subjects'] = [];
        }
        if (!isset($chart['periods'][$pk]['rows']) || !is_array($chart['periods'][$pk]['rows'])) {
            $chart['periods'][$pk]['rows'] = [];
        }
    }

    echo json_encode([
        'ok' => true,
        'studentName' => $row['student_name'],
        'courseYear' => $row['course_year'],
        'studentId' => $row['student_id'] ?? '',
        'photoPath' => $row['photo_path'] ?? '',
        'semester' => $row['semester'] ?? $semester,
        'submittedAt' => $row['submitted_at'],
        'updatedAt' => $row['updated_at'],
        'chart' => $chart,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Could not load chart: ' . $e->getMessage()]);
}
