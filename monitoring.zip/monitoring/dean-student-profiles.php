<?php
require_once __DIR__ . '/php/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    header('Location: index.php');
    exit;
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
$deanName = htmlspecialchars((string)($_SESSION['dean_name'] ?? 'Dean'), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Profiles - CSJ Dean Dashboard</title>
  <link rel="icon" href="assets/logos/csj-seal.jpg">
  <link rel="stylesheet" href="css/style.css">
  <style>
    .dean-layout{min-height:calc(100vh - 74px);display:grid;grid-template-columns:245px minmax(0,1fr)}
    .dean-sidebar{padding:24px 16px;background:var(--paper);border-right:1px solid var(--line)}
    .dean-sidebar-label{margin:0 12px 10px;color:var(--ink-soft);font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
    .dean-nav-link{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--radius-sm);background:var(--pine-100);color:var(--pine-900);font-size:13px;font-weight:700;text-decoration:none;margin-top:8px}
    .dean-nav-link:first-of-type{margin-top:0}
    .dean-nav-link.active{background:var(--pine-200,#d7e8dc)}
    .dean-content{min-width:0;padding:32px clamp(16px,4vw,48px)}
    .dean-heading{margin:0 0 8px;color:var(--pine-900);font-family:var(--font-display);font-size:26px}
    .dean-sub{margin:0 0 18px;color:var(--ink-soft);font-size:13px}
    .sp-toolbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:16px}
    .sp-toolbar input[type="search"]{min-width:220px;flex:1;min-height:40px;padding:8px 12px;border:1px solid var(--line);border-radius:var(--radius-sm);font:inherit}
    .sp-grid{display:grid;grid-template-columns:minmax(260px,.9fr) minmax(320px,1.1fr);gap:16px}
    @media(max-width:900px){.sp-grid{grid-template-columns:1fr}.dean-layout{grid-template-columns:1fr}}
    .sp-card{background:var(--paper);border:1px solid var(--line);border-radius:var(--radius-lg);padding:16px}
    .sp-list{max-height:70vh;overflow:auto;display:flex;flex-direction:column;gap:6px}
    .sp-item{text-align:left;padding:12px 14px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:#fff;cursor:pointer;font:inherit}
    .sp-item:hover,.sp-item.active{border-color:var(--pine-700,#14522f);background:var(--pine-100)}
    .sp-item strong{display:block;color:var(--pine-900);font-size:13px}
    .sp-item span{color:var(--ink-soft);font-size:11px}
    .sp-form label{display:flex;flex-direction:column;gap:6px;margin-bottom:12px;font-size:11px;font-weight:700;color:var(--ink-soft);text-transform:uppercase;letter-spacing:.04em}
    .sp-form input,.sp-form select{min-height:40px;padding:8px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);font:inherit;font-size:13px;text-transform:none;letter-spacing:normal;color:var(--ink);background:#fff}
    .sp-form .readonly{background:#f4f6f2;color:var(--ink-soft)}
    .sp-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
    .sp-msg{min-height:18px;font-size:12px;color:var(--ink-soft);margin-top:8px}
    .sp-empty{padding:20px;color:var(--ink-soft);font-size:13px}
    .sp-photo-row{
      display:flex;align-items:center;gap:14px;margin-bottom:16px;
      padding:12px;border:1px solid var(--line);border-radius:var(--radius-md);
      background:var(--pine-100,#e8f3ec);
    }
    .sp-photo-wrap{
      width:72px;height:72px;border-radius:50%;overflow:hidden;flex:0 0 auto;
      background:#eef2ea;border:1px solid #d9d0b8;
      display:flex;align-items:center;justify-content:center;
    }
    .sp-photo-wrap img{width:100%;height:100%;object-fit:cover;display:block}
    .sp-photo-meta{font-size:12px;color:var(--ink-soft);line-height:1.45}
    .sp-photo-meta strong{display:block;color:var(--pine-900);font-family:var(--font-display);font-size:15px;margin-bottom:2px}
  </style>
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="brand-logo">
      <div class="brand-text">
        <span class="brand-title">CSJ Dean Dashboard</span>
        <span class="brand-sub">Higher Education Department &middot; Dean View</span>
      </div>
    </div>
    <div class="topbar-actions">
      <a class="btn btn-ghost" href="logout.php">Logout</a>
    </div>
  </header>

  <div class="dean-layout">
        <aside class="dean-sidebar" aria-label="Dean navigation">
      <p class="dean-sidebar-label">Menu</p>
      <a class="dean-nav-link" href="dean-dashboard.php"><span aria-hidden="true">&#9638;</span> Student Entries</a>
      <a class="dean-nav-link active" href="dean-student-profiles.php" aria-current="page"><span aria-hidden="true">&#128100;</span> Student Profile</a>
      <a class="dean-nav-link" href="dean-password-requests.php"><span aria-hidden="true">&#128274;</span> Password Requests</a>
      <a class="dean-nav-link" href="dean-audit-trail.php"><span aria-hidden="true">&#9776;</span> Audit Trail</a>
      <a class="dean-nav-link" href="dean-feedback.php"><span aria-hidden="true">&#9998;</span> Feedback</a>
      <a class="dean-nav-link" href="dean-archive.php"><span aria-hidden="true">&#128230;</span> Archive</a>
    </aside>

    <main class="dean-content">
      <h1 class="dean-heading">Student Profile</h1>
      <p class="dean-sub">View student information and update Program, Year, Status, and Major.</p>

      <div class="sp-toolbar">
        <input type="search" id="spSearch" placeholder="Search name, Student ID, program…" autocomplete="off">
        <button type="button" class="btn btn-ghost" id="spRefresh">Refresh</button>
      </div>

      <div class="sp-grid">
        <section class="sp-card">
          <div class="sp-list" id="spList"><div class="sp-empty">Loading students…</div></div>
        </section>
        <section class="sp-card">
          <form class="sp-form" id="spForm" onsubmit="return false;">
            <input type="hidden" id="spKey" value="">
            <div class="sp-photo-row" id="spPhotoRow">
              <div class="sp-photo-wrap" id="spPhotoWrap" aria-label="Student profile picture">
                <img id="spPhotoImg" src="" alt="" style="display:none;">
                <span id="spPhotoInitial" style="font-family:Georgia,serif;font-weight:700;color:#14522f;font-size:24px;">?</span>
              </div>
              <div class="sp-photo-meta">
                <strong id="spPhotoName">Select a student</strong>
                <span id="spPhotoHint">Profile picture appears here when the student has uploaded one.</span>
              </div>
            </div>
            <label>Student ID
              <input class="readonly" id="spStudentId" readonly>
            </label>
            <label>Full Name
              <input class="readonly" id="spName" readonly>
            </label>
            <label>Email
              <input class="readonly" id="spEmail" readonly>
            </label>
            <label>Contact
              <input class="readonly" id="spContact" readonly>
            </label>
            <label>Address
              <input class="readonly" id="spAddress" readonly>
            </label>
            <label>Guardian
              <input class="readonly" id="spGuardian" readonly>
            </label>
            <label>Course &amp; Year (auto)
              <input class="readonly" id="spCourseYear" readonly>
            </label>
            <label>Program
              <select id="spProgram">
                <option value="">Select program…</option>
                <option value="BEEd">BEEd</option>
                <option value="BSEd">BSEd</option>
                <option value="BSBA">BSBA</option>
                <option value="BSIT">BSIT</option>
              </select>
            </label>
            <label>Year
              <select id="spYear">
                <option value="">Select year…</option>
                <option value="1st">1st</option>
                <option value="2nd">2nd</option>
                <option value="3rd">3rd</option>
                <option value="4th">4th</option>
              </select>
            </label>
            <label>Status
              <select id="spStatus">
                <option value="">Select status…</option>
                <option value="regular">Regular</option>
                <option value="irregular">Irregular</option>
              </select>
            </label>
            <label>Major
              <select id="spMajor">
                <option value="">—</option>
              </select>
            </label>
            <div class="sp-actions">
              <button type="button" class="btn btn-primary" id="spSave">Save changes</button>
            </div>
            <div class="sp-msg" id="spMsg"></div>
          </form>
        </section>
      </div>
    </main>
  </div>

  <script>
  (function () {
    const listEl = document.getElementById('spList');
    const msg = document.getElementById('spMsg');
    let students = [];
    let activeKey = '';

    const majorsByProgram = {
      BSBA: ['Operations Management', 'Financial Management'],
      BSEd: ['English', 'Filipino'],
      BSED: ['English', 'Filipino'],
      BEEd: [],
      BEED: [],
      BSIT: []
    };

    function fillMajors(program, selected) {
      const sel = document.getElementById('spMajor');
      if (!sel) return;
      let key = program || '';
      if (key) {
        const u = String(key).toUpperCase().replace(/\s+/g,'');
        if (u === 'BEED') key = 'BEEd';
        else if (u === 'BSED') key = 'BSEd';
        else if (u === 'BSBA') key = 'BSBA';
        else if (u === 'BSIT') key = 'BSIT';
      }
      const opts = majorsByProgram[key] || majorsByProgram[String(key).toUpperCase()] || [];
      sel.innerHTML = '';
      if (opts.length === 0) {
        // BSIT / BEEd — no major required
        const o = document.createElement('option');
        o.value = '';
        o.textContent = '— (not required)';
        sel.appendChild(o);
        sel.disabled = true;
        sel.value = '';
      } else {
        const blank = document.createElement('option');
        blank.value = '';
        blank.textContent = 'Select major…';
        sel.appendChild(blank);
        opts.forEach(function (m) {
          const o = document.createElement('option');
          o.value = m;
          o.textContent = m;
          if (selected === m) o.selected = true;
          sel.appendChild(o);
        });
        sel.disabled = false;
        if (selected && opts.indexOf(selected) >= 0) sel.value = selected;
      }
    }

    function say(t, ok) {
      msg.textContent = t || '';
      msg.style.color = ok ? '#14522f' : '#7d291b';
    }

    function renderList(filter) {
      const q = (filter || '').toLowerCase();
      const rows = students.filter(function (s) {
        if (!q) return true;
        const blob = [s.student_name, s.student_id, s.course_year, s.program, s.major].join(' ').toLowerCase();
        return blob.indexOf(q) !== -1;
      });
      if (!rows.length) {
        listEl.innerHTML = '<div class="sp-empty">No students found.</div>';
        return;
      }
      listEl.innerHTML = rows.map(function (s) {
        const active = s.profile_key === activeKey ? ' active' : '';
        const meta = [s.student_id || '', s.course_year || '', s.enrollment_status || ''].filter(Boolean).join(' · ');
        return '<button type="button" class="sp-item' + active + '" data-key="' + s.profile_key + '">' +
          '<strong>' + escapeHtml(s.student_name || 'Unnamed') + '</strong>' +
          '<span>' + escapeHtml(meta) + '</span></button>';
      }).join('');
      listEl.querySelectorAll('.sp-item').forEach(function (btn) {
        btn.addEventListener('click', function () { selectStudent(String(btn.getAttribute('data-key') || '')); });
      });
    }

    function escapeHtml(v) {
      return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
        return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]);
      });
    }

    
    function parseCourseYear(cy) {
      cy = String(cy || '').trim();
      var program = '', year = '';
      var pm = cy.match(/\b(BEED|BEEd|BSED|BSEd|BSBA|BSIT)\b/i);
      if (pm) {
        var p = pm[1].toUpperCase();
        if (p === 'BEED') program = 'BEEd';
        else if (p === 'BSED') program = 'BSEd';
        else program = p;
      }
      var ym = cy.match(/\b([1-4])(?:st|nd|rd|th)?\b/i);
      if (ym) {
        year = ({'1':'1st','2':'2nd','3':'3rd','4':'4th'})[ym[1]] || '';
      }
      return { program: program, year: year };
    }

    function photoUrl(path) {
      if (!path) return '';
      var p = String(path).trim();
      if (!p) return '';
      if (/^https?:\/\//i.test(p)) return p;
      // Stored as assets/uploads/students/xxx.jpg relative to site root
      if (p.indexOf('assets/') === 0) return p;
      if (p.indexOf('/') === 0) return p.replace(/^\//, '');
      return 'assets/uploads/students/' + p.replace(/^.*\//, '');
    }

    function setPhoto(s) {
      var img = document.getElementById('spPhotoImg');
      var initial = document.getElementById('spPhotoInitial');
      var nameEl = document.getElementById('spPhotoName');
      var hint = document.getElementById('spPhotoHint');
      var name = (s && s.student_name) ? s.student_name : 'Select a student';
      if (nameEl) nameEl.textContent = name || 'Select a student';
      var url = photoUrl(s && s.photo_path);
      if (url) {
        img.src = url;
        img.alt = name || 'Student photo';
        img.style.display = 'block';
        initial.style.display = 'none';
        if (hint) hint.textContent = 'Student profile picture';
        img.onerror = function () {
          img.style.display = 'none';
          initial.style.display = '';
          initial.textContent = name ? String(name).charAt(0).toUpperCase() : '?';
          if (hint) hint.textContent = 'No profile picture on file.';
        };
      } else {
        img.removeAttribute('src');
        img.style.display = 'none';
        initial.style.display = '';
        initial.textContent = name ? String(name).charAt(0).toUpperCase() : '?';
        if (hint) hint.textContent = 'No profile picture uploaded yet.';
      }
    }

    function selectStudent(key) {
      activeKey = String(key || '');
      const s = students.find(function (x) { return String(x.profile_key) === activeKey; });
      if (!s) return;
      document.getElementById('spKey').value = s.profile_key || '';
      document.getElementById('spStudentId').value = s.student_id || '';
      document.getElementById('spName').value = s.student_name || '';
      document.getElementById('spEmail').value = s.email || '';
      document.getElementById('spContact').value = s.contact_no || '';
      document.getElementById('spAddress').value = s.address || '';
      document.getElementById('spGuardian').value = s.guardian || '';
      document.getElementById('spCourseYear').value = s.course_year || '';
      var inferred = parseCourseYear(s.course_year || '');
      var prog = s.program || inferred.program || '';
      var year = s.year_level || inferred.year || '';
      if (prog) {
        var pu = String(prog).toUpperCase().replace(/\s+/g,'');
        if (pu === 'BEED') prog = 'BEEd';
        else if (pu === 'BSED') prog = 'BSEd';
        else if (pu === 'BSBA') prog = 'BSBA';
        else if (pu === 'BSIT') prog = 'BSIT';
      }
      // Year may be stored as "3" or "3rd"
      if (year && !/st|nd|rd|th/i.test(year)) {
        year = ({'1':'1st','2':'2nd','3':'3rd','4':'4th'})[String(year)] || year;
      }
      document.getElementById('spProgram').value = prog;
      document.getElementById('spYear').value = year;
      var st = String(s.enrollment_status || '').toLowerCase();
      if (st === 'regular' || st === 'irregular') {
        document.getElementById('spStatus').value = st;
      } else {
        document.getElementById('spStatus').value = s.enrollment_status || '';
      }
      fillMajors(prog, s.major || '');
      setPhoto(s);
      say('');
      renderList(document.getElementById('spSearch').value);
    }

    async function loadStudents() {
      listEl.innerHTML = '<div class="sp-empty">Loading students…</div>';
      try {
        const r = await fetch('php/dean_student_profile.php?action=list', { credentials: 'same-origin', cache: 'no-store' });
        const d = await r.json();
        if (!r.ok || !d.ok) throw new Error(d.message || 'Could not load students.');
        students = d.students || [];
        renderList(document.getElementById('spSearch').value);
        if (activeKey) selectStudent(activeKey);
      } catch (e) {
        listEl.innerHTML = '<div class="sp-empty">' + escapeHtml(e.message || 'Load failed') + '</div>';
      }
    }

    document.getElementById('spProgram').addEventListener('change', function () {
      fillMajors(this.value, '');
    });
    document.getElementById('spSearch').addEventListener('input', function () {
      renderList(this.value);
    });
    document.getElementById('spRefresh').addEventListener('click', loadStudents);
    document.getElementById('spSave').addEventListener('click', async function () {
      const key = document.getElementById('spKey').value;
      if (!key) { say('Select a student first.'); return; }
      const program = (document.getElementById('spProgram').value || '').trim();
      const year = (document.getElementById('spYear').value || '').trim();
      const status = (document.getElementById('spStatus').value || '').trim();
      let major = (document.getElementById('spMajor').value || '').trim();
      if (!program) { say('Please select a Program.'); return; }
      if (!year) { say('Please select a Year.'); return; }
      // BSBA / BSEd require a major; BSIT / BEEd do not
      const needsMajor = (program === 'BSBA' || program === 'BSEd' || program === 'BSED');
      if (needsMajor && !major) {
        say(program === 'BSBA'
          ? 'Please select a Major (Operations Management or Financial Management).'
          : 'Please select a Major (English or Filipino).');
        return;
      }
      if (!needsMajor) major = '';
      say('Saving…');
      try {
        const body = {
          action: 'save',
          profile_key: key,
          program: program,
          year_level: year,
          enrollment_status: status,
          major: major
        };
        const r = await fetch('php/dean_student_profile.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify(body)
        });
        const d = await r.json();
        if (!r.ok || !d.ok) throw new Error(d.message || 'Save failed.');
        say(d.message || 'Saved.', true);
        if (d.course_year) document.getElementById('spCourseYear').value = d.course_year;
        await loadStudents();
        selectStudent(key);
      } catch (e) {
        say(e.message || 'Save failed.');
      }
    });

    loadStudents();
  })();
  </script>
</body>
</html>
