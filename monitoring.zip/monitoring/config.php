<?php
/**
 * CSJ Student Dashboard - shared configuration.
 * This app is intentionally separate from the Instructor Dashboard.
 * Both applications use the SAME MySQL database.
 */

define('CSJ_DB_HOST', 'localhost');
define('CSJ_DB_NAME', 'csj_self_monitoring');
define('CSJ_DB_USER', 'root');
define('CSJ_DB_PASS', '');

// Security helpers (anti SQL injection, login throttling, session-cookie hardening).
require_once __DIR__ . '/php/security.php';
csj_harden_session();

// Legacy constant, no longer used for sign-up. Teacher sign-up now stamps the LIVE
// semester (system_flags.current_semester) via csj_signup_semester(), so a teacher's
// chosen subjects always show up on the Instructor Dashboard, even after the Dean has
// moved the school to a new semester.
define('CSJ_SIGNUP_SEMESTER', 'First Semester, AY 2026-2027');


// The instructor app remains separate. Photo uploads are stored there so the
// instructor's existing View Self-Monitoring photo viewer continues to work.
define('CSJ_INSTRUCTOR_APP_CANDIDATES', [
    'CSJ_Self_Monitoring_Dashboard_v4_Instructor_APPROVAL_FIXED',
    'CSJ_Self_Monitoring_Dashboard_v4_Instructor_ROOT_ONLY_FIXED',
]);

function csj_student_db(): PDO {
    $pdo = new PDO(
        'mysql:host=' . CSJ_DB_HOST . ';dbname=' . CSJ_DB_NAME . ';charset=utf8mb4',
        CSJ_DB_USER,
        CSJ_DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ] + (defined('PDO::MYSQL_ATTR_MULTI_STATEMENTS')
            // Anti SQL injection: refuse stacked queries ("...; DROP TABLE x") on this connection.
            ? [PDO::MYSQL_ATTR_MULTI_STATEMENTS => false]
            : [])
    );

    // Keep connection-side strings consistent with the project's database
    // collation. This prevents PDO parameters from being compared using a
    // different connection collation.
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");

    return $pdo;
}

function csj_student_profile_key(): string {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    // A logged-in account is authoritative. The legacy browser key remains
    // supported so the existing dashboard continues to work for old profiles.
    if (empty($_SESSION['student_profile_key'])) {
        $cookieKey = preg_replace('/[^a-f0-9]/', '', (string)($_COOKIE['csj_student_profile_key'] ?? ''));
        $_SESSION['student_profile_key'] = strlen($cookieKey) === 32
            ? $cookieKey
            : bin2hex(random_bytes(16));
    }

    $key = (string)$_SESSION['student_profile_key'];
    setcookie('csj_student_profile_key', $key, [
        'expires' => time() + 31536000,
        'path' => '/',
        'samesite' => 'Lax',
    ]);

    return $key;
}

/**
 * Prelims / Midterms / Finals monitoring sheets.
 * Each period gets its own 9-subject table with its own 6 review-event rows,
 * so a student's Prelim entries never overwrite Midterm/Final entries.
 */
function csj_period_definitions(): array {
    return [
        'prelims'  => [
            'label'      => 'Prelims',
            'tableId'    => 'tblPrelim',
            'chartTitle' => 'SELF-REVIEW MONITORING CHART FOR THE PRELIMS',
        ],
        'midterms' => [
            'label'      => 'Midterms',
            'tableId'    => 'tblMidterm',
            'chartTitle' => 'SELF-REVIEW MONITORING CHART FOR THE MIDTERMS',
        ],
        'finals'   => [
            'label'      => 'Finals',
            'tableId'    => 'tblFinals',
            'chartTitle' => 'SELF-REVIEW MONITORING CHART FOR THE FINALS',
        ],
    ];
}

function csj_default_subjects(): array {
    $subjects = [];
    for ($i = 1; $i <= 9; $i++) {
        $subjects[] = ['id' => $i, 'code' => '', 'instructor' => '—', 'approved' => false];
    }
    return $subjects;
}

function csj_default_rows(): array {
    $rows = [];
    for ($e = 1; $e <= 6; $e++) {
        $entries = [];
        for ($i = 1; $i <= 9; $i++) $entries[(string)$i] = '';
        $rows[] = ['event' => $e, 'entries' => $entries];
    }
    return $rows;
}

/**
 * Normalizes any chart array (old flat shape or new {periods:{...}} shape)
 * into a guaranteed {prelims, midterms, finals} periods array so the rest
 * of the app never has to special-case missing data.
 */
function csj_normalize_periods(array $chart): array {
    $defs = csj_period_definitions();
    $periods = is_array($chart['periods'] ?? null) ? $chart['periods'] : [];

    // Legacy migration: a chart saved before Prelims/Finals existed only had
    // top-level "subjects"/"rows" -- treat that as the Midterms sheet.
    if (empty($periods) && !empty($chart['subjects']) && !empty($chart['rows'])) {
        $periods['midterms'] = [
            'chartTitle' => $chart['meta']['chartTitle'] ?? $defs['midterms']['chartTitle'],
            'subjects'   => $chart['subjects'],
            'rows'       => $chart['rows'],
        ];
    }

    $normalized = [];
    foreach ($defs as $key => $def) {
        $p = is_array($periods[$key] ?? null) ? $periods[$key] : [];
        $normalized[$key] = [
            'chartTitle' => (isset($p['chartTitle']) && $p['chartTitle'] !== '') ? $p['chartTitle'] : $def['chartTitle'],
            'subjects'   => !empty($p['subjects']) && is_array($p['subjects']) ? $p['subjects'] : csj_default_subjects(),
            'rows'       => !empty($p['rows']) && is_array($p['rows']) ? $p['rows'] : csj_default_rows(),
            'deanApproved' => !empty($p['deanApproved']),
            'deanApprovedBy' => isset($p['deanApprovedBy']) ? (string)$p['deanApprovedBy'] : '',
            'deanApprovedAt' => isset($p['deanApprovedAt']) ? (string)$p['deanApprovedAt'] : '',
        ];
    }
    return $normalized;
}

/**
 * Which monitoring periods may the STUDENT open / edit?
 *   Prelims  - always open
 *   Midterms - only after the Dean approved the Prelims
 *   Finals   - only after the Dean approved the Midterms (which itself needs Prelims)
 * $periods must come from the DATABASE copy of the chart (never from the browser).
 * Returns e.g. ['prelims' => true, 'midterms' => false, 'finals' => false].
 */
function csj_period_access(array $periods): array {
    $access = [];
    $previousApproved = true;
    foreach (['prelims', 'midterms', 'finals'] as $key) {
        $access[$key] = $previousApproved;
        $previousApproved = $previousApproved && !empty($periods[$key]['deanApproved']);
    }
    return $access;
}

/** Human text used in the "locked" hints. */
function csj_period_lock_reason(string $key): string {
    if ($key === 'midterms') return 'Midterms unlocks after the Dean approves your Prelims.';
    if ($key === 'finals')   return 'Finals unlocks after the Dean approves your Midterms.';
    return '';
}

/** Find the separate instructor application directory beside this app. */
function csj_instructor_root(): ?string {
    $htdocs = dirname(__DIR__);
    foreach (CSJ_INSTRUCTOR_APP_CANDIDATES as $name) {
        $candidate = $htdocs . DIRECTORY_SEPARATOR . $name;
        if (is_dir($candidate)) {
            return $candidate;
        }
    }
    return null;
}

/**
 * Central current academic semester (Student / Instructor / Dean stay in sync).
 * Stored in system_flags.current_semester. Default: First Semester, AY 2026-2027
 */
function csj_default_semester(): string {
    return 'First Semester, AY 2026-2027';
}

function csj_ensure_system_flags(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS system_flags (
            flag_key VARCHAR(64) NOT NULL PRIMARY KEY,
            flag_value TEXT,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}

function csj_get_current_semester(?PDO $pdo = null): string {
    try {
        if ($pdo === null) {
            $pdo = csj_student_db();
        }
        csj_ensure_system_flags($pdo);
        $stmt = $pdo->prepare('SELECT flag_value FROM system_flags WHERE flag_key = ? LIMIT 1');
        $stmt->execute(['current_semester']);
        $val = $stmt->fetchColumn();
        if (is_string($val) && trim($val) !== '') {
            return trim($val);
        }
        $def = csj_default_semester();
        $ups = $pdo->prepare(
            'INSERT INTO system_flags (flag_key, flag_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE flag_value = VALUES(flag_value)'
        );
        $ups->execute(['current_semester', $def]);
        return $def;
    } catch (Throwable $e) {
        return csj_default_semester();
    }
}

/**
 * First Semester, AY YYYY-YYYY → Second Semester, AY YYYY-YYYY
 * Second Semester, AY YYYY-YYYY → First Semester, AY (YYYY+1)-(YYYY+2)
 */
function csj_advance_semester(string $current): string {
    $current = trim($current);
    if (preg_match('/^(First|Second)\s+Semester,\s*AY\s*(\d{4})-(\d{4})$/i', $current, $m)) {
        $term = strtolower($m[1]);
        $y1 = (int)$m[2];
        $y2 = (int)$m[3];
        if ($term === 'first') {
            return 'Second Semester, AY ' . $y1 . '-' . $y2;
        }
        return 'First Semester, AY ' . ($y1 + 1) . '-' . ($y2 + 1);
    }
    return 'Second Semester, AY 2026-2027';
}

function csj_set_current_semester(PDO $pdo, string $semester): void {
    csj_ensure_system_flags($pdo);
    $ups = $pdo->prepare(
        'INSERT INTO system_flags (flag_key, flag_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE flag_value = VALUES(flag_value), updated_at = CURRENT_TIMESTAMP'
    );
    $ups->execute(['current_semester', trim($semester)]);
}

/** Archive tables that keep history across semester transitions. */
function csj_ensure_archive_tables(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS dean_archived_periods (
            archive_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            profile_key CHAR(32) NOT NULL,
            period_key VARCHAR(20) NOT NULL,
            student_name VARCHAR(150) DEFAULT NULL,
            course_year VARCHAR(100) DEFAULT NULL,
            semester VARCHAR(150) DEFAULT NULL,
            chart_period_json LONGTEXT,
            archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            archived_by VARCHAR(150) DEFAULT NULL,
            KEY idx_profile_period (profile_key, period_key),
            KEY idx_semester (semester),
            KEY idx_archived_at (archived_at)
         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
    try { $pdo->exec('ALTER TABLE dean_archived_periods DROP INDEX uq_profile_period'); } catch (Throwable $e) {}
    try {
        $pdo->exec(
            'ALTER TABLE dean_archived_periods
             ADD UNIQUE KEY uq_profile_period_semester (profile_key, period_key, semester)'
        );
    } catch (Throwable $e) {}

    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS dean_archived_students (
            profile_key CHAR(32) NOT NULL PRIMARY KEY,
            student_name VARCHAR(150) DEFAULT NULL,
            course_year VARCHAR(100) DEFAULT NULL,
            student_id VARCHAR(50) DEFAULT NULL,
            semester VARCHAR(150) DEFAULT NULL,
            archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            archived_by VARCHAR(150) DEFAULT NULL
         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}

/**
 * START A NEW SEMESTER (the single implementation used by BOTH triggers):
 *   - automatic : php/dean_approve.php, when the last student's Finals is approved
 *   - manual    : php/dean_set_semester.php, when the Dean edits the Semester / AY boxes
 *
 * 1. every live monitoring sheet is first saved into the permanent Archive (dean_archived_periods)
 * 2. the LIVE data is cleared (monitoring_submissions, TblPrelim/TblMidTerm/TblFinal,
 *    instructor_subject_selections, dean_archived_students) in ONE transaction
 * 3. the new semester + the "transition id" are stored (students / instructors then see the
 *    New Semester popup once)
 * The Archive is never deleted.
 */
function csj_apply_semester_transition(PDO $pdo, string $deanName, string $oldSemester, string $newSemester, string $reason = 'automatic'): array {
    if (function_exists('csj_ensure_system_flags')) csj_ensure_system_flags($pdo);
    if (function_exists('csj_ensure_archive_tables')) csj_ensure_archive_tables($pdo);

    // How many students currently have a live sheet (reported back + written to the audit trail)
    $submitted = (int)$pdo->query('SELECT COUNT(DISTINCT profile_key) FROM monitoring_submissions')->fetchColumn();

    // Safety: make sure every period of every live sheet is in the Archive before anything is cleared.
    // A period is kept when it is Dean-approved, has a subject code, OR has any text typed in it
    // (so nothing a student wrote can be lost by a manual semester change).
    try {
        $subs = $pdo->query(
            'SELECT profile_key, student_name, course_year, semester, chart_json FROM monitoring_submissions'
        )->fetchAll(PDO::FETCH_ASSOC);
        $archIns = $pdo->prepare(
            'INSERT INTO dean_archived_periods
                (profile_key, period_key, student_name, course_year, semester, chart_period_json, archived_by)
             VALUES (?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                student_name = VALUES(student_name),
                course_year = VALUES(course_year),
                chart_period_json = VALUES(chart_period_json),
                archived_at = CURRENT_TIMESTAMP,
                archived_by = VALUES(archived_by)'
        );
        foreach ($subs as $sub) {
            $chart = json_decode((string)($sub['chart_json'] ?? ''), true);
            if (!is_array($chart)) continue;
            $periods = function_exists('csj_normalize_periods')
                ? csj_normalize_periods($chart)
                : (is_array($chart['periods'] ?? null) ? $chart['periods'] : []);
            $sem = (string)($sub['semester'] ?? $oldSemester);
            foreach (['prelims', 'midterms', 'finals'] as $pk) {
                $block = $periods[$pk] ?? null;
                if (!is_array($block)) continue;
                $hasContent = !empty($block['deanApproved']);
                if (!$hasContent) {
                    foreach (($block['subjects'] ?? []) as $sj) {
                        if (trim((string)($sj['code'] ?? '')) !== '') { $hasContent = true; break; }
                    }
                }
                if (!$hasContent) {
                    foreach (($block['rows'] ?? []) as $row) {
                        foreach ((array)($row['entries'] ?? []) as $txt) {
                            if (is_string($txt) && trim($txt) !== '') { $hasContent = true; break 2; }
                        }
                    }
                }
                if (!$hasContent) continue;
                $archIns->execute([
                    (string)$sub['profile_key'],
                    $pk,
                    (string)($sub['student_name'] ?? ''),
                    (string)($sub['course_year'] ?? ''),
                    $sem,
                    json_encode($block, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    $deanName,
                ]);
            }
        }
    } catch (Throwable $e) { error_log('csj_apply_semester_transition archive: ' . $e->getMessage()); }

    // Clear LIVE operational data only (Archive history stays). ONE transaction: a failure can
    // never leave the school half-reset.
    $pdo->beginTransaction();
    try {
        $pdo->exec('DELETE FROM monitoring_submissions');
        foreach (['TblPrelim', 'TblMidTerm', 'TblFinal', 'instructor_subject_selections', 'dean_archived_students'] as $tbl) {
            try { $pdo->exec('DELETE FROM `' . $tbl . '`'); } catch (Throwable $e) { /* table may not exist on old installs */ }
        }
        // The transition id comes from MySQL's clock (same clock as created_at columns), so
        // "was this account created before the semester changed?" is always exact.
        $now = (string)$pdo->query('SELECT NOW()')->fetchColumn();
        $ups = $pdo->prepare(
            'INSERT INTO system_flags (flag_key, flag_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE flag_value = VALUES(flag_value), updated_at = CURRENT_TIMESTAMP'
        );
        $ups->execute(['new_semester_at', $now]);
        $ups->execute(['last_transition_by', $deanName]);
        $ups->execute(['current_semester', $newSemester]);
        $ups->execute(['previous_semester', $oldSemester]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }


    // End of school year (new AY): promote year levels and graduate (delete) 4th-year students.
    // Triggered when the Academic Year portion of the semester label changes
    // (e.g. Second Semester, AY 2026-2027 → First Semester, AY 2027-2028).
    // Mid-year First→Second semester does NOT change year level.
    try {
        $oldAy = null; $newAy = null;
        if (preg_match('/AY\s*(\d{4})\s*-\s*(\d{4})/i', $oldSemester, $om)) $oldAy = $om[1] . '-' . $om[2];
        if (preg_match('/AY\s*(\d{4})\s*-\s*(\d{4})/i', $newSemester, $nm)) $newAy = $nm[1] . '-' . $nm[2];
        if ($oldAy !== null && $newAy !== null && $oldAy !== $newAy) {
            // Ensure academic columns exist on older XAMPP installs
            foreach ([
                "ALTER TABLE student_profiles ADD COLUMN program VARCHAR(20) DEFAULT NULL",
                "ALTER TABLE student_profiles ADD COLUMN year_level VARCHAR(20) DEFAULT NULL",
                "ALTER TABLE student_profiles ADD COLUMN enrollment_status VARCHAR(20) DEFAULT NULL",
                "ALTER TABLE student_profiles ADD COLUMN major VARCHAR(80) DEFAULT NULL",
            ] as $sqlCol) {
                try { $pdo->exec($sqlCol); } catch (Throwable $ignored) {}
            }

            $yearOrder = ['1st' => '2nd', '2nd' => '3rd', '3rd' => '4th'];
            $numToYear = ['1' => '1st', '2' => '2nd', '3' => '3rd', '4' => '4th'];
            $yearToNum = ['1st' => '1', '2nd' => '2', '3rd' => '3', '4th' => '4'];

            $rows = $pdo->query(
                'SELECT profile_key, student_id, student_name, course_year, program, year_level FROM student_profiles'
            )->fetchAll(PDO::FETCH_ASSOC);

            $upd = $pdo->prepare(
                'UPDATE student_profiles SET year_level = ?, program = ?, course_year = ? WHERE profile_key = ?'
            );

            $promoted = 0;
            $graduated = 0;
            $graduateKeys = [];

            foreach ($rows as $r) {
                $key = (string)($r['profile_key'] ?? '');
                if ($key === '') continue;
                $prog = trim((string)($r['program'] ?? ''));
                $yl = trim((string)($r['year_level'] ?? ''));
                $cy = trim((string)($r['course_year'] ?? ''));

                // Infer program / year from course_year when columns empty (e.g. "BSIT 3", "BSBA 4")
                if (($prog === '' || $yl === '') && $cy !== '') {
                    if (preg_match('/\b(BEED|BEEd|BSED|BSEd|BSBA|BSIT)\b/i', $cy, $pm)) {
                        $p = strtoupper($pm[1]);
                        if ($p === 'BEED') $prog = $prog !== '' ? $prog : 'BEEd';
                        elseif ($p === 'BSED') $prog = $prog !== '' ? $prog : 'BSEd';
                        else $prog = $prog !== '' ? $prog : $p;
                    }
                    if ($yl === '' && preg_match('/\b([1-4])(?:st|nd|rd|th)?\b/i', $cy, $ym)) {
                        $yl = $numToYear[$ym[1]] ?? $yl;
                    }
                }
                // Normalize numeric year_level ("4") → "4th"
                if (isset($numToYear[$yl])) $yl = $numToYear[$yl];

                // 4th year (and unknown already-final) → graduate: delete account + all related data
                if ($yl === '4th') {
                    $graduateKeys[] = [
                        'key' => $key,
                        'name' => (string)($r['student_name'] ?? ''),
                        'student_id' => (string)($r['student_id'] ?? ''),
                    ];
                    continue;
                }

                // 1st → 2nd → 3rd → 4th
                if ($yl === '' || !isset($yearOrder[$yl])) continue;
                $next = $yearOrder[$yl];
                $num = $yearToNum[$next] ?? '';
                $newCy = $cy;
                if ($prog !== '' && $num !== '') {
                    $newCy = $prog . ' ' . $num;
                } elseif ($num !== '' && preg_match('/\b[1-4](?:st|nd|rd|th)?\b/i', $cy)) {
                    $newCy = preg_replace('/\b[1-4](?:st|nd|rd|th)?\b/i', $num, $cy, 1);
                }
                $upd->execute([$next, $prog !== '' ? $prog : null, $newCy !== '' ? $newCy : $cy, $key]);
                $promoted++;
            }

            // Delete graduated (former 4th-year) student accounts and related rows
            foreach ($graduateKeys as $g) {
                $key = $g['key'];
                try {
                    // Phone numbers
                    try { $pdo->prepare('DELETE FROM student_phone_numbers WHERE profile_key = ?')->execute([$key]); } catch (Throwable $e) {}
                    // Biometrics
                    try { $pdo->prepare('DELETE FROM student_biometrics WHERE profile_key = ?')->execute([$key]); } catch (Throwable $e) {}
                    // Password reset requests (by Student ID / identifier)
                    try {
                        $sid = trim((string)($g['student_id'] ?? ''));
                        if ($sid !== '') {
                            $pdo->prepare('DELETE FROM password_reset_requests WHERE account_role = ? AND account_identifier = ?')->execute(['student', $sid]);
                        }
                    } catch (Throwable $e) {}
                    // Welcome / semester popup seen
                    try { $pdo->prepare('DELETE FROM semester_welcome_seen WHERE role = ? AND user_key = ?')->execute(['student', $key]); } catch (Throwable $e) {}
                    // Feedback left by this student
                    try { $pdo->prepare('DELETE FROM feedback WHERE profile_key = ?')->execute([$key]); } catch (Throwable $e) {}
                    // Messages
                    try { $pdo->prepare('DELETE FROM instructor_student_messages WHERE profile_key = ?')->execute([$key]); } catch (Throwable $e) {}
                    // Any leftover monitoring rows (normally already cleared above)
                    try { $pdo->prepare('DELETE FROM monitoring_submissions WHERE profile_key = ?')->execute([$key]); } catch (Throwable $e) {}
                    foreach (['TblPrelim', 'TblMidTerm', 'TblFinal'] as $tbl) {
                        try { $pdo->prepare("DELETE FROM `$tbl` WHERE profile_key = ?")->execute([$key]); } catch (Throwable $e) {}
                    }
                    // Account then profile
                    $pdo->prepare('DELETE FROM student_accounts WHERE profile_key = ?')->execute([$key]);
                    $pdo->prepare('DELETE FROM student_profiles WHERE profile_key = ?')->execute([$key]);
                    $graduated++;
                    if (function_exists('csj_audit_log')) {
                        try {
                            csj_audit_log(
                                $pdo, 'student_graduated_deleted', 'student', $key, $g['name'],
                                ['student_id' => $g['student_id'], 'reason' => 'end_of_ay', 'from_ay' => $oldAy, 'to_ay' => $newAy],
                                'dean', '', $deanName
                            );
                        } catch (Throwable $e) {}
                    }
                } catch (Throwable $e) {
                    error_log('csj graduate delete ' . $key . ': ' . $e->getMessage());
                }
            }

            if (function_exists('csj_audit_log')) {
                try {
                    csj_audit_log(
                        $pdo, 'ay_year_promotion', 'system', 'semester', $newSemester,
                        [
                            'from_ay' => $oldAy,
                            'to_ay' => $newAy,
                            'promoted' => $promoted,
                            'graduated_deleted' => $graduated,
                            'by' => $deanName,
                        ],
                        'dean', '', $deanName
                    );
                } catch (Throwable $e) {}
            }
        }
    } catch (Throwable $e) {
        error_log('csj_apply_semester_transition year promote: ' . $e->getMessage());
    }


    try {
        if (function_exists('csj_audit_log')) {
            csj_audit_log(
                $pdo, 'semester_transition', 'system', 'semester', $newSemester,
                ['by' => $deanName, 'cleared_students' => $submitted, 'from' => $oldSemester,
                 'to' => $newSemester, 'archive_kept' => true, 'trigger' => $reason],
                'dean', '', $deanName
            );
        }
    } catch (Throwable $e) {}

    return [
        'transitioned' => true,
        'transitionId' => $now,
        'cleared' => $submitted,
        'from' => $oldSemester,
        'to' => $newSemester,
        'archive_kept' => true,
    ];
}

/** Semester stamped on subjects a teacher chooses while signing up = the live semester. */
function csj_signup_semester(?PDO $pdo = null): string {
    return csj_get_current_semester($pdo);
}

/* ==========================================================================
 * New-semester welcome popups (Dean / Instructor / Student)
 * --------------------------------------------------------------------------
 * When the Dean approves the LAST student's Finals, php/dean_approve.php starts
 * the new semester and stores a "transition id" (system_flags.new_semester_at,
 * a MySQL NOW() value). Each account then sees its welcome popup exactly ONCE
 * per transition. "Seen" is remembered in the database (semester_welcome_seen),
 * not in the PHP session, so logging out/in or switching device never repeats it.
 * Accounts created AFTER the transition never get a "welcome back".
 * ========================================================================== */

/** Seconds a welcome popup stays on screen before it clears itself. */
define('CSJ_WELCOME_POPUP_SECONDS', 5);

function csj_ensure_welcome_table(PDO $pdo): void {
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS semester_welcome_seen (
            role VARCHAR(20) NOT NULL,
            user_key VARCHAR(80) NOT NULL,
            transition_id VARCHAR(40) NOT NULL,
            seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (role, user_key, transition_id)
         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}

/** Id of the most recent semester transition ('' if none has happened yet). */
function csj_transition_id(?PDO $pdo = null): string {
    try {
        if ($pdo === null) $pdo = csj_student_db();
        csj_ensure_system_flags($pdo);
        $st = $pdo->prepare('SELECT flag_value FROM system_flags WHERE flag_key = ? LIMIT 1');
        $st->execute(['new_semester_at']);
        $v = $st->fetchColumn();
        return is_string($v) ? trim($v) : '';
    } catch (Throwable $e) {
        return '';
    }
}

/**
 * Should this account see the welcome popup right now?
 * $role: 'dean' | 'instructor' | 'student'.  $userKey: dean_id / instructor_key / profile_key.
 * Returns ['pending' => bool, 'transitionId' => string, 'semester' => string].
 */
function csj_welcome_pending(PDO $pdo, string $role, string $userKey): array {
    $out = ['pending' => false, 'transitionId' => '', 'semester' => ''];
    try {
        $tid = csj_transition_id($pdo);
        if ($tid === '' || $userKey === '') return $out;
        $out['transitionId'] = $tid;
        $out['semester'] = csj_get_current_semester($pdo);

        csj_ensure_welcome_table($pdo);
        $seen = $pdo->prepare('SELECT 1 FROM semester_welcome_seen WHERE role = ? AND user_key = ? AND transition_id = ? LIMIT 1');
        $seen->execute([$role, $userKey, $tid]);
        if ($seen->fetchColumn()) return $out;

        // Only accounts that already existed when the semester changed get a "welcome back".
        $sql = [
            'dean'       => 'SELECT created_at FROM dean_accounts WHERE dean_id = ? LIMIT 1',
            'instructor' => 'SELECT created_at FROM instructor_profiles WHERE instructor_key = ? LIMIT 1',
            'student'    => 'SELECT created_at FROM student_profiles WHERE profile_key = ? LIMIT 1',
        ][$role] ?? null;
        if ($sql === null) return $out;
        $c = $pdo->prepare($sql);
        $c->execute([$userKey]);
        $created = $c->fetchColumn();
        if (!is_string($created) || $created === '' || strcmp($created, $tid) >= 0) return $out;   // must exist strictly BEFORE the change

        $out['pending'] = true;
    } catch (Throwable $e) {
        error_log('csj_welcome_pending: ' . $e->getMessage());
    }
    return $out;
}

function csj_welcome_mark_seen(PDO $pdo, string $role, string $userKey, string $transitionId): void {
    if ($userKey === '' || $transitionId === '') return;
    try {
        csj_ensure_welcome_table($pdo);
        $pdo->prepare('INSERT IGNORE INTO semester_welcome_seen (role, user_key, transition_id) VALUES (?, ?, ?)')
            ->execute([$role, $userKey, $transitionId]);
    } catch (Throwable $e) {
        error_log('csj_welcome_mark_seen: ' . $e->getMessage());
    }
}
