<?php
require_once __DIR__ . '/config.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    header('Location: index.php');
    exit;
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function dean_h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function dean_normalize_code(string $code): string {
    return strtolower(preg_replace('/[^a-z0-9]/i', '', $code) ?? '');
}

$deanName = (string)($_SESSION['dean_name'] ?? 'Dean');
$sort = (string)($_GET['sort'] ?? 'name');
if (!in_array($sort, ['name', 'name_desc', 'updated'], true)) $sort = 'name';
$filterCourse = trim((string)($_GET['course'] ?? ''));
$filterYear = trim((string)($_GET['year'] ?? ''));
$selectedProfileKey = preg_match('/^[a-f0-9]{32}$/i', (string)($_GET['profile'] ?? ''))
    ? strtolower((string)$_GET['profile'])
    : '';
$students = [];
$selectedStudent = null;
$pageError = '';
$courseOptions = [];
$yearOptions = [];

/**
 * Split "BSIT-3", "BSIT 3", "BSIT Year 3" into course + year level.
 */
function dean_parse_course_year(string $courseYear): array {
    $courseYear = trim($courseYear);
    if ($courseYear === '' || $courseYear === '—') {
        return ['course' => '', 'year' => ''];
    }
    // "BSIT 3", "BSBA-2", "BEED Year 1"
    if (preg_match('/^(.*?)[\s\-_]+(?:year\s*)?(\d{1,2}|I{1,3}|IV|V|VI|VII|VIII|IX|X)\s*$/i', $courseYear, $m)) {
        $courseCode = strtoupper(trim($m[1]));
        if ($courseCode === 'BSED') $courseCode = 'BSEd';
        return [
            'course' => $courseCode,
            'year' => strtoupper(trim($m[2])),
        ];
    }
    if (preg_match('/^(\d{1,2}|I{1,3}|IV|V|VI)$/i', $courseYear)) {
        return ['course' => '', 'year' => strtoupper($courseYear)];
    }
        $courseCode = strtoupper($courseYear);
    if ($courseCode === 'BSED') $courseCode = 'BSEd';
    return ['course' => $courseCode, 'year' => ''];
}

$csjDeanWelcome = null;      // set when another Dean started a new semester and this Dean has not seen it yet
$progressDone = 0;           // students (with a submitted sheet) whose Prelims+Midterms+Finals are all approved
$progressTotal = 0;          // students who have a submitted sheet
try {
    $pdo = csj_student_db();
    $csjSemCurrent = function_exists('csj_get_current_semester') ? csj_get_current_semester($pdo) : 'First Semester, AY 2026-2027';
    $csjSemTerm = 'First';
    $csjSemAy = '2026-2027';
    if (preg_match('/^(First|Second)\s+Semester,\s*AY\s*(\d{4}-\d{4})$/i', $csjSemCurrent, $sm)) {
        $csjSemTerm = ucfirst(strtolower($sm[1]));
        $csjSemAy = $sm[2];
    }


    $dw = csj_welcome_pending($pdo, 'dean', (string)$_SESSION['dean_id']);
    if (!empty($dw['pending'])) {
        $csjDeanWelcome = $dw;
        csj_welcome_mark_seen($pdo, 'dean', (string)$_SESSION['dean_id'], $dw['transitionId']);
    }

    // Official filter lists (always available)
    $courseOptions = ['BSBA', 'BEED', 'BSEd', 'BSIT'];
    $yearOptions = ['1', '2', '3', '4'];
    $yearLabels = ['1' => '1st', '2' => '2nd', '3' => '3rd', '4' => '4th'];

    // All registered students (profiles), with latest submission if any
    $profileStmt = $pdo->query(
        'SELECT sp.profile_key, sp.student_id, sp.student_name, sp.course_year, sp.updated_at AS profile_updated
         FROM student_profiles sp
         ORDER BY sp.student_name'
    );

    // Latest submission per profile
    $submissionStmt = $pdo->query(
        'SELECT ms.profile_key, ms.submitted_at, ms.updated_at, ms.semester, ms.chart_json, ms.student_name, ms.course_year
         FROM monitoring_submissions ms
         ORDER BY ms.updated_at DESC'
    );
    $latestSub = [];
    foreach ($submissionStmt->fetchAll() as $row) {
        $pk = (string)$row['profile_key'];
        if (!isset($latestSub[$pk])) {
            $latestSub[$pk] = $row;
        }
    }

    $byProfile = [];
    foreach ($profileStmt->fetchAll() as $row) {
        $pk = (string)$row['profile_key'];
        $courseYear = (string)$row['course_year'];
        $sub = $latestSub[$pk] ?? null;
        // Prefer course_year from profile (signup); fall back to submission
        if ($courseYear === '' && $sub) {
            $courseYear = (string)($sub['course_year'] ?? '');
        }
        $parsed = dean_parse_course_year($courseYear);
        $entryCount = 0;
        $finalsApproved = false;   // Dean approved the Finals => student is Complete
        $semester = '';
        $submittedAt = '';
        $updatedAt = (string)($row['profile_updated'] ?? '');
        if ($sub) {
            $semester = (string)($sub['semester'] ?? '');
            $submittedAt = (string)($sub['submitted_at'] ?? '');
            $updatedAt = (string)($sub['updated_at'] ?? $updatedAt);
            $chart = json_decode((string)($sub['chart_json'] ?? ''), true);
            if (is_array($chart)) {
                $periods = function_exists('csj_normalize_periods')
                    ? csj_normalize_periods($chart)
                    : (is_array($chart['periods'] ?? null) ? $chart['periods'] : []);
                $finalsApproved = !empty($periods['finals']['deanApproved']);
                foreach ($periods as $period) {
                    $subjects = is_array($period['subjects'] ?? null) ? $period['subjects'] : [];
                    foreach ($subjects as $s) {
                        if (trim((string)($s['code'] ?? '')) !== '') $entryCount++;
                    }
                }
            }
        }
        $byProfile[$pk] = [
            'profile_key' => $pk,
            'student_id' => (string)($row['student_id'] ?? ''),
            'student_name' => (string)$row['student_name'],
            'course_year' => $courseYear,
            'course' => $parsed['course'],
            'year_level' => $parsed['year'],
            'submitted_at' => $submittedAt,
            'updated_at' => $updatedAt,
            'semester' => $semester,
            'entry_count' => $entryCount,
            'has_submission' => $sub !== null,
            'complete' => $finalsApproved,
        ];
    }

    // Progress toward the automatic new semester (counted BEFORE finished students are hidden below)
    foreach ($byProfile as $bp) {
        if (empty($bp['has_submission'])) continue;
        $progressTotal++;
        if (!empty($bp['complete'])) $progressDone++;
    }

    // Hide students fully approved this semester (all 3 periods). After transition
    // archive flags are cleared so everyone reappears for the new semester.
    try {
        if (function_exists('csj_ensure_archive_tables')) {
            csj_ensure_archive_tables($pdo);
        } else {
            $pdo->exec(
                'CREATE TABLE IF NOT EXISTS dean_archived_students (
                    profile_key CHAR(32) NOT NULL PRIMARY KEY,
                    student_name VARCHAR(150) DEFAULT NULL,
                    course_year VARCHAR(100) DEFAULT NULL,
                    student_id VARCHAR(50) DEFAULT NULL,
                    semester VARCHAR(150) DEFAULT NULL,
                    archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    archived_by VARCHAR(150) DEFAULT NULL
                 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        }
        $fullArch = $pdo->query('SELECT profile_key FROM dean_archived_students')->fetchAll(PDO::FETCH_COLUMN);
        $fullSet = array_fill_keys(array_map('strval', $fullArch ?: []), true);
        foreach (array_keys($byProfile) as $pk) {
            if (isset($fullSet[$pk]) && !empty($byProfile[$pk]['has_submission'])) {
                unset($byProfile[$pk]);
            }
        }
        // Clean orphan archive rows (no submission left = transition already happened)
        if (!empty($fullSet)) {
            $del = $pdo->prepare('DELETE FROM dean_archived_students WHERE profile_key = ?');
            foreach (array_keys($fullSet) as $apk) {
                if (empty($byProfile[$apk]) && !isset($latestSub[$apk])) {
                    $del->execute([$apk]);
                }
            }
        }
    } catch (Throwable $e) { /* ignore */ }

    $students = array_values($byProfile);

    // Apply filters
    if ($filterCourse !== '') {
        $students = array_values(array_filter($students, static function ($s) use ($filterCourse) {
            return strcasecmp((string)$s['course'], $filterCourse) === 0;
        }));
    }
    if ($filterYear !== '') {
        $students = array_values(array_filter($students, static function ($s) use ($filterYear) {
            return strcasecmp((string)$s['year_level'], $filterYear) === 0;
        }));
    }

    // Sort
    usort($students, static function (array $a, array $b) use ($sort): int {
        if ($sort === 'updated') {
            return strcmp((string)$b['updated_at'], (string)$a['updated_at']);
        }
        if ($sort === 'name_desc') {
            $byName = strcasecmp((string)$b['student_name'], (string)$a['student_name']);
            return $byName !== 0 ? $byName : strcmp($b['profile_key'], $a['profile_key']);
        }
        // name A-Z default
        $byName = strcasecmp((string)$a['student_name'], (string)$b['student_name']);
        return $byName !== 0 ? $byName : strcmp($a['profile_key'], $b['profile_key']);
    });

    if ($selectedProfileKey !== '') {
        foreach ($students as $student) {
            if ($student['profile_key'] === $selectedProfileKey) {
                $selectedStudent = $student;
                break;
            }
        }
        // If filtered out, still load from full set for open dialog
        if (!$selectedStudent) {
            foreach ($byProfile as $student) {
                if ($student['profile_key'] === $selectedProfileKey) {
                    $selectedStudent = $student;
                    break;
                }
            }
        }
    }
} catch (Throwable $e) {
    $pageError = 'Could not load student monitoring entries. Check MySQL connection and schema.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CSJ Dean Dashboard</title>
  <link rel="icon" href="assets/logos/csj-seal.jpg">
  <link rel="stylesheet" href="css/style.css">
  <style>
    .dean-layout{min-height:calc(100vh - 74px);display:grid;grid-template-columns:245px minmax(0,1fr)}
    .dean-sidebar{padding:24px 16px;background:var(--paper);border-right:1px solid var(--line)}
    .dean-sidebar-label{margin:0 12px 10px;color:var(--ink-soft);font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
    .dean-nav-link{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--radius-sm);background:var(--pine-100);color:var(--pine-900);font-size:13px;font-weight:700;text-decoration:none;margin-top:8px}
    .dean-nav-link:first-of-type{margin-top:0}
    .dean-nav-link.active{background:var(--pine-200,#d7e8dc)}
    .dean-content{min-width:0;padding:32px clamp(16px,4vw,48px)}
    .dean-content{min-width:0;padding:32px clamp(16px,4vw,48px)}
    .dean-heading{margin:0 0 6px;color:var(--pine-900);font-family:var(--font-display);font-size:26px}
    .dean-intro{margin:0 0 22px;color:var(--ink-soft);font-size:13px;line-height:1.6}
    .dean-card{background:var(--paper);border:1px solid var(--line);border-radius:var(--radius-lg);box-shadow:var(--shadow-card);padding:22px}
    .entry-filters{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));align-items:end;margin-bottom:16px}
    .entry-filters label{display:flex;flex-direction:column;gap:6px;color:var(--ink-soft);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
    .entry-filters select{min-height:40px;padding:8px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--paper);color:var(--ink);font:inherit;font-size:13px;text-transform:none;letter-spacing:normal}
    .dean-filter-button{min-height:40px}
    .selection-summary{margin:18px 0 0;padding:12px 14px;border:1px solid var(--line-soft);border-radius:var(--radius-sm);background:var(--parchment);color:var(--ink-soft);font-size:12px;line-height:1.6}
    .entry-count{margin:22px 0 10px;color:var(--pine-900);font-size:13px;font-weight:700}
    .dean-approve-button{flex:none;min-height:36px;padding:8px 13px}
    .dean-approve-button.is-approved{background:var(--pine-100);color:var(--pine-900);border:1px solid var(--pine-700)}
    .dean-approve-button.is-approved:hover{background:#d8eadc}
    .dean-approve-button.is-denied{background:#f1d5d1;color:#74251d;border:1px solid #8b2d22}
    .dean-approve-button.deny-decision{background:#8b2d22;color:#fff;border:1px solid #8b2d22}
    .dean-decision-buttons{display:flex;flex-wrap:wrap;gap:8px}
    .student-list{display:grid;gap:10px}
    .student-link{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:15px 16px;border:1px solid var(--line);border-radius:var(--radius-md);background:var(--paper);color:var(--ink);text-decoration:none;transition:border-color .15s ease,transform .15s ease}
    .student-link:hover{border-color:var(--pine-700);transform:translateY(-1px)}
    .student-link-name{display:block;color:var(--pine-900);font-family:var(--font-display);font-size:16px;font-weight:700}
    .student-link-meta{display:block;margin-top:4px;color:var(--ink-soft);font-size:11px}
    .student-link-count{flex:none;color:var(--pine-800);font-size:11px;font-weight:700}
    .student-link-actions{display:flex;align-items:center;gap:8px;flex:none}
    .student-complete-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 11px;border-radius:999px;background:#e3f3e8;border:1px solid #8cc6a0;color:#0e4526;font-size:11px;font-weight:800;letter-spacing:.03em;white-space:nowrap}
    .student-complete-badge[hidden]{display:none}
    .semester-progress{margin:0 0 12px;padding:10px 14px;border-radius:12px;background:var(--pine-100,#e8f3ec);color:#14522f;font-size:13px;line-height:1.5}
    .student-link-archive{
      border:1px solid var(--line);background:#fff;color:var(--pine-900);
      border-radius:999px;padding:5px 10px;font-size:10.5px;font-weight:700;cursor:pointer;
    }
    .student-link-archive:hover{background:var(--pine-100)}
    .back-students{display:inline-flex;margin-top:18px;color:var(--pine-800);font-size:12px;font-weight:700;text-decoration:none}
    .entry-list{display:grid;gap:12px}
    .entry-card{padding:16px;border:1px solid var(--line);border-left:4px solid var(--gold-500);border-radius:var(--radius-md);background:var(--paper)}
    .entry-top{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
    .entry-student{margin:0;color:var(--pine-900);font-family:var(--font-display);font-size:17px}
    .entry-meta{margin-top:5px;color:var(--ink-soft);font-size:11px;line-height:1.5}
    .entry-period{flex:none;padding:5px 9px;border-radius:999px;background:var(--pine-100);color:var(--pine-900);font-size:10px;font-weight:700}
    .entry-text{margin:14px 0 0;color:var(--ink);font-size:13px;line-height:1.65;white-space:pre-wrap;overflow-wrap:anywhere}
    .empty-state,.error-state{margin-top:18px;padding:16px;border-radius:var(--radius-md);font-size:13px;line-height:1.6}
    .empty-state{background:var(--pine-100);color:var(--pine-900)}
    .error-state{background:#fff0ec;border:1px solid #e6b4a7;color:#7d291b}
    @media(max-width:760px){.dean-layout{grid-template-columns:1fr}.dean-sidebar{padding:12px 16px;border-right:0;border-bottom:1px solid var(--line)}.dean-sidebar-label{display:none}.dean-content{padding:22px 16px}.entry-filters{grid-template-columns:1fr}.dean-filter-button{width:100%}}
    @media(max-width:460px){.student-link{align-items:flex-start;flex-direction:column}.entry-top{flex-direction:column}.entry-period{order:-1}}

    /* Self-Monitoring Chart dialog (same design as instructor reviewDialog) */
    .csj-dialog{
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      padding: 0;
      width: calc(100% - 32px);
      max-width: 460px;
      box-shadow: var(--shadow-card);
      max-height: calc(100vh - 48px);
      overflow-y: auto;
    }
    .csj-dialog.wide{ max-width: 620px; }
    .csj-dialog.widest{ max-width: 980px; }
    .csj-dialog::backdrop{ background: rgba(14,61,36,0.45); }
    .dialog-form{ padding: 22px; min-width: 0; }
    .dialog-form h2{
      margin: 0 0 4px;
      color: var(--pine-900);
      font-family: var(--font-display);
      font-size: 19px;
    }
    .dialog-sub{
      margin: 0 0 14px;
      color: var(--ink-soft);
      font-size: 12px;
    }
    .dialog-actions{
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-top: 18px;
      padding-top: 14px;
      border-top: 1px solid var(--line-soft);
    }
    .dialog-hint{ font-size: 11.5px; color: var(--ink-soft); }
    .review-header{
      display: flex;
      gap: 14px;
      align-items: center;
      margin-bottom: 12px;
    }
    .review-photo{
      width: 56px;
      height: 56px;
      border-radius: 50%;
      overflow: hidden;
      flex: 0 0 auto;
      background: var(--pine-100);
      border: 2px solid var(--pine-700);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .review-photo img{ width: 100%; height: 100%; object-fit: cover; }
    .review-photo span{
      font-family: var(--font-display);
      font-weight: 700;
      font-size: 22px;
      color: var(--pine-800);
    }
    .review-who{ min-width: 0; }
    .review-name{
      font-family: var(--font-display);
      font-weight: 700;
      font-size: 19px;
      color: var(--pine-900);
    }
    .review-course{
      font-size: 13px;
      color: var(--ink);
      margin-top: 2px;
    }
    .review-header .dialog-sub{ margin: 4px 0 0; }
    .review-table-scroll{ margin-top: 4px; }
    #reviewTable .subject-head.is-mine{ outline: 2px solid var(--gold-500); outline-offset: -2px; }
    #reviewTable .cell-text{ cursor: default; }
    #reviewTable .cell-text[title]{ cursor: help; }
    #reviewTable .cell-inner{ display:flex; flex-direction:column; gap:2px; min-height:100%; }
    #reviewTable .cell-time-label{
      font-size:8px;
      font-weight:700;
      color:#c62828;
      line-height:1.2;
      letter-spacing:0;
      margin-top:3px;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
      max-width:100%;
    }
    .approve-chip-btn{
      margin-top: 6px;
      background: var(--pine-700);
      color: var(--paper);
      border: none;
      border-radius: 999px;
      padding: 4px 10px;
      font-size: 10.5px;
      font-weight: 700;
      cursor: pointer;
    }
    .approve-chip-btn:hover{ background: var(--pine-800); }
    .approve-chip-btn.is-approved{ background: var(--gold-500); color: var(--pine-900); }
    .approve-chip-btn.deny-chip-btn{ background: #8b2d22; }
    .approve-chip-btn.deny-chip-btn:hover{ background: #6f2018; }
    .approve-chip-btn.deny-chip-btn.is-denied{ background: #f1d5d1; color: #74251d; }
    .approve-chip-btn:disabled{ opacity: 0.6; cursor: not-allowed; }
    .period-tab-btn{
      padding: 6px 12px;
      border-radius: 999px;
      border: 1px solid #ccc;
      background: #f5f5f5;
      cursor: pointer;
      font-size: 12px;
    }
    /* Light-theme ghost buttons for dialogs only — do NOT override topbar Logout */
    dialog .btn-ghost,
    .dialog-actions .btn-ghost{
      background: transparent;
      border: 1px solid var(--line);
      color: var(--ink);
      border-radius: var(--radius-sm);
      padding: 8px 14px;
      font: inherit;
      font-size: 13px;
      cursor: pointer;
    }
    dialog .btn-ghost:hover,
    .dialog-actions .btn-ghost:hover{ background: var(--pine-100); }
.dean-sem-quiet-label{display:inline-flex;align-items:center;gap:5px;margin:0;cursor:pointer;}
    .dean-sem-quiet-caption{
      font-size:11px;font-weight:600;letter-spacing:.04em;text-transform:uppercase;
      color:#8a958c;font-family:var(--font-ui, system-ui, sans-serif);
    }
    .dean-sem-quiet-control{
      appearance:none;-webkit-appearance:none;
      border:none;border-bottom:1px solid transparent;
      background:transparent;color:#5a6b5e;
      font:600 13px/1.2 var(--font-ui, system-ui, sans-serif);
      padding:2px 2px 3px;outline:none;cursor:pointer;
      min-width:0;border-radius:0;
    }
    .dean-sem-quiet-control:hover,
    .dean-sem-quiet-control:focus{
      color:var(--pine-900,#14522f);
      border-bottom-color:rgba(20,82,47,.28);
    }
    select.dean-sem-quiet-control{padding-right:14px;background-image:none;}
    .dean-sem-quiet-control option{color:#1d271f;background:#fff;}
    .dean-sem-quiet-hint{font-size:11px;color:#8a958c;min-width:40px;}

  </style>
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="brand-logo">
      <div class="brand-text">
        <span class="brand-title">CSJ Dean Dashboard</span>
        <span class="brand-sub">Higher Education Department &middot; Dean View</span>
      </div>
    </div>
    <div class="topbar-actions">
      <a class="btn btn-ghost" href="logout.php">Logout</a>
    </div>
  </header>
  <div class="dean-layout">
        <aside class="dean-sidebar" aria-label="Dean navigation">
      <p class="dean-sidebar-label">Menu</p>
      <a class="dean-nav-link active" href="dean-dashboard.php" aria-current="page"><span aria-hidden="true">&#9638;</span> Student Entries</a>
      <a class="dean-nav-link" href="dean-student-profiles.php"><span aria-hidden="true">&#128100;</span> Student Profile</a>
      <a class="dean-nav-link" href="dean-password-requests.php"><span aria-hidden="true">&#128274;</span> Password Requests</a>
      <a class="dean-nav-link" href="dean-audit-trail.php"><span aria-hidden="true">&#9776;</span> Audit Trail</a>
      <a class="dean-nav-link" href="dean-feedback.php"><span aria-hidden="true">&#9998;</span> Feedback</a>
      <a class="dean-nav-link" href="dean-archive.php"><span aria-hidden="true">&#128230;</span> Archive</a>
    </aside>
    <main class="dean-content">
      <div class="dean-page-head" style="display:flex;align-items:baseline;justify-content:space-between;gap:16px;flex-wrap:wrap;margin:0 0 10px;">
        <h1 class="dean-heading" style="margin:0;">Student monitoring entries</h1>
        <form id="deanSemesterForm" class="dean-sem-quiet" onsubmit="return false;" style="display:flex;align-items:center;gap:10px;margin:0;">
          <label class="dean-sem-quiet-label">
            <span class="dean-sem-quiet-caption">Semester</span>
            <select name="semester_term" id="deanSemesterTerm" class="dean-sem-quiet-control">
              <option value="First" <?= (isset($csjSemTerm) && strcasecmp((string)$csjSemTerm,'First')===0) ? 'selected' : '' ?>>First Semester</option>
              <option value="Second" <?= (isset($csjSemTerm) && strcasecmp((string)$csjSemTerm,'Second')===0) ? 'selected' : '' ?>>Second Semester</option>
            </select>
          </label>
          <label class="dean-sem-quiet-label">
            <span class="dean-sem-quiet-caption">AY</span>
            <input type="text" name="semester_ay" id="deanSemesterAy" class="dean-sem-quiet-control"
                   value="<?= htmlspecialchars($csjSemAy ?? '2026-2027', ENT_QUOTES) ?>"
                   placeholder="2026-2029" pattern="\d{4}-\d{4}" size="9">
          </label>
          <span id="deanSemSaveHint" class="dean-sem-quiet-hint" aria-live="polite"></span>
        </form>
      </div>

<section class="dean-card" aria-label="List of students and filters">
        <form method="get" class="entry-filters" id="entryFilterForm">
          <label for="studentListLabel">List of Students
            <select id="studentListLabel" name="profile" onchange="this.form.submit()">
              <option value="">All students…</option>
              <?php foreach ($students as $student): ?>
                <option value="<?= dean_h($student['profile_key']) ?>" <?= $selectedProfileKey === $student['profile_key'] ? 'selected' : '' ?>>
                  <?= dean_h($student['student_name']) ?><?php if ($student['course_year'] !== ''): ?> — <?= dean_h($student['course_year']) ?><?php endif; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </label>
          <label for="year">Year Level
            <select id="year" name="year" onchange="this.form.submit()">
              <option value="">All year levels</option>
              <?php foreach ($yearOptions as $yearOpt): ?>
                <option value="<?= dean_h($yearOpt) ?>" <?= $filterYear === $yearOpt ? 'selected' : '' ?>><?= dean_h($yearLabels[$yearOpt] ?? $yearOpt) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label for="course">Course
            <select id="course" name="course" onchange="this.form.submit()">
              <option value="">All courses</option>
              <?php foreach ($courseOptions as $courseOpt): ?>
                <option value="<?= dean_h($courseOpt) ?>" <?= $filterCourse === $courseOpt ? 'selected' : '' ?>><?= dean_h($courseOpt) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label for="sort">A–Z
            <select id="sort" name="sort" onchange="this.form.submit()">
              <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Student name (A–Z)</option>
              <option value="name_desc" <?= $sort === 'name_desc' ? 'selected' : '' ?>>Student name (Z–A)</option>
              <option value="updated" <?= $sort === 'updated' ? 'selected' : '' ?>>Recently updated</option>
            </select>
          </label>
        </form>
        <?php if ($pageError !== ''): ?>
          <div class="error-state" role="alert"><?= dean_h($pageError) ?></div>
        <?php elseif (!$students): ?>
          <div class="empty-state">No student accounts found<?= ($filterCourse !== '' || $filterYear !== '') ? ' for these filters' : '' ?>.</div>
        <?php else: ?>
          <p class="entry-count"><?= count($students) ?> student<?= count($students) === 1 ? '' : 's' ?> (alphabetical list)</p>
          <?php if ($progressTotal > 0): ?>
          <p class="semester-progress" id="semesterProgress">
            <strong>Semester progress:</strong> <?= (int)$progressDone ?> of <?= (int)$progressTotal ?> student<?= $progressTotal === 1 ? '' : 's' ?> with a monitoring sheet fully approved (Prelims, Midterms &amp; Finals).
            The new semester starts automatically when all of them are approved.
          </p>
          <?php endif; ?>
          <div class="student-list">
            <?php foreach ($students as $student): ?>
              <a class="student-link"
                 href="?sort=<?= dean_h($sort) ?>&amp;course=<?= dean_h($filterCourse) ?>&amp;year=<?= dean_h($filterYear) ?>&amp;profile=<?= dean_h($student['profile_key']) ?>"
                 data-profile="<?= dean_h($student['profile_key']) ?>"
                 data-name="<?= dean_h($student['student_name']) ?>"
                 data-semester="<?= dean_h($student['semester']) ?>"
                 data-subject="">
                <span>
                  <span class="student-link-name"><?= dean_h($student['student_name']) ?></span>
                  <span class="student-link-meta">
                    <?php if ($student['student_id'] !== ''): ?><?= dean_h($student['student_id']) ?> &middot; <?php endif; ?>
                    <?= dean_h($student['course_year']) ?>
                    <?php if ($student['semester'] !== ''): ?> &middot; <?= dean_h($student['semester']) ?><?php endif; ?>
                    &middot; Updated <?= dean_h($student['updated_at']) ?>
                  </span>
                </span>
                <span class="student-link-actions">
                  <span class="student-complete-badge"<?= !empty($student['complete']) ? '' : ' hidden' ?> title="The Dean approved this student's Finals">&#10003; Complete</span>
                  <span class="student-link-count">View chart &rarr;</span>
                </span>
              </a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </section>
    </main>
  </div>

  <!-- Self-Monitoring Chart dialog (same as instructor reviewDialog) -->
  <dialog id="reviewDialog" class="csj-dialog widest">
    <form method="dialog" class="dialog-form">
      <h2>Self-Monitoring Chart</h2>
      <div class="review-header">
        <div class="review-photo" id="reviewPhotoWrap">
          <img id="reviewPhotoImg" src="" alt="" style="display:none;">
          <span id="reviewPhotoInitial">?</span>
        </div>
        <div class="review-who">
          <div class="review-name" id="reviewStudentName">Student Monitoring Chart</div>
          <div class="review-course" id="reviewCourseYear"></div>
          <div class="dialog-sub" id="reviewStudentMeta"></div>
        </div>
      </div>
      <div id="reviewPeriodTabs" style="display:flex;gap:6px;margin:8px 0 12px;flex-wrap:wrap;"></div>
      <div class="table-scroll review-table-scroll">
        <table class="chart-table" id="reviewTable">
          <thead><tr id="reviewHeadRow" class="head-row"></tr></thead>
          <tbody id="reviewBody"></tbody>
        </table>
      </div>
      <div class="dialog-actions" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <span id="reviewApproveMsg" class="dialog-hint"></span>
        <div style="display:flex;gap:8px;align-items:center;">
          <button id="deanPeriodApproveBtn" class="btn btn-primary dean-approve-button" type="button" style="min-height:36px;padding:8px 16px;">Approve</button>
          <button id="reviewClose" class="btn btn-ghost" type="button">Close</button>
        </div>
      </div>
    </form>
  </dialog>

  <?php
  require_once __DIR__ . '/php/semester_popup.php';
  csj_semester_popup_render([
      'seconds' => defined('CSJ_WELCOME_POPUP_SECONDS') ? CSJ_WELCOME_POPUP_SECONDS : 5,
      'show' => !empty($csjDeanWelcome) ? [
          'title'    => 'New Semester',
          'headline' => 'New semester, new learnings.',
          'sub'      => 'The new semester is now ' . ($csjDeanWelcome['semester'] ?? '') . '. Student monitoring sheets and instructors\' subject selections were cleared.',
      ] : null,
  ]);
  ?>
  <script>
  (function() {
    const PERIOD_ORDER = ['prelims', 'midterms', 'finals'];
    const PERIOD_LABELS = { prelims: 'Prelims', midterms: 'Midterms', finals: 'Finals' };
    let currentReviewPeriod = 'prelims';
    let currentReviewChart = null;
    let currentReview = null; // { profileKey, selectionId, subjectCode, semester }

    function escapeHtml(s) {
      return String(s == null ? '' : s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }

    function formatDate(v) {
      if (!v) return '—';
      try {
        const d = new Date(v);
        if (isNaN(d.getTime())) return String(v);
        return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
      } catch (e) { return String(v); }
    }

    
    function formatDateTime(v) {
      if (!v) return '';
      try {
        const raw = String(v).trim();

        // 1) Naive "YYYY-MM-DD HH:MM:SS" = Philippine wall time already (from student submit).
        //    Reformat only — do NOT apply another timezone shift (that caused the +8h / UTC bug).
        const m = raw.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/);
        if (m) {
          const mm = m[2], dd = m[3], yyyy = m[1];
          let h = parseInt(m[4], 10);
          const min = m[5];
          const ampm = h >= 12 ? 'PM' : 'AM';
          const h12 = (h % 12) || 12;
          return mm + '/' + dd + '/' + yyyy + ' ' + h12 + ':' + min + ' ' + ampm;
        }

        // 2) ISO with Z or offset → convert to Asia/Manila for display
        const d = new Date(raw);
        if (isNaN(d.getTime())) return raw;
        const parts = new Intl.DateTimeFormat('en-US', {
          timeZone: 'Asia/Manila',
          year: 'numeric', month: '2-digit', day: '2-digit',
          hour: 'numeric', minute: '2-digit', hour12: true
        }).formatToParts(d);
        const g = (type) => (parts.find((p) => p.type === type) || {}).value || '';
        return g('month') + '/' + g('day') + '/' + g('year') + ' ' + g('hour') + ':' + g('minute') + ' ' + g('dayPeriod');
      } catch (e) {
        return String(v);
      }
    }

    function normCode(s) {
      return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    }

    function setReviewPhoto(url, nameForInitial) {
      const img = document.getElementById('reviewPhotoImg');
      const initial = document.getElementById('reviewPhotoInitial');
      if (url) {
        img.src = url;
        img.style.display = '';
        initial.style.display = 'none';
      } else {
        img.style.display = 'none';
        initial.textContent = (nameForInitial || '?').trim().charAt(0).toUpperCase() || '?';
        initial.style.display = '';
      }
    }

    function getPeriodBlock(chart, period) {
      if (!chart) return { subjects: [], rows: [], deanApproved: false };
      if (chart.periods && chart.periods[period]) {
        const p = chart.periods[period];
        return {
          subjects: p.subjects || [],
          rows: p.rows || [],
          chartTitle: p.chartTitle || '',
          deanApproved: !!p.deanApproved,
          deanApprovedBy: p.deanApprovedBy || '',
          deanApprovedAt: p.deanApprovedAt || ''
        };
      }
      if (period === 'prelims' && (chart.subjects || chart.rows)) {
        return { subjects: chart.subjects || [], rows: chart.rows || [], chartTitle: '', deanApproved: false };
      }
      return { subjects: [], rows: [], deanApproved: false };
    }

    function highlightPeriodTab() {
      const tabs = document.getElementById('reviewPeriodTabs');
      if (!tabs) return;
      tabs.querySelectorAll('.period-tab-btn').forEach((btn) => {
        const on = btn.dataset.period === currentReviewPeriod;
        btn.style.background = on ? '#1a4d2e' : '#f5f5f5';
        btn.style.color = on ? '#fff' : '#222';
        btn.style.borderColor = on ? '#1a4d2e' : '#ccc';
      });
    }

    function ensureReviewPeriodTabs() {
      const tabs = document.getElementById('reviewPeriodTabs');
      if (!tabs) return;
      if (tabs.children.length) return;
      PERIOD_ORDER.forEach((pk) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'period-tab-btn';
        btn.dataset.period = pk;
        btn.textContent = PERIOD_LABELS[pk];
        btn.addEventListener('click', () => {
          currentReviewPeriod = pk;
          if (currentReviewChart) renderReviewTable(currentReviewChart);
        });
        tabs.appendChild(btn);
      });
    }

    function renderReviewTable(chart) {
      currentReviewChart = chart;
      ensureReviewPeriodTabs();
      highlightPeriodTab();

      const block = getPeriodBlock(chart, currentReviewPeriod);
      const subjects = block.subjects;
      const rows = block.rows;
      const reviewSubjectNorm = (currentReview && currentReview.subjectCode) ? normCode(currentReview.subjectCode) : '';

      const headRow = document.getElementById('reviewHeadRow');
      headRow.innerHTML = '';
      const body = document.getElementById('reviewBody');
      body.innerHTML = '';

      if (!subjects.length) {
        body.innerHTML = '<tr><td colspan="9" style="padding:16px;text-align:center;opacity:.7;">No subjects for this period yet.</td></tr>';
        updateDeanApproveButton(chart);
        return;
      }

      subjects.forEach((s) => {
        const codeNorm = normCode(s.code);
        const isMine = codeNorm !== '' && reviewSubjectNorm !== '' && codeNorm === reviewSubjectNorm;
        const th = document.createElement('th');
        th.className = 'subject-head' + (isMine ? ' is-mine' : '');
        const isApproved = !!s.approved;
        const status = ['approved', 'denied', 'pending'].includes(s.reviewStatus)
          ? s.reviewStatus
          : (isApproved ? 'approved' : 'pending');
        let reviewer = String(s.reviewedBy || s.instructor || '').trim();
        // Ignore placeholder dashes so status shows "Pending" not "Pending — —"
        if (/^[—\-–_\s]+$/.test(reviewer)) reviewer = '';
        const statusLabel = status === 'approved'
          ? '✓ Approved'
          : (status === 'denied' ? 'Denied' : 'Pending');
        // No Approve/Deny chips inside subject-head — Dean uses the single period-level Approve button below.
        th.innerHTML = `
          <span class="subject-label">Subject ${s.id}</span>
          <div style="font-family:var(--font-display);font-weight:700;">${escapeHtml(s.code || '—')}</div>
          <div class="head-status" style="font-size:9.5px;margin-top:3px;opacity:.85;">${statusLabel}${reviewer ? ' — ' + escapeHtml(reviewer) : ''}</div>
        `;
        headRow.appendChild(th);
      });

      // Update the Dean period-level Approve button state
      updateDeanApproveButton(chart);

      rows.forEach((r) => {
        const tr = document.createElement('tr');
        tr.className = 'entry-row';
        subjects.forEach((s) => {
          const val = (r.entries && r.entries[String(s.id)]) || '';
          const sid = String(s.id);
          let cellTime = '';
          if (r.entryTimes && r.entryTimes[sid]) cellTime = r.entryTimes[sid];
          else if (val && currentReview) cellTime = currentReview.updatedAt || currentReview.submittedAt || '';
          const timeLabel = cellTime ? formatDateTime(cellTime) : '';
          const tip = val && timeLabel ? ('Submitted / updated: ' + timeLabel) : '';
          const redLabel = (val && timeLabel)
            ? `<div class="cell-time-label">${escapeHtml(timeLabel)}</div>`
            : '';
          const td = document.createElement('td');
          td.className = 'entry-cell';
          td.innerHTML = `<div class="cell-inner"><div class="cell-text"${tip ? ` title="${escapeHtml(tip)}"` : ''}>${escapeHtml(val)}</div>${redLabel}</div>`;
          tr.appendChild(td);
        });
        body.appendChild(tr);
      });
    }

    // Periods are approved in order: Prelims -> Midterms -> Finals (and cleared in reverse order).
    function deanApprovalBlockReason(chart, period, approving) {
      const order = ['prelims', 'midterms', 'finals'];
      const names = { prelims: 'Prelims', midterms: 'Midterms', finals: 'Finals' };
      const isOk = (k) => !!(getPeriodBlock(chart, k) || {}).deanApproved;
      const pos = order.indexOf(period);
      if (approving && pos > 0 && !isOk(order[pos - 1])) {
        return 'Approve the ' + names[order[pos - 1]] + ' first. The student can only open the ' + names[period] + ' after that.';
      }
      if (!approving) {
        for (let i = pos + 1; i < order.length; i++) {
          if (isOk(order[i])) return 'Clear the ' + names[order[i]] + ' approval first.';
        }
      }
      return '';
    }

    function setCompleteBadge(profileKey, on) {
      document.querySelectorAll('a.student-link').forEach((link) => {
        if (link.dataset.profile !== profileKey) return;
        const badge = link.querySelector('.student-complete-badge');
        if (badge) badge.hidden = !on;
      });
    }

    function updateDeanApproveButton(chart, keepMsg) {
      const btn = document.getElementById('deanPeriodApproveBtn');
      if (!btn) return;
      const block = getPeriodBlock(chart, currentReviewPeriod);
      const approved = !!(block && block.deanApproved);
      btn.classList.toggle('is-approved', approved);
      btn.textContent = approved ? 'Approved ✓' : 'Approve';
      btn.dataset.status = approved ? 'approved' : 'pending';
      const reason = deanApprovalBlockReason(chart, currentReviewPeriod, !approved);
      btn.disabled = !!reason;
      btn.title = reason;
      const msgEl = document.getElementById('reviewApproveMsg');
      if (msgEl && !keepMsg) msgEl.textContent = reason;
    }

    async function setDeanPeriodApproval() {
      if (!currentReview) return;
      const btn = document.getElementById('deanPeriodApproveBtn');
      const msg = document.getElementById('reviewApproveMsg');
      const currentStatus = btn.dataset.status || 'pending';
      const decision = currentStatus === 'approved' ? 'pending' : 'approved';
      btn.disabled = true;
      msg.textContent = 'Saving…';

      try {
        const res = await fetch('php/dean_approve.php', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({
            selectionId: currentReview.selectionId ? Number(currentReview.selectionId) : 0,
            profileKey: currentReview.profileKey,
            period: currentReviewPeriod,
            decision: decision,
            scope: 'period',
            semester: currentReview.semester || ''
          })
        });
        const data = await res.json();
        if (!res.ok || !data.ok) throw new Error(data.message || 'Could not save decision.');

        if (!currentReviewChart.periods) currentReviewChart.periods = {};
        if (!currentReviewChart.periods[currentReviewPeriod]) {
          currentReviewChart.periods[currentReviewPeriod] = { subjects: [], rows: [] };
        }
        const periodBlock = currentReviewChart.periods[currentReviewPeriod];
        if (decision === 'approved') {
          periodBlock.deanApproved = true;
          periodBlock.deanApprovedBy = data.deanName || 'Dean';
          periodBlock.deanApprovedAt = new Date().toISOString().slice(0, 19).replace('T', ' ');
        } else {
          periodBlock.deanApproved = false;
          delete periodBlock.deanApprovedBy;
          delete periodBlock.deanApprovedAt;
        }
        updateDeanApproveButton(currentReviewChart, true);
        setCompleteBadge(currentReview.profileKey, !!data.complete);

        // That was the LAST student: the whole school moved to the new semester.
        if (data.semesterTransition) {
          var go = function () { location.reload(); };
          if (typeof csjShowSemesterPopup === 'function') {
            csjShowSemesterPopup({
              title: 'New Semester',
              headline: 'New semester, new learnings.',
              sub: 'Every student\u2019s Prelims, Midterms and Finals monitoring is approved. Monitoring sheets and instructors\u2019 subject selections were cleared for ' + (data.newSemester || 'the new semester') + '.',
              onClose: go
            });
          } else {
            go();
          }
          return;
        }
        msg.textContent = decision === 'approved'
          ? (data.complete ? '✓ Finals approved — this student is now Complete' : '✓ Dean approved this period')
          : 'Approval cleared';
      } catch (err) {
        msg.textContent = err.message || 'Could not save.';
      } finally {
        updateDeanApproveButton(currentReviewChart, true);
      }
    }

    async function openReview(profileKey, studentNameFallback, selectionId, semester, subjectCode) {
      currentReview = { profileKey, selectionId: selectionId || 0, subjectCode: subjectCode || '', semester: semester || '' };
      document.getElementById('reviewStudentName').textContent = studentNameFallback || 'Student';
      document.getElementById('reviewCourseYear').textContent = '';
      document.getElementById('reviewStudentMeta').textContent = 'Loading…';
      document.getElementById('reviewHeadRow').innerHTML = '';
      document.getElementById('reviewBody').innerHTML = '';
      document.getElementById('reviewApproveMsg').textContent = '';
      document.getElementById('reviewPeriodTabs').innerHTML = '';
      setReviewPhoto('', studentNameFallback);

      currentReviewPeriod = 'prelims';
      const dlg = document.getElementById('reviewDialog');
      dlg.showModal();

      try {
        const res = await fetch(`instructor/php/student_chart.php?profile_key=${encodeURIComponent(profileKey)}&semester=${encodeURIComponent(semester)}`);
        const data = await res.json();
        if (!data.ok) throw new Error(data.message || 'Failed to load chart');

        document.getElementById('reviewStudentName').textContent = data.studentName || studentNameFallback;
        document.getElementById('reviewCourseYear').textContent = data.courseYear || '—';
        if (currentReview) {
          currentReview.submittedAt = data.submittedAt || '';
          currentReview.updatedAt = data.updatedAt || data.submittedAt || '';
        }
        document.getElementById('reviewStudentMeta').textContent =
          `Submitted ${formatDate(data.submittedAt)} · last updated ${formatDate(data.updatedAt)}`;
        const photoUrl = data.photoPath ? String(data.photoPath).replace(/^\/+/, '') : '';
        setReviewPhoto(photoUrl ? photoUrl : '', data.studentName || studentNameFallback);

        // Prefer period that has the subject
        if (data.chart && data.chart.periods) {
          const found = PERIOD_ORDER.find((pk) => {
            const blk = data.chart.periods[pk];
            if (!blk || !blk.subjects) return false;
            return blk.subjects.some((s) => normCode(s.code) === normCode(subjectCode));
          });
          if (found) currentReviewPeriod = found;
        }

        renderReviewTable(data.chart || {});
      } catch (err) {
        document.getElementById('reviewStudentMeta').textContent = err.message || 'Could not load this chart.';
      }
    }

    document.getElementById('reviewClose').addEventListener('click', () => {
      document.getElementById('reviewDialog').close();
    });

    const deanApproveBtn = document.getElementById('deanPeriodApproveBtn');
    if (deanApproveBtn) {
      deanApproveBtn.addEventListener('click', () => setDeanPeriodApproval());
    }

    // Intercept student-link clicks to open dialog instead of (or before) navigating
    document.querySelectorAll('a.student-link').forEach((link) => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const profile = link.dataset.profile;
        const name = link.dataset.name;
        const selection = link.dataset.selection || 0;
        const semester = link.dataset.semester || '';
        const subject = link.dataset.subject || '';
        if (profile) {
          openReview(profile, name, selection, semester, subject);
          const url = new URL(window.location.href);
          url.searchParams.set('profile', profile);
          history.replaceState(null, '', url.toString());
        } else {
          window.location.href = link.href;
        }
      });
    });

    // Auto-open if page loaded with a selected student (profile in URL)
    <?php if ($selectedStudent): ?>
    openReview(
      <?= json_encode($selectedStudent['profile_key']) ?>,
      <?= json_encode($selectedStudent['student_name']) ?>,
      0,
      <?= json_encode((string)$selectedStudent['semester']) ?>,
      ''
    );
    <?php endif; ?>
  })();
  </script>

<dialog id="semChangeDialog" class="csj-dialog">
  <form method="dialog" class="dialog-form" onsubmit="return false;">
    <h2>Start a new semester?</h2>
    <p class="dialog-sub" id="semChangeLabel"></p>
    <ul style="margin:0 0 14px;padding-left:18px;font-size:13px;line-height:1.65;color:var(--ink);">
      <li>All current student monitoring sheets are saved to the <strong>Archive</strong>, then cleared.</li>
      <li>Instructor subject lists are cleared (instructors choose their subjects again).</li>
      <li>Students and instructors see the <strong>New Semester</strong> welcome once.</li>
    </ul>
    <p id="semChangeErr" role="alert" style="margin:0 0 10px;color:#7d291b;font-size:12.5px;" hidden></p>
    <div class="dialog-actions">
      <button type="button" id="semChangeCancel" class="btn btn-ghost">Cancel</button>
      <button type="button" id="semChangeOk" class="btn btn-primary">Start new semester</button>
    </div>
  </form>
</dialog>

<script>
(function(){
  /* Editing the Semester box or the AY box starts a NEW SEMESTER, exactly like the automatic
     one that happens when every student is approved (archive sheets -> clear live data ->
     new semester + welcome popups). Because that clears live data, the Dean confirms first. */
  var term = document.getElementById('deanSemesterTerm');
  var ay = document.getElementById('deanSemesterAy');
  var hint = document.getElementById('deanSemSaveHint');
  var dlg = document.getElementById('semChangeDialog');
  var okBtn = document.getElementById('semChangeOk');
  var cancelBtn = document.getElementById('semChangeCancel');
  var labelEl = document.getElementById('semChangeLabel');
  var errEl = document.getElementById('semChangeErr');
  if (!term || !ay || !dlg) return;

  var current = { term: term.value, ay: normAy(ay.value) };   // what the system is on right now
  var pending = null, busy = false, confirmed = false;

  function normAy(v) { return (v || '').trim().replace(/^AY\s*/i, ''); }
  function say(msg, keep) {
    if (!hint) return;
    hint.textContent = msg;
    if (!keep) setTimeout(function () { if (hint.textContent === msg) hint.textContent = ''; }, 2500);
  }
  function revert() { term.value = current.term; ay.value = current.ay; }

  function onEdit() {
    if (busy) return;
    var t = term.value, y = normAy(ay.value);
    if (t === current.term && y === current.ay) { say(''); return; }
    var m = /^(\d{4})-(\d{4})$/.exec(y);
    if (!m) { say('Use YYYY-YYYY (e.g. 2028-2029)', true); return; }
    if (parseInt(m[2], 10) !== parseInt(m[1], 10) + 1) { say('AY must be consecutive years', true); return; }
    say('');
    pending = { term: t, ay: y };
    labelEl.innerHTML = 'Change the semester to <strong>' + t + ' Semester, AY ' + y + '</strong>?';
    errEl.hidden = true;
    confirmed = false;
    okBtn.disabled = false;
    dlg.showModal();
  }

  // The Semester / AY boxes act when the Dean finishes editing (not on every keystroke).
  term.addEventListener('change', onEdit);
  ay.addEventListener('change', onEdit);

  cancelBtn.addEventListener('click', function () { dlg.close(); });
  // Esc, Cancel or any other way of closing without confirming puts the old values back.
  dlg.addEventListener('close', function () { if (!confirmed && !busy) { revert(); say(''); } });

  okBtn.addEventListener('click', function () {
    if (!pending || busy) return;
    busy = true; okBtn.disabled = true; errEl.hidden = true;
    var fd = new FormData();
    fd.append('semester_term', pending.term);
    fd.append('semester_ay', pending.ay);
    fd.append('confirm', '1');
    fetch('php/dean_set_semester.php', {
      method: 'POST', body: fd, credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
      .then(function (r) { return r.json().catch(function () { return { ok: false }; }); })
      .then(function (d) {
        if (d && d.ok) {
          confirmed = true; dlg.close();
          current = { term: pending.term, ay: pending.ay };
          say('New semester started', true);
          var semLabel = (pending.term === 'Second' ? 'Second' : 'First') + ' Semester, AY ' + pending.ay;
          var goHome = function () { window.location.href = 'dean-dashboard.php'; };
          if (typeof csjShowSemesterPopup === 'function' && d.changed !== false) {
            csjShowSemesterPopup({
              title: 'New Semester',
              headline: 'New semester, new learnings.',
              sub: 'Every student\u2019s monitoring sheets and instructors\u2019 subject selections were cleared for ' + semLabel + '.',
              onClose: goHome
            });
          } else {
            goHome();
          }
        } else {
          busy = false; okBtn.disabled = false;
          errEl.textContent = (d && d.message) ? d.message : 'The semester could not be changed.';
          errEl.hidden = false;
        }
      })
      .catch(function () {
        busy = false; okBtn.disabled = false;
        errEl.textContent = 'Network error. Please try again.';
        errEl.hidden = false;
      });
  });
})();
</script>

</body>
</html>
