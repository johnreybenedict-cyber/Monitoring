<?php
require_once __DIR__ . '/php/db.php';
require_once __DIR__ . '/config.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    header('Location: index.php');
    exit;
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function fb_h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$roleFilter = strtolower(trim((string)($_GET['role'] ?? '')));
$allowedRoles = ['', 'student', 'instructor'];
if (!in_array($roleFilter, $allowedRoles, true)) $roleFilter = '';

$records = [];
$pageError = '';

try {
    $pdo = csj_db();
    // Ensure table exists (same definition as php/feedback.php)
    $pdo->exec("CREATE TABLE IF NOT EXISTS feedback (
      feedback_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
      role VARCHAR(20) NOT NULL,
      profile_key CHAR(32) DEFAULT NULL,
      instructor_key CHAR(32) DEFAULT NULL,
      user_name VARCHAR(150) DEFAULT NULL,
      message TEXT NOT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (feedback_id),
      KEY idx_feedback_role (role),
      KEY idx_feedback_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $where = [];
    $params = [];
    if ($roleFilter !== '') {
        $where[] = 'role = ?';
        $params[] = $roleFilter;
    }
    $sql = 'SELECT feedback_id, role, profile_key, instructor_key, user_name, message, created_at
            FROM feedback';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY feedback_id DESC LIMIT 300';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('Dean feedback could not load: ' . $e->getMessage());
    $pageError = 'Feedback could not be loaded. Check that MySQL is running and the feedback table exists.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Feedback - CSJ Dean Dashboard</title>
  <link rel="icon" href="assets/logos/csj-seal.jpg">
  <link rel="stylesheet" href="css/style.css?v=<?= (int)(@filemtime(__DIR__ . '/css/style.css') ?: time()) ?>">
  <style>
    .dean-layout{min-height:calc(100vh - 74px);display:grid;grid-template-columns:245px minmax(0,1fr)}
    .dean-sidebar{padding:24px 16px;background:var(--paper);border-right:1px solid var(--line)}
    .dean-sidebar-label{margin:0 12px 10px;color:var(--ink-soft);font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
    .dean-nav-link{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--radius-sm);background:var(--pine-100);color:var(--pine-900);font-size:13px;font-weight:700;text-decoration:none;margin-top:8px}
    .dean-nav-link:first-of-type{margin-top:0}
    .dean-nav-link.active{background:var(--pine-200,#d7e8dc)}
    .dean-content{min-width:0;padding:32px clamp(16px,4vw,48px)}
    .dean-heading{margin:0 0 6px;color:var(--pine-900);font-family:var(--font-display);font-size:26px}
    .dean-intro{margin:0 0 18px;color:var(--ink-soft);font-size:13px;line-height:1.6}
    .fb-filters{display:flex;flex-wrap:wrap;align-items:end;gap:12px;margin-bottom:18px;padding:18px;background:var(--paper);border:1px solid var(--line);border-radius:var(--radius-lg)}
    .fb-filters label{display:flex;flex-direction:column;gap:6px;color:var(--ink-soft);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
    .fb-filters select{min-width:160px;min-height:40px;padding:8px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);background:var(--paper);color:var(--ink);font:inherit;font-size:13px;text-transform:none;letter-spacing:normal}
    .fb-list{display:grid;gap:12px}
    .fb-card{padding:16px;background:var(--paper);border:1px solid var(--line);border-left:4px solid var(--gold-500);border-radius:var(--radius-md)}
    .fb-top{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap}
    .fb-who{margin:0;color:var(--pine-900);font-family:var(--font-display);font-size:16px;font-weight:700}
    .fb-meta{margin-top:4px;color:var(--ink-soft);font-size:11px;line-height:1.5}
    .fb-role{flex:none;padding:5px 9px;border-radius:999px;background:var(--pine-100);color:var(--pine-900);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
    .fb-role.is-instructor{background:#eef2ea;color:#3d4a3a}
    .fb-msg{margin:12px 0 0;color:var(--ink);font-size:13px;line-height:1.65;white-space:pre-wrap;overflow-wrap:anywhere}
    .empty-state,.error-state{padding:16px;border-radius:var(--radius-md);font-size:13px;line-height:1.6}
    .empty-state{background:var(--parchment);border:1px solid var(--line-soft);color:var(--ink-soft)}
    .error-state{background:#fff0ec;border:1px solid #e6b4a7;color:#7d291b}
    @media(max-width:760px){.dean-layout{grid-template-columns:1fr}.dean-sidebar{padding:12px 16px;border-right:0;border-bottom:1px solid var(--line)}.dean-sidebar-label{display:none}.dean-content{padding:22px 16px}}
  </style>
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="brand-logo">
      <div class="brand-text">
        <span class="brand-title">CSJ Dean Dashboard</span>
        <span class="brand-sub">Higher Education Department &middot; Dean View</span>
      </div>
    </div>
    <div class="topbar-actions">
      <a class="btn btn-ghost" href="logout.php">Logout</a>
    </div>
  </header>
  <div class="dean-layout">
        <aside class="dean-sidebar" aria-label="Dean navigation">
      <p class="dean-sidebar-label">Menu</p>
      <a class="dean-nav-link" href="dean-dashboard.php"><span aria-hidden="true">&#9638;</span> Student Entries</a>
      <a class="dean-nav-link" href="dean-student-profiles.php"><span aria-hidden="true">&#128100;</span> Student Profile</a>
      <a class="dean-nav-link" href="dean-password-requests.php"><span aria-hidden="true">&#128274;</span> Password Requests</a>
      <a class="dean-nav-link" href="dean-audit-trail.php"><span aria-hidden="true">&#9776;</span> Audit Trail</a>
      <a class="dean-nav-link active" href="dean-feedback.php" aria-current="page"><span aria-hidden="true">&#9998;</span> Feedback</a>
      <a class="dean-nav-link" href="dean-archive.php"><span aria-hidden="true">&#128230;</span> Archive</a>
    </aside>
    <main class="dean-content">
      <h1 class="dean-heading">Feedback</h1>
      <p class="dean-intro">Messages submitted by students and instructors through their Feedback boxes.</p>

      <form method="get" class="fb-filters" id="fbFilterForm">
        <label for="role">From
          <select id="role" name="role" onchange="this.form.submit()">
            <option value="">All (students &amp; instructors)</option>
            <option value="student" <?= $roleFilter === 'student' ? 'selected' : '' ?>>Students</option>
            <option value="instructor" <?= $roleFilter === 'instructor' ? 'selected' : '' ?>>Instructors</option>
          </select>
        </label>
      </form>

      <?php if ($pageError !== ''): ?>
        <div class="error-state" role="alert"><?= fb_h($pageError) ?></div>
      <?php elseif (!$records): ?>
        <div class="empty-state">No feedback has been submitted yet.</div>
      <?php else: ?>
        <div class="fb-list">
          <?php foreach ($records as $row):
            $role = (string)($row['role'] ?? '');
            $name = trim((string)($row['user_name'] ?? ''));
            if ($name === '') $name = $role === 'instructor' ? 'Instructor' : 'Student';
            $when = (string)($row['created_at'] ?? '');
          ?>
            <article class="fb-card">
              <div class="fb-top">
                <div>
                  <h2 class="fb-who"><?= fb_h($name) ?></h2>
                  <div class="fb-meta"><?= fb_h($when !== '' ? $when : '—') ?></div>
                </div>
                <span class="fb-role<?= $role === 'instructor' ? ' is-instructor' : '' ?>"><?= fb_h($role === 'instructor' ? 'Instructor' : 'Student') ?></span>
              </div>
              <p class="fb-msg"><?= fb_h((string)($row['message'] ?? '')) ?></p>
            </article>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </main>
  </div>
</body>
</html>
