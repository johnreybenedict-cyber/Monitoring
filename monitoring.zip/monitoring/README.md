# CSJ Self-Monitoring Dashboard (Fingerprint + Instructor Approval)

## Log in with Student ID / Teacher ID + Security (anti SQL injection)

**Log in** (`index.php`): students sign in with their **Student ID**, teachers with their **Teacher ID**,
plus the password. Email addresses are no longer accepted on the Log In box (the Dean still uses the
username `dean`). Email is still collected at Sign Up for password-recovery / OTP only.

**Full Name box**: shows the hint `Last Name, First Name, Middle Name` completely inside the textbox.

**Security layers** (all in `php/security.php`, loaded by `config.php`):
1. Every query uses PDO prepared statements (input is sent as data, never pasted into SQL).
2. IDs are whitelisted: letters, digits, `.` `_` `-` only (max 64). Names: letters, spaces, `, . ' -`.
3. `csj_looks_like_sqli()` rejects UNION SELECT, `' OR 1=1`, `--`, `/* */`, `; DROP ...`, SLEEP(), etc.
4. The database connection refuses stacked queries (`MYSQL_ATTR_MULTI_STATEMENTS = false`).
5. Failed-login throttle: 10 wrong attempts per ID + IP in 10 minutes -> temporary block
   (table `login_attempts` is created automatically; change `CSJ_LOGIN_MAX_FAILS` /
   `CSJ_LOGIN_WINDOW_SECS` in `php/security.php`).
6. Session cookies are HttpOnly + SameSite=Lax, and `Secure` automatically on the ngrok https address.
7. `.htaccess` blocks direct download of `config.php`, `mail_config.php`, `schema.sql`, `README.md`
   and adds basic security headers.

## Default Dean login

- URL: `/monitoring/` (the normal login page) -> sign in with the Dean credentials
- Username: `dean`
- Password: `Dean@CSJ2026`
- Change it after first sign-in. Re-importing `schema.sql` never overwrites an existing Dean account.

## Running through ngrok

1. Start Apache + MySQL in XAMPP, import `schema.sql`.
2. Run `ngrok http 80` (or the port Apache uses, e.g. `ngrok http 8080`).
3. Open the `https://....ngrok-free.dev/monitoring/` address for EVERYTHING (register, login, fingerprint) --
   never mix `localhost` and the ngrok address, because sessions and fingerprints are tied to the host name.
4. All links are relative and the biometric code reads `X-Forwarded-Host`, so no config edits are needed.






## Dean Dashboard: Export Database + changing the semester

**Export Database (full backup)**
- Dean Dashboard -> sidebar -> **Export Database** downloads `csj_full_database_backup_<date>.sql`.
- The file contains EVERY table (structure + all rows): student, instructor and dean accounts,
  monitoring sheets, archive, feedback, audit trail, system flags, biometric records, etc.
  Tables are discovered automatically, so tables added later are included too.
- Restore: phpMyAdmin -> Import -> choose the file (it creates the database if missing and replaces
  existing tables), or `mysql -u root < csj_full_database_backup_<date>.sql`.
- The file holds accounts and password hashes: keep it private. Profile photos are files in
  `assets/uploads/`, not database rows, so back that folder up as well.
- Only a logged-in Dean can download it (the export is also written to the Audit Trail).

**Changing the Semester / AY boxes = start a new semester**
- When the Dean edits the **Semester** combobox or the **AY** box (`semester_ay`) and finishes
  editing, a confirmation appears: "Start a new semester?". After **Start new semester**:
  1. every live student monitoring sheet is saved into the Archive (nothing a student typed is lost),
     then the live sheets are cleared;
  2. instructor subject lists are cleared (instructors choose their subjects again);
  3. the new semester is stored and students and instructors see the New Semester popup once.
- This is the same code as the automatic new semester that starts when every student is approved
  (`csj_apply_semester_transition()` in `config.php`), so both behave identically.
- Cancel / Esc restores the old values and changes nothing. Choosing the semester that is already
  active does nothing. The AY must be two consecutive years, e.g. `2028-2029`.
- The Archive and all history are never deleted.

## Archive (dean-archive.php): how it works and what was fixed

- Every time the Dean approves a period (Prelims / Midterms / Finals) a snapshot of that student's
  sheet is saved in `dean_archived_periods` (one row per student + period + semester).
- When the LAST student's Finals is approved the semester changes automatically: the live student
  sheets are cleared and the Archive keeps all history in the database permanently.
- **View monitoring** opens the archived sheet in the SAME design as `student.php`: letterhead,
  subject pills, tall alternating rows, the Pending/Approved row, and the Student Name /
  Course & Year / Dean Approval footer, with Previous / Next (or the dots) to move between
  Prelims, Midterms and Finals.

Fixes in this build
1. Archive rows showed every period as missing and the viewer said "No archived snapshot for this
   period yet" even though the data was saved (an `isset()` on a null value). Fixed.
2. "Fully Completed Students" was always empty after a semester change (the live flag table is
   cleared at every transition). It is now built from the permanent archive, so it lists every
   completed student of every semester, with Student ID.
3. If the Dean cleared an approval in a NEW semester, the old semester's archived snapshot of
   that student/period was deleted too. It now only removes the current semester's snapshot.
4. A subject code could not be chosen again in Midterms or Finals if it was already used in
   Prelims ("The subject code is already selected"), which also blocked Submit. The no-duplicate
   rule now applies inside each period sheet only.

Note: a student who has not submitted anything yet is not waited for. If one student completes all
three periods before any other student has submitted, the semester changes at that moment.

## Prelims -> Midterms -> Finals approval sequence

**Student (`student.php`)**
- The student pages through Prelims / Midterms / Finals with **Previous / Next** (the three dots
  show where they are). There are no separate period buttons and no lock banner.
- Only **Prelims** is open for a new student. **Next** stays disabled (hover shows why) until the
  Dean approves the sheet before it, and the arrow keys cannot skip a locked sheet either.
- **Midterms** opens after the Dean approves the student's **Prelims**; **Finals** opens after the
  Dean approves the **Midterms**.
- The page checks the server every 5 seconds, so **Next** enables by itself shortly after the
  Dean clicks Approve. No re-login needed.

**Copy / paste rule (student.php)**
- Copy, cut and paste are blocked ONLY inside the "What I learned" cells (`.cell-text`) of every
  sheet: Ctrl+C / Ctrl+X / Ctrl+V (also Cmd, Ctrl+Insert, Shift+Insert), right-click menu,
  drag-and-drop text, and the phone "Paste" menu. A copy that would include a cell (for example
  Select-All then Ctrl+C) is blocked too. The honesty dialog appears on an attempt.
- Everything else, including the rest of the sheet (`.sheet-wrap`), the subject codes, the page
  text and the Profile fields, keeps normal copy and paste. Typing in the cells still works.

**Dean (`dean-dashboard.php`)**
- Open a student's chart, pick Prelims / Midterms / Finals and click **Approve**.
- Periods must be approved in order. The Midterms **Approve** button stays disabled until
  Prelims is approved, and Finals until Midterms is approved. An approval can only be cleared
  in reverse order (Finals, then Midterms, then Prelims).
- Once the Dean approves the **Finals**, a green **Complete** badge appears to the left of
  **View chart** in the student list (instantly, and it stays after a refresh). Clearing the
  Finals approval removes the badge.

**Security (server side)**
- The lock is enforced in `php/save.php`, not only in the browser. Whatever the browser sends
  for a locked period is ignored, and `deanApproved` is always read from the database, so a
  student cannot approve or unlock a period by editing the request.
- `php/dean_approve.php` rejects out-of-order approvals (HTTP 409).
- The shared rule is `csj_period_access()` in `config.php`.
- Existing data needs no migration: approvals already live in each student's chart JSON.

## Teacher sign-up: "Load Subjects" -> "Choose Subject(s) You Handle"

Flow on `index.php` -> **Sign Up** -> **Teacher**:

1. Fill in Full Name, Teacher ID, Department Handled, Email and Password.
2. Click **Load Subjects**. The dialog **Choose Subject(s) You Handle** opens
   (same look as the Instructor Dashboard's "Load Subject").
3. Tick the subject/section codes you teach (use the search box, e.g. `FM303` or `ENG`).
4. Click **Save Selections**. The dialog closes and the form shows
   "N subjects selected" with a chip for every chosen code.
   (Closing with the X discards ticks you did not save.)
5. Click **Create Account**. The chosen subjects are written to
   `instructor_subject_selections` for **First Semester, AY 2027-2028** and the
   teacher lands on the Instructor Dashboard with those subject cards already there.

Rules enforced by both the browser and `php/account.php`:
- A teacher must choose at least one subject before signing up.
- Only codes that exist in `php/subjects_catalog.php` are stored.
- "Department Handled" is saved to the instructor profile (`program` column).
- The semester label lives in ONE place: `CSJ_SIGNUP_SEMESTER` in `config.php`.

### What was wrong before
The page had a global `form{display:none}` style meant for the Login / Sign-up
forms. The dialog's own `<form class="dialog-form">` matched it too, so the dialog
opened but its content was invisible (just a dark backdrop). The global rule is now
scoped to `.panel > form` and the dialog no longer uses a `<form>` element at all.

## XAMPP + ngrok quick start

1. Copy the `monitoring` folder to `C:\xampp\htdocs\monitoring`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. phpMyAdmin -> Import -> choose `schema.sql` (creates DB `csj_self_monitoring`).
4. Local test: `http://localhost/monitoring/` (or `:8080` if Apache uses 8080).
5. Public link: `ngrok http 80` (or `ngrok http 8080`), then open
   `https://xxxx.ngrok-free.app/monitoring/` and use ONLY that address for sign-up,
   login and fingerprint. On the free plan click "Visit Site" on ngrok's warning page once.

## Fixes in this build

1. **Fingerprint login** – “This device biometric is not enabled for this account”
   - Credential ID is normalized (padding / base64url differences).
   - Public keys stored as base64url or raw base64 are converted to PEM correctly.
   - Lookup uses LEFT JOIN and a fallback scan so instructor credentials still work even if the profile row is incomplete.
   - If the stored key is empty, the system tries to recover it from the saved attestation object (students).

2. **Subject catalog (Instructor “Load Subject”)**
   - Replaced with the full CSJ list you provided (ACCTG201-1 … SPEC315-1).

3. **Period approval (Prelim / Midterm / Final)**
   - Instructor review dialog has **Prelims / Midterms / Finals** tabs.
   - Approving a subject applies only to the selected period.
   - Enrolled-student list shows per-period status chips.
   - Each student still has **one unique monitoring sheet per semester** (`UNIQUE (profile_key, semester)`).

4. **Unique InstructorView**
   - Each instructor has their own `instructor_key`, subject selections, and approvals. Unchanged other functions.

5. **Dean dashboard**
   - Dean accounts are separate from student and instructor accounts and do not have a public signup.
   - The Dean dashboard includes a student-entry view filterable by a teacher's selected subject; select a student profile to see that student's matching entries vertically, sort the profile list by student name or submission update time, and approve a subject for each monitoring period.
   - Student and teacher password recovery requests are queued for Dean review; after verifying the requester, a Dean can set a new password from the dashboard.
   - Teacher and Dean reviewers can approve or deny a subject for an individual monitoring period; either decision can be cleared back to Pending. Students see the current review status on their monitoring sheet.
   - The Dean sidebar includes an audit trail for account actions, monitoring-sheet submissions, accepted/denied review decisions, and password recovery actions. Its Action filter includes an Entries option to group submissions and review decisions. Submission events record a count only, never the reflection text.

## Deploy (XAMPP / Apache + MySQL)

1. Import `schema.sql` into MySQL (phpMyAdmin → Import). It is the ONLY SQL file and also creates the default Dean login.
2. Copy this folder into `htdocs` (or your virtual host root).
3. Edit `config.php` / `php/db.php` for your MySQL credentials if needed.
4. Use the **same hostname** for registration and login (e.g. always `localhost` or always your ngrok HTTPS URL).

## Biometric notes

- Platform authenticator (Windows Hello / Touch ID / Android fingerprint) only.
- Register from the student or instructor dashboard while logged in, then use the login page fingerprint button.
- If login still fails after this update, re-register the fingerprint once on the same URL you will use for login.

## Resume later (2026-10-09)

### Current state

- The app is being used locally at `http://localhost:8080/monitoring/`.
- The Dean area includes the student-entry review, per-period review decisions, password-recovery request queue, and audit trail.
- Audit events are written through `php/audit.php` and displayed at `dean-audit-trail.php`. The log avoids storing passwords, OTPs, and student reflection text.
- Monitoring sheets record submitted events, and per-subject/per-period review decisions now support Approved, Denied, or Pending. New accept/deny decisions are included in the audit trail.
- Review decisions are stored in the existing monitoring-chart JSON; no additional database migration is needed for denial support.
- PHP syntax checks, JavaScript syntax check, and editor diagnostics passed for the audit and review-decision changes. The live database behavior has not yet been integration-tested.

### Before testing the updated app

Import the single `schema.sql` in phpMyAdmin. It already contains every table
(including the former `sql/` folder's Dean, password-reset, audit-trail and
messages tables) and is safe to re-import on an existing database.

### Suggested smoke test

1. Sign in with a Dean account and open `http://localhost:8080/monitoring/dean-audit-trail.php`.
2. Check student entries, per-period Dean approval/denial controls, and the audit filters.
3. Exercise a student submission, instructor acceptance and denial, Dean acceptance and denial, and a Student/Teacher password-recovery request and review action.
4. Confirm submission, acceptance, denial, and recovery events appear in the audit trail; verify that a denied status remains after a student resubmits, and inspect the PHP/Apache error log if an operation fails.

The audit page shows only the latest 250 events; read-only page visits are not logged, and the audit table is an application history log rather than a tamper-proof record. Do not put real passwords or other secrets in this README.


## New semester (automatic)

When the Dean approves the **last** student's Finals (every student with a submitted sheet has
Prelims, Midterms and Finals approved), the system starts the next semester by itself:

* all student monitoring sheets (Prelims / Midterms / Finals) are cleared (history stays in the Archive),
* every instructor's subject list is cleared (they use **Load Subject** to pick subjects again),
* the Dean sees a centered **"New semester, new learnings."** popup,
* each instructor sees a centered **"Welcome back! We have officially transitioned to the <semester>."** popup,
* each student sees **"New semester, new learnings."**,
* every popup clears itself after `CSJ_WELCOME_POPUP_SECONDS` seconds (set in `config.php`, currently 5) and is shown only once per account per semester change.
* the popup shows a live counter ("Closes in 5 s ..."); Students and Teachers can also **right-click** (long-press on a phone) anywhere to close it at once. Esc closes it too.

Pages that are already open refresh themselves within a few seconds.

## XAMPP + ngrok quick start

1. Copy the `monitoring` folder to `C:\xampp\htdocs\` and start **Apache** and **MySQL** in XAMPP.
2. phpMyAdmin -> *Import* -> choose `schema.sql` (creates the `csj_self_monitoring` database and all tables).
   Re-importing on an existing install is safe.
3. Open `http://localhost/monitoring/` to confirm it works.
4. Run `ngrok http 80` and share the `https://xxxx.ngrok-free.app/monitoring/` address.
   All links in the app are relative, so it works on localhost and through ngrok without any change.
