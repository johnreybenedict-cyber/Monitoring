<?php
/**
 * CSJ Dean Dashboard – Archive
 * Monitoring sheets grouped by student + semester (Prelim+Midterm+Finals).
 * Auto-filter by Semester / AY. View sheet in student letterhead design.
 * Export SQL. Existing dean_approve.php archive logic is untouched.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/php/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['dean_authenticated']) || empty($_SESSION['dean_id'])) {
    header('Location: index.php');
    exit;
}
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function arch_h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$deanName = arch_h((string)($_SESSION['dean_name'] ?? 'Dean'));
$pageError = '';
$grouped = [];
$students = [];
$termFilter = trim((string)($_GET['term'] ?? ''));
$ayFilter   = trim((string)($_GET['ay'] ?? ''));
$allowedTerms = ['', 'First', 'Second'];
if (!in_array($termFilter, $allowedTerms, true)) $termFilter = '';
if ($ayFilter !== '' && preg_match('/(\d{4}\s*-\s*\d{4})/', $ayFilter, $m)) {
    $ayFilter = preg_replace('/\s+/', '', $m[1]);
} elseif ($ayFilter !== '' && !preg_match('/^\d{4}-\d{4}$/', $ayFilter)) {
    $ayFilter = '';
}

/* ------------------------------------------------------------------ */
/* SQL EXPORT — full database (all tables + data) via shared exporter */
/* ------------------------------------------------------------------ */
if (isset($_GET['export_sql']) && $_GET['export_sql'] === '1') {
    require __DIR__ . '/php/dean_export_database.php';
    exit;
}

/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* Load + group                                                       */
/* ------------------------------------------------------------------ */
try {
    $pdo = csj_db();
    if (function_exists('csj_ensure_archive_tables')) {
        csj_ensure_archive_tables($pdo);
    }

    $where = [];
    $params = [];
    if ($termFilter !== '' && $ayFilter !== '') {
        $where[] = 'semester LIKE ?';
        $params[] = $termFilter . ' Semester%AY%' . $ayFilter . '%';
    } elseif ($termFilter !== '') {
        $where[] = 'semester LIKE ?';
        $params[] = $termFilter . ' Semester%';
    } elseif ($ayFilter !== '') {
        $where[] = 'semester LIKE ?';
        $params[] = '%AY%' . $ayFilter . '%';
    }

    $sql = 'SELECT archive_id, profile_key, period_key, student_name, course_year,
                   semester, chart_period_json, archived_at, archived_by
            FROM dean_archived_periods';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY archived_at DESC, student_name ASC, period_key ASC LIMIT 2000';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rawPeriods = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $bucket = [];
    foreach ($rawPeriods as $row) {
        $pk  = (string)$row['profile_key'];
        $sem = (string)($row['semester'] ?? '');
        $key = $pk . '||' . $sem;
        if (!isset($bucket[$key])) {
            $bucket[$key] = [
                'profile_key'  => $pk,
                'student_name' => (string)($row['student_name'] ?? '—'),
                'course_year'  => (string)($row['course_year'] ?? ''),
                'semester'     => $sem,
                'archived_at'  => (string)($row['archived_at'] ?? ''),
                'archived_by'  => (string)($row['archived_by'] ?? ''),
                'periods'      => ['prelims' => null, 'midterms' => null, 'finals' => null],
            ];
        }
        $pKey = strtolower((string)$row['period_key']);
        // array_key_exists, NOT isset(): the three slots start as null, and isset() is always
        // false for null -- which silently dropped every snapshot ("No archived snapshot").
        if (array_key_exists($pKey, $bucket[$key]['periods'])) {
            $bucket[$key]['periods'][$pKey] = $row;
            if ($row['archived_at'] > $bucket[$key]['archived_at']) {
                $bucket[$key]['archived_at'] = (string)$row['archived_at'];
                $bucket[$key]['archived_by'] = (string)($row['archived_by'] ?? '');
            }
        }
    }
    $grouped = array_values($bucket);
    usort($grouped, function ($a, $b) {
        return strcmp($b['archived_at'], $a['archived_at']);
    });

    // Fully Completed Students = every student + semester whose Prelims, Midterms AND Finals
    // are all archived and Dean-approved. This is built from dean_archived_periods (permanent
    // history). dean_archived_students is only a LIVE flag used to hide finished students from
    // the Student Entries list, and it is cleared at every semester change, so it cannot be
    // used for history.
    $students = [];
    $sidStmt = $pdo->prepare('SELECT student_id FROM student_profiles WHERE profile_key = ? LIMIT 1');
    foreach ($grouped as $g) {
        $complete = true;
        foreach (['prelims', 'midterms', 'finals'] as $pkCheck) {
            $r = $g['periods'][$pkCheck] ?? null;
            $d = $r ? json_decode((string)($r['chart_period_json'] ?? ''), true) : null;
            if (!is_array($d) || empty($d['deanApproved'])) { $complete = false; break; }
        }
        if (!$complete) continue;
        $sidStmt->execute([$g['profile_key']]);
        $students[] = [
            'profile_key'  => $g['profile_key'],
            'student_name' => $g['student_name'],
            'course_year'  => $g['course_year'],
            'student_id'   => (string)($sidStmt->fetchColumn() ?: ''),
            'semester'     => $g['semester'],
            'archived_at'  => $g['archived_at'],
            'archived_by'  => $g['archived_by'],
        ];
    }

} catch (Throwable $e) {
    error_log('Dean archive page error: ' . $e->getMessage());
    $pageError = 'Archive data could not be loaded. The archive tables may not exist yet.';
}

// Prepare JSON payloads for JS (one object per grouped row)
$jsPayloads = [];
foreach ($grouped as $i => $row) {
    $periodsOut = [];
    foreach (['prelims', 'midterms', 'finals'] as $pk) {
        $block = null;
        $raw = (string)($row['periods'][$pk]['chart_period_json'] ?? '');
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                // Normal shape: { subjects, rows, ... }
                // Fallback if a full chart was stored by mistake
                if (!isset($decoded['subjects']) && isset($decoded['periods'][$pk]) && is_array($decoded['periods'][$pk])) {
                    $decoded = $decoded['periods'][$pk];
                }
                $block = $decoded;
            }
        } elseif (!empty($row['periods'][$pk])) {
            // Archive row exists but JSON empty — still open a blank chart grid
            $block = ['subjects' => [], 'rows' => []];
        }
        $periodsOut[$pk] = $block;
    }
    $jsPayloads[$i] = [
        'name'    => $row['student_name'],
        'course'  => $row['course_year'],
        'semester'=> $row['semester'],
        'periods' => $periodsOut,
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Archive – CSJ Dean Dashboard</title>
  <link rel="icon" href="assets/logos/csj-seal.jpg">
  <link rel="stylesheet" href="css/style.css">
  <style>
    .dean-layout{min-height:calc(100vh - 74px);display:grid;grid-template-columns:245px minmax(0,1fr)}
    .dean-sidebar{padding:24px 16px;background:var(--paper);border-right:1px solid var(--line)}
    .dean-sidebar-label{margin:0 12px 10px;color:var(--ink-soft);font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
    .dean-nav-link{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--radius-sm);background:var(--pine-100);color:var(--pine-900);font-size:13px;font-weight:700;text-decoration:none;margin-top:8px}
    .dean-nav-link:first-of-type{margin-top:0}
    .dean-nav-link.active{background:var(--pine-200,#d7e8dc)}
    .dean-content{min-width:0;padding:32px clamp(16px,4vw,48px)}
    .dean-heading{margin:0 0 6px;color:var(--pine-900);font-family:var(--font-display);font-size:26px}
    .dean-sub{margin:0 0 22px;color:var(--ink-soft);font-size:13.5px;line-height:1.5}

    .arch-toolbar{
      display:flex;flex-wrap:wrap;align-items:end;justify-content:space-between;gap:14px;
      margin-bottom:20px;padding:16px 18px;background:var(--paper);
      border:1px solid var(--line);border-radius:var(--radius-md);
    }
    .arch-filters{display:flex;flex-wrap:wrap;gap:12px;align-items:end}
    .arch-filters label{
      display:flex;flex-direction:column;gap:4px;font-size:11px;font-weight:700;
      color:var(--ink-soft);text-transform:uppercase;letter-spacing:.04em;
    }
    .arch-filters select,
    .arch-filters input[type="text"]{
      min-width:140px;padding:8px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);
      background:#fff;color:var(--ink);font-size:13px;
    }
    .arch-filters input[type="text"]{min-width:120px}

    .btn-export{
      display:inline-flex;align-items:center;gap:8px;padding:10px 16px;
      background:var(--pine-800);color:#fff;border:none;border-radius:var(--radius-sm);
      font-size:13px;font-weight:700;text-decoration:none;cursor:pointer;
      box-shadow:0 2px 0 var(--pine-900);
    }
    .btn-export:hover{background:var(--pine-700);color:#fff}

    .arch-section{margin-bottom:28px}
    .arch-section h2{
      margin:0 0 12px;font-family:var(--font-display);font-size:18px;color:var(--pine-900);
      display:flex;align-items:center;gap:8px;
    }
    .arch-count{
      display:inline-flex;align-items:center;justify-content:center;
      min-width:22px;height:22px;padding:0 6px;border-radius:999px;
      background:var(--pine-100);color:var(--pine-800);font-size:11px;font-weight:700;
    }

    .arch-table-wrap{
      overflow-x:auto;border:1px solid var(--line);border-radius:var(--radius-md);background:var(--paper);
    }
    table.arch-table{width:100%;border-collapse:collapse;font-size:13px}
    .arch-table th{
      text-align:left;padding:11px 14px;background:var(--pine-100);color:var(--pine-900);
      font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;
      border-bottom:1px solid var(--line);
    }
    .arch-table td{padding:11px 14px;border-bottom:1px solid var(--line-soft);vertical-align:middle}
    .arch-table tr:last-child td{border-bottom:0}
    .arch-table tbody tr.arch-row{cursor:pointer}
    .arch-table tbody tr.arch-row:hover td{background:#f0f7f2}

    .period-chips{display:flex;flex-wrap:wrap;gap:6px}
    .period-chip{
      display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:999px;
      font-size:11px;font-weight:700;border:1px solid transparent;
    }
    .period-chip.prelims.has{background:#e8f0fe;color:#1a56db;border-color:#bfdbfe}
    .period-chip.midterms.has{background:#fef3c7;color:#92400e;border-color:#fde68a}
    .period-chip.finals.has{background:#d1fae5;color:#065f46;border-color:#a7f3d0}
    .period-chip.missing{background:#f3f4f6;color:#9ca3af;border-color:#e5e7eb;opacity:.7}

    .btn-view-mon{
      display:inline-flex;align-items:center;gap:6px;padding:6px 12px;
      background:var(--pine-100);color:var(--pine-900);border:1px solid var(--pine-700);
      border-radius:var(--radius-sm);font-size:12px;font-weight:700;cursor:pointer;
    }
    .btn-view-mon:hover{background:var(--pine-800);color:#fff}

    .muted{color:var(--ink-soft);font-size:12px}
    .empty-state,.error-state{padding:18px;border-radius:var(--radius-md);font-size:13.5px;line-height:1.6}
    .empty-state{background:var(--parchment);border:1px solid var(--line-soft);color:var(--ink-soft)}
    .error-state{background:#fff0ec;border:1px solid #e6b4a7;color:#7d291b}

    /* ---- Chart viewer modal (student letterhead style) ---- */
    .arch-modal-backdrop{
      display:none;position:fixed;inset:0;background:rgba(14,61,36,.5);z-index:1000;
      align-items:flex-start;justify-content:center;padding:24px 16px;overflow-y:auto;
    }
    .arch-modal-backdrop.is-open{display:flex}
    .arch-chart-modal{
      background:var(--paper);border-radius:var(--radius-lg);width:100%;max-width:1100px;
      box-shadow:var(--shadow-card);border:1px solid var(--line-soft);
      position:relative;margin:auto;
    }
    .arch-chart-close{
      position:absolute;top:12px;right:14px;z-index:5;
      background:var(--paper);border:1px solid var(--line);border-radius:999px;
      width:36px;height:36px;font-size:20px;line-height:1;cursor:pointer;color:var(--ink-soft);
    }
    .arch-chart-close:hover{background:var(--pine-100);color:var(--pine-900)}
    .arch-chart-inner{padding:14px;position:relative}
    .arch-chart-inner .sheet{margin:0}
    .arch-chart-empty{padding:28px;text-align:center;color:var(--ink-soft);font-size:13.5px;position:relative;z-index:1}

    /* ---- The archived sheet re-uses the STUDENT sheet classes (.sheet, .letterhead, .chart-table,
       .entry-row, .cell-text, .approve-row ...) from css/style.css, so it is the same design as
       student.php. The rules below are the student.php inline rules (toolbar + bottom fields),
       scoped to this modal. ---- */
    #archModal .period-toolbar{position:relative;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 2px 14px}
    #archModal .btn-outline{background:transparent;color:var(--pine-800);border:1px solid var(--pine-700)}
    #archModal .btn-outline:hover{background:var(--pine-100)}
    #archModal .btn-outline:disabled{opacity:.4;cursor:not-allowed;background:transparent;transform:none}
    #archModal .period-status{display:flex;flex-direction:column;align-items:center;gap:6px}
    #archModal .period-label{font-family:var(--font-display);font-weight:700;font-size:14px;letter-spacing:.02em;color:var(--pine-800);background:var(--pine-100);border:1px solid var(--line);border-radius:999px;padding:6px 20px;min-width:120px;text-align:center}
    #archModal .period-steps{display:flex;gap:6px}
    #archModal .period-step{width:8px;height:8px;border-radius:50%;background:var(--line);transition:background .15s ease,transform .15s ease;cursor:pointer}
    #archModal .period-step.is-current{background:var(--gold-500);transform:scale(1.2)}
    #archModal .period-step.is-locked{background:transparent;border:1px solid #b9c2bb}
    #archModal .student-bottom-fields{display:flex;gap:28px;align-items:flex-end;margin-top:18px;padding-top:10px;border-top:1px solid #e9e3d0;position:relative;z-index:1}
    #archModal .bottom-field{min-width:0;font-size:11px;color:#1d271f}
    #archModal .bottom-field-name,#archModal .bottom-field-course{flex:1 1 0}
    #archModal .bottom-dean-wrap{flex:0 0 150px;width:150px;text-align:right}
    #archModal .bottom-line{display:block;width:100%;box-sizing:border-box;border:0;border-bottom:1px solid #5b6b5e;padding:4px 0 2px;min-height:1.35em;line-height:1.3;font:inherit;color:inherit}
    #archModal .bottom-label{display:block;margin-top:4px;font-size:10px;color:#5b6b5e}
    #archModal .bottom-dean-wrap .bottom-line,#archModal .bottom-dean-wrap .bottom-label{text-align:center}
    #archModal .dean-signature{font-family:var(--font-display);font-size:12.5px;font-weight:600;color:var(--pine-900);letter-spacing:.01em;white-space:nowrap}
    #archModal .dean-signature.is-approved strong{color:var(--pine-900);font-weight:700}
    #archModal .dear-dean-note{display:inline;font-weight:700;color:var(--pine-900);margin-left:4px}
    /* read-only look-alikes of the student's <select> and editable cell */
    #archModal div.subject-code-input{height:28px;box-sizing:border-box;display:flex;align-items:center;justify-content:center;border-radius:8px;min-width:0;overflow:hidden;white-space:nowrap}
    #archModal .cell-text{cursor:default}

    @media(max-width:760px){
      .dean-layout{grid-template-columns:1fr}
      .dean-sidebar{padding:12px 16px;border-right:0;border-bottom:1px solid var(--line)}
      .dean-sidebar-label{display:none}
      .dean-content{padding:22px 16px}
      .arch-toolbar{flex-direction:column;align-items:stretch}
      .btn-export{justify-content:center}
      #archModal .period-toolbar{flex-wrap:wrap}
      #archModal .student-bottom-fields{flex-wrap:wrap}
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="brand-logo">
      <div class="brand-text">
        <span class="brand-title">CSJ Dean Dashboard</span>
        <span class="brand-sub">Higher Education Department &middot; Dean View</span>
      </div>
    </div>
    <div class="topbar-actions">
      <a class="btn btn-ghost" href="logout.php">Logout</a>
    </div>
  </header>

  <div class="dean-layout">
        <aside class="dean-sidebar" aria-label="Dean navigation">
      <p class="dean-sidebar-label">Menu</p>
      <a class="dean-nav-link" href="dean-dashboard.php"><span aria-hidden="true">&#9638;</span> Student Entries</a>
      <a class="dean-nav-link" href="dean-student-profiles.php"><span aria-hidden="true">&#128100;</span> Student Profile</a>
      <a class="dean-nav-link" href="dean-password-requests.php"><span aria-hidden="true">&#128274;</span> Password Requests</a>
      <a class="dean-nav-link" href="dean-audit-trail.php"><span aria-hidden="true">&#9776;</span> Audit Trail</a>
      <a class="dean-nav-link" href="dean-feedback.php"><span aria-hidden="true">&#9998;</span> Feedback</a>
      <a class="dean-nav-link active" href="dean-archive.php" aria-current="page"><span aria-hidden="true">&#128230;</span> Archive</a>
    </aside>

    <main class="dean-content">
      <h1 class="dean-heading">Monitoring Archive</h1>
      <p class="dean-sub">
        Archived monitoring sheets grouped by student and semester
        (Prelims, Midterms &amp; Finals together). Click a student row or
        <strong>View monitoring</strong> to open the chart. Filters update automatically.
        Use <strong>Export SQL</strong> for a full database backup (all tables: accounts, monitoring, archive, feedback, audit trail, and more).
      </p>

      <?php if ($pageError !== ''): ?>
        <div class="error-state" role="alert"><?= arch_h($pageError) ?></div>
      <?php endif; ?>

      <div class="arch-toolbar">
        <form method="get" class="arch-filters" id="archFilterForm">
          <label>Semester
            <select name="term" id="termSelect">
              <option value="">All terms</option>
              <option value="First"  <?= $termFilter === 'First'  ? 'selected' : '' ?>>First Semester</option>
              <option value="Second" <?= $termFilter === 'Second' ? 'selected' : '' ?>>Second Semester</option>
            </select>
          </label>
          <label>AY
            <input type="text" name="ay" id="ayInput"
                   value="<?= arch_h($ayFilter) ?>"
                   placeholder="e.g. 2026-2027"
                   pattern="\d{4}-\d{4}"
                   title="Format: 2026-2027">
          </label>
        </form>

        <a class="btn-export" href="php/dean_export_database.php"
           title="Download a complete SQL backup of the entire database (all tables and data)">
          <span aria-hidden="true">&#128190;</span> Export SQL
        </a>
      </div>

      <section class="arch-section" aria-label="Archived monitoring sheets">
        <h2>
          Archived Monitoring Sheets
          <span class="arch-count"><?= count($grouped) ?></span>
        </h2>

        <?php if (empty($grouped)): ?>
          <div class="empty-state">
            No archived monitoring sheets match the current filters.
            Sheets appear here automatically after the Dean approves a period
            or when a semester transitions.
          </div>
        <?php else: ?>
          <div class="arch-table-wrap">
            <table class="arch-table">
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Course / Year</th>
                  <th>Monitoring Sheets</th>
                  <th>Semester</th>
                  <th>Archived</th>
                  <th>By</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($grouped as $i => $row):
                  $periodLabels = ['prelims' => 'Prelims', 'midterms' => 'Midterms', 'finals' => 'Finals'];
                ?>
                  <tr class="arch-row" data-idx="<?= (int)$i ?>" title="Click to view monitoring chart">
                    <td>
                      <strong><?= arch_h($row['student_name']) ?></strong>
                      <div class="muted"><?= arch_h(substr($row['profile_key'], 0, 8)) ?>…</div>
                    </td>
                    <td><?= arch_h($row['course_year'] !== '' ? $row['course_year'] : '—') ?></td>
                    <td>
                      <div class="period-chips">
                        <?php foreach ($periodLabels as $pkey => $plabel):
                          $has = !empty($row['periods'][$pkey]);
                        ?>
                          <span class="period-chip <?= $pkey ?> <?= $has ? 'has' : 'missing' ?>">
                            <?= $has ? '✓ ' : '' ?><?= arch_h($plabel) ?>
                          </span>
                        <?php endforeach; ?>
                      </div>
                    </td>
                    <td><?= arch_h($row['semester'] !== '' ? $row['semester'] : '—') ?></td>
                    <td class="muted"><?= arch_h($row['archived_at']) ?></td>
                    <td class="muted"><?= arch_h($row['archived_by'] !== '' ? $row['archived_by'] : '—') ?></td>
                    <td>
                      <button type="button" class="btn-view-mon" data-idx="<?= (int)$i ?>">
                        View monitoring
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </section>

      <section class="arch-section" aria-label="Fully archived students">
        <h2>
          Fully Completed Students
          <span class="arch-count"><?= count($students) ?></span>
        </h2>
        <p class="muted" style="margin:-6px 0 12px;">
          Students whose Prelims + Midterms + Finals were all approved
          (hidden from the live Student Entries list for the current semester).
        </p>
        <?php if (empty($students)): ?>
          <div class="empty-state">No fully completed students in the archive yet.</div>
        <?php else: ?>
          <div class="arch-table-wrap">
            <table class="arch-table">
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Student ID</th>
                  <th>Course / Year</th>
                  <th>Semester</th>
                  <th>Archived</th>
                  <th>By</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($students as $row): ?>
                  <tr>
                    <td><strong><?= arch_h((string)($row['student_name'] ?? '—')) ?></strong></td>
                    <td><?= arch_h((string)($row['student_id'] ?: '—')) ?></td>
                    <td><?= arch_h((string)($row['course_year'] ?: '—')) ?></td>
                    <td><?= arch_h((string)($row['semester'] ?: '—')) ?></td>
                    <td class="muted"><?= arch_h((string)($row['archived_at'] ?? '')) ?></td>
                    <td class="muted"><?= arch_h((string)($row['archived_by'] ?: '—')) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </section>
    </main>
  </div>

  <!-- Student-style monitoring chart modal -->
  <div class="arch-modal-backdrop" id="archModal" role="dialog" aria-modal="true" aria-labelledby="archChartTitle">
    <div class="arch-chart-modal">
      <button type="button" class="arch-chart-close" id="archModalClose" aria-label="Close">&times;</button>
      <div class="arch-chart-inner">
        <section class="sheet" id="archSheet">
          <div class="letterhead">
            <img src="assets/logos/csj-seal.jpg" alt="Colegio de San Jose seal" class="letterhead-logo logo-left">
            <div class="letterhead-text">
              <h1>COLEGIO DE SAN JOSE, JARO, ILOILO CITY, INC.</h1>
              <p class="address">E. Lopez St., Brgy. Our Lady of Fatima, Jaro, Iloilo City</p>
              <h2>HIGHER EDUCATION DEPARTMENT</h2>
              <h3 id="archChartTitle">SELF-REVIEW MONITORING CHART</h3>
              <p class="semester" id="archChartSemester"></p>
            </div>
            <img src="assets/logos/dc-slmes-logo.png" alt="DC-SLMES logo" class="letterhead-logo logo-right" onerror="this.style.display='none'">
          </div>

          <p class="dear-student">
            Dear Student, fill out each box below with what you learned or accomplished for every
            review event of the corresponding subject. This chart is meant to help you see your
            progress and manage your time before each exam period.
            <strong class="dear-dean-note">— The Dean</strong>
          </p>

          <div class="period-toolbar">
            <button id="archPrev" class="btn btn-outline" type="button">
              <svg viewBox="0 0 24 24" class="icon" width="15" height="15"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
              Previous
            </button>
            <div class="period-status">
              <span id="archPeriodLabel" class="period-label">Prelims</span>
              <div class="period-steps" id="archSteps">
                <span class="period-step" data-step="prelims" title="Prelims"></span>
                <span class="period-step" data-step="midterms" title="Midterms"></span>
                <span class="period-step" data-step="finals" title="Finals"></span>
              </div>
            </div>
            <button id="archNext" class="btn btn-outline" type="button">
              Next
              <svg viewBox="0 0 24 24" class="icon" width="15" height="15"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
          </div>

          <div class="table-scroll" id="archTableScroll">
            <table class="chart-table" id="archChartTable">
              <colgroup id="archChartCols"></colgroup>
              <thead><tr class="head-row" id="archChartHead"></tr></thead>
              <tbody id="archChartBody"></tbody>
              <tfoot><tr class="approve-row" id="archChartFoot"></tr></tfoot>
            </table>
          </div>
          <div class="arch-chart-empty" id="archChartEmpty" hidden>No data for this period.</div>

          <div class="student-bottom-fields">
            <div class="bottom-field bottom-field-name">
              <div id="archStudentName" class="bottom-line">—</div>
              <span class="bottom-label">Student Name</span>
            </div>
            <div class="bottom-field bottom-field-course">
              <div id="archStudentCourse" class="bottom-line">—</div>
              <span class="bottom-label">Course &amp; Year</span>
            </div>
            <div class="bottom-field bottom-dean-wrap">
              <div id="archDeanSig" class="bottom-line dean-signature">&nbsp;</div>
              <span class="bottom-label">Dean Approval</span>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>

  <script>
  (function () {
    /* ---- Auto-filter (no Apply / Clear buttons) ---- */
    const form = document.getElementById('archFilterForm');
    const termSelect = document.getElementById('termSelect');
    const ayInput = document.getElementById('ayInput');
    let ayTimer = null;

    termSelect.addEventListener('change', function () { form.submit(); });
    ayInput.addEventListener('change', function () { form.submit(); });
    ayInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); form.submit(); }
    });
    // Debounced live filter while typing AY
    ayInput.addEventListener('input', function () {
      clearTimeout(ayTimer);
      ayTimer = setTimeout(function () {
        // Only submit if empty or valid AY pattern
        const v = ayInput.value.trim();
        if (v === '' || /^\d{4}-\d{4}$/.test(v) || /AY\s*\d{4}-\d{4}/i.test(v)) {
          form.submit();
        }
      }, 700);
    });

    /* ---- Chart viewer ---- */
    const PAYLOADS = <?= json_encode($jsPayloads, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const PERIOD_LABELS = { prelims: 'PRELIMS', midterms: 'MIDTERMS', finals: 'FINALS' };
    const PERIOD_ORDER = ['prelims', 'midterms', 'finals'];

    const modal = document.getElementById('archModal');
    const closeBtn = document.getElementById('archModalClose');
    const titleEl = document.getElementById('archChartTitle');
    const semEl = document.getElementById('archChartSemester');
    const nameEl = document.getElementById('archStudentName');
    const courseEl = document.getElementById('archStudentCourse');
    const deanSigEl = document.getElementById('archDeanSig');
    const colsEl = document.getElementById('archChartCols');
    const headEl = document.getElementById('archChartHead');
    const bodyEl = document.getElementById('archChartBody');
    const footEl = document.getElementById('archChartFoot');
    const emptyEl = document.getElementById('archChartEmpty');
    const scrollEl = document.getElementById('archTableScroll');
    const prevBtn = document.getElementById('archPrev');
    const nextBtn = document.getElementById('archNext');
    const periodLabelEl = document.getElementById('archPeriodLabel');
    const stepEls = document.querySelectorAll('#archSteps .period-step');
    const PERIOD_NAMES = { prelims: 'Prelims', midterms: 'Midterms', finals: 'Finals' };
    const SHEET_ROWS = 6;   // same number of review events the student sheet shows

    let currentData = null;
    let currentPeriod = 'prelims';

    function esc(s) {
      return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function cellValue(r, s, i) {
      // Official chart shape: { event, entries: { "1": "...", "2": "..." } }
      const sid = s && s.id != null ? String(s.id) : String(i + 1);
      if (!r || typeof r !== 'object') return '';
      if (r.entries && typeof r.entries === 'object') {
        let v = r.entries[sid];
        if (v == null) v = r.entries[i + 1];
        if (v == null) v = r.entries[String(i)];
        if (typeof v === 'object' && v !== null) v = v.text || v.value || v.content || '';
        return v == null ? '' : String(v);
      }
      if (Array.isArray(r)) return r[i] != null ? String(r[i]) : '';
      let v = r[sid];
      if (v == null) v = r['subject' + (i + 1)];
      if (v == null) v = r['s' + (i + 1)];
      if (v == null) v = r[i];
      if (typeof v === 'object' && v !== null) v = v.text || v.value || v.content || '';
      return v == null ? '' : String(v);
    }

    function defaultSubjects() {
      const out = [];
      for (let i = 1; i <= 9; i++) out.push({ id: i, code: '', instructor: '', approved: false });
      return out;
    }

    // Same little status box the student sheet shows under every subject.
    function approveCellHtml(s) {
      const status = (s && ['approved', 'denied', 'pending'].indexOf(s.reviewStatus) !== -1)
        ? s.reviewStatus : ((s && s.approved) ? 'approved' : 'pending');
      const reviewer = (s && (s.reviewedBy || s.instructor)) ? String(s.reviewedBy || s.instructor) : '';
      let icon;
      if (status === 'approved') {
        icon = '<circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.12"/><path d="M7 12.5l3 3 7-7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>';
      } else if (status === 'denied') {
        icon = '<circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.12"/><path d="M8 8l8 8m0-8l-8 8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>';
      } else {
        icon = '<circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-dasharray="3 3"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>';
      }
      const word = status.charAt(0).toUpperCase() + status.slice(1);
      return '<div class="approve-box is-' + status + '"><svg viewBox="0 0 24 24" class="approve-icon">' + icon + '</svg>'
        + '<span class="approve-word">' + esc(word) + '</span></div>'
        + '<div class="instructor-name">' + esc(status === 'pending' || reviewer === '' ? '—' : reviewer) + '</div>';
    }

    function renderPeriod(periodKey) {
      currentPeriod = periodKey;
      const idx = PERIOD_ORDER.indexOf(periodKey);
      prevBtn.disabled = idx <= 0;
      nextBtn.disabled = idx >= PERIOD_ORDER.length - 1;
      periodLabelEl.textContent = PERIOD_NAMES[periodKey] || periodKey;
      stepEls.forEach(function (st) {
        const k = st.getAttribute('data-step');
        st.classList.toggle('is-current', k === periodKey);
        st.classList.toggle('is-locked', !(currentData && currentData.periods && currentData.periods[k]));
      });

      semEl.textContent = currentData.semester || '';
      nameEl.textContent = currentData.name || '—';
      courseEl.textContent = currentData.course || '—';

      let block = (currentData.periods && currentData.periods[periodKey]) || null;
      colsEl.innerHTML = '';
      headEl.innerHTML = '';
      bodyEl.innerHTML = '';
      footEl.innerHTML = '';

      // Some older archive rows may store the whole chart under .periods
      if (block && !block.subjects && block.periods && block.periods[periodKey]) {
        block = block.periods[periodKey];
      }

      titleEl.textContent = (block && block.chartTitle)
        ? String(block.chartTitle)
        : 'SELF-REVIEW MONITORING CHART FOR THE ' + (PERIOD_LABELS[periodKey] || periodKey.toUpperCase());
      deanSigEl.classList.toggle('is-approved', !!(block && block.deanApproved));
      deanSigEl.innerHTML = (block && block.deanApproved) ? '<strong>Approved</strong>' : '&nbsp;';

      if (!block) {
        emptyEl.hidden = false;
        emptyEl.textContent = 'No archived snapshot for this period yet.';
        scrollEl.style.display = 'none';
        return;
      }

      let subjects = Array.isArray(block.subjects) ? block.subjects.slice() : [];
      let rows = Array.isArray(block.rows) ? block.rows.slice() : [];
      if (!subjects.length) subjects = defaultSubjects();   // always a 9-column chart

      emptyEl.hidden = true;
      scrollEl.style.display = '';

      subjects.forEach(function (s, i) {
        const sid = s && s.id != null ? s.id : (i + 1);
        const code = (s && (s.code || s.label || s.name)) ? String(s.code || s.label || s.name).trim() : '';
        const col = document.createElement('col');
        col.className = 'col-subject';
        colsEl.appendChild(col);
        const th = document.createElement('th');
        th.className = 'subject-head';
        th.innerHTML = '<span class="subject-label">Subject ' + esc(sid) + '</span>'
          + '<div class="subject-code-input">' + (code ? esc(code) : '&nbsp;') + '</div>';
        headEl.appendChild(th);

        const fth = document.createElement('td');
        fth.className = 'approve-cell';
        fth.innerHTML = approveCellHtml(s);
        footEl.appendChild(fth);
      });

      // Same number of review-event rows as the student's sheet (blank rows stay visible).
      for (let e = rows.length; e < SHEET_ROWS; e++) rows.push({ event: e + 1, entries: {} });

      rows.forEach(function (r) {
        const tr = document.createElement('tr');
        tr.className = 'entry-row';
        subjects.forEach(function (s, i) {
          const td = document.createElement('td');
          td.className = 'entry-cell';
          const inner = document.createElement('div');
          inner.className = 'cell-inner';
          const txt = document.createElement('div');
          txt.className = 'cell-text';
          txt.textContent = cellValue(r, s, i);
          inner.appendChild(txt);
          td.appendChild(inner);
          tr.appendChild(td);
        });
        bodyEl.appendChild(tr);
      });
    }

    function openViewer(idx, preferredPeriod) {
      currentData = PAYLOADS[idx];
      if (!currentData) return;
      // Pick first available period if preferred missing
      let start = preferredPeriod || 'prelims';
      if (!currentData.periods[start]) {
        start = PERIOD_ORDER.find(function (p) { return currentData.periods[p]; }) || 'prelims';
      }
      renderPeriod(start);
      modal.classList.add('is-open');
    }

    function hide() { modal.classList.remove('is-open'); }

    // Row click
    document.querySelectorAll('tr.arch-row').forEach(function (tr) {
      tr.addEventListener('click', function (e) {
        if (e.target.closest('.btn-view-mon')) return; // button handles itself
        openViewer(parseInt(tr.getAttribute('data-idx'), 10));
      });
    });
    // View monitoring buttons
    document.querySelectorAll('.btn-view-mon').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        openViewer(parseInt(btn.getAttribute('data-idx'), 10));
      });
    });
    // Previous / Next / dots (same navigation as the student sheet)
    function stepArch(delta) {
      if (!currentData) return;
      const i = PERIOD_ORDER.indexOf(currentPeriod) + delta;
      if (i < 0 || i >= PERIOD_ORDER.length) return;
      renderPeriod(PERIOD_ORDER[i]);
    }
    prevBtn.addEventListener('click', function () { stepArch(-1); });
    nextBtn.addEventListener('click', function () { stepArch(1); });
    stepEls.forEach(function (st) {
      st.addEventListener('click', function () {
        if (currentData) renderPeriod(st.getAttribute('data-step'));
      });
    });

    closeBtn.addEventListener('click', hide);
    modal.addEventListener('click', function (e) { if (e.target === modal) hide(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') hide(); });
  })();
  </script>
</body>
</html>
