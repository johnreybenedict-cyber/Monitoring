<?php
// Sign-up lives on index.php — keep this file only as a safe redirect.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Location: index.php#signup');
exit;
